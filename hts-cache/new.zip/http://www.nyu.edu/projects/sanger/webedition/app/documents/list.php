 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
        "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
<head>
	<title>The Public Writings of Margaret Sanger: Web Edition</title> 
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<link href="../documents/styles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../documents/global.js"></script> 
</head>
<body onload="MM_preloadImages('../images/header_r2_c1_f2.gif','../images/header_r2_c2_f2.gif','../images/header_r2_c3_f2.gif','../images/header_r2_c4_f2.gif','../images/header_r2_c5_f2.gif');">
<div id="container" style="width: 626px; margin: 0px auto;"> 
<p style="margin-top: 0px; margin-bottom: 0px;">
	<img id="header_r1_c1" src="../images/header_r1_c1.gif" width="625" height="95" alt="" /><img src="../images/spacer.gif" width="1" height="95" alt="" /> 
</p>
<p style="margin-top: 0px; /*\*/margin-top: -3px;/**/">
	<a href="http://www.nyu.edu/projects/sanger/project/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c1','','../images/header_r2_c1_f2.gif',1);"><img id="header_r2_c1" src="../images/header_r2_c1.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/documents/electroniced.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c2','','../images/header_r2_c2_f2.gif',1);"><img id="header_r2_c2" src="../images/header_r2_c2.gif" width="104" height="20" alt="" /></a><a href="search.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c3','','../images/header_r2_c3_f2.gif',1);"><img id="header_r2_c3" src="../images/header_r2_c3.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c4','','../images/header_r2_c4_f2.gif',1);"><img id="header_r2_c4" src="../images/header_r2_c4.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/contactus" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c5','','../images/header_r2_c5_f2.gif',1);"><img id="header_r2_c5" src="../images/header_r2_c5.gif" width="104" height="20" alt="" /></a><img id="header_r2_c6" src="../images/header_r2_c6.jpg" width="105" height="20" alt="" /><img src="../images/spacer.gif" width="1" height="20" alt="" /> 
</p>
<div class="outBox">
	<div class="inBox">
<h2>The database currently contains the following titles:</h2>
<div>1 <a href="?start=40&num_pages=12">2</a> <a href="?start=80&num_pages=12">3</a> <a href="?start=120&num_pages=12">4</a> <a href="?start=160&num_pages=12">5</a> <a href="?start=200&num_pages=12">6</a> <a href="?start=240&num_pages=12">7</a> <a href="?start=280&num_pages=12">8</a> <a href="?start=320&num_pages=12">9</a> <a href="?start=360&num_pages=12">10</a> <a href="?start=400&num_pages=12">11</a> <a href="?start=440&num_pages=12">12</a> <a href="?start=40&num_pages=12">Next</a></div><OL><LI VALUE="1"><b><a href='show.php?sangerDoc=420010.xml'>"" Advice</a></b></LI>
<span class="resultSubLine">1914-05-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="2"><b><a href='show.php?sangerDoc=306320.xml'>"The Woman Rebel" and The Fight for Birth Control</a></b></LI>
<span class="resultSubLine">1916-04-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="3"><b><a href='show.php?sangerDoc=320118.xml'>A "Birth Control" Lecture Tour</a></b></LI>
<span class="resultSubLine">1916-08-09 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="4"><b><a href='show.php?sangerDoc=306638.xml'>A Better Race Through Birth Control</a></b></LI>
<span class="resultSubLine">1923-11-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="5"><b><a href='show.php?sangerDoc=223299.xml'>A Law Breaking Policeman</a></b></LI>
<span class="resultSubLine">1919-11-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="6"><b><a href='show.php?sangerDoc=420035.xml'>A Little Lesson</a></b></LI>
<span class="resultSubLine">1914-09-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="7"><b><a href='show.php?sangerDoc=302957.xml'>A Message to Mothers</a></b></LI>
<span class="resultSubLine">1916-04-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="8"><b><a href='show.php?sangerDoc=103187.xml'>A Message to the Women of China</a></b></LI>
<span class="resultSubLine">1931-00-00 &nbsp;(Typed statement)</span>
<br />&nbsp;
<LI VALUE="9"><b><a href='show.php?sangerDoc=238045.xml'>A News Letter from Margaret Sanger</a></b></LI>
<span class="resultSubLine">1932-04-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="10"><b><a href='show.php?sangerDoc=226268.xml'>A Parents' Problem or Woman's?</a></b></LI>
<span class="resultSubLine">1919-03-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="11"><b><a href='show.php?sangerDoc=143721.xml'>A Program of Contraceptive Research</a></b></LI>
<span class="resultSubLine">1928-06-05 &nbsp;(Typed draft document)</span>
<br />&nbsp;
<LI VALUE="12"><b><a href='show.php?sangerDoc=225696.xml'>A Public Nuisance</a></b></LI>
<span class="resultSubLine">1931-10-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="13"><b><a href='show.php?sangerDoc=420021.xml'>A QUESTION</a></b></LI>
<span class="resultSubLine">1914-08-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="14"><b><a href='show.php?sangerDoc=320519.xml'>A Question of Privilege</a></b></LI>
<span class="resultSubLine">1949-10-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="15"><b><a href='show.php?sangerDoc=206332.xml'>A Statement of Facts--An Obligation Fulfilled</a></b></LI>
<span class="resultSubLine">1918-08-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="16"><b><a href='show.php?sangerDoc=106580.xml'>A Statement of Support for Emma Goldman</a></b></LI>
<span class="resultSubLine">1916-03-01 &nbsp;(Typed speech)</span>
<br />&nbsp;
<LI VALUE="17"><b><a href='show.php?sangerDoc=143448.xml'>A Victory, A New Year and A New Day</a></b></LI>
<span class="resultSubLine">1919-02-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="18"><b><a href='show.php?sangerDoc=420006.xml'>Abortion in the United States</a></b></LI>
<span class="resultSubLine">1914-05-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="19"><b><a href='show.php?sangerDoc=128195.xml'>Acceptance of IPPF Presidency                 Speech</a></b></LI>
<span class="resultSubLine">1953-08-19 &nbsp;(Autograph draft speech)</span>
<br />&nbsp;
<LI VALUE="20"><b><a href='show.php?sangerDoc=420076.xml'>Address at the Pioneer's Dinner</a></b></LI>
<span class="resultSubLine">1925-03-26 &nbsp;(Typed speech)</span>
<br />&nbsp;
<LI VALUE="21"><b><a href='show.php?sangerDoc=101861.xml'>Address to Pennsylvania Birth Control      Leagues</a></b></LI>
<span class="resultSubLine">1929-02-27 &nbsp;(Typed speech)</span>
<br />&nbsp;
<LI VALUE="22"><b><a href='show.php?sangerDoc=101800.xml'>Address to the Japanese People</a></b></LI>
<span class="resultSubLine">1952-10-00 &nbsp;(Published speech)</span>
<br />&nbsp;
<LI VALUE="23"><b><a href='show.php?sangerDoc=225142.xml'>All Together--Now!</a></b></LI>
<span class="resultSubLine">1918-10-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="24"><b><a href='show.php?sangerDoc=101807.xml'>America Needs a Code for Babies</a></b></LI>
<span class="resultSubLine">1934-03-27 &nbsp;(Typed draft article)</span>
<br />&nbsp;
<LI VALUE="25"><b><a href='show.php?sangerDoc=101793.xml'>American Women's Association Testimonial Dinner Address</a></b></LI>
<span class="resultSubLine">1932-04-20 &nbsp;(Typed speech)</span>
<br />&nbsp;
<LI VALUE="26"><b><a href='show.php?sangerDoc=101827.xml'>Americans are "Headline Thinkers</a></b></LI>
<span class="resultSubLine">1926-01-03 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="27"><b><a href='show.php?sangerDoc=420052.xml'>Amusement</a></b></LI>
<span class="resultSubLine">1914-04-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="28"><b><a href='show.php?sangerDoc=236413.xml'>An Authority on Family Life Says: Save War Marriages</a></b></LI>
<span class="resultSubLine">1945-04-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="29"><b><a href='show.php?sangerDoc=128064.xml'>An Englishmans Opinion of America</a></b></LI>
<span class="resultSubLine">1915-00-00 &nbsp;(Autograph draft article)</span>
<br />&nbsp;
<LI VALUE="30"><b><a href='show.php?sangerDoc=301393.xml'>An Evening With George De Forest Brush</a></b></LI>
<span class="resultSubLine">1912-08-04 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="31"><b><a href='show.php?sangerDoc=420031.xml'>An Important Book</a></b></LI>
<span class="resultSubLine">1914-07-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="32"><b><a href='show.php?sangerDoc=239056.xml'>An Open Letter To Alfred E. Smith</a></b></LI>
<span class="resultSubLine">1918-11-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="33"><b><a href='show.php?sangerDoc=143710.xml'>An Open Letter to Cardinal Patrick J.                     Hayes</a></b></LI>
<span class="resultSubLine">1928-05-28 &nbsp;(Typed draft article)</span>
<br />&nbsp;
<LI VALUE="34"><b><a href='show.php?sangerDoc=420024.xml'>Another Woman</a></b></LI>
<span class="resultSubLine">1914-08-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="35"><b><a href='show.php?sangerDoc=225503.xml'>Are Birth Control Methods Injurious?</a></b></LI>
<span class="resultSubLine">1919-01-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="36"><b><a href='show.php?sangerDoc=420026.xml'>Are Preventive Means Injurious?</a></b></LI>
<span class="resultSubLine">1914-07-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="37"><b><a href='show.php?sangerDoc=302493.xml'>Asia Discovers Birth Control</a></b></LI>
<span class="resultSubLine">1956-07-00 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="38"><b><a href='show.php?sangerDoc=224215.xml'>At Long Last</a></b></LI>
<span class="resultSubLine">1937-07-06 &nbsp;(Published article)</span>
<br />&nbsp;
<LI VALUE="39"><b><a href='show.php?sangerDoc=008951.xml'>Bermuda</a></b></LI>
<span class="resultSubLine">1937-05-00 &nbsp;(Typed draft speech)</span>
<br />&nbsp;
<LI VALUE="40"><b><a href='show.php?sangerDoc=320908.xml'>Bermuda                 Speech</a></b></LI>
<span class="resultSubLine">1937-05-17 &nbsp;(Published article)</span>
</OL><div>1 <a href="?start=40&num_pages=12">2</a> <a href="?start=80&num_pages=12">3</a> <a href="?start=120&num_pages=12">4</a> <a href="?start=160&num_pages=12">5</a> <a href="?start=200&num_pages=12">6</a> <a href="?start=240&num_pages=12">7</a> <a href="?start=280&num_pages=12">8</a> <a href="?start=320&num_pages=12">9</a> <a href="?start=360&num_pages=12">10</a> <a href="?start=400&num_pages=12">11</a> <a href="?start=440&num_pages=12">12</a> <a href="?start=40&num_pages=12">Next</a></div>  </div>
</div>
	<div><br /></div>

	<p style="margin-top: 0px; margin-bottom: 0px;">
		<a href="http://www.nyu.edu/projects/sanger/aboutms/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c1','','../images/sanger_foot_r1_c1_f2.gif',1);"><img id="sanger_foot_r1_c1" src="../images/sanger_foot_r1_c1.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/documents/electroniced.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c2','','../images/sanger_foot_r1_c2_f2.gif',1);"><img id="sanger_foot_r1_c2" src="../images/sanger_foot_r1_c2.gif" width="104" height="20" alt="" /></a><a href="search.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c3','','../images/sanger_foot_r1_c3_f2.gif',1);"><img id="sanger_foot_r1_c3" src="../images/sanger_foot_r1_c3.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c4','','../images/sanger_foot_r1_c4_f2.gif',1);"><img id="sanger_foot_r1_c4" src="../images/sanger_foot_r1_c4.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/contactus/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c5','','../images/sanger_foot_r1_c5_f2.gif',1);"><img id="sanger_foot_r1_c5" src="../images/sanger_foot_r1_c5.gif" width="104" height="20" alt="" /></a><img id="sanger_foot_r1_c6" src="../images/sanger_foot_r1_c6.jpg" width="105" height="20" alt="" />
	</p>
	<p style="margin-bottom: 0px; margin-top: -1px; /*\*/margin-top: -4px;/**/">
		<img src="../images/spacer.gif" width="545" height="1" alt="" /><a href="http://validator.w3.org/check/referer"><img src="../images/xhtml11.gif" alt="valid" /></a>
	</p>
</div> <!-- end of Container --> 
</body>
</html>
