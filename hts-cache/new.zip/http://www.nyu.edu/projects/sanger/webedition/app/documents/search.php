<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
        "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
<head>
	<title>The Public Writings of Margaret Sanger: Web Edition</title> 
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<link href="../documents/styles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../documents/global.js"></script> 
</head>
<body onload="MM_preloadImages('../images/header_r2_c1_f2.gif','../images/header_r2_c2_f2.gif','../images/header_r2_c3_f2.gif','../images/header_r2_c4_f2.gif','../images/header_r2_c5_f2.gif');">
<div id="container" style="width: 626px; margin: 0px auto;"> 
<p style="margin-top: 0px; margin-bottom: 0px;">
	<img id="header_r1_c1" src="../images/header_r1_c1.gif" width="625" height="95" alt="" /><img src="../images/spacer.gif" width="1" height="95" alt="" /> 
</p>
<p style="margin-top: 0px; /*\*/margin-top: -3px;/**/">
	<a href="http://www.nyu.edu/projects/sanger/project/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c1','','../images/header_r2_c1_f2.gif',1);"><img id="header_r2_c1" src="../images/header_r2_c1.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/documents/electroniced.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c2','','../images/header_r2_c2_f2.gif',1);"><img id="header_r2_c2" src="../images/header_r2_c2.gif" width="104" height="20" alt="" /></a><a href="search.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c3','','../images/header_r2_c3_f2.gif',1);"><img id="header_r2_c3" src="../images/header_r2_c3.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c4','','../images/header_r2_c4_f2.gif',1);"><img id="header_r2_c4" src="../images/header_r2_c4.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/contactus" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('header_r2_c5','','../images/header_r2_c5_f2.gif',1);"><img id="header_r2_c5" src="../images/header_r2_c5.gif" width="104" height="20" alt="" /></a><img id="header_r2_c6" src="../images/header_r2_c6.jpg" width="105" height="20" alt="" /><img src="../images/spacer.gif" width="1" height="20" alt="" /> 
</p>
<div class="outBox">
	<div class="inBox">
 
<br />                                                                                                                                                                                        
                <div style="font-size: 16px; font-weight: bold">Search the Web Edition</div>                                                                                                              
(<a href="list.php">list all records</a>)<br />  		<br />
		<h3>Basic Search</h3> 
		<form action="" method="post" id="search1">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td class="searchLabelCell">
						&nbsp; 
					</td>
					<td>
						<input name="body1" type="text" id="body1" /> 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
					<td>
						<i>(search every part of the documents)</i> 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						&nbsp; 
					</td>
					<td>
						<input type="submit" name="submit1" value="Search!" /> 
					</td>
				</tr>
			</table>
		</form>
		<hr />
		<h3>Advanced Search</h3> 
		<form action="" method="post" id="search2">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td class="searchLabelCell">
						<b>title: &nbsp;</b> 
					</td>
					<td>
						<input name="title" type="text" id="title" /> 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
					<td>
						<i>(search through all of the document titles)</i> 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						<b>full text: &nbsp;</b> 
					</td>
					<td>
						<input name="body2" type="text" id="body2" /> 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
					<td>
						<i>(search through the body of the documents)</i> 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						<b>date: &nbsp;</b> 
					</td>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						<i>on/from</i>: &nbsp; 
					</td>
					<td>
						<select name="month1" id="month1"> 
							<option value="">
								&nbsp; 
							</option>
							<option value="01">
								January 
							</option>
							<option value="02">
								February 
							</option>
							<option value="03">
								March 
							</option>
							<option value="04">
								April 
							</option>
							<option value="05">
								May 
							</option>
							<option value="06">
								June 
							</option>
							<option value="07">
								July 
							</option>
							<option value="08">
								August 
							</option>
							<option value="09">
								September 
							</option>
							<option value="10">
								October 
							</option>
							<option value="11">
								November 
							</option>
							<option value="12">
								December 
							</option>
						</select> 
						<select name="day1" id="day1"> 
							<option value="">
								&nbsp; 
							</option><option value="1">
		1 
		</option>
<option value="2">
		2 
		</option>
<option value="3">
		3 
		</option>
<option value="4">
		4 
		</option>
<option value="5">
		5 
		</option>
<option value="6">
		6 
		</option>
<option value="7">
		7 
		</option>
<option value="8">
		8 
		</option>
<option value="9">
		9 
		</option>
<option value="10">
		10 
		</option>
<option value="11">
		11 
		</option>
<option value="12">
		12 
		</option>
<option value="13">
		13 
		</option>
<option value="14">
		14 
		</option>
<option value="15">
		15 
		</option>
<option value="16">
		16 
		</option>
<option value="17">
		17 
		</option>
<option value="18">
		18 
		</option>
<option value="19">
		19 
		</option>
<option value="20">
		20 
		</option>
<option value="21">
		21 
		</option>
<option value="22">
		22 
		</option>
<option value="23">
		23 
		</option>
<option value="24">
		24 
		</option>
<option value="25">
		25 
		</option>
<option value="26">
		26 
		</option>
<option value="27">
		27 
		</option>
<option value="28">
		28 
		</option>
<option value="29">
		29 
		</option>
<option value="30">
		30 
		</option>
<option value="31">
		31 
		</option>
						</select> <select name="year1" id="year1"> 
							<option value="">
								&nbsp; 
							</option><option value="1911">
		1911 
		</option>
<option value="1912">
		1912 
		</option>
<option value="1913">
		1913 
		</option>
<option value="1914">
		1914 
		</option>
<option value="1915">
		1915 
		</option>
<option value="1916">
		1916 
		</option>
<option value="1917">
		1917 
		</option>
<option value="1918">
		1918 
		</option>
<option value="1919">
		1919 
		</option>
<option value="1920">
		1920 
		</option>
<option value="1921">
		1921 
		</option>
<option value="1922">
		1922 
		</option>
<option value="1923">
		1923 
		</option>
<option value="1924">
		1924 
		</option>
<option value="1925">
		1925 
		</option>
<option value="1926">
		1926 
		</option>
<option value="1927">
		1927 
		</option>
<option value="1928">
		1928 
		</option>
<option value="1929">
		1929 
		</option>
<option value="1930">
		1930 
		</option>
<option value="1931">
		1931 
		</option>
<option value="1932">
		1932 
		</option>
<option value="1933">
		1933 
		</option>
<option value="1934">
		1934 
		</option>
<option value="1935">
		1935 
		</option>
<option value="1936">
		1936 
		</option>
<option value="1937">
		1937 
		</option>
<option value="1938">
		1938 
		</option>
<option value="1939">
		1939 
		</option>
<option value="1940">
		1940 
		</option>
<option value="1941">
		1941 
		</option>
<option value="1942">
		1942 
		</option>
<option value="1943">
		1943 
		</option>
<option value="1944">
		1944 
		</option>
<option value="1945">
		1945 
		</option>
<option value="1946">
		1946 
		</option>
<option value="1947">
		1947 
		</option>
<option value="1948">
		1948 
		</option>
<option value="1949">
		1949 
		</option>
<option value="1950">
		1950 
		</option>
<option value="1951">
		1951 
		</option>
<option value="1952">
		1952 
		</option>
<option value="1953">
		1953 
		</option>
<option value="1954">
		1954 
		</option>
<option value="1955">
		1955 
		</option>
<option value="1956">
		1956 
		</option>
<option value="1957">
		1957 
		</option>
<option value="1958">
		1958 
		</option>
<option value="1959">
		1959 
		</option>
<option value="1960">
		1960 
		</option>
						</select> 
					</td>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						<i>through</i>: &nbsp; 
					</td>
					<td>
						<select name="month2" id="month2"> 
							<option value="">
								&nbsp; 
							</option>
							<option value="01">
								January 
							</option>
							<option value="02">
								February 
							</option>
							<option value="03">
								March 
							</option>
							<option value="04">
								April 
							</option>
							<option value="05">
								May 
							</option>
							<option value="06">
								June 
							</option>
							<option value="07">
								July 
							</option>
							<option value="08">
								August 
							</option>
							<option value="09">
								September 
							</option>
							<option value="10">
								October 
							</option>
							<option value="11">
								November 
							</option>
							<option value="12">
								December 
							</option>
						</select> 

						<select name="day2" id="day2"> 
							<option value="">
								&nbsp; 
							</option><option value="1">
		1 
		</option>
<option value="2">
		2 
		</option>
<option value="3">
		3 
		</option>
<option value="4">
		4 
		</option>
<option value="5">
		5 
		</option>
<option value="6">
		6 
		</option>
<option value="7">
		7 
		</option>
<option value="8">
		8 
		</option>
<option value="9">
		9 
		</option>
<option value="10">
		10 
		</option>
<option value="11">
		11 
		</option>
<option value="12">
		12 
		</option>
<option value="13">
		13 
		</option>
<option value="14">
		14 
		</option>
<option value="15">
		15 
		</option>
<option value="16">
		16 
		</option>
<option value="17">
		17 
		</option>
<option value="18">
		18 
		</option>
<option value="19">
		19 
		</option>
<option value="20">
		20 
		</option>
<option value="21">
		21 
		</option>
<option value="22">
		22 
		</option>
<option value="23">
		23 
		</option>
<option value="24">
		24 
		</option>
<option value="25">
		25 
		</option>
<option value="26">
		26 
		</option>
<option value="27">
		27 
		</option>
<option value="28">
		28 
		</option>
<option value="29">
		29 
		</option>
<option value="30">
		30 
		</option>
<option value="31">
		31 
		</option>

						</select> <select name="year2" id="year2"> 
							<option value="">
								&nbsp; 
							</option><option value="1911">
		1911 
		</option>
<option value="1912">
		1912 
		</option>
<option value="1913">
		1913 
		</option>
<option value="1914">
		1914 
		</option>
<option value="1915">
		1915 
		</option>
<option value="1916">
		1916 
		</option>
<option value="1917">
		1917 
		</option>
<option value="1918">
		1918 
		</option>
<option value="1919">
		1919 
		</option>
<option value="1920">
		1920 
		</option>
<option value="1921">
		1921 
		</option>
<option value="1922">
		1922 
		</option>
<option value="1923">
		1923 
		</option>
<option value="1924">
		1924 
		</option>
<option value="1925">
		1925 
		</option>
<option value="1926">
		1926 
		</option>
<option value="1927">
		1927 
		</option>
<option value="1928">
		1928 
		</option>
<option value="1929">
		1929 
		</option>
<option value="1930">
		1930 
		</option>
<option value="1931">
		1931 
		</option>
<option value="1932">
		1932 
		</option>
<option value="1933">
		1933 
		</option>
<option value="1934">
		1934 
		</option>
<option value="1935">
		1935 
		</option>
<option value="1936">
		1936 
		</option>
<option value="1937">
		1937 
		</option>
<option value="1938">
		1938 
		</option>
<option value="1939">
		1939 
		</option>
<option value="1940">
		1940 
		</option>
<option value="1941">
		1941 
		</option>
<option value="1942">
		1942 
		</option>
<option value="1943">
		1943 
		</option>
<option value="1944">
		1944 
		</option>
<option value="1945">
		1945 
		</option>
<option value="1946">
		1946 
		</option>
<option value="1947">
		1947 
		</option>
<option value="1948">
		1948 
		</option>
<option value="1949">
		1949 
		</option>
<option value="1950">
		1950 
		</option>
<option value="1951">
		1951 
		</option>
<option value="1952">
		1952 
		</option>
<option value="1953">
		1953 
		</option>
<option value="1954">
		1954 
		</option>
<option value="1955">
		1955 
		</option>
<option value="1956">
		1956 
		</option>
<option value="1957">
		1957 
		</option>
<option value="1958">
		1958 
		</option>
<option value="1959">
		1959 
		</option>
<option value="1960">
		1960 
		</option>
						</select> 
					</td>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
					<td>
						<i>(search on one date or from a range of dates)</i> 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						<b>document type: &nbsp;</b> 
					</td>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						<i>1</i>: &nbsp; 
					</td>
					<td>
						<select name="doctype2" style="width: 200px;"> 
							<option value="">
								&nbsp; 
							</option>
							<option value="article">
								article 
							</option>
							<option value="document">
								document 
							</option>
							<option value="interview">
								interview 
							</option>
							<option value="review">
								review 
							</option>
							<option value="speech">
								speech 
							</option>
							<option value="statement">
								statement 
							</option>
							<option value="testimony">
								testimony 
							</option>
						</select> 
					</td>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						<i>2</i>: &nbsp; 
					</td>
					<td>
						<select name="doctype1" style="width: 200px;"> 
							<option value="">
								&nbsp; 
							</option>
							<option value="Autograph">
								Autograph 
							</option>
							<option value="Autograph draft">
								Autograph draft 
							</option>
							<option value="Published">
								Published 
							</option>
							<option value="Typed">
								Typed 
							</option>
							<option value="Typed draft">
								Typed draft 
							</option>
						</select> 
					</td>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
					<td>
						<i>(find documents of particular types)</i> 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						<b>journal title: &nbsp;</b> 
					</td>
					<td>
						<select name="journal" style="width: 400px;"> 
							<option value=''></option>

							<option value='16'>American Eugenics</option>
							<option value='102'>American Medicine</option>
							<option value='98'>American Weekly</option>
							<option value='100'>Arizona Daily Citizen</option>
							<option value='84'>Around the World News of Population and Birth Control</option>
							<option value='87'>Asia</option>
							<option value='109'>Birth Control News</option>
							<option value='58'>Birth Control Review</option>
							<option value='3'>Birth Control Review, the</option>
							<option value='17'>Britannica Book of the Year</option>
							<option value='96'>Britannica Book of the Year (1947), pp.                 119-20.</option>
							<option value='64'>Champion of Youth</option>
							<option value='77'>Charlotte Observer</option>
							<option value='8'>Chicago Defender</option>
							<option value='47'>China Times (Shanghai)</option>
							<option value='46'>Church and Society</option>
							<option value='91'>Clubwoman, the</option>
							<option value='19'>Colliers</option>
							<option value='30'>Community Church of Boston, "Birth Control and Civil Liberties"</option>
							<option value='12'>Congressional Digest</option>
							<option value='74'>Coronet Magazine</option>
							<option value='103'>Crisis, the</option>
							<option value='69'>Debate Between Margaret Sanger, Negative and Winter                     Russell, Affirmative</option>
							<option value='86'>Estes' Back to Nature Magazine</option>
							<option value='11'>Eugenics</option>
							<option value='2'>Fairplay</option>
							<option value='105'>Family Limitation</option>
							<option value='43'>Family Planning Movement in Japan</option>
							<option value='88'>Fifth International Conference on Planned Parenthood,                     Report of the Proceedings</option>
							<option value='90'>For Legalized Birth Control</option>
							<option value='29'>Forum and Century (1930-1940) Mar. 1935 p. 139-141;</option>
							<option value='76'>Free Pulpit in                     Action, a</option>
							<option value='65'>Freedom: A Journal of Anarchist Communism</option>
							<option value='52'>Grolier Encyclopedia</option>
							<option value='6'>Holland Magazine</option>
							<option value='10'>Human Fertility</option>
							<option value='32'>Il Proletario</option>
							<option value='89'>Illustrated Weekly of India, the</option>
							<option value='67'>International Aspects of Birth Control; the Proceedings of the Neo-Malthusian and Birth Control Conference</option>
							<option value='75'>International Socialist Review</option>
							<option value='85'>Journal of Contraception, the</option>
							<option value='5'>Lloyd's Sunday News</option>
							<option value='27'>Lloyd's Weekly</option>
							<option value='60'>Long Beach Press</option>
							<option value='21'>Magnetation Methods of Birth Control</option>
							<option value='59'>Malthusian</option>
							<option value='57'>Malthusian, the</option>
							<option value='23'>Margaret Sanger Papers</option>
							<option value='92'>Margaret Sanger Papers, Library of                 Congress</option>
							<option value='70'>Margaret Sanger Papers, Library of Congress</option>
							<option value='62'>Margaret Sanger Papers, Sophia Smith Collection</option>
							<option value='22'>Melting Pot, the</option>
							<option value='15'>Metropolitan Magazine, the</option>
							<option value='41'>Modern School, the</option>
							<option value='53'>Modern School</option>
							<option value='107'>Morality of Birth Control, the</option>
							<option value='26'>Mother Earth</option>
							<option value='73'>Mothers' Aid Message</option>
							<option value='108'>MSPP</option>
							<option value='95'>Nation, the</option>
							<option value='14'>Negro Digest</option>
							<option value='28'>New Generation, the</option>
							<option value='44'>New Masses</option>
							<option value='37'>New Republic, the</option>
							<option value='35'>New York                     Times</option>
							<option value='79'>New York American</option>
							<option value='13'>New York Call</option>
							<option value='78'>New York Sunday Call, the</option>
							<option value='63'>News of Population and Birth Control</option>
							<option value='55'>North American Review</option>
							<option value='31'>Oklahoma State                     Register</option>
							<option value='54'>One Hundred Fifty Years of Birth Control: Malthus (1798) to Cheltenham,                     England (1948)</option>
							<option value='99'>People</option>
							<option value='40'>Physical Culture</option>
							<option value='51'>Plain Talk Magazine</option>
							<option value='104'>Population Problems Series</option>
							<option value='101'>Proceedings of the First American Birth Control Conference</option>
							<option value='80'>Proceedings of the International Congress on Population                     and World Resources in Relation to Family</option>
							<option value='81'>Proceedings of the Sixth                     International Neo-Malthusian and Birth Control Conference,                     Volume IV</option>
							<option value='83'>Proceedings of the World Population Conference</option>
							<option value='48'>Providence Journal</option>
							<option value='34'>Reader's Digest</option>
							<option value='24'>Redbook Magazine</option>
							<option value='49'>Report of the Fifth International Neo-Malthusian and Birth Control Conference</option>
							<option value='38'>Revolutionary Almanac, the</option>
							<option value='72'>Royal Gazette and Colonist Daily, the</option>
							<option value='39'>San Francisco Call & Post</option>
							<option value='82'>Sayings of Others</option>
							<option value='45'>Senator, the</option>
							<option value='1'>Sex in                     Civilization</option>
							<option value='20'>SHE Magazine: Page Extra Clip Sheet</option>
							<option value='25'>Smith College Collection</option>
							<option value='97'>Solidarity</option>
							<option value='66'>Spur, the</option>
							<option value='42'>SSC</option>
							<option value='68'>Theosophist, the</option>
							<option value='56'>Thinker, the</option>
							<option value='33'>Third International Conference on Planned Parenthood, Report of the                     Proceedings</option>
							<option value='106'>Tomorrow</option>
							<option value='7'>True Confessions</option>
							<option value='9'>Unidentified journal</option>
							<option value='50'>Unknown</option>
							<option value='18'>Voice of Youth</option>
							<option value='36'>Western Comrade</option>
							<option value='61'>Wilkes-Barre Times, the</option>
							<option value='71'>Winnipeg Free Press</option>
							<option value='4'>Woman Rebel, the</option>
							<option value='93'>Woman's Digest</option>
							<option value='94'>Women United</option>

						</select>
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
					<td>
						<i>(find documents from a particular journal)</i> 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						<b>subject index: &nbsp;</b> 
					</td>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td class="searchLabelCell">
						&nbsp; 
					</td>
					<td><select name="category[]" multiple style="height: 150px; width: 400px;"><br /><option value=638> "feeble-minded" persons</option>
<option value=902>-- allowed to reproduce</option>
<option value=639>-- fertility and birth rate of</option>
<option value=39> "unfit" to reproduce</option>
<option value=67>-- descriptions of</option>
<option value=318>-- MS on</option>
<option value=319>-- social burdens, as</option>
<option value=101> abortion</option>
<option value=102>-- birth control vs.</option>
<option value=103>-- frequency of</option>
<option value=104>-- health risks of</option>
<option value=426>-- laws and legislation</option>
<option value=257>-- MS on</option>
<option value=523> academics</option>
<option value=524>-- birth control and</option>
<option value=315> adolescence</option>
<option value=595> Africa</option>
<option value=596>-- birth control in</option>
<option value=127> African-Americans</option>
<option value=128>-- birth control and</option>
<option value=131>-- discrimination</option>
<option value=839>-- infant mortality rates among</option>
<option value=129>-- maternal mortality rates among</option>
<option value=130>-- MS on</option>
<option value=787> alcohol</option>
<option value=788>-- MS on</option>
<option value=624> Allison, Van Kleeck</option>
<option value=485> American Birth Control League</option>
<option value=519> American Medical Association</option>
<option value=440> anarchism and anarchists</option>
<option value=493>-- in Spain</option>
<option value=492>-- MS on</option>
<option value=874>-- violence and</option>
<option value=708> Anglican Church</option>
<option value=709>-- birth control and abortion and</option>
<option value=559> Anti-Nazi Commitee</option>
<option value=794> Around the World News of Population and Birth Cont</option>
<option value=340> Asia</option>
<option value=341>-- birth control in</option>
<option value=276> Australia</option>
<option value=277>-- birth rates in</option>
<option value=72> Austria</option>
<option value=73>-- birth control in</option>
<option value=801> authoritarianism</option>
<option value=358> autobiography</option>
<option value=359>-- My fight for Birth Control</option>
<option value=832> awards</option>
<option value=876> Barnberger, Charles J.</option>
<option value=135> Bermuda</option>
<option value=136>-- government</option>
<option value=137>---- birth control and</option>
<option value=138>---- public health programs</option>
<option value=767>-- public health programs</option>
<option value=1> birth control</option>
<option value=49>-- access to</option>
<option value=520>---- in remote places</option>
<option value=139>---- international</option>
<option value=610>-- American opinion on</option>
<option value=194>-- and marriage</option>
<option value=443>-- and natural resources</option>
<option value=357>-- and sexuality</option>
<option value=442>-- and war</option>
<option value=261>-- arrests and imprisionment</option>
<option value=415>-- arrests and imprisonment</option>
<option value=697>-- arrests for</option>
<option value=298>-- as a term</option>
<option value=454>-- Asia</option>
<option value=662>-- birth control leagues</option>
<option value=663>---- Birth Control League of New York</option>
<option value=664>---- National Birth Control League</option>
<option value=802>-- civilized behavior as</option>
<option value=58>-- class-based</option>
<option value=2>-- clinics and leagues</option>
<option value=293>---- educational benefits of</option>
<option value=328>---- establishment of</option>
<option value=625>---- formation of</option>
<option value=597>---- in Europe</option>
<option value=228>---- in India</option>
<option value=3>---- in Netherlands</option>
<option value=105>---- in US</option>
<option value=294>---- marriage counseling at</option>
<option value=772>---- need for</option>
<option value=580>---- physicians and</option>
<option value=295>---- research benefits of</option>
<option value=713>-- creation of term</option>
<option value=196>-- definitions of</option>
<option value=198>-- dissemination of information on</option>
<option value=44>-- distribution of information about</option>
<option value=710>---- morality of</option>
<option value=50>-- economic benefits and risks of</option>
<option value=826>-- effectiveness of</option>
<option value=33>-- health benefits and risks</option>
<option value=299>-- health benefits of</option>
<option value=723>-- hospitals and</option>
<option value=652>-- in Japan</option>
<option value=106>-- in marriages</option>
<option value=250>-- international</option>
<option value=251>-- international conferences on</option>
<option value=107>-- lack of knowledge of</option>
<option value=197>---- negative consequences of</option>
<option value=45>-- laws and legislation</option>
<option value=46>---- Comstock act</option>
<option value=598>---- Connecticut</option>
<option value=239>---- Customs Regulations</option>
<option value=507>---- doctor's only laws</option>
<option value=156>---- doctors-only bills</option>
<option value=158>---- Federal</option>
<option value=304>-------- Comstock act</option>
<option value=305>---- federal lobbying</option>
<option value=291>---- in Japan</option>
<option value=252>---- Japan</option>
<option value=416>---- Massachusetts</option>
<option value=865>---- Mississippi</option>
<option value=159>---- MS on</option>
<option value=108>---- New York</option>
<option value=853>---- North Carolina</option>
<option value=854>---- Oregon</option>
<option value=157>---- Postal Code and Regulations</option>
<option value=855>---- Puerto Rico</option>
<option value=379>---- State</option>
<option value=707>-------- lobbying</option>
<option value=886>-------- New York (1142 Penal Code)</option>
<option value=724>-------- New York (1145 Penal Code)</option>
<option value=109>-- legal cases</option>
<option value=110>---- Crane Decision'</option>
<option value=570>---- U.S. v. One Package of Japanese contraceptives</option>
<option value=717>---- U.S. V. One Package of Japanese contraceptives'</option>
<option value=312>-- legalization of</option>
<option value=324>-- mainstreaming of</option>
<option value=140>-- medical community and</option>
<option value=59>-- medically controlled</option>
<option value=111>-- methods</option>
<option value=399>---- condom</option>
<option value=195>---- continence</option>
<option value=409>---- diaphragm</option>
<option value=262>---- douche</option>
<option value=263>---- efficacy of</option>
<option value=884>---- female</option>
<option value=756>---- herbal</option>
<option value=112>---- instructions</option>
<option value=835>---- laxatives</option>
<option value=867>---- male</option>
<option value=836>---- nursing</option>
<option value=856>---- pessaries</option>
<option value=755>---- pill</option>
<option value=296>---- research</option>
<option value=227>---- rice-based</option>
<option value=264>---- safe period</option>
<option value=400>---- sponge</option>
<option value=837>---- stem pessary</option>
<option value=186>---- sterilization</option>
<option value=838>---- suppository</option>
<option value=789>---- withdrawal</option>
<option value=166>-- methods and devices</option>
<option value=421>---- chemical contraceptives</option>
<option value=173>---- continence</option>
<option value=167>---- pessaries (diaphragm)</option>
<option value=879>---- stem pessary</option>
<option value=828>-- morality and</option>
<option value=32>-- morality of</option>
<option value=626>-- movememt</option>
<option value=4>-- movement</option>
<option value=51>---- American</option>
<option value=5>---- disputes within</option>
<option value=551>---- funding</option>
<option value=6>---- goals and strategies</option>
<option value=147>---- history of</option>
<option value=478>---- in California</option>
<option value=187>---- international</option>
<option value=380>---- MS on</option>
<option value=444>-- neo-Malthusian arguments for</option>
<option value=23>-- opposition to</option>
<option value=448>-- physicial justifications for</option>
<option value=611>-- population and</option>
<option value=480>-- propaganda and publicity</option>
<option value=819>-- psychological benefits of</option>
<option value=141>-- religion and</option>
<option value=650>-- reproductive choices and decisions</option>
<option value=715>-- resolutions</option>
<option value=716>---- local</option>
<option value=190>-- response to the Pope's statements on</option>
<option value=521>-- rights associated with</option>
<option value=16>-- socio-economic benefits of</option>
<option value=420>-- socioeconomic benefits</option>
<option value=816>-- socioeconomic benefits of</option>
<option value=900>-- Soviet Union</option>
<option value=325>-- suppression of</option>
<option value=191>-- the Bible and</option>
<option value=405>-- upper classes and</option>
<option value=270>-- war and</option>
<option value=17>-- working classes</option>
<option value=656>-- youth and</option>
<option value=199> Birth Control Clinical Research Bureau</option>
<option value=547>-- raid</option>
<option value=864>-- raid of</option>
<option value=200>-- records of</option>
<option value=729> birth control clinics</option>
<option value=730>-- Amboy street clinic</option>
<option value=425> birth control clinics and leagues</option>
<option value=510>-- establishment of</option>
<option value=571> Birth Control Federation of America</option>
<option value=258> birth control laws and legislation</option>
<option value=846>-- federal</option>
<option value=259>-- MS on</option>
<option value=661> Birth Control League</option>
<option value=365> birth control movement</option>
<option value=486>-- international</option>
<option value=376> birth control propaganda and publicity</option>
<option value=334> Birth Control Review, The</option>
<option value=387>-- suppression of</option>
<option value=52> birth rate</option>
<option value=771>-- consequences on</option>
<option value=215>-- decline in</option>
<option value=342>-- efforts to increase</option>
<option value=142>-- efforts to reduce</option>
<option value=889>-- increase in</option>
<option value=316>-- MS on</option>
<option value=53>-- population growth and</option>
<option value=748> Blanchard, Paul</option>
<option value=824> Blossom, Frederick A.</option>
<option value=68> Book Review</option>
<option value=69>-- response to a</option>
<option value=441> Boy Scouts</option>
<option value=201> Brownsville Clinic</option>
<option value=463>-- arrests and trial</option>
<option value=202>-- raid and trials</option>
<option value=511> Brush, George DeForest</option>
<option value=317> Burbank, Luther</option>
<option value=467> Byrne, Ethel Higgins</option>
<option value=790> cancer</option>
<option value=791>-- birth control and</option>
<option value=209> capitalism</option>
<option value=673>-- MS on</option>
<option value=752> Cassidente, Mrs.</option>
<option value=24> catholic church</option>
<option value=604>-- </option>
<option value=406>-- birth control and</option>
<option value=25>-- birth control and abortion and</option>
<option value=174>---- in England</option>
<option value=899>-- freedom of speech and</option>
<option value=726>-- in Spain</option>
<option value=54>-- MS on</option>
<option value=160>-- political influence of</option>
<option value=353>-- population and</option>
<option value=265> censorship</option>
<option value=721>-- European opinion on</option>
<option value=722>-- in England</option>
<option value=605>-- in schools</option>
<option value=464>-- in United States</option>
<option value=565> Chamberlain, Neville</option>
<option value=566>-- MS on</option>
<option value=369> child labor</option>
<option value=360> children</option>
<option value=658>-- rights of</option>
<option value=361>-- unwanted</option>
<option value=47> child spacing</option>
<option value=271> child welfare</option>
<option value=765>-- and birth control</option>
<option value=370> China</option>
<option value=703>-- birth control clinics and leagues</option>
<option value=455>-- birth control in</option>
<option value=892>-- birth rate in</option>
<option value=526>-- MS on</option>
<option value=456>-- population policy of</option>
<option value=371>-- women in</option>
<option value=897> Christ</option>
<option value=898>-- MS on the hypothetical second coming of</option>
<option value=266> Christianity</option>
<option value=175> Church of England</option>
<option value=176>-- birth control and</option>
<option value=29> civilization</option>
<option value=30>-- MS on</option>
<option value=407> class warfare</option>
<option value=31> client letters</option>
<option value=556> communism</option>
<option value=557>-- MS on</option>
<option value=660> Comstock, Anthony</option>
<option value=192> conception</option>
<option value=193>-- definition of</option>
<option value=7> conferences</option>
<option value=349>-- All India Conference on Family Planning</option>
<option value=350>---- 1954</option>
<option value=8>-- International Birth Control Conference</option>
<option value=9>---- 1930 (7th)</option>
<option value=94>-- International Conference on Planned Parenthood</option>
<option value=822>---- 1955 (5th)</option>
<option value=95>---- 1958 (6th)</option>
<option value=505>-- International Neo-Malthusian and birth Control Con</option>
<option value=506>---- 1925 (6th)</option>
<option value=744>-- International Neo-Malthusian and birth Control Con</option>
<option value=745>---- 1925 (6th)</option>
<option value=487>-- International Neo-Malthusian and birth Control Con</option>
<option value=488>---- 1925 (6th)</option>
<option value=381>-- International Neo-Malthusian and Birth Control Con</option>
<option value=382>---- 1925 (6th)</option>
<option value=671>-- International Sex Education Conference</option>
<option value=672>---- 1946 (Stockholm)</option>
<option value=203>-- Lambeth Conference</option>
<option value=204>---- 1930</option>
<option value=851>-- White House Conference on Child health and Protect</option>
<option value=852>---- 1930</option>
<option value=796>-- World Conference on the Family and Population</option>
<option value=797>---- 1947</option>
<option value=753>-- World Population Conference</option>
<option value=754>---- 1927</option>
<option value=412> Congressional bills</option>
<option value=413>-- S.600</option>
<option value=414>---- 1934</option>
<option value=862>-- S.4582</option>
<option value=863>---- 1931</option>
<option value=817> conjugal intimacy</option>
<option value=818>-- the right of</option>
<option value=240> Connecticut</option>
<option value=241>-- birth control</option>
<option value=242>---- laws and legislation</option>
<option value=811> Cox, Harold</option>
<option value=494> Cuba</option>
<option value=495>-- political conditions in</option>
<option value=210> Davis, Katharine Bement</option>
<option value=490> death rate</option>
<option value=491>-- decline of</option>
<option value=449> Depression, The</option>
<option value=450>-- effects of</option>
<option value=872> direct action</option>
<option value=873>-- MS on</option>
<option value=351> divorce</option>
<option value=352>-- in U.S.</option>
<option value=372> Drysdale, Charles Vickery</option>
<option value=620> Drysdale, George</option>
<option value=410> Dutch Neo-Malthusian League</option>
<option value=211> Edelsohn, Rebecca</option>
<option value=503> education</option>
<option value=504>-- in Spain</option>
<option value=335> Ellis, Havelock</option>
<option value=670>-- MS on</option>
<option value=60> England</option>
<option value=773>-- birth control clinics and leagues in</option>
<option value=77>-- birth control in</option>
<option value=61>-- birth rate</option>
<option value=278>-- birth rate in</option>
<option value=812>-- fertility rates</option>
<option value=62>-- labor movement</option>
<option value=881>-- militants in</option>
<option value=564>-- MS on</option>
<option value=76>-- population policies</option>
<option value=653>-- population policies of</option>
<option value=733>-- views of America</option>
<option value=388> Enright, Richard</option>
<option value=582> Ervin, Charles W.</option>
<option value=34> eugenics</option>
<option value=35>-- birth control and</option>
<option value=216>-- criticisms of</option>
<option value=36>-- MS on</option>
<option value=217>-- positive</option>
<option value=74> Europe</option>
<option value=725>-- birth control clinics and leagues</option>
<option value=75>-- birth control in</option>
<option value=468>-- MS on</option>
<option value=740>-- travel in</option>
<option value=536>-- women in</option>
<option value=253> Family Limitation</option>
<option value=623>-- censorship of</option>
<option value=113> family planning</option>
<option value=518> Family Planning Federation of Japan</option>
<option value=55> family size</option>
<option value=218>-- class-based</option>
<option value=489>-- men and</option>
<option value=56>-- MS on</option>
<option value=537> famine</option>
<option value=469> feeble-minded persons</option>
<option value=803>-- allowed to reproduce</option>
<option value=470>-- fertility and birth rate of</option>
<option value=302> feminism and feminists</option>
<option value=508>-- in England</option>
<option value=303>-- MS on</option>
<option value=496> Ferrer, Francisco</option>
<option value=583>-- MS on</option>
<option value=297> fertility</option>
<option value=533> fertility limitation</option>
<option value=534>-- of physicaly disabled and diseased</option>
<option value=591> fertility rates</option>
<option value=813>-- in England</option>
<option value=417> First American Birth Control Conference (1921)</option>
<option value=893> fit (to reproduce)</option>
<option value=894>-- MS on</option>
<option value=457> food supply</option>
<option value=804> foreign aid</option>
<option value=78> France</option>
<option value=79>-- birth control in</option>
<option value=80>-- birth rate in</option>
<option value=279>-- death rate in</option>
<option value=739>-- MS on</option>
<option value=301> free love</option>
<option value=354> free speech and free press</option>
<option value=827> Free Speech League</option>
<option value=185> Gandhi, Mahatma</option>
<option value=428> Gemany</option>
<option value=429>-- socioeconomic conditions</option>
<option value=890> German</option>
<option value=891>-- pro-natalism in</option>
<option value=81> Germany</option>
<option value=427>-- abortion in</option>
<option value=82>-- birth control in</option>
<option value=343>-- birth rate in</option>
<option value=560>-- MS on</option>
<option value=83>-- population policies</option>
<option value=344>-- population policies of</option>
<option value=430>-- working classes in</option>
<option value=509> Goldman, Emma</option>
<option value=525> Hankins, Frank</option>
<option value=655> Hayes, Patrick J. (Archbishop)</option>
<option value=675> heredity</option>
<option value=676>-- MS on</option>
<option value=848> Hirsch, Max</option>
<option value=561> Hitler, Adolf</option>
<option value=562>-- MS on</option>
<option value=563>-- opposition to</option>
<option value=644> Holland</option>
<option value=645>-- birth control in</option>
<option value=280> Hungary</option>
<option value=281>-- birth rate in</option>
<option value=895> Huxley, Julian</option>
<option value=896> Huxley Family</option>
<option value=383> immigration</option>
<option value=471>-- MS on</option>
<option value=384>-- U.S. policy</option>
<option value=96> India</option>
<option value=732>-- birth control clinics and leagues</option>
<option value=229>-- birth control in</option>
<option value=230>-- birth control movement in</option>
<option value=233>-- mortality rates</option>
<option value=234>---- infant</option>
<option value=235>---- maternal</option>
<option value=97>-- MS on</option>
<option value=232>-- overpopulation in</option>
<option value=458>-- population policy of</option>
<option value=831>-- population rate in</option>
<option value=231>-- women in</option>
<option value=15> individualism</option>
<option value=539> individuals</option>
<option value=540>-- rights of</option>
<option value=402> Industrial Workers of the World</option>
<option value=404>-- MS and</option>
<option value=403>-- suppression of</option>
<option value=696> infanticide</option>
<option value=522> infant mortality rate</option>
<option value=844> insane asylums</option>
<option value=517> International Conference on Planned Parenthood, 5t</option>
<option value=513> International Congress of Eugenics</option>
<option value=514>-- in 1921 (2nd, New York)</option>
<option value=870> International Medical Congress on Contraceptives (</option>
<option value=683> International Neo-Malthusian and Birth Control Con</option>
<option value=684>-- in 1922 (5th--London)</option>
<option value=681> International Neo-Malthusian and Birth Control Con</option>
<option value=682>-- in 1911 (4th--Dresden)</option>
<option value=679> International Neo-Malthusian and Birth Control Con</option>
<option value=680>-- in 1910 (3rd--The Hague)</option>
<option value=373> International Neo-Malthusian and Birth Control Con</option>
<option value=374>-- in 1922 (5th--London)</option>
<option value=685> International Neo-Malthusian and Birth Control Con</option>
<option value=686>-- in 1925 (6th--New York)</option>
<option value=541> International Neo-Malthusian and Birth Control Con</option>
<option value=542>-- in 1922 (5th--London)</option>
<option value=677> International Neo-Malthusian and Birth Control Con</option>
<option value=678>-- in 1905 (2nd--Liege)</option>
<option value=687> International Neo-Malthusian and Birth Control Con</option>
<option value=688>-- in 1925 (6th--New York)</option>
<option value=689>---- proceedings</option>
<option value=98> International Planned Parenthood Federation</option>
<option value=878> Ishimoto, Baroness Shidzue</option>
<option value=808> Ishimoto, Keikichi (Baron)</option>
<option value=567> Italy</option>
<option value=618>-- birth rate in</option>
<option value=616>-- MS on</option>
<option value=766>-- overpopulation and</option>
<option value=568>-- population policies</option>
<option value=747>-- population policies of</option>
<option value=617>-- pro-natalism in</option>
<option value=213> jails and imprisonment</option>
<option value=751>-- Blackwell's Island Workhouse (New York)</option>
<option value=214>-- MS on</option>
<option value=170> Japan</option>
<option value=702>-- birth control clinics and leagues</option>
<option value=172>-- birth control in</option>
<option value=289>-- government of</option>
<option value=705>-- modernization of</option>
<option value=544>-- MS on</option>
<option value=750>-- over-population and</option>
<option value=619>-- overpopulation and</option>
<option value=798>-- political situation</option>
<option value=548>-- population policies</option>
<option value=171>-- population policies of</option>
<option value=459>-- population policy of</option>
<option value=543>-- socioeconomic conditions</option>
<option value=290>-- U.S. occupation of</option>
<option value=545>-- women in</option>
<option value=546>-- working conditions</option>
<option value=799> Japan Chronicle</option>
<option value=640> Jukes family</option>
<option value=641> Kallikak family</option>
<option value=809> Keynes, John Maynard</option>
<option value=63> labor movement</option>
<option value=355>-- birth control and</option>
<option value=64>-- MS on</option>
<option value=439>-- radical</option>
<option value=70>-- strikes</option>
<option value=779>---- Hazleton (PA) Silk Strike (1913)</option>
<option value=71>---- Lawrence, MA (1912)</option>
<option value=484>---- Paterson (NJ) Silk Strike (1913)</option>
<option value=849>-- women and</option>
<option value=161> labor movement,</option>
<option value=162>-- birth control and</option>
<option value=883> Land and Liberty</option>
<option value=401> law-breaking and direct action</option>
<option value=212> law breaking and direct action</option>
<option value=329> League for Women Voters</option>
<option value=330>-- birth control and</option>
<option value=690> Ligue de la regeneration humaine</option>
<option value=741> Lincoln, Abraham</option>
<option value=423> love</option>
<option value=424>-- concept of</option>
<option value=701> Lovejoy, Owen</option>
<option value=292> MacArthur, Douglas</option>
<option value=691> Malthusian League (British)</option>
<option value=431> Malthusian theory</option>
<option value=432>-- opposition to</option>
<option value=692>---- Marxists and</option>
<option value=246> Marchant, James</option>
<option value=389> Marion, Kitty</option>
<option value=28> marriage</option>
<option value=422>-- MS on</option>
<option value=657>-- reforms</option>
<option value=718> marriage age</option>
<option value=719>-- men</option>
<option value=720>-- women</option>
<option value=393> Martens, R. C.</option>
<option value=727> Marxism and Marxists</option>
<option value=774>-- birth control and</option>
<option value=728>-- MS on</option>
<option value=314> masturbation</option>
<option value=182> men</option>
<option value=529>-- birth control and</option>
<option value=183>-- marriage age</option>
<option value=272>-- reproductive choices and decisions</option>
<option value=267>-- sexual fulfillment of</option>
<option value=646> mental capacity</option>
<option value=155> mentally disabled and diseased</option>
<option value=599>-- birth control and</option>
<option value=472>-- fertility and birth rate of</option>
<option value=903>-- fertility of</option>
<option value=586> Mexico</option>
<option value=587>-- descriptions of</option>
<option value=627> Michigan</option>
<option value=628>-- birth control in</option>
<option value=629> middle classes</option>
<option value=630>-- birth control and</option>
<option value=576> midwives</option>
<option value=577>-- birth control and</option>
<option value=578>-- MS on</option>
<option value=602> milk stations</option>
<option value=466> Mindell, Fania</option>
<option value=631> Missouri</option>
<option value=632>-- birth control in</option>
<option value=497> Modern School movement</option>
<option value=498>-- in Spain</option>
<option value=829> morality</option>
<option value=830>-- infant</option>
<option value=868> mortality</option>
<option value=869>-- infant</option>
<option value=26> mortality rates</option>
<option value=27>-- infant</option>
<option value=236>-- maternal</option>
<option value=603> mother's pensions</option>
<option value=273> motherhood</option>
<option value=614>-- conscripted</option>
<option value=669>-- consripted</option>
<option value=743>-- MS on</option>
<option value=612> Mussolini, Benito</option>
<option value=613>-- policy of</option>
<option value=569> Mussolini, Benito Amilcare Andrea</option>
<option value=857> National Committee on Federal Legislation for Birt</option>
<option value=858>-- goals of</option>
<option value=163> National Committee on Federal Legislation for Birt</option>
<option value=164>-- birth control bills</option>
<option value=847> National Committee on Federal Legislation for Birt</option>
<option value=780> National Committee on Federal Legislation for Birt</option>
<option value=781>-- goals of</option>
<option value=608> National Committee on Federal Legislation for Birt</option>
<option value=609>-- goals of</option>
<option value=177> National Conference of Labor Women (England, 1925)</option>
<option value=178> National Council of Public Morals (1925, England)</option>
<option value=885> neo-Malthusianism</option>
<option value=10> Netherlands, the</option>
<option value=871>-- birth control clinics and leagues</option>
<option value=11>-- birth control in</option>
<option value=845>-- conditions in</option>
<option value=408>-- MS in</option>
<option value=436>-- population policies in</option>
<option value=433>-- socioeconomic conditions</option>
<option value=434> Netherlands, the+</option>
<option value=435>-- women in</option>
<option value=411> New Deal</option>
<option value=148> New York</option>
<option value=331>-- birth control in</option>
<option value=149>-- sex education in</option>
<option value=150> New York City</option>
<option value=390>-- birth control and</option>
<option value=151>-- birth control in</option>
<option value=282>-- mortality rate</option>
<option value=283>---- infant</option>
<option value=394>-- working classes in</option>
<option value=535> New York Society for the Suppression of Vice</option>
<option value=825> New York Women's Publishing Co.</option>
<option value=284> New Zealand</option>
<option value=285>-- birth rates in</option>
<option value=345>-- conditions in</option>
<option value=800> Nietzsche, Frederick</option>
<option value=254> North Carolina</option>
<option value=255>-- birth control in</option>
<option value=362> nurses</option>
<option value=363>-- birth control and</option>
<option value=579>-- MS on</option>
<option value=366> obscenity</option>
<option value=552> Ohio</option>
<option value=553>-- birth control in</option>
<option value=633> Oregon</option>
<option value=634>-- birth control in</option>
<option value=615> overpopulation</option>
<option value=654>-- emigration and</option>
<option value=309> parenthood</option>
<option value=310>-- MS on</option>
<option value=606> parents associations</option>
<option value=607>-- New York, NY</option>
<option value=527> peace</option>
<option value=528>-- MS on</option>
<option value=554> peace movement and pacifism</option>
<option value=600> physically disabled and diseased</option>
<option value=601>-- birth control and</option>
<option value=12> physicians</option>
<option value=13>-- birth control and</option>
<option value=268>-- MS on</option>
<option value=152>-- women</option>
<option value=377> Planned Parenthood Federation of America</option>
<option value=700> Poets</option>
<option value=346> politicians</option>
<option value=347>-- birth control and</option>
<option value=842> Pope Pius XI</option>
<option value=843>-- Encyclical letter by</option>
<option value=188> Pope Piux XI</option>
<option value=189>-- Encyclical letter by</option>
<option value=219> population</option>
<option value=378>-- birth control and</option>
<option value=814>-- British Empire and</option>
<option value=704>-- control of</option>
<option value=395>-- excess</option>
<option value=396>-- food supply and</option>
<option value=220>-- war and</option>
<option value=247> population control</option>
<option value=248>-- government policies</option>
<option value=249>---- in England</option>
<option value=447>-- MS on</option>
<option value=397>-- public reaction to</option>
<option value=143> population growth</option>
<option value=144>-- natural resources and</option>
<option value=145>-- regulation of</option>
<option value=146>-- standard of living and</option>
<option value=473>-- war and</option>
<option value=499> Portet, Lorenzo</option>
<option value=584>-- MS on</option>
<option value=368> Post Office (U.S.)</option>
<option value=90> poverty</option>
<option value=91>-- family size and</option>
<option value=114> pregnancy</option>
<option value=115>-- fears of</option>
<option value=805> progress</option>
<option value=338> propaganda</option>
<option value=339>-- MS on</option>
<option value=516> prostitution</option>
<option value=698>-- birth control and</option>
<option value=784>-- MS on</option>
<option value=306> public health</option>
<option value=307>-- birth control and</option>
<option value=308>---- </option>
<option value=840> Puerto Rico</option>
<option value=888>-- birth control in</option>
<option value=841>-- maternal mortality rates in</option>
<option value=313> quackery</option>
<option value=179> Quakers (Society of Friends)</option>
<option value=180>-- birth control and</option>
<option value=274> race suicide</option>
<option value=132> racial/ethnic references</option>
<option value=133>-- to African-Americans</option>
<option value=221> racial and ethnic references</option>
<option value=222>-- to Jews</option>
<option value=574>-- to Spaniards</option>
<option value=735> racial ethnic references</option>
<option value=737>-- to Dutch</option>
<option value=738>-- to Germans</option>
<option value=736>-- to Irish</option>
<option value=762> radical labor movements</option>
<option value=336> radicals</option>
<option value=585>-- in Spain</option>
<option value=337>-- MS on</option>
<option value=706>-- suppression and deportation of</option>
<option value=742> reincarnation</option>
<option value=621> religion</option>
<option value=622>-- MS on</option>
<option value=532> reproduction</option>
<option value=462> reproductive responsibility</option>
<option value=693> Robin, Paul</option>
<option value=223> Roman Empire</option>
<option value=224>-- birth control and</option>
<option value=225> Roosevelt, Theodore</option>
<option value=226>-- MS on</option>
<option value=181> Royal Institute of Public Health (England)</option>
<option value=481> Russia</option>
<option value=482>-- population policies</option>
<option value=116> Sachs, Sadie (story)</option>
<option value=589> Sanger, Magaret</option>
<option value=590>-- autobiographical</option>
<option value=99> Sanger, Margaret</option>
<option value=260>-- arrests</option>
<option value=731>-- arrests and trial of</option>
<option value=419>-- autobiographical</option>
<option value=782>-- awards</option>
<option value=465>-- background of</option>
<option value=364>-- biography</option>
<option value=100>-- descriptions of</option>
<option value=451>-- exile, 1914-15</option>
<option value=165>-- nursing and</option>
<option value=237>-- speaking tours</option>
<option value=635>---- 1916 (U.S.)</option>
<option value=332>---- 1919 (U.S.)</option>
<option value=460>---- 1922 (Japan)</option>
<option value=714>---- 1932 (U.S.)</option>
<option value=238>---- 1935-1936 (India)</option>
<option value=834>---- 1936 (India)</option>
<option value=461>---- 1954 (Japan)</option>
<option value=65> Sanger, Margaret Louise Higgins</option>
<option value=391>-- arrests</option>
<option value=66>-- autobiographical writings</option>
<option value=775>-- speaking tours</option>
<option value=776>---- 1920 (England)</option>
<option value=810>---- 1922 (World)</option>
<option value=375>-- unauthorized use of name</option>
<option value=665> Sanger, William</option>
<option value=666>-- arrest, trial and imprisonment</option>
<option value=476> Scotland</option>
<option value=674>-- descriptions of</option>
<option value=477>-- MS on</option>
<option value=117> sex education</option>
<option value=118>-- birth control and</option>
<option value=119>-- need for</option>
<option value=659>-- parental responsibility and</option>
<option value=882> sex reform</option>
<option value=205> sexual desire</option>
<option value=21> sexuality</option>
<option value=823>-- men's</option>
<option value=859>-- MS on</option>
<option value=22>-- women's</option>
<option value=515>-- working class</option>
<option value=764> Sixth International Neo-Malthusian and Birth Contr</option>
<option value=581> Smith, Alfred E.</option>
<option value=57> socialism</option>
<option value=512>-- and art</option>
<option value=875>-- in Germany</option>
<option value=768>-- MS on</option>
<option value=642> society</option>
<option value=643>-- responsibility and</option>
<option value=134> Southern States</option>
<option value=437> Soviet Union</option>
<option value=438>-- birth control in</option>
<option value=500> Spain</option>
<option value=502>-- anticlericalism in</option>
<option value=573>-- MS on</option>
<option value=501>-- political conditions in</option>
<option value=820>-- socioeconomic conditions</option>
<option value=860> spirituality</option>
<option value=861>-- MS on</option>
<option value=206> St. Augustine</option>
<option value=208> St. Mark</option>
<option value=207> St. Matthew</option>
<option value=792> sterility</option>
<option value=793>-- birth control and</option>
<option value=37> sterilization</option>
<option value=757>-- benefits and risks of</option>
<option value=575>-- candidates for</option>
<option value=760>-- in Sweden</option>
<option value=761>-- in United State</option>
<option value=850>-- methods</option>
<option value=647>-- methods and devices</option>
<option value=311>-- methods of</option>
<option value=38>-- MS on</option>
<option value=758> sterlization</option>
<option value=759>-- methods of</option>
<option value=694> Stoecker, Helene</option>
<option value=153> Stone, Hannah Mayer</option>
<option value=154>-- MS on</option>
<option value=815> Stopes, Marie C.</option>
<option value=777> Stopes, Marie Carmichael</option>
<option value=695> Stritt, Marie</option>
<option value=806> technology</option>
<option value=901> Thorpe, Herbert A.</option>
<option value=746> Tisserant, Eugene</option>
<option value=866> Town Hall raid</option>
<option value=92> unfit to reproduce</option>
<option value=93>-- MS on</option>
<option value=88> United States</option>
<option value=89>-- charitable relief in</option>
<option value=821>-- descriptions of</option>
<option value=549>-- expansion of</option>
<option value=120>-- government</option>
<option value=121>---- birth control and</option>
<option value=256>---- public health programs</option>
<option value=275>-- population of</option>
<option value=385>-- population policies</option>
<option value=348>-- population policies of</option>
<option value=320>-- socio-economic conditions in</option>
<option value=418>-- socioeconomic conditions</option>
<option value=333>-- southern region</option>
<option value=479>-- western region</option>
<option value=48> United States Children's Bureau</option>
<option value=667> United States Congress</option>
<option value=592> United States government</option>
<option value=593>-- birth control and</option>
<option value=648>-- public health programs</option>
<option value=474> upper classes</option>
<option value=475>-- birth control and</option>
<option value=550> Vanderlip, Frank A.</option>
<option value=243> venereal disease</option>
<option value=785>-- alcohol and</option>
<option value=287>-- and war</option>
<option value=245>-- gonorrhea</option>
<option value=286>-- prevention of</option>
<option value=244>-- syphilis</option>
<option value=699> venereal diseases</option>
<option value=531> voluntary motherhood</option>
<option value=322> war</option>
<option value=833>-- birth control and</option>
<option value=538>-- causes of</option>
<option value=323>-- marriage and</option>
<option value=807>-- nuclear</option>
<option value=769> welfare capitalism</option>
<option value=770>-- MS on</option>
<option value=300> Wells, H.G.</option>
<option value=636> Wisconsin</option>
<option value=637>-- birth control in</option>
<option value=880> Witcop, Rose</option>
<option value=392> Woman's Suffrage Party</option>
<option value=326> Woman Rebel</option>
<option value=572>-- articles in</option>
<option value=795>-- birth control and</option>
<option value=367>-- legal case</option>
<option value=327>-- suppression of</option>
<option value=168> woman suffrage</option>
<option value=386>-- MS on</option>
<option value=169>-- working women and</option>
<option value=18> women</option>
<option value=122>-- birth control and</option>
<option value=530>-- employment of</option>
<option value=20>-- enslavement of</option>
<option value=19>-- freedom and rights of</option>
<option value=668>-- gender roles</option>
<option value=86>-- gender roles and</option>
<option value=40>-- health of</option>
<option value=184>-- marriage age</option>
<option value=87>-- maternal feelings</option>
<option value=41>-- reproductive choices and decisions</option>
<option value=269>-- sexual freedom and fulfillment</option>
<option value=778> Women's Cooperative Guild (England)</option>
<option value=711> working class</option>
<option value=887>-- revolution and</option>
<option value=712>-- women and girls</option>
<option value=42> working classes</option>
<option value=783>-- alcohol and</option>
<option value=877>-- birth control</option>
<option value=43>-- birth control and</option>
<option value=123>-- children</option>
<option value=398>-- conditions of</option>
<option value=124>-- fertility of</option>
<option value=125>-- living conditions of</option>
<option value=356>-- men and boys</option>
<option value=588>-- MS on</option>
<option value=786>-- nutrition and</option>
<option value=321>-- revolution and</option>
<option value=651>-- war and</option>
<option value=126>-- women and girls</option>
<option value=452> world peace</option>
<option value=453>-- MS on</option>
<option value=594> World Population Conference</option>
<option value=84> World War I</option>
<option value=555>-- anti-war efforts</option>
<option value=288>-- MS on</option>
<option value=85>-- population and</option>
<option value=749>-- travel during</option>
<option value=734>-- U.S. Entry</option>
<option value=649>-- women and</option>
<option value=445> World War II</option>
<option value=446>-- MS on</option>
<option value=558>-- origins of</option>
<option value=483>-- population and</option>
<option value=763>-- women and</option>
<option value=14> xxxx</option>
<!--built by UltraTree v.1.1 http://www.tourbase.ru/zink/-->
</select>					</td>
					</tr>
				<tr>
						<td>
							&nbsp; 
						</td>
						<td>
							<i>(search within a specific subject index)</i> 
						</td>
				</tr>
				<tr>
						<td>
							&nbsp;
						</td>
				</tr>
				<tr> 
					<td> 
						<h3>Mentions:</h3> 
					</td> 
				</tr> 
				<tr> <!-- mentioned places -JR --> 
					<td class="searchLabelCell"> 
						<b>place: &nbsp;</b> 
					</td> 
					<td> 
						<select name="mentionedPlace" style="width: 400px;"> 
							<option value=''></option>
                                  <option value=''></option>                                   <option value='Aden, Yemen'>Aden, Yemen</option>                                   <option value='Adyar, India'>Adyar, India</option>                                   <option value='Africa'>Africa</option>                                   <option value='Akron, OH'>Akron, OH</option>                                   <option value='Alabama'>Alabama</option>                                   <option value='Alahabad, India'>Alahabad, India</option>                                   <option value='Alaska'>Alaska</option>                                   <option value='Albany, NY'>Albany, NY</option>                                   <option value='Alexandria, Egypt'>Alexandria, Egypt</option>                                   <option value='Allahabad, India'>Allahabad, India</option>                                   <option value='Alsace-Lorraine, France'>Alsace-Lorraine, France</option>                                   <option value='America'>America</option>                                   <option value='Amesterdam, the Netherlands'>Amesterdam, the Netherlands</option>                                   <option value='Amsterdam, Netherlands'>Amsterdam, Netherlands</option>                                   <option value='Amsterdam, the Netherlands'>Amsterdam, the Netherlands</option>                                   <option value='Argentina'>Argentina</option>                                   <option value='Arizona'>Arizona</option>                                   <option value='Arkansas'>Arkansas</option>                                   <option value='Arlington, VA'>Arlington, VA</option>                                   <option value='Asia'>Asia</option>                                   <option value='Atlantic City, NJ'>Atlantic City, NJ</option>                                   <option value='Austin, Texas'>Austin, Texas</option>                                   <option value='Australia'>Australia</option>                                   <option value='Austria'>Austria</option>                                   <option value='Baltimore, Maryland'>Baltimore, Maryland</option>                                   <option value='Baltimore, MD'>Baltimore, MD</option>                                   <option value='Bangalore, India'>Bangalore, India</option>                                   <option value='Barbados'>Barbados</option>                                   <option value='Barcelona, Spain'>Barcelona, Spain</option>                                   <option value='Baroda, India'>Baroda, India</option>                                   <option value='Bataan, Phillipines'>Bataan, Phillipines</option>                                   <option value='Beijing, China'>Beijing, China</option>                                   <option value='Belgium'>Belgium</option>                                   <option value='Benares, India'>Benares, India</option>                                   <option value='Bengal, India'>Bengal, India</option>                                   <option value='Berks County, PA'>Berks County, PA</option>                                   <option value='Berlin, Germany'>Berlin, Germany</option>                                   <option value='Bermuda'>Bermuda</option>                                   <option value='Birmingham, England'>Birmingham, England</option>                                   <option value='Bolougne, France'>Bolougne, France</option>                                   <option value='Bombay, India'>Bombay, India</option>                                   <option value='Boston, MA'>Boston, MA</option>                                   <option value='Boston, Massachusetts'>Boston, Massachusetts</option>                                   <option value='Bournemouth, England'>Bournemouth, England</option>                                   <option value='Brazil'>Brazil</option>                                   <option value='Bridgeport, CT'>Bridgeport, CT</option>                                   <option value='Brighton, England'>Brighton, England</option>                                   <option value='Bristol, England'>Bristol, England</option>                                   <option value='Britain'>Britain</option>                                   <option value='British Empire'>British Empire</option>                                   <option value='British Isles'>British Isles</option>                                   <option value='British West Indies'>British West Indies</option>                                   <option value='Brixton, England'>Brixton, England</option>                                   <option value='Brooklyn, New York'>Brooklyn, New York</option>                                   <option value='Brooklyn, New York City, NY'>Brooklyn, New York City, NY</option>                                   <option value='Brooklyn, New York, United States'>Brooklyn, New York, United States</option>                                   <option value='Brooklyn, NY'>Brooklyn, NY</option>                                   <option value='Brownsville, NY'>Brownsville, NY</option>                                   <option value='Brussels, Belgium'>Brussels, Belgium</option>                                   <option value='Buenos Ayres, Argentina'>Buenos Ayres, Argentina</option>                                   <option value='Buffalo, NY'>Buffalo, NY</option>                                   <option value='Burma'>Burma</option>                                   <option value='Butte, MT'>Butte, MT</option>                                   <option value='CA'>CA</option>                                   <option value='Cairo, Egypt'>Cairo, Egypt</option>                                   <option value='Calcutta, India'>Calcutta, India</option>                                   <option value='Calicut, India'>Calicut, India</option>                                   <option value='California'>California</option>                                   <option value='Cambridge, England'>Cambridge, England</option>                                   <option value='Cambridge, MA'>Cambridge, MA</option>                                   <option value='Camp Pike, AK'>Camp Pike, AK</option>                                   <option value='Camp Upton, AK'>Camp Upton, AK</option>                                   <option value='Canada'>Canada</option>                                   <option value='Cape Cod, MA'>Cape Cod, MA</option>                                   <option value='Catalonia, Spain'>Catalonia, Spain</option>                                   <option value='central Europe'>central Europe</option>                                   <option value='Ceylon'>Ceylon</option>                                   <option value='Charleston, WV'>Charleston, WV</option>                                   <option value='Charlottesville, VA'>Charlottesville, VA</option>                                   <option value='Cheltenham, England'>Cheltenham, England</option>                                   <option value='Chicago, IL'>Chicago, IL</option>                                   <option value='Chicago, Illinois'>Chicago, Illinois</option>                                   <option value='China'>China</option>                                   <option value='Cincinatti, OH'>Cincinatti, OH</option>                                   <option value='Cincinnati, OH'>Cincinnati, OH</option>                                   <option value='Cleveland, OH'>Cleveland, OH</option>                                   <option value='College Point, NY'>College Point, NY</option>                                   <option value='Colombo, Ceylon'>Colombo, Ceylon</option>                                   <option value='Colorado'>Colorado</option>                                   <option value='Connecticut'>Connecticut</option>                                   <option value='Continent'>Continent</option>                                   <option value='Cornwall, England'>Cornwall, England</option>                                   <option value='CT'>CT</option>                                   <option value='Cuba'>Cuba</option>                                   <option value='Death Valley, CA'>Death Valley, CA</option>                                   <option value='Delaware'>Delaware</option>                                   <option value='Delhi, India'>Delhi, India</option>                                   <option value='Denmark'>Denmark</option>                                   <option value='Denver, CO'>Denver, CO</option>                                   <option value='Detroit, MI'>Detroit, MI</option>                                   <option value='Dieppe, France'>Dieppe, France</option>                                   <option value='District of Columbia'>District of Columbia</option>                                   <option value='District of Columbia, United States'>District of Columbia, United States</option>                                   <option value='Dresden, Germany'>Dresden, Germany</option>                                   <option value='Earth'>Earth</option>                                   <option value='Edinburgh, Scotland'>Edinburgh, Scotland</option>                                   <option value='Egypt'>Egypt</option>                                   <option value='Elizabeth City, NC'>Elizabeth City, NC</option>                                   <option value='England'>England</option>                                   <option value='Ethiopia'>Ethiopia</option>                                   <option value='Europe'>Europe</option>                                   <option value='Fall River, MA'>Fall River, MA</option>                                   <option value='Far East'>Far East</option>                                   <option value='Fishkill, NY'>Fishkill, NY</option>                                   <option value='Florida'>Florida</option>                                   <option value='Folkestone, England'>Folkestone, England</option>                                   <option value='Folkstone, England'>Folkstone, England</option>                                   <option value='Formosa'>Formosa</option>                                   <option value='France'>France</option>                                   <option value='Friedrichshafen, Germany'>Friedrichshafen, Germany</option>                                   <option value='Fusan, Japan'>Fusan, Japan</option>                                   <option value='Fuzan, Japan'>Fuzan, Japan</option>                                   <option value='Garden City, New York'>Garden City, New York</option>                                   <option value='Geneva, IL'>Geneva, IL</option>                                   <option value='Geneva, Switzerland'>Geneva, Switzerland</option>                                   <option value='Genva, Switzerland'>Genva, Switzerland</option>                                   <option value='Georgia'>Georgia</option>                                   <option value='Germany'>Germany</option>                                   <option value='Gibraltar'>Gibraltar</option>                                   <option value='Gibralter'>Gibralter</option>                                   <option value='Glasgow, Scotland'>Glasgow, Scotland</option>                                   <option value='Great Britain'>Great Britain</option>                                   <option value='Great Britian'>Great Britian</option>                                   <option value='Greece'>Greece</option>                                   <option value='Hagerstown, MD'>Hagerstown, MD</option>                                   <option value='Hague, Netherlands'>Hague, Netherlands</option>                                   <option value='Hague, the Netherlands'>Hague, the Netherlands</option>                                   <option value='Haledon, NJ'>Haledon, NJ</option>                                   <option value='Halluin, France'>Halluin, France</option>                                   <option value='Hamilton, Bermuda'>Hamilton, Bermuda</option>                                   <option value='Harlem'>Harlem</option>                                   <option value='Harold J. Cox'>Harold J. Cox</option>                                   <option value='Hartford, CT'>Hartford, CT</option>                                   <option value='Hawaii'>Hawaii</option>                                   <option value='Hayword, CA'>Hayword, CA</option>                                   <option value='Hazelton, Pa.'>Hazelton, Pa.</option>                                   <option value='Hazleton, PA'>Hazleton, PA</option>                                   <option value='Himalayas'>Himalayas</option>                                   <option value='Hoboken, NJ'>Hoboken, NJ</option>                                   <option value='Holland'>Holland</option>                                   <option value='Hollywood, California'>Hollywood, California</option>                                   <option value='Hong Kong'>Hong Kong</option>                                   <option value='Hong Kong, China'>Hong Kong, China</option>                                   <option value='Honolulu, HI'>Honolulu, HI</option>                                   <option value='Houston, TX'>Houston, TX</option>                                   <option value='Hungary'>Hungary</option>                                   <option value='Huntington, WV'>Huntington, WV</option>                                   <option value='Hyderabad, India'>Hyderabad, India</option>                                   <option value='Iceland'>Iceland</option>                                   <option value='Idaho'>Idaho</option>                                   <option value='Illinois'>Illinois</option>                                   <option value='India'>India</option>                                   <option value='Indiana'>Indiana</option>                                   <option value='Indianapolis'>Indianapolis</option>                                   <option value='Indianapolis, IN'>Indianapolis, IN</option>                                   <option value='Iowa'>Iowa</option>                                   <option value='Ireland'>Ireland</option>                                   <option value='Israel'>Israel</option>                                   <option value='Italy'>Italy</option>                                   <option value='Jamaica'>Jamaica</option>                                   <option value='Japan'>Japan</option>                                   <option value='Kandy, Ceylon'>Kandy, Ceylon</option>                                   <option value='Kansas'>Kansas</option>                                   <option value='Kashmir, India'>Kashmir, India</option>                                   <option value='Kentucky'>Kentucky</option>                                   <option value='Kobe, Japan'>Kobe, Japan</option>                                   <option value='Korea'>Korea</option>                                   <option value='Kyoto'>Kyoto</option>                                   <option value='Kyoto, Japan'>Kyoto, Japan</option>                                   <option value='Kyushu, Japan'>Kyushu, Japan</option>                                   <option value='Lake Erie'>Lake Erie</option>                                   <option value='Lancashire, England'>Lancashire, England</option>                                   <option value='Latin America'>Latin America</option>                                   <option value='Lawrence, MA'>Lawrence, MA</option>                                   <option value='Leeds, England'>Leeds, England</option>                                   <option value='Liege, Belgium'>Liege, Belgium</option>                                   <option value='Lille, France'>Lille, France</option>                                   <option value='Lithuania'>Lithuania</option>                                   <option value='Little Falls, NY'>Little Falls, NY</option>                                   <option value='Liverpool, England'>Liverpool, England</option>                                   <option value='London'>London</option>                                   <option value='London, England'>London, England</option>                                   <option value='London, United Kingdom'>London, United Kingdom</option>                                   <option value='Long Island City, NY'>Long Island City, NY</option>                                   <option value='Long Island, NY'>Long Island, NY</option>                                   <option value='Los Angeles, CA'>Los Angeles, CA</option>                                   <option value='Los Angeles, California'>Los Angeles, California</option>                                   <option value='Los Angles, CA'>Los Angles, CA</option>                                   <option value='Louisiana'>Louisiana</option>                                   <option value='Lowell, MA'>Lowell, MA</option>                                   <option value='Lower East Side'>Lower East Side</option>                                   <option value='Lucknow, India'>Lucknow, India</option>                                   <option value='Ludlow, CO'>Ludlow, CO</option>                                   <option value='MA'>MA</option>                                   <option value='Madagascar'>Madagascar</option>                                   <option value='Madras, India'>Madras, India</option>                                   <option value='Madrid, Spain'>Madrid, Spain</option>                                   <option value='Maine'>Maine</option>                                   <option value='Malaya'>Malaya</option>                                   <option value='Malta'>Malta</option>                                   <option value='Manchuko'>Manchuko</option>                                   <option value='Manchukuo'>Manchukuo</option>                                   <option value='Manchuria'>Manchuria</option>                                   <option value='Manchuria, China'>Manchuria, China</option>                                   <option value='Mars'>Mars</option>                                   <option value='Mars-en-Barzoeuf'>Mars-en-Barzoeuf</option>                                   <option value='Maryland'>Maryland</option>                                   <option value='Massachusetts'>Massachusetts</option>                                   <option value='Mecca, Saudia Arabia'>Mecca, Saudia Arabia</option>                                   <option value='Memphis, TN'>Memphis, TN</option>                                   <option value='Mesopotamia'>Mesopotamia</option>                                   <option value='Mexico'>Mexico</option>                                   <option value='Michigan'>Michigan</option>                                   <option value='Middlesex'>Middlesex</option>                                   <option value='Milan, Italy'>Milan, Italy</option>                                   <option value='Milwaukee, WI'>Milwaukee, WI</option>                                   <option value='Milwaukee, Wisconsin'>Milwaukee, Wisconsin</option>                                   <option value='Minneapolis, MN'>Minneapolis, MN</option>                                   <option value='Minnesota'>Minnesota</option>                                   <option value='Mississippi'>Mississippi</option>                                   <option value='Missouri'>Missouri</option>                                   <option value='MN'>MN</option>                                   <option value='Montana'>Montana</option>                                   <option value='Montjuich'>Montjuich</option>                                   <option value='Morocco'>Morocco</option>                                   <option value='Moscow, Soviet Union'>Moscow, Soviet Union</option>                                   <option value='Munich Germany'>Munich Germany</option>                                   <option value='Munich, Germany'>Munich, Germany</option>                                   <option value='Mysore City, India'>Mysore City, India</option>                                   <option value='Mysore, India'>Mysore, India</option>                                   <option value='Nagoya, Japan'>Nagoya, Japan</option>                                   <option value='Nara'>Nara</option>                                   <option value='Nashville, Tennessee'>Nashville, Tennessee</option>                                   <option value='Nazareth, Pa.'>Nazareth, Pa.</option>                                   <option value='NE'>NE</option>                                   <option value='near east'>near east</option>                                   <option value='Nebraska'>Nebraska</option>                                   <option value='Netherlands'>Netherlands</option>                                   <option value='Netherlands, Amsterdam'>Netherlands, Amsterdam</option>                                   <option value='Netherlands, the'>Netherlands, the</option>                                   <option value='Netherlands, The Hague'>Netherlands, The Hague</option>                                   <option value='Nevada'>Nevada</option>                                   <option value='New Castle, PA'>New Castle, PA</option>                                   <option value='New Delhi, India'>New Delhi, India</option>                                   <option value='New England'>New England</option>                                   <option value='New Hampshire'>New Hampshire</option>                                   <option value='New Haven, CT'>New Haven, CT</option>                                   <option value='New Jersey'>New Jersey</option>                                   <option value='New Mexico'>New Mexico</option>                                   <option value='New Rochelle, NY'>New Rochelle, NY</option>                                   <option value='New York'>New York</option>                                   <option value='New York City'>New York City</option>                                   <option value='New York City, New York'>New York City, New York</option>                                   <option value='New York City, NY'>New York City, NY</option>                                   <option value='New York State'>New York State</option>                                   <option value='New York, N.Y.'>New York, N.Y.</option>                                   <option value='New York, NY'>New York, NY</option>                                   <option value='New York,NY'>New York,NY</option>                                   <option value='New Zealand'>New Zealand</option>                                   <option value='Newark, NJ'>Newark, NJ</option>                                   <option value='Newport, RI'>Newport, RI</option>                                   <option value='Nikko'>Nikko</option>                                   <option value='NJ'>NJ</option>                                   <option value='North America'>North America</option>                                   <option value='North Atlantic'>North Atlantic</option>                                   <option value='North Carolina'>North Carolina</option>                                   <option value='North Carolina, United States'>North Carolina, United States</option>                                   <option value='North Dakota'>North Dakota</option>                                   <option value='Northern China'>Northern China</option>                                   <option value='Northern Ireland'>Northern Ireland</option>                                   <option value='Norway'>Norway</option>                                   <option value='NY'>NY</option>                                   <option value='Oakland, CA'>Oakland, CA</option>                                   <option value='Occident'>Occident</option>                                   <option value='Ohio'>Ohio</option>                                   <option value='Oklahoma'>Oklahoma</option>                                   <option value='Oregon'>Oregon</option>                                   <option value='Orient'>Orient</option>                                   <option value='Osaka, Japan'>Osaka, Japan</option>                                   <option value='Ossawatomie, KS'>Ossawatomie, KS</option>                                   <option value='Oyster Bay, NY'>Oyster Bay, NY</option>                                   <option value='PA'>PA</option>                                   <option value='Pacific'>Pacific</option>                                   <option value='Pakistan'>Pakistan</option>                                   <option value='Palestine'>Palestine</option>                                   <option value='Paris'>Paris</option>                                   <option value='Paris, France'>Paris, France</option>                                   <option value='Paris,France'>Paris,France</option>                                   <option value='Pasadena, CA'>Pasadena, CA</option>                                   <option value='Paterson, NJ'>Paterson, NJ</option>                                   <option value='Pearl Harbor, Hawaii'>Pearl Harbor, Hawaii</option>                                   <option value='Pearl Harbor, HI'>Pearl Harbor, HI</option>                                   <option value='Penang, Malaya'>Penang, Malaya</option>                                   <option value='Penang, Malaysia'>Penang, Malaysia</option>                                   <option value='Penn, England'>Penn, England</option>                                   <option value='Pennsylvania'>Pennsylvania</option>                                   <option value='Pennsylvania, United States'>Pennsylvania, United States</option>                                   <option value='Perpignan, France'>Perpignan, France</option>                                   <option value='Phila, Pa'>Phila, Pa</option>                                   <option value='Philadelphia, PA'>Philadelphia, PA</option>                                   <option value='Philadelphia, PA.'>Philadelphia, PA.</option>                                   <option value='Philippine Islands'>Philippine Islands</option>                                   <option value='Philippines'>Philippines</option>                                   <option value='Pitssburgh, PA'>Pitssburgh, PA</option>                                   <option value='Pittsburgh, PA'>Pittsburgh, PA</option>                                   <option value='Poland'>Poland</option>                                   <option value='Poona, India'>Poona, India</option>                                   <option value='Portbou, France'>Portbou, France</option>                                   <option value='Portbou, Spain'>Portbou, Spain</option>                                   <option value='Portland, OR'>Portland, OR</option>                                   <option value='Portugal'>Portugal</option>                                   <option value='Providence, RI'>Providence, RI</option>                                   <option value='Provincetown, MA'>Provincetown, MA</option>                                   <option value='Puerto Rico'>Puerto Rico</option>                                   <option value='Punjab, India'>Punjab, India</option>                                   <option value='Racine, WI'>Racine, WI</option>                                   <option value='Rangoon, Burma'>Rangoon, Burma</option>                                   <option value='Rhode Island'>Rhode Island</option>                                   <option value='Richen, Germany'>Richen, Germany</option>                                   <option value='Richmond, VA'>Richmond, VA</option>                                   <option value='Rochester, NY'>Rochester, NY</option>                                   <option value='Rome'>Rome</option>                                   <option value='Rome, Italy'>Rome, Italy</option>                                   <option value='Rotterdam, Netherlands'>Rotterdam, Netherlands</option>                                   <option value='Rotterdam, the Netherlands'>Rotterdam, the Netherlands</option>                                   <option value='Rouen, France'>Rouen, France</option>                                   <option value='Russia'>Russia</option>                                   <option value='Sacramento, CA'>Sacramento, CA</option>                                   <option value='Sahara Desert'>Sahara Desert</option>                                   <option value='Salem, MA'>Salem, MA</option>                                   <option value='Salem, Massachusetts'>Salem, Massachusetts</option>                                   <option value='San Antonio, TX'>San Antonio, TX</option>                                   <option value='San Diego, CA'>San Diego, CA</option>                                   <option value='San Francisco, CA'>San Francisco, CA</option>                                   <option value='San Francisco, California, USA'>San Francisco, California, USA</option>                                   <option value='San Juan, Puerto Rico'>San Juan, Puerto Rico</option>                                   <option value='Scandinavia'>Scandinavia</option>                                   <option value='Scandinavian countries'>Scandinavian countries</option>                                   <option value='Scotland'>Scotland</option>                                   <option value='Seattle, WA'>Seattle, WA</option>                                   <option value='Sebere, Spain'>Sebere, Spain</option>                                   <option value='Seoul, Korea'>Seoul, Korea</option>                                   <option value='Shanghai, China'>Shanghai, China</option>                                   <option value='Siberia, Soviet Union'>Siberia, Soviet Union</option>                                   <option value='Singapore'>Singapore</option>                                   <option value='South Africa'>South Africa</option>                                   <option value='South America'>South America</option>                                   <option value='South Carolina'>South Carolina</option>                                   <option value='South Dakota'>South Dakota</option>                                   <option value='South Pacific'>South Pacific</option>                                   <option value='Soviet Union'>Soviet Union</option>                                   <option value='Spain'>Spain</option>                                   <option value='Spokane, WA'>Spokane, WA</option>                                   <option value='Springfield, IL'>Springfield, IL</option>                                   <option value='St. George, Bermuda'>St. George, Bermuda</option>                                   <option value='St. Louis, MO'>St. Louis, MO</option>                                   <option value='St. Louis, Mo.'>St. Louis, Mo.</option>                                   <option value='St. Paul, MN'>St. Paul, MN</option>                                   <option value='St. Pol, France'>St. Pol, France</option>                                   <option value='Stockholm, Sweden'>Stockholm, Sweden</option>                                   <option value='Sweden'>Sweden</option>                                   <option value='Switzerland'>Switzerland</option>                                   <option value='Syria'>Syria</option>                                   <option value='Tarrytown, NY'>Tarrytown, NY</option>                                   <option value='Tennessee'>Tennessee</option>                                   <option value='Texas'>Texas</option>                                   <option value='the Americas'>the Americas</option>                                   <option value='The Hague, Netherlands'>The Hague, Netherlands</option>                                   <option value='The Hague, the Netherlands'>The Hague, the Netherlands</option>                                   <option value='the Marianne Islands, Micronesia'>the Marianne Islands, Micronesia</option>                                   <option value='The Netherlands'>The Netherlands</option>                                   <option value='the Orient'>the Orient</option>                                   <option value='Tokyo, Japan'>Tokyo, Japan</option>                                   <option value='Toyko, Japan'>Toyko, Japan</option>                                   <option value='Trans-Jordan'>Trans-Jordan</option>                                   <option value='Transjordania'>Transjordania</option>                                   <option value='Travancore, India'>Travancore, India</option>                                   <option value='Triplicane, India'>Triplicane, India</option>                                   <option value='Trivandrum, India'>Trivandrum, India</option>                                   <option value='Tucson, AR'>Tucson, AR</option>                                   <option value='Tucson, Arizona'>Tucson, Arizona</option>                                   <option value='Turin, Italy'>Turin, Italy</option>                                   <option value='Turkey'>Turkey</option>                                   <option value='U.S.S.R.'>U.S.S.R.</option>                                   <option value='Union of Soviet Socialist Republics'>Union of Soviet Socialist Republics</option>                                   <option value='United Kingdom'>United Kingdom</option>                                   <option value='United State'>United State</option>                                   <option value='United States'>United States</option>                                   <option value='United States of America'>United States of America</option>                                   <option value='Unites States of America'>Unites States of America</option>                                   <option value='Utah'>Utah</option>                                   <option value='Utopia'>Utopia</option>                                   <option value='Utrecht, Netherlands'>Utrecht, Netherlands</option>                                   <option value='Vatican City'>Vatican City</option>                                   <option value='Vera Cruz, Mexico'>Vera Cruz, Mexico</option>                                   <option value='Verdun, France'>Verdun, France</option>                                   <option value='Vermont'>Vermont</option>                                   <option value='Versailles, France'>Versailles, France</option>                                   <option value='Vich, Spain'>Vich, Spain</option>                                   <option value='Vienna, Austria'>Vienna, Austria</option>                                   <option value='Virgin Islands'>Virgin Islands</option>                                   <option value='Virginia'>Virginia</option>                                   <option value='Wales'>Wales</option>                                   <option value='Wardha, India'>Wardha, India</option>                                   <option value='Warsaw, Poland'>Warsaw, Poland</option>                                   <option value='Washington'>Washington</option>                                   <option value='Washington D. C.'>Washington D. C.</option>                                   <option value='Washington D.C'>Washington D.C</option>                                   <option value='Washington D.C.'>Washington D.C.</option>                                   <option value='Washington, D. C.'>Washington, D. C.</option>                                   <option value='Washington, D.C'>Washington, D.C</option>                                   <option value='Washington, D.C.'>Washington, D.C.</option>                                   <option value='Washington, D.C., United States'>Washington, D.C., United States</option>                                   <option value='Washington, DC'>Washington, DC</option>                                   <option value='Washtington, D.C.'>Washtington, D.C.</option>                                   <option value='West Bengal, India'>West Bengal, India</option>                                   <option value='West Berlin, Federal Republic of Germany'>West Berlin, Federal Republic of Germany</option>                                   <option value='west Germany'>west Germany</option>                                   <option value='West Indian federation'>West Indian federation</option>                                   <option value='West Virginia'>West Virginia</option>                                   <option value='Western Hemisphere'>Western Hemisphere</option>                                   <option value='White Plains, NY'>White Plains, NY</option>                                   <option value='Wilkes-Barre, PA'>Wilkes-Barre, PA</option>                                   <option value='Wisconsin'>Wisconsin</option>                                   <option value='WV'>WV</option>                                   <option value='Wyoming'>Wyoming</option>                                   <option value='Yokahama, Japan'>Yokahama, Japan</option>                                   <option value='Yokohama, Japan'>Yokohama, Japan</option>                                   <option value='Zurich, Switzerland'>Zurich, Switzerland</option>  
						</select> 
					</td> 
				</tr>  
				<tr> 
					<td></td> 
					<td> 
						<i>(find documents that mention a particular place)</i>
					</td> 
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr> <!-- mentioned person -JR --> 
					<td class="searchLabelCell"> 
						<b>person: &nbsp;</b> 
					</td> 
					<td> 
						<select name="mentionedPerson" style="width: 400px;"> 
							<option value=''></option>
                                  <option value='-MARGARET SANGER'>-MARGARET SANGER</option>                                   <option value='Abott, H.P. Almon'>Abott, H.P. Almon</option>                                   <option value='Abraham Lincoln'>Abraham Lincoln</option>                                   <option value='Abraham Stone'>Abraham Stone</option>                                   <option value='Ackerman, Edward'>Ackerman, Edward</option>                                   <option value='Ackerman, Frances'>Ackerman, Frances</option>                                   <option value='Ackermann, Frances B.'>Ackermann, Frances B.</option>                                   <option value='Adam'>Adam</option>                                   <option value='Adams, Grantley Herbert'>Adams, Grantley Herbert</option>                                   <option value='Adams, James Truslow'>Adams, James Truslow</option>                                   <option value='add name'>add name</option>                                   <option value='Adler, Alfred'>Adler, Alfred</option>                                   <option value='Adolf Hitler'>Adolf Hitler</option>                                   <option value='Adolph Lessig'>Adolph Lessig</option>                                   <option value='Akihito'>Akihito</option>                                   <option value='Albert Einstein'>Albert Einstein</option>                                   <option value='Albert Ludwig Sigesmund Niesser'>Albert Ludwig Sigesmund Niesser</option>                                   <option value='Aletta Jacobs'>Aletta Jacobs</option>                                   <option value='Alexander M. Thompson'>Alexander M. Thompson</option>                                   <option value='Alexander Scott'>Alexander Scott</option>                                   <option value='Alfred Fournier'>Alfred Fournier</option>                                   <option value='Alfred Franzis Pribram'>Alfred Franzis Pribram</option>                                   <option value='Alice B. Stockham'>Alice B. Stockham</option>                                   <option value='Alice Drydale Vickery'>Alice Drydale Vickery</option>                                   <option value='Allen, Frederick H.'>Allen, Frederick H.</option>                                   <option value='Allison, Van Kleeck'>Allison, Van Kleeck</option>                                   <option value='Alphonso XIII of Spain'>Alphonso XIII of Spain</option>                                   <option value='Alzalde, Eugenio'>Alzalde, Eugenio</option>                                   <option value='Amano, Kageyasu'>Amano, Kageyasu</option>                                   <option value='Ambassador'>Ambassador</option>                                   <option value='Amrit Kaur, Rajkumari'>Amrit Kaur, Rajkumari</option>                                   <option value='Anatole France'>Anatole France</option>                                   <option value='Anna Reynolds Cassidente'>Anna Reynolds Cassidente</option>                                   <option value='Anna Ross Weeks'>Anna Ross Weeks</option>                                   <option value='Anne H. Wilcox'>Anne H. Wilcox</option>                                   <option value='Anne Purcell Higgins'>Anne Purcell Higgins</option>                                   <option value='Annie Besant'>Annie Besant</option>                                   <option value='Annie Kenney'>Annie Kenney</option>                                   <option value='Anthony Comstock'>Anthony Comstock</option>                                   <option value='Anthony, Susan B.'>Anthony, Susan B.</option>                                   <option value='Anthony, Susan Brownell'>Anthony, Susan Brownell</option>                                   <option value='Archer, William'>Archer, William</option>                                   <option value='Aristocles'>Aristocles</option>                                   <option value='Aristotle'>Aristotle</option>                                   <option value='Arnold Bennett'>Arnold Bennett</option>                                   <option value='Arnold, Julia Francis'>Arnold, Julia Francis</option>                                   <option value='Arnold, Matthew'>Arnold, Matthew</option>                                   <option value='Arthur Conan Doyle'>Arthur Conan Doyle</option>                                   <option value='Arthur Hayday'>Arthur Hayday</option>                                   <option value='Arthur James Balfour'>Arthur James Balfour</option>                                   <option value='Arthur Sullivan'>Arthur Sullivan</option>                                   <option value='Arturo Giovannitti'>Arturo Giovannitti</option>                                   <option value='Arundale, George'>Arundale, George</option>                                   <option value='Ashley, Jessie'>Ashley, Jessie</option>                                   <option value='August Forel'>August Forel</option>                                   <option value='AUGUSTE COMTE'>AUGUSTE COMTE</option>                                   <option value='Augustine'>Augustine</option>                                   <option value='Aylmer Maude'>Aylmer Maude</option>                                   <option value='Baden Powell'>Baden Powell</option>                                   <option value='Baker, Josephine'>Baker, Josephine</option>                                   <option value='Baker, Polly'>Baker, Polly</option>                                   <option value='Bakunin, Mikhail'>Bakunin, Mikhail</option>                                   <option value='Bamberger, Charles'>Bamberger, Charles</option>                                   <option value='Bamberger, Charles J.'>Bamberger, Charles J.</option>                                   <option value='Barnes, Ernest William'>Barnes, Ernest William</option>                                   <option value='Bass, Edith Harland Bird'>Bass, Edith Harland Bird</option>                                   <option value='Beatrice Fairfax'>Beatrice Fairfax</option>                                   <option value='Beatrice Forbes-Robertson Hale'>Beatrice Forbes-Robertson Hale</option>                                   <option value='Beatrice Webb'>Beatrice Webb</option>                                   <option value='BECCARIA'>BECCARIA</option>                                   <option value='Becker, Bernard'>Becker, Bernard</option>                                   <option value='Beebe, Gilbert W.'>Beebe, Gilbert W.</option>                                   <option value='Benedetto Croce'>Benedetto Croce</option>                                   <option value='Benito Mussolini'>Benito Mussolini</option>                                   <option value='Benjamin Barr Lindsey'>Benjamin Barr Lindsey</option>                                   <option value='Bennett, Arnold'>Bennett, Arnold</option>                                   <option value='Bennett, Enoch Arnold'>Bennett, Enoch Arnold</option>                                   <option value='Bent, M.J.'>Bent, M.J.</option>                                   <option value='Bercker, Bernard'>Bercker, Bernard</option>                                   <option value='Berg, Charles'>Berg, Charles</option>                                   <option value='Bergson, Henri'>Bergson, Henri</option>                                   <option value='Bernard John Seymour, Lord Coleridge'>Bernard John Seymour, Lord Coleridge</option>                                   <option value='Bernhardi, Friedrich von'>Bernhardi, Friedrich von</option>                                   <option value='Bernstein, ?'>Bernstein, ?</option>                                   <option value='Bertillon, Jacques'>Bertillon, Jacques</option>                                   <option value='Bertrand E. Dawson'>Bertrand E. Dawson</option>                                   <option value='Bertrand Russell'>Bertrand Russell</option>                                   <option value='Besant, Anne'>Besant, Anne</option>                                   <option value='Besant, Annie'>Besant, Annie</option>                                   <option value='Bessede, G.'>Bessede, G.</option>                                   <option value='Bessie Ingham Drysdale'>Bessie Ingham Drysdale</option>                                   <option value='Beverly, James Rumsey'>Beverly, James Rumsey</option>                                   <option value='Biggs, Hermann M.'>Biggs, Hermann M.</option>                                   <option value='Bill Sikes'>Bill Sikes</option>                                   <option value='Blacker, C. P.'>Blacker, C. P.</option>                                   <option value='Blake, William'>Blake, William</option>                                   <option value='Blanchard, Paul'>Blanchard, Paul</option>                                   <option value='Blank, Mrs.'>Blank, Mrs.</option>                                   <option value='Blavatsky, Helena'>Blavatsky, Helena</option>                                   <option value='Bloch, Iwan'>Bloch, Iwan</option>                                   <option value='Block, Iwan'>Block, Iwan</option>                                   <option value='Blossom, Frederick A.'>Blossom, Frederick A.</option>                                   <option value='Bocker, Dorothy'>Bocker, Dorothy</option>                                   <option value='Bonaparte, Napoleon'>Bonaparte, Napoleon</option>                                   <option value='Boyce, Neith'>Boyce, Neith</option>                                   <option value='Bradlaugh, Charles'>Bradlaugh, Charles</option>                                   <option value='Bradlaw, Charles'>Bradlaw, Charles</option>                                   <option value='Braga, A.J.'>Braga, A.J.</option>                                   <option value='Breed, Mary'>Breed, Mary</option>                                   <option value='Bridget C. Peixotto'>Bridget C. Peixotto</option>                                   <option value='Brodie, W. Hugh'>Brodie, W. Hugh</option>                                   <option value='Broun, Heywood Campbell'>Broun, Heywood Campbell</option>                                   <option value='Brown, Harrison'>Brown, Harrison</option>                                   <option value='Brown, Royal L.'>Brown, Royal L.</option>                                   <option value='Brown, W. E.'>Brown, W. E.</option>                                   <option value='Browne, Arthur Heber'>Browne, Arthur Heber</option>                                   <option value='Bruere, Robert'>Bruere, Robert</option>                                   <option value='Bruno, Giordano'>Bruno, Giordano</option>                                   <option value='Brush, Dorothy'>Brush, Dorothy</option>                                   <option value='Brush, Dorothy Hamilton'>Brush, Dorothy Hamilton</option>                                   <option value='Bryan Donkin'>Bryan Donkin</option>                                   <option value='Buck, Pearl'>Buck, Pearl</option>                                   <option value='Buckmaster, Stanley'>Buckmaster, Stanley</option>                                   <option value='Buddha'>Buddha</option>                                   <option value='Burbank, Luther'>Burbank, Luther</option>                                   <option value='Burch, Guy Irving'>Burch, Guy Irving</option>                                   <option value='Burr, Emily T.'>Burr, Emily T.</option>                                   <option value='Butterfield, Oliver M.'>Butterfield, Oliver M.</option>                                   <option value='Byrne, Ethel'>Byrne, Ethel</option>                                   <option value='Byrne, Ethel Higgins'>Byrne, Ethel Higgins</option>                                   <option value='C. W. Saleeby'>C. W. Saleeby</option>                                   <option value='Caesar, Julius'>Caesar, Julius</option>                                   <option value='Cai, Yuanpei'>Cai, Yuanpei</option>                                   <option value='Caligula'>Caligula</option>                                   <option value='Campbell, Harold G.'>Campbell, Harold G.</option>                                   <option value='Candide'>Candide</option>                                   <option value='Cannon, Mary Antoinette'>Cannon, Mary Antoinette</option>                                   <option value='Carli, Mario'>Carli, Mario</option>                                   <option value='Carlile, Richard'>Carlile, Richard</option>                                   <option value='Carlo Tresca'>Carlo Tresca</option>                                   <option value='Carlyle, Thomas'>Carlyle, Thomas</option>                                   <option value='Caron, Arthur'>Caron, Arthur</option>                                   <option value='Carpenter, Edward'>Carpenter, Edward</option>                                   <option value='Carr-Saunders, Alexander'>Carr-Saunders, Alexander</option>                                   <option value='Carr-Saunders, Alexander Morris'>Carr-Saunders, Alexander Morris</option>                                   <option value='Catherine II of Russia'>Catherine II of Russia</option>                                   <option value='Catherine II, of Russia'>Catherine II, of Russia</option>                                   <option value='Chamberlain, Mary'>Chamberlain, Mary</option>                                   <option value='Chambers, Robert'>Chambers, Robert</option>                                   <option value='Chance, Clinton'>Chance, Clinton</option>                                   <option value='Chance, Clinton F.'>Chance, Clinton F.</option>                                   <option value='Chandrasekar, Sripati'>Chandrasekar, Sripati</option>                                   <option value='Chang, Min Chueh'>Chang, Min Chueh</option>                                   <option value='Chapelier, Emile'>Chapelier, Emile</option>                                   <option value='Charles Bradlaugh'>Charles Bradlaugh</option>                                   <option value='Charles Cline'>Charles Cline</option>                                   <option value='Charles Darwin'>Charles Darwin</option>                                   <option value='Charles de Secondat, Baron de la Br et de Montesquieu'>Charles de Secondat, Baron de la Br et de Montesquieu</option>                                   <option value='Charles Knowlton'>Charles Knowlton</option>                                   <option value='Charles Louis Chassaignac'>Charles Louis Chassaignac</option>                                   <option value='Charles Robert Drysdale'>Charles Robert Drysdale</option>                                   <option value='Charles Sims'>Charles Sims</option>                                   <option value='Charles Vickery Drysdale'>Charles Vickery Drysdale</option>                                   <option value='Charlotte Bronte Emily Bronte'>Charlotte Bronte Emily Bronte</option>                                   <option value='Charlotte Perkins Gilman'>Charlotte Perkins Gilman</option>                                   <option value='Chatterton-Hill, Georges'>Chatterton-Hill, Georges</option>                                   <option value='Chesterton, G. K.'>Chesterton, G. K.</option>                                   <option value='Cheyney, Ralph'>Cheyney, Ralph</option>                                   <option value='Chimna Bai II'>Chimna Bai II</option>                                   <option value='Christ'>Christ</option>                                   <option value='Christabel Pankhurst'>Christabel Pankhurst</option>                                   <option value='Cisneros, Jose Abraham'>Cisneros, Jose Abraham</option>                                   <option value='Clark, John Proctor'>Clark, John Proctor</option>                                   <option value='Clayton, Henry Delamar'>Clayton, Henry Delamar</option>                                   <option value='Clayton, Henry Delamar, Jr.'>Clayton, Henry Delamar, Jr.</option>                                   <option value='Clemenceau, Georges'>Clemenceau, Georges</option>                                   <option value='Clinchy, Russell J.'>Clinchy, Russell J.</option>                                   <option value='Cline, Charles'>Cline, Charles</option>                                   <option value='Coghill, Harvie'>Coghill, Harvie</option>                                   <option value='Cohen, Melvin R.'>Cohen, Melvin R.</option>                                   <option value='Cole, Leon J.'>Cole, Leon J.</option>                                   <option value='Colquitt, Oscar B.'>Colquitt, Oscar B.</option>                                   <option value='Colt, Elizabeth W.'>Colt, Elizabeth W.</option>                                   <option value='Columbus, Christopher'>Columbus, Christopher</option>                                   <option value='Compton, Karl'>Compton, Karl</option>                                   <option value='Compton, Karl Taylor'>Compton, Karl Taylor</option>                                   <option value='Comstock, Anita'>Comstock, Anita</option>                                   <option value='Comstock, Anthony'>Comstock, Anthony</option>                                   <option value='Comstock. Anthony'>Comstock. Anthony</option>                                   <option value='Confucius'>Confucius</option>                                   <option value='Conrad, Earl'>Conrad, Earl</option>                                   <option value='Content, Harold'>Content, Harold</option>                                   <option value='Content, Harold A.'>Content, Harold A.</option>                                   <option value='Coolidge, Calvin'>Coolidge, Calvin</option>                                   <option value='Cooper Rawson'>Cooper Rawson</option>                                   <option value='Cooper, George M.'>Cooper, George M.</option>                                   <option value='Cooper, James'>Cooper, James</option>                                   <option value='Cooper, James F.'>Cooper, James F.</option>                                   <option value='Cooper, James Freyer'>Cooper, James Freyer</option>                                   <option value='Cooper, James Wayne'>Cooper, James Wayne</option>                                   <option value='Coppola, Francesco'>Coppola, Francesco</option>                                   <option value='Cornwall, Bill A.'>Cornwall, Bill A.</option>                                   <option value='Count Cowamura'>Count Cowamura</option>                                   <option value='Cousins, Margaret Elizabeth'>Cousins, Margaret Elizabeth</option>                                   <option value='Cox, Harold'>Cox, Harold</option>                                   <option value='Crane, Frederick E.'>Crane, Frederick E.</option>                                   <option value='Cravello, Victor'>Cravello, Victor</option>                                   <option value='Creadick, A. N.'>Creadick, A. N.</option>                                   <option value='Crew, Francis Albert Eley'>Crew, Francis Albert Eley</option>                                   <option value='Cropsey, James C.'>Cropsey, James C.</option>                                   <option value='Cummings, Homer S.'>Cummings, Homer S.</option>                                   <option value='Cummings, Homer Stile'>Cummings, Homer Stile</option>                                   <option value='Cummings, Homer Stille'>Cummings, Homer Stille</option>                                   <option value='Cyon, Francoisee'>Cyon, Francoisee</option>                                   <option value='Czar Nicholas II of Russia'>Czar Nicholas II of Russia</option>                                   <option value='Daniel McKelvey'>Daniel McKelvey</option>                                   <option value='Darrow, Clarence'>Darrow, Clarence</option>                                   <option value='Darwin, Charles'>Darwin, Charles</option>                                   <option value='Davidson, Colin J.'>Davidson, Colin J.</option>                                   <option value='Davis, Katerine Bement'>Davis, Katerine Bement</option>                                   <option value='Davis, Katherine Bennett'>Davis, Katherine Bennett</option>                                   <option value='Dawson, Bertrand'>Dawson, Bertrand</option>                                   <option value='Dawson, Bertrand Edward'>Dawson, Bertrand Edward</option>                                   <option value='Dayton, Alston G.'>Dayton, Alston G.</option>                                   <option value='de Beer-Meijers'>de Beer-Meijers</option>                                   <option value='de Buen, Odon'>de Buen, Odon</option>                                   <option value='De Gourmont, Remy'>De Gourmont, Remy</option>                                   <option value='De Plauzoles, Sicard'>De Plauzoles, Sicard</option>                                   <option value='De Silver, Albert'>De Silver, Albert</option>                                   <option value='de Vries'>de Vries</option>                                   <option value='deBeer-Meijers, Clara'>deBeer-Meijers, Clara</option>                                   <option value='Dekker, Meta M.'>Dekker, Meta M.</option>                                   <option value='del Caserello, Antonio Canovas'>del Caserello, Antonio Canovas</option>                                   <option value='del Marmol, Tarrida'>del Marmol, Tarrida</option>                                   <option value='Delafield, Charlotte Wyeth'>Delafield, Charlotte Wyeth</option>                                   <option value='Dell, Floyd'>Dell, Floyd</option>                                   <option value='Dell, Robert'>Dell, Robert</option>                                   <option value='Denman, Gertrude Mary'>Denman, Gertrude Mary</option>                                   <option value='Dennett, Mary Ware'>Dennett, Mary Ware</option>                                   <option value='Desai, Mahadev'>Desai, Mahadev</option>                                   <option value='Dever, Paul A.'>Dever, Paul A.</option>                                   <option value='Dewees, Lovett'>Dewees, Lovett</option>                                   <option value='Dewey, John'>Dewey, John</option>                                   <option value='Dickinson, Robert Latou'>Dickinson, Robert Latou</option>                                   <option value='Dill, Thomas Melville, Colonel'>Dill, Thomas Melville, Colonel</option>                                   <option value='Dill, Thomas Melville, Lieutenant-Colonel'>Dill, Thomas Melville, Lieutenant-Colonel</option>                                   <option value='Dineen, Joseph P.'>Dineen, Joseph P.</option>                                   <option value='Dix, Arthur'>Dix, Arthur</option>                                   <option value='Dixelles, ?'>Dixelles, ?</option>                                   <option value='Dodge, Eva'>Dodge, Eva</option>                                   <option value='Donahue, Thomas'>Donahue, Thomas</option>                                   <option value='Dora Marsden'>Dora Marsden</option>                                   <option value='Doran, Martin F.'>Doran, Martin F.</option>                                   <option value='Dorothy Dix'>Dorothy Dix</option>                                   <option value='Dorothy Hamilton Brush'>Dorothy Hamilton Brush</option>                                   <option value='Dorr, Rheta Childe'>Dorr, Rheta Childe</option>                                   <option value='Dr. Pangloss'>Dr. Pangloss</option>                                   <option value='Dr. Prince A. Morrow'>Dr. Prince A. Morrow</option>                                   <option value='Draupadi'>Draupadi</option>                                   <option value='Drysdale, Bessie Ingham'>Drysdale, Bessie Ingham</option>                                   <option value='Drysdale, Charles R.'>Drysdale, Charles R.</option>                                   <option value='Drysdale, Charles Robert'>Drysdale, Charles Robert</option>                                   <option value='Drysdale, Charles Vichery'>Drysdale, Charles Vichery</option>                                   <option value='Drysdale, Charles Vickery'>Drysdale, Charles Vickery</option>                                   <option value='Drysdale, George'>Drysdale, George</option>                                   <option value='Drysdale, George R.'>Drysdale, George R.</option>                                   <option value='Drysdale, George Robert'>Drysdale, George Robert</option>                                   <option value='Dunbar, Helen Flanders'>Dunbar, Helen Flanders</option>                                   <option value='E. Goldstein'>E. Goldstein</option>                                   <option value='E. W. Barnes'>E. W. Barnes</option>                                   <option value='East, E.M.'>East, E.M.</option>                                   <option value='East, Edward M.'>East, Edward M.</option>                                   <option value='East, Edward Murray'>East, Edward Murray</option>                                   <option value='Eastman, Nicholson J.'>Eastman, Nicholson J.</option>                                   <option value='Eden, Thomas Watts'>Eden, Thomas Watts</option>                                   <option value='Edgar Sydenstricker'>Edgar Sydenstricker</option>                                   <option value='Edgar, J. Clifton'>Edgar, J. Clifton</option>                                   <option value='Edin, Karl'>Edin, Karl</option>                                   <option value='Edith Houghton Hooker'>Edith Houghton Hooker</option>                                   <option value='Edith How-Martin'>Edith How-Martin</option>                                   <option value='Edward Bond Foote'>Edward Bond Foote</option>                                   <option value='Edward Carpenter'>Edward Carpenter</option>                                   <option value='Edward F. Cassidy'>Edward F. Cassidy</option>                                   <option value='Edward Jenner'>Edward Jenner</option>                                   <option value='Edward M. Barrow'>Edward M. Barrow</option>                                   <option value='Edward Morgan'>Edward Morgan</option>                                   <option value='Edward VIII (king of England)'>Edward VIII (king of England)</option>                                   <option value='Edward, Prince of Wales'>Edward, Prince of Wales</option>                                   <option value='Edwin Holt'>Edwin Holt</option>                                   <option value='Eilpern, Jacob'>Eilpern, Jacob</option>                                   <option value='Einstein, Albert'>Einstein, Albert</option>                                   <option value='Eliot, George'>Eliot, George</option>                                   <option value='Elischer, Julius'>Elischer, Julius</option>                                   <option value='Elizabeth Gurley Flynn'>Elizabeth Gurley Flynn</option>                                   <option value='Ellen Key'>Ellen Key</option>                                   <option value='Ellen Wilkinson'>Ellen Wilkinson</option>                                   <option value='Elliot, Dr.'>Elliot, Dr.</option>                                   <option value='Ellis, Edith'>Ellis, Edith</option>                                   <option value='Ellis, Edward Peppen'>Ellis, Edward Peppen</option>                                   <option value='Ellis, Havelock'>Ellis, Havelock</option>                                   <option value='Ellis, Henry Havelock'>Ellis, Henry Havelock</option>                                   <option value='Ellsworth Huntington'>Ellsworth Huntington</option>                                   <option value='Elmhirst, Dorothy Payne Whitney Straight'>Elmhirst, Dorothy Payne Whitney Straight</option>                                   <option value='Emerson, John Haven'>Emerson, John Haven</option>                                   <option value='Emerson, Ralph Waldo'>Emerson, Ralph Waldo</option>                                   <option value='EMILE ZOLA'>EMILE ZOLA</option>                                   <option value='Emma Goldman'>Emma Goldman</option>                                   <option value='Emmeline Pankhurst'>Emmeline Pankhurst</option>                                   <option value='English, O. Spurgeon'>English, O. Spurgeon</option>                                   <option value='Ernest, Victor'>Ernest, Victor</option>                                   <option value='Ernst, Morris L.'>Ernst, Morris L.</option>                                   <option value='Ernst, Morris Leopold'>Ernst, Morris Leopold</option>                                   <option value='Errico Malatesta'>Errico Malatesta</option>                                   <option value='Erskine, John Francis Ashley'>Erskine, John Francis Ashley</option>                                   <option value='Ervin, Charles W.'>Ervin, Charles W.</option>                                   <option value='Ettor, Joseph'>Ettor, Joseph</option>                                   <option value='EUGENE BRIEUX'>EUGENE BRIEUX</option>                                   <option value='EUGENE HUMBERT'>EUGENE HUMBERT</option>                                   <option value='Eugenia of Spain'>Eugenia of Spain</option>                                   <option value='Eulenberg, ?'>Eulenberg, ?</option>                                   <option value='Evangeline Booth'>Evangeline Booth</option>                                   <option value='Evans, Herbert Maclean'>Evans, Herbert Maclean</option>                                   <option value='Evans, Leonard Wynne'>Evans, Leonard Wynne</option>                                   <option value='Eve'>Eve</option>                                   <option value='F. C. D. Hicks'>F. C. D. Hicks</option>                                   <option value='F. J. Taussig'>F. J. Taussig</option>                                   <option value='F. McM.'>F. McM.</option>                                   <option value='Fairchild, Henry Pratt'>Fairchild, Henry Pratt</option>                                   <option value='Falk, I. S.'>Falk, I. S.</option>                                   <option value='Faure, Sebastian'>Faure, Sebastian</option>                                   <option value='Fenollosa, Ernest'>Fenollosa, Ernest</option>                                   <option value='Ferch, Johann'>Ferch, Johann</option>                                   <option value='Ferdinand Mascaux'>Ferdinand Mascaux</option>                                   <option value='Ferdinand V of Spain'>Ferdinand V of Spain</option>                                   <option value='Ferguson, Lindo'>Ferguson, Lindo</option>                                   <option value='Ferrer, Francisco'>Ferrer, Francisco</option>                                   <option value='Ferrer,Franciso'>Ferrer,Franciso</option>                                   <option value='Findley, Palmer'>Findley, Palmer</option>                                   <option value='Fineshriber, William H.'>Fineshriber, William H.</option>                                   <option value='Fischer-Duckelmann, Anna'>Fischer-Duckelmann, Anna</option>                                   <option value='Fishbein, Morris'>Fishbein, Morris</option>                                   <option value='Fitch, John A.'>Fitch, John A.</option>                                   <option value='Flora Drummond'>Flora Drummond</option>                                   <option value='Floyd Dell'>Floyd Dell</option>                                   <option value='Forel, Auguste'>Forel, Auguste</option>                                   <option value='Fosdick, Harry Emerson'>Fosdick, Harry Emerson</option>                                   <option value='Foster Kennedy'>Foster Kennedy</option>                                   <option value='Francis Place'>Francis Place</option>                                   <option value='Francis Thompson'>Francis Thompson</option>                                   <option value='Francis, Saint'>Francis, Saint</option>                                   <option value='Francisco Madero'>Francisco Madero</option>                                   <option value='Frank E. Vogel'>Frank E. Vogel</option>                                   <option value='Frank Harris'>Frank Harris</option>                                   <option value='Frank Tannenbaum'>Frank Tannenbaum</option>                                   <option value='Fred Adair'>Fred Adair</option>                                   <option value='Frederick Crane'>Frederick Crane</option>                                   <option value='Frederick H. Gillett'>Frederick H. Gillett</option>                                   <option value='Frederick Haddon'>Frederick Haddon</option>                                   <option value='Frederick M. Elliot'>Frederick M. Elliot</option>                                   <option value='Frederick Sumner Boyd'>Frederick Sumner Boyd</option>                                   <option value='Freschi, John J.'>Freschi, John J.</option>                                   <option value='Freud, Sigmund'>Freud, Sigmund</option>                                   <option value='Friedrich Nietzsche'>Friedrich Nietzsche</option>                                   <option value='G. B.'>G. B.</option>                                   <option value='G. St. J. Perrott'>G. St. J. Perrott</option>                                   <option value='Gabriel Giroud'>Gabriel Giroud</option>                                   <option value='Gamble, Clarence'>Gamble, Clarence</option>                                   <option value='Gamble, Clarence J.'>Gamble, Clarence J.</option>                                   <option value='Gamble, Clarence James'>Gamble, Clarence James</option>                                   <option value='Gana, Francisco'>Gana, Francisco</option>                                   <option value='Gandhi, Devdas'>Gandhi, Devdas</option>                                   <option value='Gandhi, Kanti Harilal'>Gandhi, Kanti Harilal</option>                                   <option value='Gandhi, Kasturba Nakanji'>Gandhi, Kasturba Nakanji</option>                                   <option value='Gandhi, Mahandas'>Gandhi, Mahandas</option>                                   <option value='Gandhi, Mohandas K.'>Gandhi, Mohandas K.</option>                                   <option value='Garrett, Elizabeth H.'>Garrett, Elizabeth H.</option>                                   <option value='Garrison, William Lloyd'>Garrison, William Lloyd</option>                                   <option value='Geisler, Murray'>Geisler, Murray</option>                                   <option value='Genghis Khan'>Genghis Khan</option>                                   <option value='George Bernard Shaw'>George Bernard Shaw</option>                                   <option value='George Carrel'>George Carrel</option>                                   <option value='George De Forest Brush'>George De Forest Brush</option>                                   <option value='George Drysdale'>George Drysdale</option>                                   <option value='George Eliot'>George Eliot</option>                                   <option value='George Kirkpatrick'>George Kirkpatrick</option>                                   <option value='George Lansbury'>George Lansbury</option>                                   <option value='George V of England'>George V of England</option>                                   <option value='George W. Crile'>George W. Crile</option>                                   <option value='George Washington'>George Washington</option>                                   <option value='Ghandi, Mohandas'>Ghandi, Mohandas</option>                                   <option value='Gibbs, Phillip'>Gibbs, Phillip</option>                                   <option value='Gilbert Murray'>Gilbert Murray</option>                                   <option value='Gillett, Frederick'>Gillett, Frederick</option>                                   <option value='Gillett, Frederick Huntington'>Gillett, Frederick Huntington</option>                                   <option value='Gillett, John'>Gillett, John</option>                                   <option value='Gilmore, John'>Gilmore, John</option>                                   <option value='Giroud, Gabriel'>Giroud, Gabriel</option>                                   <option value='Goddard, Henry H.'>Goddard, Henry H.</option>                                   <option value='Goering, Hermann Ernst'>Goering, Hermann Ernst</option>                                   <option value='Goering, Hermann Wilhelm'>Goering, Hermann Wilhelm</option>                                   <option value='Goerring, Hermann'>Goerring, Hermann</option>                                   <option value='Goldstein, ?'>Goldstein, ?</option>                                   <option value='Goldstein, Jonah J.'>Goldstein, Jonah J.</option>                                   <option value='Goldstein, Leopold Z.'>Goldstein, Leopold Z.</option>                                   <option value='Gopalaswami, R.A.'>Gopalaswami, R.A.</option>                                   <option value='Gorgas, William'>Gorgas, William</option>                                   <option value='Gottfried Wilhelm von Leibniz'>Gottfried Wilhelm von Leibniz</option>                                   <option value='Gottschlak, Dr.'>Gottschlak, Dr.</option>                                   <option value='Grafenberg, Ernst'>Grafenberg, Ernst</option>                                   <option value='Grand, Nicholas'>Grand, Nicholas</option>                                   <option value='Grandjean, Valentin'>Grandjean, Valentin</option>                                   <option value='Grant Sanger'>Grant Sanger</option>                                   <option value='Green, Susan'>Green, Susan</option>                                   <option value='Griffith, Edward Fyfe'>Griffith, Edward Fyfe</option>                                   <option value='Grover N. Whalen'>Grover N. Whalen</option>                                   <option value='Grover Whalen'>Grover Whalen</option>                                   <option value='Gschwend, Herr'>Gschwend, Herr</option>                                   <option value='Gudkin, John'>Gudkin, John</option>                                   <option value='Guggenheim, Benjamin'>Guggenheim, Benjamin</option>                                   <option value='Guglielmo Ferrero'>Guglielmo Ferrero</option>                                   <option value='Gussie Miller'>Gussie Miller</option>                                   <option value='GUSTAVE LE BON'>GUSTAVE LE BON</option>                                   <option value='Guttmacher, Alan F.'>Guttmacher, Alan F.</option>                                   <option value='Guttmacher, Alan Frank'>Guttmacher, Alan Frank</option>                                   <option value='GUY DE MAUPASSANT'>GUY DE MAUPASSANT</option>                                   <option value='Guy, John Henry'>Guy, John Henry</option>                                   <option value='Guyer, Michael Frederic'>Guyer, Michael Frederic</option>                                   <option value='Gyan Chand'>Gyan Chand</option>                                   <option value='H. G. Wells'>H. G. Wells</option>                                   <option value='H. L. Heath'>H. L. Heath</option>                                   <option value='H. Rider Haggard'>H. Rider Haggard</option>                                   <option value='Haber, William'>Haber, William</option>                                   <option value='Haire, Norman'>Haire, Norman</option>                                   <option value='Halton, Mary'>Halton, Mary</option>                                   <option value='Hancock, Frank'>Hancock, Frank</option>                                   <option value='Hand, Augustus N.'>Hand, Augustus N.</option>                                   <option value='Hand, Augustus Noble'>Hand, Augustus Noble</option>                                   <option value='Hand, Billings Learned'>Hand, Billings Learned</option>                                   <option value='Hand, Learned S.'>Hand, Learned S.</option>                                   <option value='Hanihara, Masanao'>Hanihara, Masanao</option>                                   <option value='Hankins, Frank'>Hankins, Frank</option>                                   <option value='Hanson, Carl'>Hanson, Carl</option>                                   <option value='Hapgood, Hutchins'>Hapgood, Hutchins</option>                                   <option value='Hardy, G.'>Hardy, G.</option>                                   <option value='Harman, Moses'>Harman, Moses</option>                                   <option value='Harmon, Moses'>Harmon, Moses</option>                                   <option value='Harold A. Content'>Harold A. Content</option>                                   <option value='Harold Cox'>Harold Cox</option>                                   <option value='Harrison, Hubert'>Harrison, Hubert</option>                                   <option value='Hartman, Carl Gottfried'>Hartman, Carl Gottfried</option>                                   <option value='Hatfield, Henry'>Hatfield, Henry</option>                                   <option value='Havelock Ellis'>Havelock Ellis</option>                                   <option value='Hawthorne, Charles'>Hawthorne, Charles</option>                                   <option value='Hayes, Carlton J. H.'>Hayes, Carlton J. H.</option>                                   <option value='Hayes, Patrick'>Hayes, Patrick</option>                                   <option value='Hayes, Patrick J.'>Hayes, Patrick J.</option>                                   <option value='Hayes, Patrick Joseph'>Hayes, Patrick Joseph</option>                                   <option value='Haywood, William D.'>Haywood, William D.</option>                                   <option value='Hazel Corbin'>Hazel Corbin</option>                                   <option value='Hazel, John Raymond'>Hazel, John Raymond</option>                                   <option value='HÃ¤berlin, Heinrich'>HÃ¤berlin, Heinrich</option>                                   <option value='Hearn, Lafcadio'>Hearn, Lafcadio</option>                                   <option value='Heidelberg, Virginia'>Heidelberg, Virginia</option>                                   <option value='Helen MacMurchy'>Helen MacMurchy</option>                                   <option value='Helene Stoecker'>Helene Stoecker</option>                                   <option value='Henrik Ibsen'>Henrik Ibsen</option>                                   <option value='Henry Lewes'>Henry Lewes</option>                                   <option value='Henry Russell Wakefield'>Henry Russell Wakefield</option>                                   <option value='Henry Siegel'>Henry Siegel</option>                                   <option value='Henshaw, Paul Stewart'>Henshaw, Paul Stewart</option>                                   <option value='Hepburn, Katharine Houghton'>Hepburn, Katharine Houghton</option>                                   <option value='Hepburn, Katherine Houghton'>Hepburn, Katherine Houghton</option>                                   <option value='Herbert A. Thorpe'>Herbert A. Thorpe</option>                                   <option value='Herbert George Wells'>Herbert George Wells</option>                                   <option value='Herbert Hoover'>Herbert Hoover</option>                                   <option value='Herman, Moses'>Herman, Moses</option>                                   <option value='Herod'>Herod</option>                                   <option value='Herod.'>Herod.</option>                                   <option value='Herrick, William W.'>Herrick, William W.</option>                                   <option value='Higgins, Anne Purcell'>Higgins, Anne Purcell</option>                                   <option value='Hildyard, Reginal John Thoroton'>Hildyard, Reginal John Thoroton</option>                                   <option value='Hildyard, Reginald John Thoroton'>Hildyard, Reginald John Thoroton</option>                                   <option value='Himes, Norman E'>Himes, Norman E</option>                                   <option value='Hinz, Dr. ?'>Hinz, Dr. ?</option>                                   <option value='Hirohito'>Hirohito</option>                                   <option value='Hirose, Hisatado'>Hirose, Hisatado</option>                                   <option value='Hirsch, Max'>Hirsch, Max</option>                                   <option value='Hirt, Ludwig'>Hirt, Ludwig</option>                                   <option value='Hitler, Adolf'>Hitler, Adolf</option>                                   <option value='Hlderlin, Friedrich'>Hlderlin, Friedrich</option>                                   <option value='Hodson, Cora'>Hodson, Cora</option>                                   <option value='Hoey, Jane M.'>Hoey, Jane M.</option>                                   <option value='Hoitsema-Rutgers, Marie'>Hoitsema-Rutgers, Marie</option>                                   <option value='Holden, Dr. Frederick C.'>Holden, Dr. Frederick C.</option>                                   <option value='Holden, Frederick'>Holden, Frederick</option>                                   <option value='Holmes, John Haynes'>Holmes, John Haynes</option>                                   <option value='Holmes, Oliver Wendall'>Holmes, Oliver Wendall</option>                                   <option value='Holt, Rackham'>Holt, Rackham</option>                                   <option value='Honda, Chikao'>Honda, Chikao</option>                                   <option value='Hooker, Donald R.'>Hooker, Donald R.</option>                                   <option value='Hoover, Herbert'>Hoover, Herbert</option>                                   <option value='Horace Towner'>Horace Towner</option>                                   <option value='Horder, Thomas'>Horder, Thomas</option>                                   <option value='Horder, Thomas Jeeves'>Horder, Thomas Jeeves</option>                                   <option value='How-Martyn, Edith'>How-Martyn, Edith</option>                                   <option value='Hughes, Alice'>Hughes, Alice</option>                                   <option value='Hugo, Victor'>Hugo, Victor</option>                                   <option value='Hugo, Victor-Marie'>Hugo, Victor-Marie</option>                                   <option value='Husley, Thomas Henry'>Husley, Thomas Henry</option>                                   <option value='Hutchinson'>Hutchinson</option>                                   <option value='Huxley, Aldous'>Huxley, Aldous</option>                                   <option value='Huxley, Julian'>Huxley, Julian</option>                                   <option value='Huxley, Leonard'>Huxley, Leonard</option>                                   <option value='Huxley, Thomas Henry'>Huxley, Thomas Henry</option>                                   <option value='I. D. N.'>I. D. N.</option>                                   <option value='Ibsen, Henrik'>Ibsen, Henrik</option>                                   <option value='Ichabod Crane'>Ichabod Crane</option>                                   <option value='Ichita, Kobashi'>Ichita, Kobashi</option>                                   <option value='Ida Albright'>Ida Albright</option>                                   <option value='Inge, Dean'>Inge, Dean</option>                                   <option value='Inge, William Ralph'>Inge, William Ralph</option>                                   <option value='Ingersoll, Robert G.'>Ingersoll, Robert G.</option>                                   <option value='Ingersoll, Robert Green'>Ingersoll, Robert Green</option>                                   <option value='Irwin, Inez Hayes'>Irwin, Inez Hayes</option>                                   <option value='Isabella I of Spain'>Isabella I of Spain</option>                                   <option value='Isadora Duncan'>Isadora Duncan</option>                                   <option value='Ishimoto, Keikichi'>Ishimoto, Keikichi</option>                                   <option value='Ishimoto, Shidzue Kato'>Ishimoto, Shidzue Kato</option>                                   <option value='Ishiwara'>Ishiwara</option>                                   <option value='Ives, C. P.'>Ives, C. P.</option>                                   <option value='IWAN BLOCH'>IWAN BLOCH</option>                                   <option value='J. A. Serrato'>J. A. Serrato</option>                                   <option value='J. Breen'>J. Breen</option>                                   <option value='J. C. Webster'>J. C. Webster</option>                                   <option value='J. Gonzales'>J. Gonzales</option>                                   <option value='J.O.P. Bland'>J.O.P. Bland</option>                                   <option value='Jack, Cerise Carman'>Jack, Cerise Carman</option>                                   <option value='Jacob Panken'>Jacob Panken</option>                                   <option value='Jacobi, Abraham'>Jacobi, Abraham</option>                                   <option value='Jacobs, Aletta'>Jacobs, Aletta</option>                                   <option value='Jacobs, Morris A.'>Jacobs, Morris A.</option>                                   <option value='Jake Burns'>Jake Burns</option>                                   <option value='James F. Cooper'>James F. Cooper</option>                                   <option value='James H.S. Bossard'>James H.S. Bossard</option>                                   <option value='James Joyce'>James Joyce</option>                                   <option value='James Marchant'>James Marchant</option>                                   <option value='James Russell Lowell'>James Russell Lowell</option>                                   <option value='James S. Wood'>James S. Wood</option>                                   <option value='Jane Addams'>Jane Addams</option>                                   <option value='Japanese Consul General'>Japanese Consul General</option>                                   <option value='Jawaharlal Nehru'>Jawaharlal Nehru</option>                                   <option value='Jean J. Coronel'>Jean J. Coronel</option>                                   <option value='Jean Jacques Rousseau'>Jean Jacques Rousseau</option>                                   <option value='JEAN MARESTAN'>JEAN MARESTAN</option>                                   <option value='Jefferson, Thomas'>Jefferson, Thomas</option>                                   <option value='Jesus Christ'>Jesus Christ</option>                                   <option value='Jesus M. Rangel'>Jesus M. Rangel</option>                                   <option value='Jimmu'>Jimmu</option>                                   <option value='Jingu'>Jingu</option>                                   <option value='Joab H. Banton'>Joab H. Banton</option>                                   <option value='Joan of Arc'>Joan of Arc</option>                                   <option value='Johannes Rutgers'>Johannes Rutgers</option>                                   <option value='John Bagnell Bury'>John Bagnell Bury</option>                                   <option value='John Brown'>John Brown</option>                                   <option value='JOHN BURNS'>JOHN BURNS</option>                                   <option value='John Clifford'>John Clifford</option>                                   <option value='John D. Rockefeller, Jr.'>John D. Rockefeller, Jr.</option>                                   <option value='John F. Hylan'>John F. Hylan</option>                                   <option value='John Galsworthy'>John Galsworthy</option>                                   <option value='John Golden'>John Golden</option>                                   <option value='John Humphrey Noyes'>John Humphrey Noyes</option>                                   <option value='John Maynard Keynes'>John Maynard Keynes</option>                                   <option value='JOHN MORLEY'>JOHN MORLEY</option>                                   <option value='John Mott'>John Mott</option>                                   <option value='John Proctor Clark'>John Proctor Clark</option>                                   <option value='JOHN RUSKIN'>JOHN RUSKIN</option>                                   <option value='John S. Sumner'>John S. Sumner</option>                                   <option value='John Simon'>John Simon</option>                                   <option value='John Stuart Mill'>John Stuart Mill</option>                                   <option value='Johnannes Rutgers'>Johnannes Rutgers</option>                                   <option value='Johns Adams Kingsbury'>Johns Adams Kingsbury</option>                                   <option value='Jonathan Swift'>Jonathan Swift</option>                                   <option value='Jones, F. Robertson'>Jones, F. Robertson</option>                                   <option value='JOSEPH CHAMBERLAIN'>JOSEPH CHAMBERLAIN</option>                                   <option value='Joseph Ettor'>Joseph Ettor</option>                                   <option value='JOSEPH MCCABE'>JOSEPH MCCABE</option>                                   <option value='Jospeh Ettor'>Jospeh Ettor</option>                                   <option value='Juda'>Juda</option>                                   <option value='Judah'>Judah</option>                                   <option value='Judas'>Judas</option>                                   <option value='Jukes'>Jukes</option>                                   <option value='Julia Lathrop'>Julia Lathrop</option>                                   <option value='Julian Street'>Julian Street</option>                                   <option value='Julius Caesar'>Julius Caesar</option>                                   <option value='Jung, Carl'>Jung, Carl</option>                                   <option value='Juris Van Houten'>Juris Van Houten</option>                                   <option value='Justice Coleridge'>Justice Coleridge</option>                                   <option value='Justus Sheffield'>Justus Sheffield</option>                                   <option value='Kaiser Wilhelm II of Germany'>Kaiser Wilhelm II of Germany</option>                                   <option value='Kallikak'>Kallikak</option>                                   <option value='Kamijo, Aiichi'>Kamijo, Aiichi</option>                                   <option value='Kant, Immanuel'>Kant, Immanuel</option>                                   <option value='Karamura, Sumiyoshi,'>Karamura, Sumiyoshi,</option>                                   <option value='Karl Marx'>Karl Marx</option>                                   <option value='Katharine'>Katharine</option>                                   <option value='Katharine Bement Davis'>Katharine Bement Davis</option>                                   <option value='Katherine B. Davis'>Katherine B. Davis</option>                                   <option value='Katherine Vogel'>Katherine Vogel</option>                                   <option value='Kato Shidzue Ishimoto'>Kato Shidzue Ishimoto</option>                                   <option value='Kato, Shidzue'>Kato, Shidzue</option>                                   <option value='Kato, Shidzue Ishimoto'>Kato, Shidzue Ishimoto</option>                                   <option value='Kato, Shizue'>Kato, Shizue</option>                                   <option value='Kaufman, Alvin R.'>Kaufman, Alvin R.</option>                                   <option value='Kaufman, Alvin Ratz'>Kaufman, Alvin Ratz</option>                                   <option value='Kautsky, Karl'>Kautsky, Karl</option>                                   <option value='Kawasaki, Hideji'>Kawasaki, Hideji</option>                                   <option value='Keikichi Ishimoto'>Keikichi Ishimoto</option>                                   <option value='Keller, Arnold'>Keller, Arnold</option>                                   <option value='Keller, Helen'>Keller, Helen</option>                                   <option value='Kennedy, Anne'>Kennedy, Anne</option>                                   <option value='Keynes, John Maynard'>Keynes, John Maynard</option>                                   <option value='Kiersch de Jung'>Kiersch de Jung</option>                                   <option value='Kikuye Yamakawa'>Kikuye Yamakawa</option>                                   <option value='Kind, Philip'>Kind, Philip</option>                                   <option value='Kinsolving, Arthur B.'>Kinsolving, Arthur B.</option>                                   <option value='Kirby, E. Stuart'>Kirby, E. Stuart</option>                                   <option value='Kisch, Heinrich'>Kisch, Heinrich</option>                                   <option value='Kitaoka, Juitsu'>Kitaoka, Juitsu</option>                                   <option value='Kitty Marion'>Kitty Marion</option>                                   <option value='Kleinwachter, ?'>Kleinwachter, ?</option>                                   <option value='Kling, L. E.'>Kling, L. E.</option>                                   <option value='Kling, Llewellyn E.'>Kling, Llewellyn E.</option>                                   <option value='Klotz-Forest, Dr.'>Klotz-Forest, Dr.</option>                                   <option value='Klumpp, James S.'>Klumpp, James S.</option>                                   <option value='Knowlton, Charles'>Knowlton, Charles</option>                                   <option value='Knowlton, Charles L.'>Knowlton, Charles L.</option>                                   <option value='Knut Wicksell'>Knut Wicksell</option>                                   <option value='Koiyama'>Koiyama</option>                                   <option value='Kolney, Fernand'>Kolney, Fernand</option>                                   <option value='Korin, Ogata'>Korin, Ogata</option>                                   <option value='Koya, Yoshio'>Koya, Yoshio</option>                                   <option value='Krafft-Ebing, Richard von'>Krafft-Ebing, Richard von</option>                                   <option value='Kropotkin, Peter'>Kropotkin, Peter</option>                                   <option value='L. Gonzales'>L. Gonzales</option>                                   <option value='Lafeadie Hearn'>Lafeadie Hearn</option>                                   <option value='Lankester, Edwin Ray'>Lankester, Edwin Ray</option>                                   <option value='LANSA'>LANSA</option>                                   <option value='Lao-Tse;'>Lao-Tse;</option>                                   <option value='Larsen, Nils Paul'>Larsen, Nils Paul</option>                                   <option value='Lasker, Albert'>Lasker, Albert</option>                                   <option value='Lasker, Bruno'>Lasker, Bruno</option>                                   <option value='Lasker, Florina'>Lasker, Florina</option>                                   <option value='Lasker, Mary'>Lasker, Mary</option>                                   <option value='Lasker, Mary Woodard'>Lasker, Mary Woodard</option>                                   <option value='Lasker, Nettie Heidenheimer Davis'>Lasker, Nettie Heidenheimer Davis</option>                                   <option value='Latz, Leo'>Latz, Leo</option>                                   <option value='Latz, Leo J.'>Latz, Leo J.</option>                                   <option value='LÃ¶wenfeld, Leopold'>LÃ¶wenfeld, Leopold</option>                                   <option value='Lena Ashwell'>Lena Ashwell</option>                                   <option value='Lenox, James'>Lenox, James</option>                                   <option value='Leo Latz'>Leo Latz</option>                                   <option value='Leonard Darwin'>Leonard Darwin</option>                                   <option value='Leonard Reese'>Leonard Reese</option>                                   <option value='Leonardo Vasquez'>Leonardo Vasquez</option>                                   <option value='Lericolais, Eugene'>Lericolais, Eugene</option>                                   <option value='Levenstein, Irvin'>Levenstein, Irvin</option>                                   <option value='Levine, Lena'>Levine, Lena</option>                                   <option value='Levy, John'>Levy, John</option>                                   <option value='Lifshiz, Anna'>Lifshiz, Anna</option>                                   <option value='LINCAB'>LINCAB</option>                                   <option value='Lincoln, Abraham'>Lincoln, Abraham</option>                                   <option value='Lindsay, Benjamin Barr'>Lindsay, Benjamin Barr</option>                                   <option value='Lippman, Walter'>Lippman, Walter</option>                                   <option value='Little, C.C.'>Little, C.C.</option>                                   <option value='Little, Clarence Cook'>Little, Clarence Cook</option>                                   <option value='Lloyd George, David'>Lloyd George, David</option>                                   <option value='Lombardio. Michele Angiolillo'>Lombardio. Michele Angiolillo</option>                                   <option value='Lorenzo, Anselmo'>Lorenzo, Anselmo</option>                                   <option value='Louis Gergotz'>Louis Gergotz</option>                                   <option value='Louis Harris'>Louis Harris</option>                                   <option value='Louis Pasteur'>Louis Pasteur</option>                                   <option value='Louise Michel'>Louise Michel</option>                                   <option value='Luther Burbank'>Luther Burbank</option>                                   <option value='Luther, Martin'>Luther, Martin</option>                                   <option value='Luxemborg, Rosa'>Luxemborg, Rosa</option>                                   <option value='Lydston Ruggles'>Lydston Ruggles</option>                                   <option value='Lyndon Macassey'>Lyndon Macassey</option>                                   <option value='M. P. Martinez'>M. P. Martinez</option>                                   <option value='M. S. L.'>M. S. L.</option>                                   <option value='MacArthur, Douglas'>MacArthur, Douglas</option>                                   <option value='MacBride, E. W.'>MacBride, E. W.</option>                                   <option value='Macbride, Ernest William'>Macbride, Ernest William</option>                                   <option value='MacCracken, Henry Noble'>MacCracken, Henry Noble</option>                                   <option value='Macdonald, Angus'>Macdonald, Angus</option>                                   <option value='Macgowan, Kenneth'>Macgowan, Kenneth</option>                                   <option value='MacLeish, Archibald'>MacLeish, Archibald</option>                                   <option value='Madison, James'>Madison, James</option>                                   <option value='Maharaja'>Maharaja</option>                                   <option value='Mahatma Ghandi'>Mahatma Ghandi</option>                                   <option value='Maisel, Max'>Maisel, Max</option>                                   <option value='Maisel, Max N.'>Maisel, Max N.</option>                                   <option value='Malato, Charles'>Malato, Charles</option>                                   <option value='Mallet, Bernard'>Mallet, Bernard</option>                                   <option value='Malthus, Thomas'>Malthus, Thomas</option>                                   <option value='Malthus, Thomas Robert'>Malthus, Thomas Robert</option>                                   <option value='Mantegazza, Paolo'>Mantegazza, Paolo</option>                                   <option value='Marc Epstein'>Marc Epstein</option>                                   <option value='Marcuse, Julian'>Marcuse, Julian</option>                                   <option value='Margaret D. Robins,'>Margaret D. Robins,</option>                                   <option value='Margaret H. Sanger'>Margaret H. Sanger</option>                                   <option value='Margaret Sanger'>Margaret Sanger</option>                                   <option value='Maria Rutgers-Hoitsema'>Maria Rutgers-Hoitsema</option>                                   <option value='Marie C. Stopes'>Marie C. Stopes</option>                                   <option value='Marie Carmichael Stopes'>Marie Carmichael Stopes</option>                                   <option value='Marie Ganz'>Marie Ganz</option>                                   <option value='MARIE HUOT'>MARIE HUOT</option>                                   <option value='Marie Stopes'>Marie Stopes</option>                                   <option value='Marie Stritt'>Marie Stritt</option>                                   <option value='Marinont, Leon'>Marinont, Leon</option>                                   <option value='Marion, Kitty'>Marion, Kitty</option>                                   <option value='Marjorie Wells'>Marjorie Wells</option>                                   <option value='Mark'>Mark</option>                                   <option value='Marshall, Hudson Snowden'>Marshall, Hudson Snowden</option>                                   <option value='Marshall. H. Snowden'>Marshall. H. Snowden</option>                                   <option value='Martial, Rene'>Martial, Rene</option>                                   <option value='Martin Luther'>Martin Luther</option>                                   <option value='Martin, Alice Marjorie'>Martin, Alice Marjorie</option>                                   <option value='Martin, Helen'>Martin, Helen</option>                                   <option value='Martin, James'>Martin, James</option>                                   <option value='Mary Minora'>Mary Minora</option>                                   <option value='Mary Sullivan'>Mary Sullivan</option>                                   <option value='Mary Sumner Boyd'>Mary Sumner Boyd</option>                                   <option value='Mary Wollstonecraft'>Mary Wollstonecraft</option>                                   <option value='Mary, Virgin, Saint'>Mary, Virgin, Saint</option>                                   <option value='Mas, Luis'>Mas, Luis</option>                                   <option value='Masanao Hanihara'>Masanao Hanihara</option>                                   <option value='Masani, Minocher Rustam'>Masani, Minocher Rustam</option>                                   <option value='Mascaux, Fernand'>Mascaux, Fernand</option>                                   <option value='Matthew'>Matthew</option>                                   <option value='Matthew Arnold'>Matthew Arnold</option>                                   <option value='Mauclair, Camille'>Mauclair, Camille</option>                                   <option value='Maude Glasgow'>Maude Glasgow</option>                                   <option value='Max Hirsch'>Max Hirsch</option>                                   <option value='Mayo, Katherine'>Mayo, Katherine</option>                                   <option value='McCarthy, Joseph'>McCarthy, Joseph</option>                                   <option value='McNamera, Anna'>McNamera, Anna</option>                                   <option value='Megaw, John'>Megaw, John</option>                                   <option value='Megaw, John Wallace'>Megaw, John Wallace</option>                                   <option value='Megaw, Sir Jonn'>Megaw, Sir Jonn</option>                                   <option value='member of United States armed forces'>member of United States armed forces</option>                                   <option value='Menninger, Karl'>Menninger, Karl</option>                                   <option value='Mensigna, Wilhelm'>Mensigna, Wilhelm</option>                                   <option value='Mensinga, Wilhelm'>Mensinga, Wilhelm</option>                                   <option value='Mensinga, Willhelm'>Mensinga, Willhelm</option>                                   <option value='Mereto, Joseph'>Mereto, Joseph</option>                                   <option value='Meric, Victor'>Meric, Victor</option>                                   <option value='Merviss, Jacob'>Merviss, Jacob</option>                                   <option value='Mesta, Perle Skirvin'>Mesta, Perle Skirvin</option>                                   <option value='Meunier, Ernestine'>Meunier, Ernestine</option>                                   <option value='Meyers, William Starr'>Meyers, William Starr</option>                                   <option value='Michael Bakunin'>Michael Bakunin</option>                                   <option value='Michael Hennessey Higgins'>Michael Hennessey Higgins</option>                                   <option value='Michel, Robert'>Michel, Robert</option>                                   <option value='Miki, Takeo'>Miki, Takeo</option>                                   <option value='Mill, John Stuart'>Mill, John Stuart</option>                                   <option value='Miller, James R.'>Miller, James R.</option>                                   <option value='Milliken, Rhoda'>Milliken, Rhoda</option>                                   <option value='Mindell, Fania'>Mindell, Fania</option>                                   <option value='Mindell, Fannie'>Mindell, Fannie</option>                                   <option value='Minister of Health'>Minister of Health</option>                                   <option value='Miss Quinn'>Miss Quinn</option>                                   <option value='Miss. Phillips'>Miss. Phillips</option>                                   <option value='Mohammed'>Mohammed</option>                                   <option value='Moley, Raymond'>Moley, Raymond</option>                                   <option value='MONTESQUIEU'>MONTESQUIEU</option>                                   <option value='Montseny, Frederico Urales'>Montseny, Frederico Urales</option>                                   <option value='Mooney, John'>Mooney, John</option>                                   <option value='Mooney, Sergeant'>Mooney, Sergeant</option>                                   <option value='Morgan, Anne'>Morgan, Anne</option>                                   <option value='Morral, Mateo'>Morral, Mateo</option>                                   <option value='Morris Sheppard'>Morris Sheppard</option>                                   <option value='Moscowitz, Grover'>Moscowitz, Grover</option>                                   <option value='Moscowitz, Grover C.'>Moscowitz, Grover C.</option>                                   <option value='Moscowitz, Grover M.'>Moscowitz, Grover M.</option>                                   <option value='Moses'>Moses</option>                                   <option value='Moses Oppenheimer'>Moses Oppenheimer</option>                                   <option value='Moses, Bessie Louise'>Moses, Bessie Louise</option>                                   <option value='Moussolini, Benito'>Moussolini, Benito</option>                                   <option value='Mrs. Sarah Conboy'>Mrs. Sarah Conboy</option>                                   <option value='Mudd, Stuart'>Mudd, Stuart</option>                                   <option value='Munroe, Ruth'>Munroe, Ruth</option>                                   <option value='Muramatsu, Minoru'>Muramatsu, Minoru</option>                                   <option value='Murray, George Gilbert Aim'>Murray, George Gilbert Aim</option>                                   <option value='Mussolini, Benito'>Mussolini, Benito</option>                                   <option value='Myers, Hiram'>Myers, Hiram</option>                                   <option value='Myrdal, Gunnar'>Myrdal, Gunnar</option>                                   <option value='Naidu, Sarojini'>Naidu, Sarojini</option>                                   <option value='Nancy Langhorne Astor'>Nancy Langhorne Astor</option>                                   <option value='Napoleon'>Napoleon</option>                                   <option value='Naquet, Alfred'>Naquet, Alfred</option>                                   <option value='Nardu, Lawrence Housman Saronjin'>Nardu, Lawrence Housman Saronjin</option>                                   <option value='Nariman, K.F.'>Nariman, K.F.</option>                                   <option value='Nariman, Khurshed Framji'>Nariman, Khurshed Framji</option>                                   <option value='Nation, Carrie'>Nation, Carrie</option>                                   <option value='Nehru, Jaharwalal'>Nehru, Jaharwalal</option>                                   <option value='Nehru, Jawaharlal'>Nehru, Jawaharlal</option>                                   <option value='Neiland'>Neiland</option>                                   <option value='Nelson, Janet Fowler'>Nelson, Janet Fowler</option>                                   <option value='Nero'>Nero</option>                                   <option value='Neville Chamberlain'>Neville Chamberlain</option>                                   <option value='Newton'>Newton</option>                                   <option value='Nicholas II'>Nicholas II</option>                                   <option value='Nicholas II of Russia'>Nicholas II of Russia</option>                                   <option value='Nielsen, Rita'>Nielsen, Rita</option>                                   <option value='Nietzsche, Friedrich'>Nietzsche, Friedrich</option>                                   <option value='Noah'>Noah</option>                                   <option value='Noel Porter'>Noel Porter</option>                                   <option value='Nomad, Ali'>Nomad, Ali</option>                                   <option value='Norman Haire'>Norman Haire</option>                                   <option value='Notestein, Frank'>Notestein, Frank</option>                                   <option value='Noyes, John Humphrey'>Noyes, John Humphrey</option>                                   <option value='Nyeda, Professor'>Nyeda, Professor</option>                                   <option value='Nystrom, Anton'>Nystrom, Anton</option>                                   <option value='Nyswander, Rachel'>Nyswander, Rachel</option>                                   <option value='O'Brien, Joseph'>O'Brien, Joseph</option>                                   <option value='O'Connell, William Henry'>O'Connell, William Henry</option>                                   <option value='O'Keefe, George J.'>O'Keefe, George J.</option>                                   <option value='O'Shea, William J.'>O'Shea, William J.</option>                                   <option value='ODA OLBERG'>ODA OLBERG</option>                                   <option value='Olive Schreiner'>Olive Schreiner</option>                                   <option value='Onan'>Onan</option>                                   <option value='One highly educated Indian man'>One highly educated Indian man</option>                                   <option value='one of the priests'>one of the priests</option>                                   <option value='Orr, John Boyd'>Orr, John Boyd</option>                                   <option value='Orr, Sir John Boyd'>Orr, Sir John Boyd</option>                                   <option value='Orwell, George'>Orwell, George</option>                                   <option value='Osborn, Fairfield'>Osborn, Fairfield</option>                                   <option value='Oscar Wilde'>Oscar Wilde</option>                                   <option value='Ottesen-Jensen, Elise'>Ottesen-Jensen, Elise</option>                                   <option value='Otto Bobsien'>Otto Bobsien</option>                                   <option value='Overton, John'>Overton, John</option>                                   <option value='Owen Lovejoy'>Owen Lovejoy</option>                                   <option value='Owen, Robert Dale'>Owen, Robert Dale</option>                                   <option value='Oxnam, G. Bromley'>Oxnam, G. Bromley</option>                                   <option value='Oxnam, Garfield Bromley'>Oxnam, Garfield Bromley</option>                                   <option value='Palmer, Eileen'>Palmer, Eileen</option>                                   <option value='Pankhurst, Emmeline'>Pankhurst, Emmeline</option>                                   <option value='Paris, France'>Paris, France</option>                                   <option value='Parker, Joanne'>Parker, Joanne</option>                                   <option value='Parker, Theodore'>Parker, Theodore</option>                                   <option value='Parran, Thomas'>Parran, Thomas</option>                                   <option value='Patrick Hayes'>Patrick Hayes</option>                                   <option value='Patrick J. Hayes'>Patrick J. Hayes</option>                                   <option value='Patrick J. Ward'>Patrick J. Ward</option>                                   <option value='Patrick Quinlan'>Patrick Quinlan</option>                                   <option value='PAUL ADAM'>PAUL ADAM</option>                                   <option value='Paul Popenoe'>Paul Popenoe</option>                                   <option value='Paul Robin'>Paul Robin</option>                                   <option value='Pearl, Raymond'>Pearl, Raymond</option>                                   <option value='Percy Ames'>Percy Ames</option>                                   <option value='Percy L. Gassaway'>Percy L. Gassaway</option>                                   <option value='Peterson, Houston'>Peterson, Houston</option>                                   <option value='Petruchio'>Petruchio</option>                                   <option value='Phiilips, Wendell'>Phiilips, Wendell</option>                                   <option value='Phillips, Anna Jane'>Phillips, Anna Jane</option>                                   <option value='Phillips, John C.'>Phillips, John C.</option>                                   <option value='Pierce, C.C.'>Pierce, C.C.</option>                                   <option value='Pierce, Claude C.'>Pierce, Claude C.</option>                                   <option value='Pierre Laval'>Pierre Laval</option>                                   <option value='Pierson, Richard N.'>Pierson, Richard N.</option>                                   <option value='Pillay, A.P.'>Pillay, A.P.</option>                                   <option value='Pillay, Dr. A.P.'>Pillay, Dr. A.P.</option>                                   <option value='Pilpel, Harriet F.'>Pilpel, Harriet F.</option>                                   <option value='Pincus, Gregory Goodwin'>Pincus, Gregory Goodwin</option>                                   <option value='Pissoort, Elizabeth'>Pissoort, Elizabeth</option>                                   <option value='Pius IX'>Pius IX</option>                                   <option value='Pius XI'>Pius XI</option>                                   <option value='Pius XI, Pope'>Pius XI, Pope</option>                                   <option value='Place, Francis'>Place, Francis</option>                                   <option value='Plato'>Plato</option>                                   <option value='Ploetz, Alfred'>Ploetz, Alfred</option>                                   <option value='Plutarch'>Plutarch</option>                                   <option value='Pope Pius XI'>Pope Pius XI</option>                                   <option value='Pope Piux XI'>Pope Piux XI</option>                                   <option value='Popenoe, Paul'>Popenoe, Paul</option>                                   <option value='Porfirio Diaz'>Porfirio Diaz</option>                                   <option value='Portet, Lorenzo'>Portet, Lorenzo</option>                                   <option value='Portis, S. Bernard'>Portis, S. Bernard</option>                                   <option value='Potter, Charles Francis>'>Potter, Charles Francis></option>                                   <option value='Prentiss Willson'>Prentiss Willson</option>                                   <option value='Pres Bank of England'>Pres Bank of England</option>                                   <option value='Price, Dr.'>Price, Dr.</option>                                   <option value='Price, Marie Perry'>Price, Marie Perry</option>                                   <option value='Prince Albert Morrow'>Prince Albert Morrow</option>                                   <option value='Pusey, William Allen'>Pusey, William Allen</option>                                   <option value='Quixote, Don'>Quixote, Don</option>                                   <option value='R. C. Martens'>R. C. Martens</option>                                   <option value='Ralph Waldo Emerson'>Ralph Waldo Emerson</option>                                   <option value='Rama Rau, Dhanvanthi'>Rama Rau, Dhanvanthi</option>                                   <option value='Rama Rau, Dhanvanthi Handoo'>Rama Rau, Dhanvanthi Handoo</option>                                   <option value='Rama Rau, Dhavanthi Handoo'>Rama Rau, Dhavanthi Handoo</option>                                   <option value='Ramesan, Sir Vepa'>Ramesan, Sir Vepa</option>                                   <option value='Ramesan, Vepa'>Ramesan, Vepa</option>                                   <option value='Ramos, Rafael Menendez'>Ramos, Rafael Menendez</option>                                   <option value='Rangel, Jesus M.'>Rangel, Jesus M.</option>                                   <option value='Rathbone, Eleanor'>Rathbone, Eleanor</option>                                   <option value='Rebecca Edelsohn'>Rebecca Edelsohn</option>                                   <option value='Rebecca Edelson'>Rebecca Edelson</option>                                   <option value='Reclus, Elise'e'>Reclus, Elise'e</option>                                   <option value='Reclus, Elisee'>Reclus, Elisee</option>                                   <option value='REMY DE GOURMONT'>REMY DE GOURMONT</option>                                   <option value='Richard Enright'>Richard Enright</option>                                   <option value='Rider Haggard'>Rider Haggard</option>                                   <option value='Risselada'>Risselada</option>                                   <option value='Robert Allerton Parker'>Robert Allerton Parker</option>                                   <option value='Robert G. Ingersoll'>Robert G. Ingersoll</option>                                   <option value='Robert L. Dickinson'>Robert L. Dickinson</option>                                   <option value='Robert L. Owen'>Robert L. Owen</option>                                   <option value='Robert Morse Woodbury'>Robert Morse Woodbury</option>                                   <option value='Robin, Paul'>Robin, Paul</option>                                   <option value='Robinson, James H.'>Robinson, James H.</option>                                   <option value='Robinson, James Harvey'>Robinson, James Harvey</option>                                   <option value='Robinson, William J.'>Robinson, William J.</option>                                   <option value='Rock,John'>Rock,John</option>                                   <option value='Rockefeller, John D., Jr.'>Rockefeller, John D., Jr.</option>                                   <option value='Rocker, Rudolf'>Rocker, Rudolf</option>                                   <option value='Rodman, Henrietta'>Rodman, Henrietta</option>                                   <option value='Roosevelt, Eleanor'>Roosevelt, Eleanor</option>                                   <option value='Roosevelt, Franklin Delano'>Roosevelt, Franklin Delano</option>                                   <option value='Roosevelt, Theodore'>Roosevelt, Theodore</option>                                   <option value='Rose Witcop'>Rose Witcop</option>                                   <option value='Rose, Florence'>Rose, Florence</option>                                   <option value='Rosenbaum'>Rosenbaum</option>                                   <option value='Ross, Edward Alsworth'>Ross, Edward Alsworth</option>                                   <option value='Roswell H. Johnson'>Roswell H. Johnson</option>                                   <option value='Rothstein, Arnold'>Rothstein, Arnold</option>                                   <option value='Roussel, Nelly'>Roussel, Nelly</option>                                   <option value='Royal S. Copeland'>Royal S. Copeland</option>                                   <option value='rs. Kutten Nair'>rs. Kutten Nair</option>                                   <option value='Rublee, Juliet Barrett'>Rublee, Juliet Barrett</option>                                   <option value='Rukmini, Devi'>Rukmini, Devi</option>                                   <option value='Russell, Alexander J.H.'>Russell, Alexander J.H.</option>                                   <option value='Russell, Bertand'>Russell, Bertand</option>                                   <option value='Russell, Bertrand'>Russell, Bertrand</option>                                   <option value='Russell, Bertrand Arthur William'>Russell, Bertrand Arthur William</option>                                   <option value='Russell, Colonel Alexander H.J.'>Russell, Colonel Alexander H.J.</option>                                   <option value='Rutgers, Johannes'>Rutgers, Johannes</option>                                   <option value='S. Ten Cate'>S. Ten Cate</option>                                   <option value='S.A. Stouffer'>S.A. Stouffer</option>                                   <option value='Sachs, Jake'>Sachs, Jake</option>                                   <option value='Sachs, Sadie'>Sachs, Sadie</option>                                   <option value='Salvatore Bruno'>Salvatore Bruno</option>                                   <option value='Salvemini, Gaetano'>Salvemini, Gaetano</option>                                   <option value='Samuel Butler'>Samuel Butler</option>                                   <option value='Samuel Hoare'>Samuel Hoare</option>                                   <option value='Sanders, Barkev S.'>Sanders, Barkev S.</option>                                   <option value='Sanger, Grant'>Sanger, Grant</option>                                   <option value='Sanger, Margaret'>Sanger, Margaret</option>                                   <option value='Sanger, Peggy'>Sanger, Peggy</option>                                   <option value='Sanger, Stuart'>Sanger, Stuart</option>                                   <option value='Sanger, William'>Sanger, William</option>                                   <option value='Sansome, George'>Sansome, George</option>                                   <option value='Santa Claus'>Santa Claus</option>                                   <option value='Sarah Christopher'>Sarah Christopher</option>                                   <option value='Sarah Conboy'>Sarah Conboy</option>                                   <option value='Saunders, W. O.'>Saunders, W. O.</option>                                   <option value='Sayajirao III Khanderao Gaekwad'>Sayajirao III Khanderao Gaekwad</option>                                   <option value='Schopenhauer, Arthur'>Schopenhauer, Arthur</option>                                   <option value='Scidmore, George H.'>Scidmore, George H.</option>                                   <option value='Scudder, Ida'>Scudder, Ida</option>                                   <option value='Seibels, Robert E.'>Seibels, Robert E.</option>                                   <option value='Sen, Binay Ranjan'>Sen, Binay Ranjan</option>                                   <option value='Seneca'>Seneca</option>                                   <option value='Sesshu, Toyo'>Sesshu, Toyo</option>                                   <option value='Sethu Lakshmi Bai'>Sethu Lakshmi Bai</option>                                   <option value='Shackelton, Edith'>Shackelton, Edith</option>                                   <option value='Shakespeare, William'>Shakespeare, William</option>                                   <option value='Sharma, P.S.'>Sharma, P.S.</option>                                   <option value='Shaw, Bernard'>Shaw, Bernard</option>                                   <option value='Shaw, George Bernard'>Shaw, George Bernard</option>                                   <option value='Shea, Albert J.'>Shea, Albert J.</option>                                   <option value='Sheean, vincent'>Sheean, vincent</option>                                   <option value='Shidzue Ishimoto Kato'>Shidzue Ishimoto Kato</option>                                   <option value='Shih, Hu'>Shih, Hu</option>                                   <option value='Shipler, Guy Emery'>Shipler, Guy Emery</option>                                   <option value='Sidney Webb'>Sidney Webb</option>                                   <option value='Sigmund Freud'>Sigmund Freud</option>                                   <option value='Simon, Robert E.'>Simon, Robert E.</option>                                   <option value='Slade, Mirabehu'>Slade, Mirabehu</option>                                   <option value='Smith, Albert Emmanuel'>Smith, Albert Emmanuel</option>                                   <option value='Smith, Alfred E.'>Smith, Alfred E.</option>                                   <option value='Smith, Helena Huntington'>Smith, Helena Huntington</option>                                   <option value='Socrates'>Socrates</option>                                   <option value='Sol Bromberg'>Sol Bromberg</option>                                   <option value='St. Augustine'>St. Augustine</option>                                   <option value='St. Mark'>St. Mark</option>                                   <option value='St. Matthew'>St. Matthew</option>                                   <option value='Stebbins, Ernest L.'>Stebbins, Ernest L.</option>                                   <option value='Stebbins, Ernest Lyman'>Stebbins, Ernest Lyman</option>                                   <option value='Stein, Irving R.'>Stein, Irving R.</option>                                   <option value='Steinach, Eugen'>Steinach, Eugen</option>                                   <option value='Stickney, Percy'>Stickney, Percy</option>                                   <option value='Stirner, Max'>Stirner, Max</option>                                   <option value='Stockham, Alice Bunker'>Stockham, Alice Bunker</option>                                   <option value='Stone, Abraham'>Stone, Abraham</option>                                   <option value='Stone, Eric'>Stone, Eric</option>                                   <option value='Stone, Hannah Mayer'>Stone, Hannah Mayer</option>                                   <option value='Stone, Mrs. Eugene'>Stone, Mrs. Eugene</option>                                   <option value='Stopes, Marie'>Stopes, Marie</option>                                   <option value='Stopes, Marie Carmichael'>Stopes, Marie Carmichael</option>                                   <option value='Strange, William'>Strange, William</option>                                   <option value='Stuyvesant, Elizabeth'>Stuyvesant, Elizabeth</option>                                   <option value='Sullivan, Mary'>Sullivan, Mary</option>                                   <option value='Sundaram, Manjeri'>Sundaram, Manjeri</option>                                   <option value='Sutkowsky'>Sutkowsky</option>                                   <option value='Sutor, Franck'>Sutor, Franck</option>                                   <option value='Swan, Thomas W.'>Swan, Thomas W.</option>                                   <option value='Swan, Thomas Walter'>Swan, Thomas Walter</option>                                   <option value='Swann, Edward'>Swann, Edward</option>                                   <option value='Sylvia Pankhurst'>Sylvia Pankhurst</option>                                   <option value='Tagore, Rabindranath'>Tagore, Rabindranath</option>                                   <option value='Takao, Kazuo'>Takao, Kazuo</option>                                   <option value='Taylor, Howard Canning, Jr.'>Taylor, Howard Canning, Jr.</option>                                   <option value='Tertullian'>Tertullian</option>                                   <option value='Tery, Gustave'>Tery, Gustave</option>                                   <option value='Theodore Roosevelt'>Theodore Roosevelt</option>                                   <option value='Thomas Flynn'>Thomas Flynn</option>                                   <option value='THOMAS HUXLEY'>THOMAS HUXLEY</option>                                   <option value='Thomas Malthus'>Thomas Malthus</option>                                   <option value='Thomas Paine'>Thomas Paine</option>                                   <option value='Thomas Parran'>Thomas Parran</option>                                   <option value='Thomas, Herbert'>Thomas, Herbert</option>                                   <option value='Thompson, Warren'>Thompson, Warren</option>                                   <option value='Thompson, Warren S.'>Thompson, Warren S.</option>                                   <option value='Thoreau, Henry David'>Thoreau, Henry David</option>                                   <option value='Thurman, I. N.'>Thurman, I. N.</option>                                   <option value='Tileston, Wilder'>Tileston, Wilder</option>                                   <option value='Tisserant, Eugene'>Tisserant, Eugene</option>                                   <option value='Todd, Helen'>Todd, Helen</option>                                   <option value='Tom Mann'>Tom Mann</option>                                   <option value='Tom Mooney'>Tom Mooney</option>                                   <option value='Tomosaburo Kato'>Tomosaburo Kato</option>                                   <option value='Tompkins, Katherine'>Tompkins, Katherine</option>                                   <option value='Treub, Hector'>Treub, Hector</option>                                   <option value='Trollope, Anthony'>Trollope, Anthony</option>                                   <option value='Tsuneoka, Ichiro'>Tsuneoka, Ichiro</option>                                   <option value='Tubman, Harriet'>Tubman, Harriet</option>                                   <option value='Tutunja, Djamil Pasha'>Tutunja, Djamil Pasha</option>                                   <option value='Tutunji, Djamil Pasha'>Tutunji, Djamil Pasha</option>                                   <option value='unidentified'>unidentified</option>                                   <option value='United States of America'>United States of America</option>                                   <option value='unknown'>unknown</option>                                   <option value='Upham, John H. J.'>Upham, John H. J.</option>                                   <option value='Upham, John H.J.'>Upham, John H.J.</option>                                   <option value='Upham, John Howell Janeway'>Upham, John Howell Janeway</option>                                   <option value='Upton Sinclair's'>Upton Sinclair's</option>                                   <option value='Uthoff, H. C.'>Uthoff, H. C.</option>                                   <option value='Vacher de Lapouge, Georges'>Vacher de Lapouge, Georges</option>                                   <option value='Valenta, ?'>Valenta, ?</option>                                   <option value='Valentino Modestino'>Valentino Modestino</option>                                   <option value='Valiant, Margaret'>Valiant, Margaret</option>                                   <option value='Van Houten, Samuel'>Van Houten, Samuel</option>                                   <option value='van Huevel'>van Huevel</option>                                   <option value='Vanderlip, Frank A.'>Vanderlip, Frank A.</option>                                   <option value='Vargas, Martinez'>Vargas, Martinez</option>                                   <option value='Vasquez, Leonard'>Vasquez, Leonard</option>                                   <option value='Veblen, Thorstein'>Veblen, Thorstein</option>                                   <option value='Vickery, Alice'>Vickery, Alice</option>                                   <option value='Vickery, Alice Drysdale'>Vickery, Alice Drysdale</option>                                   <option value='Victor Cravello'>Victor Cravello</option>                                   <option value='Victor Hugo'>Victor Hugo</option>                                   <option value='Victoriano Huerta'>Victoriano Huerta</option>                                   <option value='Virgin Mary'>Virgin Mary</option>                                   <option value='Visvesvarayya, Mokshagundam'>Visvesvarayya, Mokshagundam</option>                                   <option value='Vogt, William'>Vogt, William</option>                                   <option value='Voltaire'>Voltaire</option>                                   <option value='von Bernhardi, Friedrich'>von Bernhardi, Friedrich</option>                                   <option value='von Bernhardi, Friedrich Adolf Julius'>von Bernhardi, Friedrich Adolf Julius</option>                                   <option value='von Krafft-Ebing, Richard'>von Krafft-Ebing, Richard</option>                                   <option value='Vorse, Mary Heaton'>Vorse, Mary Heaton</option>                                   <option value='W. Grant Hague'>W. Grant Hague</option>                                   <option value='Walter B. Cannon'>Walter B. Cannon</option>                                   <option value='Ward, Mary Agusta'>Ward, Mary Agusta</option>                                   <option value='Ware, H.M.'>Ware, H.M.</option>                                   <option value='Watrous, Charles E.'>Watrous, Charles E.</option>                                   <option value='Webb, Walter Prescott'>Webb, Walter Prescott</option>                                   <option value='Weintraub, Philip'>Weintraub, Philip</option>                                   <option value='Weis, Ignace Semmel'>Weis, Ignace Semmel</option>                                   <option value='Wells, George Phillip'>Wells, George Phillip</option>                                   <option value='Wells, H. G.'>Wells, H. G.</option>                                   <option value='Wells, H.G.'>Wells, H.G.</option>                                   <option value='Wells, Herbert George'>Wells, Herbert George</option>                                   <option value='Wendell Phillips'>Wendell Phillips</option>                                   <option value='West, George P.'>West, George P.</option>                                   <option value='Westermarck, Edward'>Westermarck, Edward</option>                                   <option value='Weyl, Walter E.'>Weyl, Walter E.</option>                                   <option value='Whalen, Grover A.'>Whalen, Grover A.</option>                                   <option value='White, William H.'>White, William H.</option>                                   <option value='Whitehurst, Margaret'>Whitehurst, Margaret</option>                                   <option value='Whitman, Charles S.'>Whitman, Charles S.</option>                                   <option value='Whitman, Walt'>Whitman, Walt</option>                                   <option value='Wiesner, Berthold P.'>Wiesner, Berthold P.</option>                                   <option value='Wiesner, Bertold Paul'>Wiesner, Bertold Paul</option>                                   <option value='Wile, Ira'>Wile, Ira</option>                                   <option value='Wilhelm II of Germany'>Wilhelm II of Germany</option>                                   <option value='Wille, Bruno'>Wille, Bruno</option>                                   <option value='William Allen Pusey'>William Allen Pusey</option>                                   <option value='William Archer'>William Archer</option>                                   <option value='WILLIAM BATESON'>WILLIAM BATESON</option>                                   <option value='William Dudley Haywood'>William Dudley Haywood</option>                                   <option value='WILLIAM GRAHAM SUMNER'>WILLIAM GRAHAM SUMNER</option>                                   <option value='William Harvey'>William Harvey</option>                                   <option value='William J. Robinson'>William J. Robinson</option>                                   <option value='William Lloyd-George'>William Lloyd-George</option>                                   <option value='William McAdoo'>William McAdoo</option>                                   <option value='William Morris'>William Morris</option>                                   <option value='William Osler'>William Osler</option>                                   <option value='William R. Hearst'>William R. Hearst</option>                                   <option value='WIlliam Ralph Inge'>WIlliam Ralph Inge</option>                                   <option value='William Sanger'>William Sanger</option>                                   <option value='William Shakespeare'>William Shakespeare</option>                                   <option value='William T. Belfield'>William T. Belfield</option>                                   <option value='Williams'>Williams</option>                                   <option value='Williams S. Gilbert'>Williams S. Gilbert</option>                                   <option value='Williams, Gertrude'>Williams, Gertrude</option>                                   <option value='Williams, J. Whitridge'>Williams, J. Whitridge</option>                                   <option value='Williams, L.J.'>Williams, L.J.</option>                                   <option value='Williams, Linsley'>Williams, Linsley</option>                                   <option value='Wilson, Woodrow'>Wilson, Woodrow</option>                                   <option value='Winternitz, Mathilde'>Winternitz, Mathilde</option>                                   <option value='Winternitz, Milton C.'>Winternitz, Milton C.</option>                                   <option value='Witkowski, G. J.'>Witkowski, G. J.</option>                                   <option value='Wood, George Bacon'>Wood, George Bacon</option>                                   <option value='Wood, Howard Kingsley'>Wood, Howard Kingsley</option>                                   <option value='Wood, L. Foster'>Wood, L. Foster</option>                                   <option value='Woodbridge, Morris E.'>Woodbridge, Morris E.</option>                                   <option value='Woodrow Wilson'>Woodrow Wilson</option>                                   <option value='Wright, Frank Lloyd'>Wright, Frank Lloyd</option>                                   <option value='Wright, Helena'>Wright, Helena</option>                                   <option value='Yamakawa'>Yamakawa</option>                                   <option value='Yasui, Seiichiro'>Yasui, Seiichiro</option>                                   <option value='Yerushalmy, Jacob'>Yerushalmy, Jacob</option>                                   <option value='Yokahama Prefector of Police'>Yokahama Prefector of Police</option>                                   <option value='Yokoyama, Fuku'>Yokoyama, Fuku</option>                                   <option value='Yoshida Shigeru'>Yoshida Shigeru</option>                                   <option value='Young, Virginia C.'>Young, Virginia C.</option>                                   <option value='Yuchi'>Yuchi</option>                                   <option value='Yucki, Mr.'>Yucki, Mr.</option>                                   <option value='ZENO'>ZENO</option>                                   <option value='Zenophon'>Zenophon</option>                                   <option value='Zetkin, Clara'>Zetkin, Clara</option>                                   <option value='Zinsser, Hans'>Zinsser, Hans</option>  
						</select> 
					</td> 
				</tr>  
				<tr> 
					<td></td> 
					<td> 
						<i>(find documents that mention a particular place)</i>
					</td> 
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr> <!-- mentioned organization -JR --> 
					<td class="searchLabelCell"> 
						<b>organization: &nbsp;</b> 
					</td> 
					<td> 
						<select name="mentionedOrganization" style="width: 400px;"> 
							<option value=''></option>
                                  <option value=''></option>                                   <option value='10th National Conference of Gynecologists and Obstetricians'>10th National Conference of Gynecologists and Obstetricians</option>                                   <option value='3rd International Planned Parenthood Conference, Third (Bombay)'>3rd International Planned Parenthood Conference, Third (Bombay)</option>                                   <option value='55th Southern Conference of the Methodist Episcopal Church'>55th Southern Conference of the Methodist Episcopal Church</option>                                   <option value='6th International Neo-Malthusian and Birth Control Conference'>6th International Neo-Malthusian and Birth Control Conference</option>                                   <option value='Academy of Medicine'>Academy of Medicine</option>                                   <option value='Afro-Asian Conference of Women'>Afro-Asian Conference of Women</option>                                   <option value='Alabama State Board of Health'>Alabama State Board of Health</option>                                   <option value='Albert D. and Mary Lasker Foundation'>Albert D. and Mary Lasker Foundation</option>                                   <option value='Albert D. and Mary Lasker Foundation Awards'>Albert D. and Mary Lasker Foundation Awards</option>                                   <option value='All India Conference of Gynecologists and Obstetricians'>All India Conference of Gynecologists and Obstetricians</option>                                   <option value='All India Medical Conference'>All India Medical Conference</option>                                   <option value='All India Obstetric and Gynacological Congress'>All India Obstetric and Gynacological Congress</option>                                   <option value='All India Population Conference'>All India Population Conference</option>                                   <option value='All India Woman's Conference'>All India Woman's Conference</option>                                   <option value='All India Womanâ€™s Conference'>All India Womanâ€™s Conference</option>                                   <option value='All India Women's Conference'>All India Women's Conference</option>                                   <option value='All India Womenâ€™s Conference'>All India Womenâ€™s Conference</option>                                   <option value='All Indian Obstetric and Gynecological Congress'>All Indian Obstetric and Gynecological Congress</option>                                   <option value='all-India Conference on Family Planning'>all-India Conference on Family Planning</option>                                   <option value='All-India Medical Conference'>All-India Medical Conference</option>                                   <option value='All-India Woman's Conference'>All-India Woman's Conference</option>                                   <option value='All-India Women's Conference'>All-India Women's Conference</option>                                   <option value='All-India Womenâ€™s Conference'>All-India Womenâ€™s Conference</option>                                   <option value='all-Japan Conference on Family Planning'>all-Japan Conference on Family Planning</option>                                   <option value='Alotan Manufacturing Company'>Alotan Manufacturing Company</option>                                   <option value='American Association for the Advancement of Science'>American Association for the Advancement of Science</option>                                   <option value='American Association of University Women'>American Association of University Women</option>                                   <option value='American Birth Control League'>American Birth Control League</option>                                   <option value='American Committee on Maternal Welfare'>American Committee on Maternal Welfare</option>                                   <option value='American Federation of Labor'>American Federation of Labor</option>                                   <option value='American Gynecological Society'>American Gynecological Society</option>                                   <option value='American Health Service'>American Health Service</option>                                   <option value='American Institute of Public Opinion'>American Institute of Public Opinion</option>                                   <option value='American Legion of Secaucus'>American Legion of Secaucus</option>                                   <option value='American Medical Association'>American Medical Association</option>                                   <option value='American Medical Association Committee to Study Contraceptive Practices'>American Medical Association Committee to Study Contraceptive Practices</option>                                   <option value='American Medical Association Council on Pharmacy and Chemistry'>American Medical Association Council on Pharmacy and Chemistry</option>                                   <option value='American Medical Association, Committee to Study Contraceptive Practice and Allied Problems'>American Medical Association, Committee to Study Contraceptive Practice and Allied Problems</option>                                   <option value='American Medical Association, Council of Pharmacy and Chemistry'>American Medical Association, Council of Pharmacy and Chemistry</option>                                   <option value='American Medical Association, Council on Physical Therapy'>American Medical Association, Council on Physical Therapy</option>                                   <option value='American Medical Association, House of Delegates'>American Medical Association, House of Delegates</option>                                   <option value='American medican Association Council on Chemistry and Pharmacy'>American medican Association Council on Chemistry and Pharmacy</option>                                   <option value='American Public Welfare Association'>American Public Welfare Association</option>                                   <option value='American Social Hygiene Association'>American Social Hygiene Association</option>                                   <option value='American Unitarian Association'>American Unitarian Association</option>                                   <option value='Anglican (Protestant Episcopal) Communion'>Anglican (Protestant Episcopal) Communion</option>                                   <option value='Anti-Naturalization League'>Anti-Naturalization League</option>                                   <option value='Anti-Nazi Committee'>Anti-Nazi Committee</option>                                   <option value='Appellate Division of the New York State Supreme Court'>Appellate Division of the New York State Supreme Court</option>                                   <option value='Associated Catholic Charities'>Associated Catholic Charities</option>                                   <option value='Associated Parents' Association of Greater New York'>Associated Parents' Association of Greater New York</option>                                   <option value='Associated Parentsâ€™ Association of Greater New York'>Associated Parentsâ€™ Association of Greater New York</option>                                   <option value='Associated Press'>Associated Press</option>                                   <option value='Association for Family Reform'>Association for Family Reform</option>                                   <option value='Association for Improving the Condition of the Poor'>Association for Improving the Condition of the Poor</option>                                   <option value='Association MaternitÃ© Heureuse'>Association MaternitÃ© Heureuse</option>                                   <option value='Association of Garment Manufacturers'>Association of Garment Manufacturers</option>                                   <option value='Association Pro Salud Maternal e Infantil de Puerto Rico'>Association Pro Salud Maternal e Infantil de Puerto Rico</option>                                   <option value='Astor Library'>Astor Library</option>                                   <option value='Auditorium Theater'>Auditorium Theater</option>                                   <option value='Bacteriological institute'>Bacteriological institute</option>                                   <option value='Baptist Church'>Baptist Church</option>                                   <option value='Bedford Hills Reformatory'>Bedford Hills Reformatory</option>                                   <option value='Belgian league'>Belgian league</option>                                   <option value='Bellevue Hospital'>Bellevue Hospital</option>                                   <option value='Bermuda Board of Health'>Bermuda Board of Health</option>                                   <option value='Bermuda Department of Health'>Bermuda Department of Health</option>                                   <option value='Bermuda Health Department'>Bermuda Health Department</option>                                   <option value='Bermuda Hotel Men's Association'>Bermuda Hotel Men's Association</option>                                   <option value='Bermuda House of Assembly'>Bermuda House of Assembly</option>                                   <option value='Bermuda Legislative Council'>Bermuda Legislative Council</option>                                   <option value='Birth Control Clinic Research Bureau'>Birth Control Clinic Research Bureau</option>                                   <option value='Birth Control Clinical Research Bureau'>Birth Control Clinical Research Bureau</option>                                   <option value='Birth Control Comes of Age Anniversary Dinner'>Birth Control Comes of Age Anniversary Dinner</option>                                   <option value='Birth Control Federation of America'>Birth Control Federation of America</option>                                   <option value='Birth Control Federation of America, Inc'>Birth Control Federation of America, Inc</option>                                   <option value='Birth Control Federation of America, Inc.'>Birth Control Federation of America, Inc.</option>                                   <option value='Birth Control Information Centre'>Birth Control Information Centre</option>                                   <option value='Birth Control International Information Centre'>Birth Control International Information Centre</option>                                   <option value='Birth Control League'>Birth Control League</option>                                   <option value='Birth Control League of'>Birth Control League of</option>                                   <option value='Birth Control League of America'>Birth Control League of America</option>                                   <option value='Birth Control League of New York'>Birth Control League of New York</option>                                   <option value='Birth Control League.'>Birth Control League.</option>                                   <option value='Birth Control Leagues'>Birth Control Leagues</option>                                   <option value='Blackwell's Island'>Blackwell's Island</option>                                   <option value='Blackwell's Island Penitentiary'>Blackwell's Island Penitentiary</option>                                   <option value='Blckwell's Island Penitentiary'>Blckwell's Island Penitentiary</option>                                   <option value='Board of Education'>Board of Education</option>                                   <option value='Board of Health'>Board of Health</option>                                   <option value='Bombay Chronicle'>Bombay Chronicle</option>                                   <option value='Bombay Municipal Corporation'>Bombay Municipal Corporation</option>                                   <option value='Boston University of Medicine'>Boston University of Medicine</option>                                   <option value='Boy Scouts, the'>Boy Scouts, the</option>                                   <option value='Brentano's'>Brentano's</option>                                   <option value='British Broadcasting Corporation'>British Broadcasting Corporation</option>                                   <option value='British Empire'>British Empire</option>                                   <option value='British Government'>British Government</option>                                   <option value='British Medical Association'>British Medical Association</option>                                   <option value='British Medical Society'>British Medical Society</option>                                   <option value='British Medical Society, Penang Branch'>British Medical Society, Penang Branch</option>                                   <option value='British Ministry of Health'>British Ministry of Health</option>                                   <option value='British Museum'>British Museum</option>                                   <option value='British National Birth-rate Commission'>British National Birth-rate Commission</option>                                   <option value='Brooklyn Court of Special Sessions'>Brooklyn Court of Special Sessions</option>                                   <option value='Brownsville Birth Control Clinic'>Brownsville Birth Control Clinic</option>                                   <option value='Brownsville clinic'>Brownsville clinic</option>                                   <option value='Bryn Mawr Hospital'>Bryn Mawr Hospital</option>                                   <option value='Bureau of Child Hygiene'>Bureau of Child Hygiene</option>                                   <option value='Bureau of the Metropolitan Police Department'>Bureau of the Metropolitan Police Department</option>                                   <option value='Bureau of Venereal Disease of New York'>Bureau of Venereal Disease of New York</option>                                   <option value='Burns Detective Agency'>Burns Detective Agency</option>                                   <option value='Cabell County Medical Society'>Cabell County Medical Society</option>                                   <option value='California Institute of Technology'>California Institute of Technology</option>                                   <option value='Cambridge University'>Cambridge University</option>                                   <option value='Carbozine Laboratory'>Carbozine Laboratory</option>                                   <option value='Catholic Church'>Catholic Church</option>                                   <option value='Catholic Diocese of Albany'>Catholic Diocese of Albany</option>                                   <option value='Catholic Diocese of New York'>Catholic Diocese of New York</option>                                   <option value='Cental Powers'>Cental Powers</option>                                   <option value='Central Conference of American Rabbis'>Central Conference of American Rabbis</option>                                   <option value='Central Drug Research institute'>Central Drug Research institute</option>                                   <option value='Chapman & Hall'>Chapman & Hall</option>                                   <option value='Charing Cross Hospital'>Charing Cross Hospital</option>                                   <option value='Charity Organization Society in, the'>Charity Organization Society in, the</option>                                   <option value='Chicago Woman's Aid Society'>Chicago Woman's Aid Society</option>                                   <option value='Children's Memorial Clinic'>Children's Memorial Clinic</option>                                   <option value='Childrenâ€™s Memorial Clinic'>Childrenâ€™s Memorial Clinic</option>                                   <option value='Chinese Medical Association'>Chinese Medical Association</option>                                   <option value='Christian Church'>Christian Church</option>                                   <option value='Church of England'>Church of England</option>                                   <option value='Church of the Master'>Church of the Master</option>                                   <option value='Cigar Makers'>Cigar Makers</option>                                   <option value='Cincinnati Medical School'>Cincinnati Medical School</option>                                   <option value='City Federation of Women's Clubs,'>City Federation of Women's Clubs,</option>                                   <option value='City Federation of Womenâ€™s Clubs,'>City Federation of Womenâ€™s Clubs,</option>                                   <option value='City National Bank of New York'>City National Bank of New York</option>                                   <option value='Civil guard'>Civil guard</option>                                   <option value='Civilian Conservation Corps'>Civilian Conservation Corps</option>                                   <option value='Cleveland Associated Charities'>Cleveland Associated Charities</option>                                   <option value='Clinical Research Bureau'>Clinical Research Bureau</option>                                   <option value='Columbia Broadcasting system'>Columbia Broadcasting system</option>                                   <option value='Columbia University'>Columbia University</option>                                   <option value='Columbia University College of Physicians and Surgeons'>Columbia University College of Physicians and Surgeons</option>                                   <option value='Commercial College'>Commercial College</option>                                   <option value='commercial organization'>commercial organization</option>                                   <option value='Commercial School of Liverpool'>Commercial School of Liverpool</option>                                   <option value='Commission on Industrial Relations'>Commission on Industrial Relations</option>                                   <option value='Committee'>Committee</option>                                   <option value='Committee for Defense of Medical Right'>Committee for Defense of Medical Right</option>                                   <option value='Committee of 100'>Committee of 100</option>                                   <option value='Committee on Human Reproduction'>Committee on Human Reproduction</option>                                   <option value='Committee on Prenatal and Maternal Care'>Committee on Prenatal and Maternal Care</option>                                   <option value='Committee on Safety'>Committee on Safety</option>                                   <option value='Committee to Study Contraceptive Practices and Allied Problems'>Committee to Study Contraceptive Practices and Allied Problems</option>                                   <option value='Community Chests'>Community Chests</option>                                   <option value='Community Church of New York'>Community Church of New York</option>                                   <option value='Community Church,'>Community Church,</option>                                   <option value='Conference of Congregational Churches of'>Conference of Congregational Churches of</option>                                   <option value='Conference of Social Hygiene'>Conference of Social Hygiene</option>                                   <option value='Conference on Contraceptive Research and Clinical Practice'>Conference on Contraceptive Research and Clinical Practice</option>                                   <option value='Congregational Church'>Congregational Church</option>                                   <option value='Congress'>Congress</option>                                   <option value='Congress of the Royal Institute of Public Health'>Congress of the Royal Institute of Public Health</option>                                   <option value='Connecticut Birth Control League'>Connecticut Birth Control League</option>                                   <option value='Connecticut Supreme Court'>Connecticut Supreme Court</option>                                   <option value='Consumers' Union'>Consumers' Union</option>                                   <option value='Consumersâ€™ Union'>Consumersâ€™ Union</option>                                   <option value='Cooper Union'>Cooper Union</option>                                   <option value='Cornell Medical College'>Cornell Medical College</option>                                   <option value='Corporation of Glasgow'>Corporation of Glasgow</option>                                   <option value='Court of Appeal for Ontario'>Court of Appeal for Ontario</option>                                   <option value='Court of Appeals'>Court of Appeals</option>                                   <option value='Court of Special Sessions'>Court of Special Sessions</option>                                   <option value='Cultural Society of'>Cultural Society of</option>                                   <option value='Custom House'>Custom House</option>                                   <option value='Department of Zoology of Edinburgh University'>Department of Zoology of Edinburgh University</option>                                   <option value='Departments of Health'>Departments of Health</option>                                   <option value='Doubleday, Doran and Company'>Doubleday, Doran and Company</option>                                   <option value='Duplin Silk Mill'>Duplin Silk Mill</option>                                   <option value='Dutch Government'>Dutch Government</option>                                   <option value='Dutch league'>Dutch league</option>                                   <option value='Dutch Neo-Malthusian League'>Dutch Neo-Malthusian League</option>                                   <option value='Edinburgh University'>Edinburgh University</option>                                   <option value='England, Ministry of Health'>England, Ministry of Health</option>                                   <option value='English Society of Friends'>English Society of Friends</option>                                   <option value='Entente Powers'>Entente Powers</option>                                   <option value='Episcopal Church'>Episcopal Church</option>                                   <option value='Episcopal House of Bishops'>Episcopal House of Bishops</option>                                   <option value='Episcopal House of Deputies'>Episcopal House of Deputies</option>                                   <option value='Ethical Culture Society, Leiglstive Committee'>Ethical Culture Society, Leiglstive Committee</option>                                   <option value='Eugenic Clinic'>Eugenic Clinic</option>                                   <option value='Eugenics Education Society'>Eugenics Education Society</option>                                   <option value='Eugenics Society'>Eugenics Society</option>                                   <option value='European Relief Council'>European Relief Council</option>                                   <option value='Fabian Hall'>Fabian Hall</option>                                   <option value='Family Planning association'>Family Planning association</option>                                   <option value='Family Planning Association of Great Britain'>Family Planning Association of Great Britain</option>                                   <option value='Family Planning Association of India'>Family Planning Association of India</option>                                   <option value='Family Planning Association of New Zealand'>Family Planning Association of New Zealand</option>                                   <option value='Family Planning Association of Puerto Rico'>Family Planning Association of Puerto Rico</option>                                   <option value='Family Planning Federation of Japan'>Family Planning Federation of Japan</option>                                   <option value='Federal Committee on Legislation for Birth Control'>Federal Committee on Legislation for Birth Control</option>                                   <option value='Federal Council of Churches of Christ in America'>Federal Council of Churches of Christ in America</option>                                   <option value='Federal Council of the Church of Christ in America, Committee on Marriage and the Family'>Federal Council of the Church of Christ in America, Committee on Marriage and the Family</option>                                   <option value='Federal Council of the Churches of Christ in America'>Federal Council of the Churches of Christ in America</option>                                   <option value='Federal Emergency Relief Administration'>Federal Emergency Relief Administration</option>                                   <option value='Federal Reserve'>Federal Reserve</option>                                   <option value='Federation for Child Study Legislative Committee'>Federation for Child Study Legislative Committee</option>                                   <option value='Fifth International Conference on Planned Parenthood'>Fifth International Conference on Planned Parenthood</option>                                   <option value='Fifth International Neo-Malthusian Conference'>Fifth International Neo-Malthusian Conference</option>                                   <option value='First National Birth Control Conference'>First National Birth Control Conference</option>                                   <option value='fourth International Planned Parenthood conference'>fourth International Planned Parenthood conference</option>                                   <option value='Fox College'>Fox College</option>                                   <option value='Free Speech League'>Free Speech League</option>                                   <option value='Free Speech League, the'>Free Speech League, the</option>                                   <option value='French Red Cross'>French Red Cross</option>                                   <option value='French Union of Family Associations'>French Union of Family Associations</option>                                   <option value='Friend of Mental Liberty'>Friend of Mental Liberty</option>                                   <option value='Gallup'>Gallup</option>                                   <option value='General Council of Congregational and Christian Churches'>General Council of Congregational and Christian Churches</option>                                   <option value='General Federation of Women's Clubs'>General Federation of Women's Clubs</option>                                   <option value='General Federation of Womenâ€™s Clubs'>General Federation of Womenâ€™s Clubs</option>                                   <option value='Generation Consciente'>Generation Consciente</option>                                   <option value='Germany Government'>Germany Government</option>                                   <option value='Government of India'>Government of India</option>                                   <option value='Government University of Peking'>Government University of Peking</option>                                   <option value='Gran Consiglio de Fascismo'>Gran Consiglio de Fascismo</option>                                   <option value='Great Britain, Labor Party'>Great Britain, Labor Party</option>                                   <option value='Great Britian Ministry of Health'>Great Britian Ministry of Health</option>                                   <option value='Gynecological association'>Gynecological association</option>                                   <option value='Hague Publishing Company, Inc.'>Hague Publishing Company, Inc.</option>                                   <option value='Hannah Stone Maternal Health Center'>Hannah Stone Maternal Health Center</option>                                   <option value='Hartford Federation of Churches'>Hartford Federation of Churches</option>                                   <option value='Harvard University'>Harvard University</option>                                   <option value='Havard University'>Havard University</option>                                   <option value='Holy Name Society'>Holy Name Society</option>                                   <option value='Hong Kong Family Planning Association'>Hong Kong Family Planning Association</option>                                   <option value='Hong Kong University'>Hong Kong University</option>                                   <option value='Hotel Plaza'>Hotel Plaza</option>                                   <option value='Houghton Mifflin Company'>Houghton Mifflin Company</option>                                   <option value='House of Commons'>House of Commons</option>                                   <option value='House of Lords'>House of Lords</option>                                   <option value='house of representatives'>house of representatives</option>                                   <option value='Human Betterment Association of America'>Human Betterment Association of America</option>                                   <option value='Human Betterment Foundation'>Human Betterment Foundation</option>                                   <option value='Hungarian Medical Senate'>Hungarian Medical Senate</option>                                   <option value='Imperial Japanese Navy'>Imperial Japanese Navy</option>                                   <option value='Imperial Medical College'>Imperial Medical College</option>                                   <option value='Indian Council of Medical Research'>Indian Council of Medical Research</option>                                   <option value='Indian Medical Service'>Indian Medical Service</option>                                   <option value='Indian National Congress'>Indian National Congress</option>                                   <option value='Industrial Hygiene Division'>Industrial Hygiene Division</option>                                   <option value='Industrial Workers of the World'>Industrial Workers of the World</option>                                   <option value='Institute of Euthenics'>Institute of Euthenics</option>                                   <option value='Institute of Pacific Relations'>Institute of Pacific Relations</option>                                   <option value='Institute of Public Health'>Institute of Public Health</option>                                   <option value='Interboro Rapid Transit Co.'>Interboro Rapid Transit Co.</option>                                   <option value='Interdepartmental Committee to coordinate Health & Welfare Activities'>Interdepartmental Committee to coordinate Health & Welfare Activities</option>                                   <option value='Interdepartmental Committee to Coordinate Health and Welfare Activity, Technical Committee'>Interdepartmental Committee to Coordinate Health and Welfare Activity, Technical Committee</option>                                   <option value='International Association of Workers'>International Association of Workers</option>                                   <option value='International Birth Control Conference, Seventh (Zurich)'>International Birth Control Conference, Seventh (Zurich)</option>                                   <option value='International Child Welfare League, the'>International Child Welfare League, the</option>                                   <option value='International Committee on Planned Parenthood'>International Committee on Planned Parenthood</option>                                   <option value='International Committee on Planned Parenthood, American Committee'>International Committee on Planned Parenthood, American Committee</option>                                   <option value='International Committee on Planned Parenthood, British Committee'>International Committee on Planned Parenthood, British Committee</option>                                   <option value='International Conference'>International Conference</option>                                   <option value='International Conference on Birth Control, Third (Bombay)'>International Conference on Birth Control, Third (Bombay)</option>                                   <option value='International Conference on Planned Parenthood, 5th (1955, Tokyo)'>International Conference on Planned Parenthood, 5th (1955, Tokyo)</option>                                   <option value='International Conference on Planned Parenthood, Fifth (Tokyo, 1955)'>International Conference on Planned Parenthood, Fifth (Tokyo, 1955)</option>                                   <option value='International Conference on Planned Parenthood, Fourth (Stockholm)'>International Conference on Planned Parenthood, Fourth (Stockholm)</option>                                   <option value='International Conference on Planned Parenthood, Third (Bombay)'>International Conference on Planned Parenthood, Third (Bombay)</option>                                   <option value='International Congress of Eugenics'>International Congress of Eugenics</option>                                   <option value='International Congress on Population and World Resources in Relation to Family, Conference Committee'>International Congress on Population and World Resources in Relation to Family, Conference Committee</option>                                   <option value='International Congress on Population and World Resources in Relation to the Family'>International Congress on Population and World Resources in Relation to the Family</option>                                   <option value='International Federation of Birth Control League'>International Federation of Birth Control League</option>                                   <option value='International Medical Congress'>International Medical Congress</option>                                   <option value='International Medical Group for the Investigation of Birth Control'>International Medical Group for the Investigation of Birth Control</option>                                   <option value='International Neo-Malthusian and Birth Control Conference, Fifth (London)'>International Neo-Malthusian and Birth Control Conference, Fifth (London)</option>                                   <option value='International Neo-Malthusian and Birth control Conference, Sixth (New York)'>International Neo-Malthusian and Birth control Conference, Sixth (New York)</option>                                   <option value='International Neo-Malthusian Bureau of Correspondence and Defence'>International Neo-Malthusian Bureau of Correspondence and Defence</option>                                   <option value='International Planned Parenthood Federation'>International Planned Parenthood Federation</option>                                   <option value='International Planned Parenthood Federation, English Committee'>International Planned Parenthood Federation, English Committee</option>                                   <option value='International Planned Parenthood Federation, Steering Committee'>International Planned Parenthood Federation, Steering Committee</option>                                   <option value='International Planned Parenthood federation.'>International Planned Parenthood federation.</option>                                   <option value='International Rice commission'>International Rice commission</option>                                   <option value='International Union for the Scientific Study of Population Problems'>International Union for the Scientific Study of Population Problems</option>                                   <option value='International Union of Family Organizations'>International Union of Family Organizations</option>                                   <option value='Iowa Medical Society'>Iowa Medical Society</option>                                   <option value='Italian Chamber of Deputies'>Italian Chamber of Deputies</option>                                   <option value='Italy Chamber of Deputies'>Italy Chamber of Deputies</option>                                   <option value='Japan Federation of Family Planning'>Japan Federation of Family Planning</option>                                   <option value='Japan Foreign Office'>Japan Foreign Office</option>                                   <option value='Japan Home Office'>Japan Home Office</option>                                   <option value='Japan Institute of Public Health'>Japan Institute of Public Health</option>                                   <option value='Japan Ministry of Health and Welfare'>Japan Ministry of Health and Welfare</option>                                   <option value='Japan Public Health Institute'>Japan Public Health Institute</option>                                   <option value='Japan, Government of'>Japan, Government of</option>                                   <option value='Japan, House of Councillors'>Japan, House of Councillors</option>                                   <option value='Japan, House of Councillors Public Welfare Committee'>Japan, House of Councillors Public Welfare Committee</option>                                   <option value='Japan, Ministry of Health and Welfare'>Japan, Ministry of Health and Welfare</option>                                   <option value='Japanese Diet'>Japanese Diet</option>                                   <option value='Japanese Foreign Office'>Japanese Foreign Office</option>                                   <option value='Japanese government'>Japanese government</option>                                   <option value='Japanese Gynecological Society'>Japanese Gynecological Society</option>                                   <option value='Japanese Home Office'>Japanese Home Office</option>                                   <option value='Jewish Community Center'>Jewish Community Center</option>                                   <option value='Jewish Federation of Women'>Jewish Federation of Women</option>                                   <option value='Johns Hopkins Hospital'>Johns Hopkins Hospital</option>                                   <option value='Johns Hopkins Medical School'>Johns Hopkins Medical School</option>                                   <option value='Johns Hopkins University'>Johns Hopkins University</option>                                   <option value='Johns Hopkins University Hospital'>Johns Hopkins University Hospital</option>                                   <option value='Johns Hopkins University Medical School'>Johns Hopkins University Medical School</option>                                   <option value='Journal of Marriage Hygiene'>Journal of Marriage Hygiene</option>                                   <option value='Juke Family'>Juke Family</option>                                   <option value='Junior League'>Junior League</option>                                   <option value='Junior League of New York'>Junior League of New York</option>                                   <option value='Juvenile Court'>Juvenile Court</option>                                   <option value='Kaizo'>Kaizo</option>                                   <option value='Kaizo group'>Kaizo group</option>                                   <option value='Kaizo publishing house'>Kaizo publishing house</option>                                   <option value='Kakushin Kurabu (Reform Club)'>Kakushin Kurabu (Reform Club)</option>                                   <option value='Kallikak Family'>Kallikak Family</option>                                   <option value='Keneseth Israel Synagogue'>Keneseth Israel Synagogue</option>                                   <option value='Knights of Columbus'>Knights of Columbus</option>                                   <option value='Komsomol'>Komsomol</option>                                   <option value='Koya, Yoshio'>Koya, Yoshio</option>                                   <option value='Labor Temple'>Labor Temple</option>                                   <option value='Lambeth Conference'>Lambeth Conference</option>                                   <option value='Lambeth conference of the bishops'>Lambeth conference of the bishops</option>                                   <option value='Lancet Club'>Lancet Club</option>                                   <option value='Lasker foundation'>Lasker foundation</option>                                   <option value='Laundry Workers Union'>Laundry Workers Union</option>                                   <option value='Lawrence Defense Conference'>Lawrence Defense Conference</option>                                   <option value='League for Women Voters'>League for Women Voters</option>                                   <option value='League of Nations'>League of Nations</option>                                   <option value='League of Women Voters,'>League of Women Voters,</option>                                   <option value='Leagues of Nations'>Leagues of Nations</option>                                   <option value='Leavenworth Penitentiary'>Leavenworth Penitentiary</option>                                   <option value='Lenox Library'>Lenox Library</option>                                   <option value='Liberal Club'>Liberal Club</option>                                   <option value='Library of Congress'>Library of Congress</option>                                   <option value='Ligue de la rÃ©gÃ©neration humaine'>Ligue de la rÃ©gÃ©neration humaine</option>                                   <option value='London University'>London University</option>                                   <option value='Lying In Hospital'>Lying In Hospital</option>                                   <option value='Madras Neo-Malthusian League'>Madras Neo-Malthusian League</option>                                   <option value='Magistrates Court'>Magistrates Court</option>                                   <option value='Mainichi Daily News'>Mainichi Daily News</option>                                   <option value='Mainichi Press'>Mainichi Press</option>                                   <option value='Malaysian Young Men's Christian Association'>Malaysian Young Men's Christian Association</option>                                   <option value='Malthusian League'>Malthusian League</option>                                   <option value='Margaret Sanger Research Bureau'>Margaret Sanger Research Bureau</option>                                   <option value='Marstin Press'>Marstin Press</option>                                   <option value='Mass Education Movement'>Mass Education Movement</option>                                   <option value='Massachusetts General Hospital'>Massachusetts General Hospital</option>                                   <option value='Massachusetts Institute of Technology'>Massachusetts Institute of Technology</option>                                   <option value='Massachusetts Legislature'>Massachusetts Legislature</option>                                   <option value='Massachusetts Medical society'>Massachusetts Medical society</option>                                   <option value='Massachusetts Mother's Health Council'>Massachusetts Mother's Health Council</option>                                   <option value='Massachusetts Motherâ€™s Health Council'>Massachusetts Motherâ€™s Health Council</option>                                   <option value='Massachusetts Supreme Court'>Massachusetts Supreme Court</option>                                   <option value='Maternal and Child Welfare Centers'>Maternal and Child Welfare Centers</option>                                   <option value='Maternal and Infant Welfare Stations'>Maternal and Infant Welfare Stations</option>                                   <option value='Maternity and Infant Welfare Agencies'>Maternity and Infant Welfare Agencies</option>                                   <option value='Maternity Center Association of New York'>Maternity Center Association of New York</option>                                   <option value='Maternity Centres'>Maternity Centres</option>                                   <option value='Mathusian League'>Mathusian League</option>                                   <option value='Medical Association'>Medical Association</option>                                   <option value='Men's City Club of St. Louis'>Men's City Club of St. Louis</option>                                   <option value='Methodist Church Regional Conferences'>Methodist Church Regional Conferences</option>                                   <option value='Methodist Episcopal Church City Planning Committee'>Methodist Episcopal Church City Planning Committee</option>                                   <option value='Migrant Workers World Union'>Migrant Workers World Union</option>                                   <option value='Miners of Wyoming'>Miners of Wyoming</option>                                   <option value='Ministry of Health'>Ministry of Health</option>                                   <option value='Ministry of Health and Welfare'>Ministry of Health and Welfare</option>                                   <option value='Ministry of Health and Welfare of Japan'>Ministry of Health and Welfare of Japan</option>                                   <option value='Ministry of Health of'>Ministry of Health of</option>                                   <option value='Minnesota Medical Association'>Minnesota Medical Association</option>                                   <option value='Modern School'>Modern School</option>                                   <option value='Mount Pleasant Congregational Church'>Mount Pleasant Congregational Church</option>                                   <option value='Municipal Corporation of Bombay'>Municipal Corporation of Bombay</option>                                   <option value='Murphy, John W.'>Murphy, John W.</option>                                   <option value='National Academy'>National Academy</option>                                   <option value='National and State Conferences of Social Work'>National and State Conferences of Social Work</option>                                   <option value='National Association of Broadcasters'>National Association of Broadcasters</option>                                   <option value='National Association of Education'>National Association of Education</option>                                   <option value='National Birth Control Association'>National Birth Control Association</option>                                   <option value='National Birth Rate Commission'>National Birth Rate Commission</option>                                   <option value='National Birth-Rate Commission'>National Birth-Rate Commission</option>                                   <option value='National Broadcasting company'>National Broadcasting company</option>                                   <option value='National Catholic Welfare Conference'>National Catholic Welfare Conference</option>                                   <option value='National Catholic Welfare Council'>National Catholic Welfare Council</option>                                   <option value='National Citizens committee'>National Citizens committee</option>                                   <option value='National Clergymen's Advisory council'>National Clergymen's Advisory council</option>                                   <option value='National Clergymenâ€™s Advisory council'>National Clergymenâ€™s Advisory council</option>                                   <option value='National Commission for Federal Legislation on Birth Control'>National Commission for Federal Legislation on Birth Control</option>                                   <option value='National Committe on Federal Legislation for Birth Control'>National Committe on Federal Legislation for Birth Control</option>                                   <option value='National Committee for Federal Legislation on Birth Control'>National Committee for Federal Legislation on Birth Control</option>                                   <option value='National Committee on Federal Legislation for Birth Control'>National Committee on Federal Legislation for Birth Control</option>                                   <option value='National Committee on Maternal Health'>National Committee on Maternal Health</option>                                   <option value='National Conference of Colored Parent-Teachers'>National Conference of Colored Parent-Teachers</option>                                   <option value='National Conference of Labor Women'>National Conference of Labor Women</option>                                   <option value='National Conference of Social Work'>National Conference of Social Work</option>                                   <option value='National Convention of Charities'>National Convention of Charities</option>                                   <option value='National Council of Jewish Women'>National Council of Jewish Women</option>                                   <option value='National Council of Negro Women'>National Council of Negro Women</option>                                   <option value='National Council of Public Morals'>National Council of Public Morals</option>                                   <option value='National Emergency Council'>National Emergency Council</option>                                   <option value='National Health Council'>National Health Council</option>                                   <option value='National Institute of Statistic, Italy'>National Institute of Statistic, Italy</option>                                   <option value='National Manufacturers Association'>National Manufacturers Association</option>                                   <option value='National Marriage Guidance Council'>National Marriage Guidance Council</option>                                   <option value='National Medical Association'>National Medical Association</option>                                   <option value='National Medical Committee on State and Federal Birth Control Legislation'>National Medical Committee on State and Federal Birth Control Legislation</option>                                   <option value='National Medical Council on Birth Control'>National Medical Council on Birth Control</option>                                   <option value='National Negro Insurance association'>National Negro Insurance association</option>                                   <option value='National Planning Committee on Work with Negroes'>National Planning Committee on Work with Negroes</option>                                   <option value='National Recovery Administration'>National Recovery Administration</option>                                   <option value='National Research council'>National Research council</option>                                   <option value='National Research Council Committee on Human Reproduction'>National Research Council Committee on Human Reproduction</option>                                   <option value='National Research council's Committee on Human Reproduction'>National Research council's Committee on Human Reproduction</option>                                   <option value='National Research councilâ€™s Committee on Human Reproduction'>National Research councilâ€™s Committee on Human Reproduction</option>                                   <option value='National Resources Committee'>National Resources Committee</option>                                   <option value='National Urban League'>National Urban League</option>                                   <option value='National Youth Administration'>National Youth Administration</option>                                   <option value='Naturalization Aid Society'>Naturalization Aid Society</option>                                   <option value='Nederlandse Vereniging voor Sexuele Hervorming'>Nederlandse Vereniging voor Sexuele Hervorming</option>                                   <option value='Negro Newspaper Association, the'>Negro Newspaper Association, the</option>                                   <option value='Neo-Malthusian League'>Neo-Malthusian League</option>                                   <option value='Netherlands Central Bureau of Statistics'>Netherlands Central Bureau of Statistics</option>                                   <option value='New Generation League'>New Generation League</option>                                   <option value='New Life Movement'>New Life Movement</option>                                   <option value='New Women's Movement of Japan'>New Women's Movement of Japan</option>                                   <option value='New York Academy of Medicine'>New York Academy of Medicine</option>                                   <option value='New York Academy of Medicine, Committee on Public Health'>New York Academy of Medicine, Committee on Public Health</option>                                   <option value='New York Academy of Medicine, Council'>New York Academy of Medicine, Council</option>                                   <option value='New York Birth Control League'>New York Birth Control League</option>                                   <option value='New York Board of Education'>New York Board of Education</option>                                   <option value='New York City Board of Education'>New York City Board of Education</option>                                   <option value='New York City Board of Health'>New York City Board of Health</option>                                   <option value='New York City Board of Hospitals'>New York City Board of Hospitals</option>                                   <option value='New York City Court of Special Sessions'>New York City Court of Special Sessions</option>                                   <option value='New York City Police Department'>New York City Police Department</option>                                   <option value='New York City Policewomen's Bureau'>New York City Policewomen's Bureau</option>                                   <option value='New York City Vocational Adjustment Bureau'>New York City Vocational Adjustment Bureau</option>                                   <option value='New York City Woman's Suffrage Party'>New York City Woman's Suffrage Party</option>                                   <option value='New York Committee for Planned Parenthood'>New York Committee for Planned Parenthood</option>                                   <option value='New York Court of Appeals'>New York Court of Appeals</option>                                   <option value='New York Health Department'>New York Health Department</option>                                   <option value='New York Herald Tribune'>New York Herald Tribune</option>                                   <option value='New York League of Women Workers'>New York League of Women Workers</option>                                   <option value='New York Legislature'>New York Legislature</option>                                   <option value='New York Mayor's Committee of Women on National Defense'>New York Mayor's Committee of Women on National Defense</option>                                   <option value='New York Society for the Suppression of Vice'>New York Society for the Suppression of Vice</option>                                   <option value='New York State Assembly'>New York State Assembly</option>                                   <option value='New York State Board of Charities'>New York State Board of Charities</option>                                   <option value='New York State Court of Appeals'>New York State Court of Appeals</option>                                   <option value='New York State Department of Health'>New York State Department of Health</option>                                   <option value='New York State Federation for Planned Parenthood'>New York State Federation for Planned Parenthood</option>                                   <option value='New York University'>New York University</option>                                   <option value='New York Women's Publishing Co., Inc.'>New York Women's Publishing Co., Inc.</option>                                   <option value='New York World's Fair'>New York World's Fair</option>                                   <option value='New York Worldâ€™s Fair'>New York Worldâ€™s Fair</option>                                   <option value='Newark Maternal Health Center'>Newark Maternal Health Center</option>                                   <option value='Newspaper Enterprise Associates'>Newspaper Enterprise Associates</option>                                   <option value='Nieuw Malthuiaansche Bond'>Nieuw Malthuiaansche Bond</option>                                   <option value='Nieuw Malthusiaansche Bond'>Nieuw Malthusiaansche Bond</option>                                   <option value='Nieuw Malthusiaansche Bond,'>Nieuw Malthusiaansche Bond,</option>                                   <option value='North Carolina Department of Health and Human Services'>North Carolina Department of Health and Human Services</option>                                   <option value='North Carolina State Board of Health, Division of Preventative Medicine'>North Carolina State Board of Health, Division of Preventative Medicine</option>                                   <option value='nter-American Commission of Women'>nter-American Commission of Women</option>                                   <option value='Oneida Community'>Oneida Community</option>                                   <option value='Oregon State Board of Pharmacy'>Oregon State Board of Pharmacy</option>                                   <option value='Otago university'>Otago university</option>                                   <option value='Park Theater'>Park Theater</option>                                   <option value='Park Theatre'>Park Theatre</option>                                   <option value='Parliament'>Parliament</option>                                   <option value='Parliament of the United Kingdom'>Parliament of the United Kingdom</option>                                   <option value='Paulist fathers'>Paulist fathers</option>                                   <option value='Peers Club'>Peers Club</option>                                   <option value='Peers' Club'>Peers' Club</option>                                   <option value='Peersâ€™ Club'>Peersâ€™ Club</option>                                   <option value='Peiping National University'>Peiping National University</option>                                   <option value='Peking University'>Peking University</option>                                   <option value='Penang General Hospital'>Penang General Hospital</option>                                   <option value='Penang Maternity Hospital'>Penang Maternity Hospital</option>                                   <option value='Penang Municipal Health Work'>Penang Municipal Health Work</option>                                   <option value='Penang Rotary Club'>Penang Rotary Club</option>                                   <option value='Pennsylvania Birth Control Federation'>Pennsylvania Birth Control Federation</option>                                   <option value='Pennsylvania Board of Education'>Pennsylvania Board of Education</option>                                   <option value='Philadelphia Child Guidance Clinin'>Philadelphia Child Guidance Clinin</option>                                   <option value='Philadelphia Yearly Meeting of the Religious Society of Friends'>Philadelphia Yearly Meeting of the Religious Society of Friends</option>                                   <option value='Planned Parenhood Federation of America Dickinson Research Memorial Fund'>Planned Parenhood Federation of America Dickinson Research Memorial Fund</option>                                   <option value='Planned Parenthood'>Planned Parenthood</option>                                   <option value='Planned Parenthood Clinic of Tuscon'>Planned Parenthood Clinic of Tuscon</option>                                   <option value='Planned Parenthood Committee of Greater New York'>Planned Parenthood Committee of Greater New York</option>                                   <option value='Planned Parenthood Federation of America'>Planned Parenthood Federation of America</option>                                   <option value='Planned Parenthood Federation of America, Committee on Clinic Studies'>Planned Parenthood Federation of America, Committee on Clinic Studies</option>                                   <option value='Planned Parenthood Federation of America, Division of Negro Service'>Planned Parenthood Federation of America, Division of Negro Service</option>                                   <option value='Planned Parenthood Federation of America, Inc'>Planned Parenthood Federation of America, Inc</option>                                   <option value='Planned Parenthood Federation of America, Inc.'>Planned Parenthood Federation of America, Inc.</option>                                   <option value='Planned Parenthood Federation of America, Medical Advisory Committee'>Planned Parenthood Federation of America, Medical Advisory Committee</option>                                   <option value='Planned Parenthood Federation of America, Medical Committee'>Planned Parenthood Federation of America, Medical Committee</option>                                   <option value='Planned Parenthood Federation of America, National Clergyman's Advisory Council'>Planned Parenthood Federation of America, National Clergyman's Advisory Council</option>                                   <option value='Planned Parenthood Federation of America, National Clergymen's Advisory Committee'>Planned Parenthood Federation of America, National Clergymen's Advisory Committee</option>                                   <option value='Planned Parenthood Federation of America, National Negro Advisory Council'>Planned Parenthood Federation of America, National Negro Advisory Council</option>                                   <option value='Planned Parenthood League of Connecticut'>Planned Parenthood League of Connecticut</option>                                   <option value='Plantations Club'>Plantations Club</option>                                   <option value='Population Advisory Board'>Population Advisory Board</option>                                   <option value='Population Problem Institute'>Population Problem Institute</option>                                   <option value='Population Reference bureau'>Population Reference bureau</option>                                   <option value='Post Office'>Post Office</option>                                   <option value='Post Office Department, the'>Post Office Department, the</option>                                   <option value='post-office'>post-office</option>                                   <option value='Princeton University'>Princeton University</option>                                   <option value='Public Forum'>Public Forum</option>                                   <option value='Puerto Rico, Department of Health'>Puerto Rico, Department of Health</option>                                   <option value='Queens Count Penitentiary'>Queens Count Penitentiary</option>                                   <option value='Queens County () Penitentiary'>Queens County () Penitentiary</option>                                   <option value='Queens County Penitentiary'>Queens County Penitentiary</option>                                   <option value='Rabbinical Assembly of America'>Rabbinical Assembly of America</option>                                   <option value='Ramsey County Medical Society, the'>Ramsey County Medical Society, the</option>                                   <option value='Rangel-Cline Defense Committee'>Rangel-Cline Defense Committee</option>                                   <option value='Rationalist Schools,'>Rationalist Schools,</option>                                   <option value='Red Cross'>Red Cross</option>                                   <option value='Reformatory for Women'>Reformatory for Women</option>                                   <option value='Reichstag'>Reichstag</option>                                   <option value='Reischstag'>Reischstag</option>                                   <option value='Republican Party Convention'>Republican Party Convention</option>                                   <option value='Rhode Island Birth Control League'>Rhode Island Birth Control League</option>                                   <option value='Rice Institute'>Rice Institute</option>                                   <option value='Rickshaw Men's Union'>Rickshaw Men's Union</option>                                   <option value='RiksfÃ¶rbundet fÃ¶r Sexeull Upplysning'>RiksfÃ¶rbundet fÃ¶r Sexeull Upplysning</option>                                   <option value='Riksforbundet fur Sexuell Upplysning'>Riksforbundet fur Sexuell Upplysning</option>                                   <option value='Riverside Church'>Riverside Church</option>                                   <option value='Robert L. Dickinson Research memorial'>Robert L. Dickinson Research memorial</option>                                   <option value='Rockefeller Foundation'>Rockefeller Foundation</option>                                   <option value='Rockefeller Institute'>Rockefeller Institute</option>                                   <option value='Roman Catholic Archdiocese of New York City'>Roman Catholic Archdiocese of New York City</option>                                   <option value='Roman Catholic Church'>Roman Catholic Church</option>                                   <option value='Salvation Army'>Salvation Army</option>                                   <option value='Sanger Clinic'>Sanger Clinic</option>                                   <option value='Scripps Foundation for Population Research'>Scripps Foundation for Population Research</option>                                   <option value='Scripps Foundation of Research in Population Problems'>Scripps Foundation of Research in Population Problems</option>                                   <option value='Selective Service System'>Selective Service System</option>                                   <option value='Selective Service System, Medical Division'>Selective Service System, Medical Division</option>                                   <option value='Senate'>Senate</option>                                   <option value='Shinfujin Kyokai'>Shinfujin Kyokai</option>                                   <option value='Shoshone'>Shoshone</option>                                   <option value='Sing-Sing Correctional Facility'>Sing-Sing Correctional Facility</option>                                   <option value='Sixth International Neo-Malthusian and Birth Control Conference'>Sixth International Neo-Malthusian and Birth Control Conference</option>                                   <option value='Smith College'>Smith College</option>                                   <option value='Socialist party'>Socialist party</option>                                   <option value='Socialist Party of New York'>Socialist Party of New York</option>                                   <option value='Socialist Party of New York City'>Socialist Party of New York City</option>                                   <option value='Socialist party of the'>Socialist party of the</option>                                   <option value='Society for the Prevention of Cruelty to Children'>Society for the Prevention of Cruelty to Children</option>                                   <option value='Society for the Study and Promotion of Family Hygiene'>Society for the Study and Promotion of Family Hygiene</option>                                   <option value='Society for the Suppression of Vice'>Society for the Suppression of Vice</option>                                   <option value='Society of Friends'>Society of Friends</option>                                   <option value='South African National Council for Maternal and Family Welfare'>South African National Council for Maternal and Family Welfare</option>                                   <option value='Spanish Army'>Spanish Army</option>                                   <option value='Spanish Government'>Spanish Government</option>                                   <option value='St. Anthonyâ€™s Roman Catholic Church'>St. Anthonyâ€™s Roman Catholic Church</option>                                   <option value='St. Luke's International Hospital'>St. Luke's International Hospital</option>                                   <option value='St. Lukeâ€™s International Hospital'>St. Lukeâ€™s International Hospital</option>                                   <option value='St. Patrick's Cathedral'>St. Patrick's Cathedral</option>                                   <option value='St. Patrickâ€™s Cathedral'>St. Patrickâ€™s Cathedral</option>                                   <option value='St. Paul's'>St. Paul's</option>                                   <option value='St. Paul's Cathedral'>St. Paul's Cathedral</option>                                   <option value='St. Paulâ€™s Cathedral'>St. Paulâ€™s Cathedral</option>                                   <option value='St. Phillip's Church'>St. Phillip's Church</option>                                   <option value='St. Phillipâ€™s Church'>St. Phillipâ€™s Church</option>                                   <option value='State Eugenic Board'>State Eugenic Board</option>                                   <option value='State Medical Association'>State Medical Association</option>                                   <option value='State Medical Society'>State Medical Society</option>                                   <option value='Statistical Bureau of the Japanese Cabinet'>Statistical Bureau of the Japanese Cabinet</option>                                   <option value='Stockholm Birth Control'>Stockholm Birth Control</option>                                   <option value='Teaching Center Clinic'>Teaching Center Clinic</option>                                   <option value='Temple University'>Temple University</option>                                   <option value='the American Birth Control League'>the American Birth Control League</option>                                   <option value='the Church of'>the Church of</option>                                   <option value='the Committee of One Hundred'>the Committee of One Hundred</option>                                   <option value='the Conference of Methodist Episcopal Churches'>the Conference of Methodist Episcopal Churches</option>                                   <option value='the Spanish Civil Guard'>the Spanish Civil Guard</option>                                   <option value='the Women's City Club'>the Women's City Club</option>                                   <option value='the Womenâ€™s City Club'>the Womenâ€™s City Club</option>                                   <option value='Theosophical Society'>Theosophical Society</option>                                   <option value='Third International Conference on Planned Parenthood'>Third International Conference on Planned Parenthood</option>                                   <option value='Third International Conference on Planned Parenthood (Bombay)'>Third International Conference on Planned Parenthood (Bombay)</option>                                   <option value='third International Planned Parenthood conference'>third International Planned Parenthood conference</option>                                   <option value='Third Southern Conference on Tomorrow's Children'>Third Southern Conference on Tomorrow's Children</option>                                   <option value='Third Southern Conference on Tomorrowâ€™s Children'>Third Southern Conference on Tomorrowâ€™s Children</option>                                   <option value='Tinnevelly Medical Association'>Tinnevelly Medical Association</option>                                   <option value='Tokyo University'>Tokyo University</option>                                   <option value='Tokyo Young Men's Christian Association'>Tokyo Young Men's Christian Association</option>                                   <option value='Town Hall'>Town Hall</option>                                   <option value='Triangle shirtwaist factory'>Triangle shirtwaist factory</option>                                   <option value='Troup Junior High School'>Troup Junior High School</option>                                   <option value='Tucson Mothers Health Clinic'>Tucson Mothers Health Clinic</option>                                   <option value='Typographical Union'>Typographical Union</option>                                   <option value='U. S. Army'>U. S. Army</option>                                   <option value='U. S. Department of the Treasury'>U. S. Department of the Treasury</option>                                   <option value='U. S. Navy'>U. S. Navy</option>                                   <option value='U. S. Post Office'>U. S. Post Office</option>                                   <option value='U.S. Census Bureau'>U.S. Census Bureau</option>                                   <option value='U.S. Children's Bureau'>U.S. Children's Bureau</option>                                   <option value='U.S. Commissioner of Education'>U.S. Commissioner of Education</option>                                   <option value='U.S. Congress, Committee on the Judiciary'>U.S. Congress, Committee on the Judiciary</option>                                   <option value='U.S. Department of Labor'>U.S. Department of Labor</option>                                   <option value='U.S. Department of the Navy'>U.S. Department of the Navy</option>                                   <option value='U.S. Federal Trade Commission'>U.S. Federal Trade Commission</option>                                   <option value='U.S. Post Office'>U.S. Post Office</option>                                   <option value='U.S. Public Health Service'>U.S. Public Health Service</option>                                   <option value='U.S. Senate'>U.S. Senate</option>                                   <option value='U.S. War Department'>U.S. War Department</option>                                   <option value='U.S.S.R. Government'>U.S.S.R. Government</option>                                   <option value='Unidentified'>Unidentified</option>                                   <option value='Union for the study of Population'>Union for the study of Population</option>                                   <option value='Unitarian Associations'>Unitarian Associations</option>                                   <option value='United Nations'>United Nations</option>                                   <option value='United Nations Commission on Human Rights'>United Nations Commission on Human Rights</option>                                   <option value='United Nations Department of Social and Economic Affairs'>United Nations Department of Social and Economic Affairs</option>                                   <option value='United Nations Economic and Social Council'>United Nations Economic and Social Council</option>                                   <option value='United Nations Educational, Scientific, and Cultural organization'>United Nations Educational, Scientific, and Cultural organization</option>                                   <option value='United Nations Food and Agricultural organization'>United Nations Food and Agricultural organization</option>                                   <option value='United Nations Food and Agriculture Organization'>United Nations Food and Agriculture Organization</option>                                   <option value='United Nations International Health Conference'>United Nations International Health Conference</option>                                   <option value='United Nations, International Health Conference'>United Nations, International Health Conference</option>                                   <option value='United Press'>United Press</option>                                   <option value='United Service Organization'>United Service Organization</option>                                   <option value='United State Congress'>United State Congress</option>                                   <option value='United States Air Force'>United States Air Force</option>                                   <option value='United States Army'>United States Army</option>                                   <option value='United States Bureau of Customs'>United States Bureau of Customs</option>                                   <option value='United States Bureau of Education'>United States Bureau of Education</option>                                   <option value='United States Child Labor Commission'>United States Child Labor Commission</option>                                   <option value='United States Children's Bureau'>United States Children's Bureau</option>                                   <option value='United States Childrenâ€™s Bureau'>United States Childrenâ€™s Bureau</option>                                   <option value='United States Circuit Court'>United States Circuit Court</option>                                   <option value='United States Circuit Court of Appeals'>United States Circuit Court of Appeals</option>                                   <option value='United States Circuit Court of Appeals for the Second Circuit'>United States Circuit Court of Appeals for the Second Circuit</option>                                   <option value='United States Circuit Court of Appeals, Second District'>United States Circuit Court of Appeals, Second District</option>                                   <option value='United States Congress'>United States Congress</option>                                   <option value='United States Court of Appeals'>United States Court of Appeals</option>                                   <option value='United States Customs'>United States Customs</option>                                   <option value='United States Department of Agriculture'>United States Department of Agriculture</option>                                   <option value='United States Department of Agricultures'>United States Department of Agricultures</option>                                   <option value='United States Department of Labor'>United States Department of Labor</option>                                   <option value='United States District Court, Southern District of New York'>United States District Court, Southern District of New York</option>                                   <option value='United States Embassy of Paris'>United States Embassy of Paris</option>                                   <option value='United States Federal Trade Commission'>United States Federal Trade Commission</option>                                   <option value='United States government'>United States government</option>                                   <option value='United States House of Representatives'>United States House of Representatives</option>                                   <option value='United States House of Representatives, Committee on the Revision of Laws'>United States House of Representatives, Committee on the Revision of Laws</option>                                   <option value='United States Marine Corps'>United States Marine Corps</option>                                   <option value='United States National Recovery Administration'>United States National Recovery Administration</option>                                   <option value='United States Navy'>United States Navy</option>                                   <option value='United States Penitentiary, Leavenworth'>United States Penitentiary, Leavenworth</option>                                   <option value='United States Post Office, the'>United States Post Office, the</option>                                   <option value='United States Post Office'>United States Post Office</option>                                   <option value='United States Postal Service'>United States Postal Service</option>                                   <option value='United States Public Health Service'>United States Public Health Service</option>                                   <option value='United States Publich Health Service'>United States Publich Health Service</option>                                   <option value='United States Senate'>United States Senate</option>                                   <option value='United States Supreme Court'>United States Supreme Court</option>                                   <option value='United States Supreme Court of Errors'>United States Supreme Court of Errors</option>                                   <option value='United States Treasury'>United States Treasury</option>                                   <option value='United States Treasury Department'>United States Treasury Department</option>                                   <option value='United Textile Workers of America'>United Textile Workers of America</option>                                   <option value='Universalist General Convention'>Universalist General Convention</option>                                   <option value='University of'>University of</option>                                   <option value='University of Barcelona'>University of Barcelona</option>                                   <option value='University of California'>University of California</option>                                   <option value='University of London'>University of London</option>                                   <option value='University of Michigan'>University of Michigan</option>                                   <option value='University of Pennsylvania'>University of Pennsylvania</option>                                   <option value='University of Wisconsin'>University of Wisconsin</option>                                   <option value='Upper House Welfare Committee'>Upper House Welfare Committee</option>                                   <option value='Urban League, New York City'>Urban League, New York City</option>                                   <option value='Vassar College'>Vassar College</option>                                   <option value='Vatican'>Vatican</option>                                   <option value='Victoria Theatre'>Victoria Theatre</option>                                   <option value='Vineland Training School for the Feeble Minded'>Vineland Training School for the Feeble Minded</option>                                   <option value='Virginia League for Planned Parenthood'>Virginia League for Planned Parenthood</option>                                   <option value='Voluntary Parenthood League'>Voluntary Parenthood League</option>                                   <option value='Walden School'>Walden School</option>                                   <option value='Waldorf-Astoria Hotel'>Waldorf-Astoria Hotel</option>                                   <option value='Walter Scott'>Walter Scott</option>                                   <option value='Washington Naval Conference'>Washington Naval Conference</option>                                   <option value='Washington Naval Conference, 1922'>Washington Naval Conference, 1922</option>                                   <option value='Washington, D.C. Police Department, Women's Division'>Washington, D.C. Police Department, Women's Division</option>                                   <option value='Watumull foundation'>Watumull foundation</option>                                   <option value='West Side Unitarian Church'>West Side Unitarian Church</option>                                   <option value='WFAS'>WFAS</option>                                   <option value='William Faro, Inc.'>William Faro, Inc.</option>                                   <option value='William Heineman'>William Heineman</option>                                   <option value='Woman's Co-operative Guild'>Woman's Co-operative Guild</option>                                   <option value='Women Accepted for Volunteer Emergency Service'>Women Accepted for Volunteer Emergency Service</option>                                   <option value='Women's Auxillary Army Corps'>Women's Auxillary Army Corps</option>                                   <option value='Women's City Club of St. Louis'>Women's City Club of St. Louis</option>                                   <option value='Women's Co-Operative Guild'>Women's Co-Operative Guild</option>                                   <option value='Women's Committee'>Women's Committee</option>                                   <option value='Women's Committee on Socialist and Suffrage Propaganda'>Women's Committee on Socialist and Suffrage Propaganda</option>                                   <option value='Women's Cooperative Guild'>Women's Cooperative Guild</option>                                   <option value='Women's Republican Club'>Women's Republican Club</option>                                   <option value='Womenâ€™s Cooperative Guild'>Womenâ€™s Cooperative Guild</option>                                   <option value='Womenâ€™s International League for Peace and Freedom'>Womenâ€™s International League for Peace and Freedom</option>                                   <option value='Womenâ€™s Republican Club'>Womenâ€™s Republican Club</option>                                   <option value='Worcester Foundation for Experimental Biology'>Worcester Foundation for Experimental Biology</option>                                   <option value='Workmen's Association for Social Services'>Workmen's Association for Social Services</option>                                   <option value='Workmenâ€™s Association for Social Services'>Workmenâ€™s Association for Social Services</option>                                   <option value='Works Progress Administration'>Works Progress Administration</option>                                   <option value='World Conference on the Family and Population'>World Conference on the Family and Population</option>                                   <option value='World Court'>World Court</option>                                   <option value='World Food and Agricultural'>World Food and Agricultural</option>                                   <option value='World Health Organization'>World Health Organization</option>                                   <option value='World Population Conference'>World Population Conference</option>                                   <option value='World Population Conference, 1927'>World Population Conference, 1927</option>                                   <option value='World Population Conference, 1927 (Geneva)'>World Population Conference, 1927 (Geneva)</option>                                   <option value='Writers' War Board'>Writers' War Board</option>                                   <option value='Y. W. C. A.'>Y. W. C. A.</option>                                   <option value='Yale Law School'>Yale Law School</option>                                   <option value='Yale Medical School'>Yale Medical School</option>                                   <option value='Yale University'>Yale University</option>                                   <option value='Yale University School of Medicine'>Yale University School of Medicine</option>                                   <option value='Yokahama Police'>Yokahama Police</option>                                   <option value='Young Men's and Young Women's Hebrew Association'>Young Men's and Young Women's Hebrew Association</option>                                   <option value='Young Men's Christian Association'>Young Men's Christian Association</option>                                   <option value='Young Men's Christian Association of Tokyo'>Young Men's Christian Association of Tokyo</option>                                   <option value='Young Men's Hebrew Association'>Young Men's Hebrew Association</option>                                   <option value='Young Menâ€™s and Young Womenâ€™s Hebrew Association'>Young Menâ€™s and Young Womenâ€™s Hebrew Association</option>                                   <option value='Young Menâ€™s Hebrew Association'>Young Menâ€™s Hebrew Association</option>                                   <option value='Young Mens Chrisitan Association'>Young Mens Chrisitan Association</option>                                   <option value='Young Mens Christian Association'>Young Mens Christian Association</option>                                   <option value='Young Mens Hebrew Association'>Young Mens Hebrew Association</option>                                   <option value='Young Women's Christian Association'>Young Women's Christian Association</option>                                   <option value='Young Womens Chrisian Association'>Young Womens Chrisian Association</option>                                   <option value='Zaibatsu (Industrial and Commercial ombines)'>Zaibatsu (Industrial and Commercial ombines)</option>                                   <option value='Zurich Department of Health'>Zurich Department of Health</option>                                   <option value='Zurich Department of Social Welfare'>Zurich Department of Social Welfare</option>  
						</select> 
					</td> 
				</tr>  
				<tr> 
					<td></td> 
					<td> 
						<i>(find documents that mention a particular organization)</i>
					</td> 
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr> <!-- mentioned title -JR --> 
					<td class="searchLabelCell"> 
						<b>title: &nbsp;</b> 
					</td> 
					<td> 
						<select name="mentionedTitle" style="width: 400px;"> 
							<option value=''></option>
                                  <option value=''></option>                                   <option value='"Methods of Birth Control'>"Methods of Birth Control</option>                                   <option value='"The Prevention of Conception"'>"The Prevention of Conception"</option>                                   <option value='"THE WOMAN REBEL'>"THE WOMAN REBEL</option>                                   <option value='84.9% Said Yes. Poll on Planned Parenthood'>84.9% Said Yes. Poll on Planned Parenthood</option>                                   <option value='A.M.A. Journal'>A.M.A. Journal</option>                                   <option value='â€œFamily Limitation'>â€œFamily Limitation</option>                                   <option value='â€œThe Pivot of Civilizationâ€'>â€œThe Pivot of Civilizationâ€</option>                                   <option value='Abortion in Relation to Fetal and Maternal Welfare.'>Abortion in Relation to Fetal and Maternal Welfare.</option>                                   <option value='Age of Reason, the'>Age of Reason, the</option>                                   <option value='American Dilemma, an'>American Dilemma, an</option>                                   <option value='American Journal of Sociology'>American Journal of Sociology</option>                                   <option value='American Mercury'>American Mercury</option>                                   <option value='Annual Summary of Marriages, Births and Deaths in , , etc., the'>Annual Summary of Marriages, Births and Deaths in , , etc., the</option>                                   <option value='Annual Summary of Marriages, Births and Deaths in England, Wales'>Annual Summary of Marriages, Births and Deaths in England, Wales</option>                                   <option value='Apocrypha'>Apocrypha</option>                                   <option value='Arabian Nights'>Arabian Nights</option>                                   <option value='ARE PREVENTIVE MEANS INJURIOUS'>ARE PREVENTIVE MEANS INJURIOUS</option>                                   <option value='Atlantic Charter'>Atlantic Charter</option>                                   <option value='Atlantic Monthly'>Atlantic Monthly</option>                                   <option value='Aux jeunes hommes, aux jeunes filles. Ce qu'ils dovient apprendre sur la vie sexuelle'>Aux jeunes hommes, aux jeunes filles. Ce qu'ils dovient apprendre sur la vie sexuelle</option>                                   <option value='Aux jeunes hommes, aux jeunes filles. Ce quâ€™ils dovient apprendre sur la vie sexuelle'>Aux jeunes hommes, aux jeunes filles. Ce quâ€™ils dovient apprendre sur la vie sexuelle</option>                                   <option value='Ayons peu d'enfans! Pourquoi? Comment?'>Ayons peu d'enfans! Pourquoi? Comment?</option>                                   <option value='Ayons peu dâ€™enfans! Pourquoi? Comment?'>Ayons peu dâ€™enfans! Pourquoi? Comment?</option>                                   <option value='Berliner Post'>Berliner Post</option>                                   <option value='Better Health for 13,000,000'>Better Health for 13,000,000</option>                                   <option value='Better Health for 13,000,000.'>Better Health for 13,000,000.</option>                                   <option value='Better Health for Thirteen Million'>Better Health for Thirteen Million</option>                                   <option value='Beyond Good & Evil'>Beyond Good & Evil</option>                                   <option value='Bible'>Bible</option>                                   <option value='Biology of Conception, the'>Biology of Conception, the</option>                                   <option value='Biology of Conception'>Biology of Conception</option>                                   <option value='Birth control Bulletin'>Birth control Bulletin</option>                                   <option value='Birth Control by a Pill'>Birth Control by a Pill</option>                                   <option value='Birth Control League, the'>Birth Control League, the</option>                                   <option value='Birth Control or Abortion?'>Birth Control or Abortion?</option>                                   <option value='Birth Control Review'>Birth Control Review</option>                                   <option value='Birth Control ReviewREVIEW'>Birth Control ReviewREVIEW</option>                                   <option value='Birth Control: Is it Moral?'>Birth Control: Is it Moral?</option>                                   <option value='Birth Control's Big Year'>Birth Control's Big Year</option>                                   <option value='Birth Controlâ€™s Big Year'>Birth Controlâ€™s Big Year</option>                                   <option value='Birth of Tragedy'>Birth of Tragedy</option>                                   <option value='Birth Spacing; Its Effect on Health of Mothers and Infants'>Birth Spacing; Its Effect on Health of Mothers and Infants</option>                                   <option value='Call, the'>Call, the</option>                                   <option value='Candide'>Candide</option>                                   <option value='case decision'>case decision</option>                                   <option value='Case Worker and Family Planning, the'>Case Worker and Family Planning, the</option>                                   <option value='Casse Editorial'>Casse Editorial</option>                                   <option value='Catholics and Planned Parenthood'>Catholics and Planned Parenthood</option>                                   <option value='Century of the Child, the'>Century of the Child, the</option>                                   <option value='Children of Tomorrow'>Children of Tomorrow</option>                                   <option value='Children's Era, the'>Children's Era, the</option>                                   <option value='Church and the Social Crisis, the'>Church and the Social Crisis, the</option>                                   <option value='Churchman, the'>Churchman, the</option>                                   <option value='Clinic Directory'>Clinic Directory</option>                                   <option value='Clinical Medicine'>Clinical Medicine</option>                                   <option value='Clubwoman >, the'>Clubwoman >, the</option>                                   <option value='Comstock laws'>Comstock laws</option>                                   <option value='Conception Control by Plastic Cervix Cap'>Conception Control by Plastic Cervix Cap</option>                                   <option value='Conference'>Conference</option>                                   <option value='conference on Better Care for Mothers and Babies'>conference on Better Care for Mothers and Babies</option>                                   <option value='Constitution'>Constitution</option>                                   <option value='Constitution of the United States'>Constitution of the United States</option>                                   <option value='Contemporary Review'>Contemporary Review</option>                                   <option value='Contemporary Science Series'>Contemporary Science Series</option>                                   <option value='Contraception and Fertility in the Southern Appalachian'>Contraception and Fertility in the Southern Appalachian</option>                                   <option value='Contraceptive Practices'>Contraceptive Practices</option>                                   <option value='Contraceptive Service of the Department of Health, City of Nashville, the'>Contraceptive Service of the Department of Health, City of Nashville, the</option>                                   <option value='Contraceptive Services in the U.S.'>Contraceptive Services in the U.S.</option>                                   <option value='Control of Conception as a Public Health Responsibility'>Control of Conception as a Public Health Responsibility</option>                                   <option value='Control of Contraception in a Selected Rural Sample'>Control of Contraception in a Selected Rural Sample</option>                                   <option value='Control of Parenthood;, the'>Control of Parenthood;, the</option>                                   <option value='Current History'>Current History</option>                                   <option value='Cyclopedia of Medicine and Surgery'>Cyclopedia of Medicine and Surgery</option>                                   <option value='Danger Spots World and Population'>Danger Spots World and Population</option>                                   <option value='Dangerous Thought Bill.'>Dangerous Thought Bill.</option>                                   <option value='Dangerous Thoughts Bill", the'>Dangerous Thoughts Bill", the</option>                                   <option value='Dangerous Thoughts Law'>Dangerous Thoughts Law</option>                                   <option value='De l'amour physique'>De l'amour physique</option>                                   <option value='De l'avortement. Est-ce un crime?'>De l'avortement. Est-ce un crime?</option>                                   <option value='De lâ€™amour physique'>De lâ€™amour physique</option>                                   <option value='De lâ€™avortement. Est-ce un crime?'>De lâ€™avortement. Est-ce un crime?</option>                                   <option value='decision'>decision</option>                                   <option value='DEFENCE OF ASSASSINATION'>DEFENCE OF ASSASSINATION</option>                                   <option value='Defendons-nous! Pour le neo-malthusisme; contre l'immoralite des moralistes'>Defendons-nous! Pour le neo-malthusisme; contre l'immoralite des moralistes</option>                                   <option value='Defendons-nous! Pour le neo-malthusisme; contre lâ€™immoralite des moralistes'>Defendons-nous! Pour le neo-malthusisme; contre lâ€™immoralite des moralistes</option>                                   <option value='Defense of Assassination, the'>Defense of Assassination, the</option>                                   <option value='Determinants and Consequences of Populations Trends, the'>Determinants and Consequences of Populations Trends, the</option>                                   <option value='Diseases of Women'>Diseases of Women</option>                                   <option value='Doctor Talks to the Bride, the'>Doctor Talks to the Bride, the</option>                                   <option value='Dutch Methods of Birth Control'>Dutch Methods of Birth Control</option>                                   <option value='Ecclesiasticus'>Ecclesiasticus</option>                                   <option value='Edinburgh Review'>Edinburgh Review</option>                                   <option value='Effectiveness of a Simple Contraceptive Method, the'>Effectiveness of a Simple Contraceptive Method, the</option>                                   <option value='Elements de science sociale, par le Dr. G. DRYSDALE'>Elements de science sociale, par le Dr. G. DRYSDALE</option>                                   <option value='Elements of Social Science'>Elements of Social Science</option>                                   <option value='Elements of Social Science, the'>Elements of Social Science, the</option>                                   <option value='Elements of Social Science,'>Elements of Social Science,</option>                                   <option value='Employing the Married Woman Worker.'>Employing the Married Woman Worker.</option>                                   <option value='Encyclical of the Pope'>Encyclical of the Pope</option>                                   <option value='Encyclopedia Britannica, the'>Encyclopedia Britannica, the</option>                                   <option value='English Methods of Birth Control'>English Methods of Birth Control</option>                                   <option value='Entre proletaires'>Entre proletaires</option>                                   <option value='Erewhon'>Erewhon</option>                                   <option value='Essai sur la vasectomie'>Essai sur la vasectomie</option>                                   <option value='Essay on Population'>Essay on Population</option>                                   <option value='ESSAYS ON POPULATION'>ESSAYS ON POPULATION</option>                                   <option value='Eugenic Mother and Baby, the'>Eugenic Mother and Baby, the</option>                                   <option value='Eugenic Protection Law'>Eugenic Protection Law</option>                                   <option value='Eugenics Review'>Eugenics Review</option>                                   <option value='Evening Sun'>Evening Sun</option>                                   <option value='Every Woman's Book'>Every Woman's Book</option>                                   <option value='Facts for Young Women'>Facts for Young Women</option>                                   <option value='Family in Pursuit of Happiness, the'>Family in Pursuit of Happiness, the</option>                                   <option value='Family Limitation'>Family Limitation</option>                                   <option value='Fecundity of Families Dependent on Public Charity'>Fecundity of Families Dependent on Public Charity</option>                                   <option value='Federal and State laws Pertaining to Birth Control'>Federal and State laws Pertaining to Birth Control</option>                                   <option value='Fifth International Conference on Planned Parenthood'>Fifth International Conference on Planned Parenthood</option>                                   <option value='Fifth International Neo-Malthusian and Birth Control Conference'>Fifth International Neo-Malthusian and Birth Control Conference</option>                                   <option value='Fifth International Neo-Malthusian and Birth control Conference*'>Fifth International Neo-Malthusian and Birth control Conference*</option>                                   <option value='first American Birth Control conference'>first American Birth Control conference</option>                                   <option value='first Birth Control Conference'>first Birth Control Conference</option>                                   <option value='First International Neo-Malthusian Conference'>First International Neo-Malthusian Conference</option>                                   <option value='Flowers -- Mr. and Mrs. Buttercup, their home and their family, the'>Flowers -- Mr. and Mrs. Buttercup, their home and their family, the</option>                                   <option value='Fortune'>Fortune</option>                                   <option value='Fortune Magazine'>Fortune Magazine</option>                                   <option value='Fourth International Neo-Malthusian Conference, the'>Fourth International Neo-Malthusian Conference, the</option>                                   <option value='Freedom From Fear'>Freedom From Fear</option>                                   <option value='Frozen Manpower of India, the'>Frozen Manpower of India, the</option>                                   <option value='Fruits of Philosophy'>Fruits of Philosophy</option>                                   <option value='Fruits of Philosophy, the'>Fruits of Philosophy, the</option>                                   <option value='Gallup'>Gallup</option>                                   <option value='Generation consciente'>Generation consciente</option>                                   <option value='Genesis'>Genesis</option>                                   <option value='Genesis XXXVIII'>Genesis XXXVIII</option>                                   <option value='Germany and the Next War'>Germany and the Next War</option>                                   <option value='Getting Married'>Getting Married</option>                                   <option value='Girl'>Girl</option>                                   <option value='Gleanings from a Note Book'>Gleanings from a Note Book</option>                                   <option value='Gospel'>Gospel</option>                                   <option value='Gospel.'>Gospel.</option>                                   <option value='Happy Family, the'>Happy Family, the</option>                                   <option value='Harijan'>Harijan</option>                                   <option value='Harper's'>Harper's</option>                                   <option value='Havelock Ellis: Philosopher of Love'>Havelock Ellis: Philosopher of Love</option>                                   <option value='High Cost of Babies, the'>High Cost of Babies, the</option>                                   <option value='History of Prostitution'>History of Prostitution</option>                                   <option value='House bill No. 11330'>House bill No. 11330</option>                                   <option value='Human Biology'>Human Biology</option>                                   <option value='Human Breeding and Survival'>Human Breeding and Survival</option>                                   <option value='Human Fertility'>Human Fertility</option>                                   <option value='HUMAN REGENERATION'>HUMAN REGENERATION</option>                                   <option value='Idea of Progress'>Idea of Progress</option>                                   <option value='Ignorance and its Consequences'>Ignorance and its Consequences</option>                                   <option value='Illustrated Weekly of India, the'>Illustrated Weekly of India, the</option>                                   <option value='Illustrations and Proofs of the Principle of Population'>Illustrations and Proofs of the Principle of Population</option>                                   <option value='In Conquest and Kultur'>In Conquest and Kultur</option>                                   <option value='In the Garden'>In the Garden</option>                                   <option value='Independent, the'>Independent, the</option>                                   <option value='India's Human Resources'>India's Human Resources</option>                                   <option value='India's Social Revolution'>India's Social Revolution</option>                                   <option value='Indiaâ€™s Human Resources'>Indiaâ€™s Human Resources</option>                                   <option value='Indiaâ€™s Social Revolution'>Indiaâ€™s Social Revolution</option>                                   <option value='Infant Mortality and Its Causes'>Infant Mortality and Its Causes</option>                                   <option value='Institute for Venereal Disease Education of'>Institute for Venereal Disease Education of</option>                                   <option value='International'>International</option>                                   <option value='International Constitution'>International Constitution</option>                                   <option value='Is Birth Control a Benefit to Humanity?'>Is Birth Control a Benefit to Humanity?</option>                                   <option value='Is Overpopulation a Threat to Permanent Peace'>Is Overpopulation a Threat to Permanent Peace</option>                                   <option value='J.A.M.A.'>J.A.M.A.</option>                                   <option value='Japan Chronicle'>Japan Chronicle</option>                                   <option value='Japan Times'>Japan Times</option>                                   <option value='Jelly Alone as Contraceptive in Post-Partum Cases'>Jelly Alone as Contraceptive in Post-Partum Cases</option>                                   <option value='Jelly alone as Contraceptive Method'>Jelly alone as Contraceptive Method</option>                                   <option value='Jl. Assn. Med. Coll.'>Jl. Assn. Med. Coll.</option>                                   <option value='Journal'>Journal</option>                                   <option value='Journal of Conception'>Journal of Conception</option>                                   <option value='Journal of Heredity, the'>Journal of Heredity, the</option>                                   <option value='Journal of Marriage Hygiene'>Journal of Marriage Hygiene</option>                                   <option value='Journal of the >, the'>Journal of the >, the</option>                                   <option value='Journal of the American Medical Assn.'>Journal of the American Medical Assn.</option>                                   <option value='Journal of the American Medical Association'>Journal of the American Medical Association</option>                                   <option value='Journal of the American Statistical Association'>Journal of the American Statistical Association</option>                                   <option value='Kaizo'>Kaizo</option>                                   <option value='Kaizo Magazine'>Kaizo Magazine</option>                                   <option value='Karezza'>Karezza</option>                                   <option value='L'Ecole Renovee'>L'Ecole Renovee</option>                                   <option value='L'education sexuelle'>L'education sexuelle</option>                                   <option value='L'initiation sexuelle'>L'initiation sexuelle</option>                                   <option value='L'Intransigeant'>L'Intransigeant</option>                                   <option value='L'oeuvre'>L'oeuvre</option>                                   <option value='La fonction sexualle'>La fonction sexualle</option>                                   <option value='La generation humaine'>La generation humaine</option>                                   <option value='La grande utopie: l'impuissance de la repopulation'>La grande utopie: l'impuissance de la repopulation</option>                                   <option value='La grande utopie: lâ€™impuissance de la repopulation'>La grande utopie: lâ€™impuissance de la repopulation</option>                                   <option value='La greve des ventres'>La greve des ventres</option>                                   <option value='La Justice'>La Justice</option>                                   <option value='La loi de Malthus'>La loi de Malthus</option>                                   <option value='La pauvrete. Sa seule cause, son seule remede, par le Dr. >'>La pauvrete. Sa seule cause, son seule remede, par le Dr. ></option>                                   <option value='La physique, de l'amour'>La physique, de l'amour</option>                                   <option value='La physique, de lâ€™amour'>La physique, de lâ€™amour</option>                                   <option value='La procreation volontaire'>La procreation volontaire</option>                                   <option value='La question sexuelle'>La question sexuelle</option>                                   <option value='La societe mourante et le neo-malthusisme'>La societe mourante et le neo-malthusisme</option>                                   <option value='La vie sexuelle et ses lois'>La vie sexuelle et ses lois</option>                                   <option value='Lâ€™education sexuelle'>Lâ€™education sexuelle</option>                                   <option value='Lâ€™initiation sexuelle'>Lâ€™initiation sexuelle</option>                                   <option value='Ladies Home Journal'>Ladies Home Journal</option>                                   <option value='Ladies' Home Journal'>Ladies' Home Journal</option>                                   <option value='Ladiesâ€™ Home Journal'>Ladiesâ€™ Home Journal</option>                                   <option value='LAND AND LIBERTY'>LAND AND LIBERTY</option>                                   <option value='LAND AND LIBERTY.'>LAND AND LIBERTY.</option>                                   <option value='Land of Italy'>Land of Italy</option>                                   <option value='Le breviaire de la femme enceinte'>Le breviaire de la femme enceinte</option>                                   <option value='Le mal de vivre'>Le mal de vivre</option>                                   <option value='Le mariage, l'amour libre et la libre maternite'>Le mariage, l'amour libre et la libre maternite</option>                                   <option value='Le mariage, lâ€™amour libre et la libre maternite'>Le mariage, lâ€™amour libre et la libre maternite</option>                                   <option value='Le Neo-Malthusien'>Le Neo-Malthusien</option>                                   <option value='Le neo-malthusisme est-il moral?'>Le neo-malthusisme est-il moral?</option>                                   <option value='Le probleme de la population'>Le probleme de la population</option>                                   <option value='Le probleme sexuel'>Le probleme sexuel</option>                                   <option value='Legal Status of Contraception'>Legal Status of Contraception</option>                                   <option value='Life of Cromwell'>Life of Cromwell</option>                                   <option value='Limitation of Offspring'>Limitation of Offspring</option>                                   <option value='London Daily Sketch'>London Daily Sketch</option>                                   <option value='London Herald'>London Herald</option>                                   <option value='London Nation'>London Nation</option>                                   <option value='London Sunday Times'>London Sunday Times</option>                                   <option value='LOOK'>LOOK</option>                                   <option value='Lucifer'>Lucifer</option>                                   <option value='Madame Butterfly'>Madame Butterfly</option>                                   <option value='Magnetation Methods of Birth Control'>Magnetation Methods of Birth Control</option>                                   <option value='Mahabharata'>Mahabharata</option>                                   <option value='Malthus et ses disciples'>Malthus et ses disciples</option>                                   <option value='Man and the Earth'>Man and the Earth</option>                                   <option value='Manchester Guardian Commercial'>Manchester Guardian Commercial</option>                                   <option value='Marriage and Parenthoodâ€“the Problem of Birth Control.'>Marriage and Parenthoodâ€“the Problem of Birth Control.</option>                                   <option value='Marriage and Sexual Harmony'>Marriage and Sexual Harmony</option>                                   <option value='Marriage Bed, the'>Marriage Bed, the</option>                                   <option value='Marriage Counsel'>Marriage Counsel</option>                                   <option value='Marriage Counsel in Relation to Planned Parenthood'>Marriage Counsel in Relation to Planned Parenthood</option>                                   <option value='Marriage Counsel in Relation to Planned Parenthood,'>Marriage Counsel in Relation to Planned Parenthood,</option>                                   <option value='Marriage Manual'>Marriage Manual</option>                                   <option value='Marriage Manual, a'>Marriage Manual, a</option>                                   <option value='Married Love'>Married Love</option>                                   <option value='Masses'>Masses</option>                                   <option value='Medical Record'>Medical Record</option>                                   <option value='Menace, the'>Menace, the</option>                                   <option value='Methods Used to Prevent Large Families'>Methods Used to Prevent Large Families</option>                                   <option value='Metropolitan Magazine, the'>Metropolitan Magazine, the</option>                                   <option value='Mikado'>Mikado</option>                                   <option value='Milbank Mem. Quart.'>Milbank Mem. Quart.</option>                                   <option value='Milbank Quarterly'>Milbank Quarterly</option>                                   <option value='Militants in England, the'>Militants in England, the</option>                                   <option value='Mississippi Doctor'>Mississippi Doctor</option>                                   <option value='Molly Pitchers of This War., the'>Molly Pitchers of This War., the</option>                                   <option value='MORAL PHYSIOLOGY'>MORAL PHYSIOLOGY</option>                                   <option value='Mother'>Mother</option>                                   <option value='Mother and Child'>Mother and Child</option>                                   <option value='Motherhood in Bondage'>Motherhood in Bondage</option>                                   <option value='Moyens d'eviter la grossesse'>Moyens d'eviter la grossesse</option>                                   <option value='Moyens d'eviter les grandes families, par les docteurs'>Moyens d'eviter les grandes families, par les docteurs</option>                                   <option value='Moyens dâ€™eviter la grossesse'>Moyens dâ€™eviter la grossesse</option>                                   <option value='Moyens dâ€™eviter les grandes families, par les docteurs'>Moyens dâ€™eviter les grandes families, par les docteurs</option>                                   <option value='MSM'>MSM</option>                                   <option value='MULTIPLYING MAN'>MULTIPLYING MAN</option>                                   <option value='My Country Tis of Thee'>My Country Tis of Thee</option>                                   <option value='My Country, Tis of Thee'>My Country, Tis of Thee</option>                                   <option value='My Fight for Birth Control'>My Fight for Birth Control</option>                                   <option value='N. Y. Evening Mail'>N. Y. Evening Mail</option>                                   <option value='N.Y. American, the'>N.Y. American, the</option>                                   <option value='Nation'>Nation</option>                                   <option value='National Negro Leaders Agree: Planned Parenthood Means Better Families'>National Negro Leaders Agree: Planned Parenthood Means Better Families</option>                                   <option value='Natl. Med. Assn. Jl'>Natl. Med. Assn. Jl</option>                                   <option value='NEO-MALTHUSIAN'>NEO-MALTHUSIAN</option>                                   <option value='Neo-malthusisme et socialsme'>Neo-malthusisme et socialsme</option>                                   <option value='New Haven Journal-Courier'>New Haven Journal-Courier</option>                                   <option value='NEW MASSES'>NEW MASSES</option>                                   <option value='New Republic'>New Republic</option>                                   <option value='New Republic, the'>New Republic, the</option>                                   <option value='New York American'>New York American</option>                                   <option value='New York Sunday Call'>New York Sunday Call</option>                                   <option value='New York Times'>New York Times</option>                                   <option value='News of Population and Birth Control'>News of Population and Birth Control</option>                                   <option value='Nineteenth Century Magazine'>Nineteenth Century Magazine</option>                                   <option value='No Masters'>No Masters</option>                                   <option value='Notions d'hygiene feminine populaire: l'Adolescente'>Notions d'hygiene feminine populaire: l'Adolescente</option>                                   <option value='Notions dâ€™hygiene feminine populaire: lâ€™Adolescente'>Notions dâ€™hygiene feminine populaire: lâ€™Adolescente</option>                                   <option value='Obstetrics'>Obstetrics</option>                                   <option value='Of chaste marriage'>Of chaste marriage</option>                                   <option value='Old Testament'>Old Testament</option>                                   <option value='Onna Daigaku'>Onna Daigaku</option>                                   <option value='Open Discussion'>Open Discussion</option>                                   <option value='Outline for a Course in Planned Parenthood, an'>Outline for a Course in Planned Parenthood, an</option>                                   <option value='Outline for a Course in Planned Parenthood'>Outline for a Course in Planned Parenthood</option>                                   <option value='Outlook and Independent, the'>Outlook and Independent, the</option>                                   <option value='pamphlet'>pamphlet</option>                                   <option value='Parent and the State, the'>Parent and the State, the</option>                                   <option value='Passaic Weekly'>Passaic Weekly</option>                                   <option value='Penal Code of the United States'>Penal Code of the United States</option>                                   <option value='Peu d'enfants. Porquoi? Comment?'>Peu d'enfants. Porquoi? Comment?</option>                                   <option value='Peu dâ€™enfants. Porquoi? Comment?'>Peu dâ€™enfants. Porquoi? Comment?</option>                                   <option value='Phenylmercuric Acetate as a Contraceptive'>Phenylmercuric Acetate as a Contraceptive</option>                                   <option value='physician's Responsibility in Planned Parenthood, the'>physician's Responsibility in Planned Parenthood, the</option>                                   <option value='physicianâ€™s Responsibility in Planned Parenthood, the'>physicianâ€™s Responsibility in Planned Parenthood, the</option>                                   <option value='Pivot of Civilization, the'>Pivot of Civilization, the</option>                                   <option value='PLAIN TALK'>PLAIN TALK</option>                                   <option value='Planned Parenthood Story, a'>Planned Parenthood Story, a</option>                                   <option value='Planned Parenthood: Its Contribution to Family, Community and Nation'>Planned Parenthood: Its Contribution to Family, Community and Nation</option>                                   <option value='Planned Parenthood: its Contribution to Lasting Peace'>Planned Parenthood: its Contribution to Lasting Peace</option>                                   <option value='Planning to Have a Baby'>Planning to Have a Baby</option>                                   <option value='Plenty of People'>Plenty of People</option>                                   <option value='Population and War'>Population and War</option>                                   <option value='Population et subsistances'>Population et subsistances</option>                                   <option value='Practical Methods'>Practical Methods</option>                                   <option value='Practical Obstetrics'>Practical Obstetrics</option>                                   <option value='Practical Obstretrics'>Practical Obstretrics</option>                                   <option value='Practice of Obstetrics, the'>Practice of Obstetrics, the</option>                                   <option value='Pregnant Woman in a Lean Age'>Pregnant Woman in a Lean Age</option>                                   <option value='Preparing for Marriage'>Preparing for Marriage</option>                                   <option value='Problem of Sex Education in Schools, the'>Problem of Sex Education in Schools, the</option>                                   <option value='Problems of Population and Parenthood'>Problems of Population and Parenthood</option>                                   <option value='Proceedings'>Proceedings</option>                                   <option value='Psalms 127'>Psalms 127</option>                                   <option value='Psychology of Sex'>Psychology of Sex</option>                                   <option value='Psychosomatic Diagnosis'>Psychosomatic Diagnosis</option>                                   <option value='Reconstruction'>Reconstruction</option>                                   <option value='Report of Sub-Committee on Birth Control'>Report of Sub-Committee on Birth Control</option>                                   <option value='Republic'>Republic</option>                                   <option value='Responsibility for the Health of Tomorrow's Family.'>Responsibility for the Health of Tomorrow's Family.</option>                                   <option value='Responsibility for the Health of Tomorrowâ€™s Family.'>Responsibility for the Health of Tomorrowâ€™s Family.</option>                                   <option value='Review, the'>Review, the</option>                                   <option value='REVIEW'>REVIEW</option>                                   <option value='Rhythm, the'>Rhythm, the</option>                                   <option value='Rhythm'>Rhythm</option>                                   <option value='Road to Survival, the'>Road to Survival, the</option>                                   <option value='Roman Catholicism's Moral Certainties'>Roman Catholicism's Moral Certainties</option>                                   <option value='Roman Catholicismâ€™s Moral Certainties'>Roman Catholicismâ€™s Moral Certainties</option>                                   <option value='Roots of Delinquency, the'>Roots of Delinquency, the</option>                                   <option value='Science of Life, the'>Science of Life, the</option>                                   <option value='Sculptor and the King, the'>Sculptor and the King, the</option>                                   <option value='Second International'>Second International</option>                                   <option value='Senate bill No. 4000'>Senate bill No. 4000</option>                                   <option value='September Morn'>September Morn</option>                                   <option value='Sermon on the Mount'>Sermon on the Mount</option>                                   <option value='Sexual Ethics'>Sexual Ethics</option>                                   <option value='Sexual Impulse'>Sexual Impulse</option>                                   <option value='SHE Magazine'>SHE Magazine</option>                                   <option value='Silence Broken'>Silence Broken</option>                                   <option value='Sixth International Conference on Planned Parenthood'>Sixth International Conference on Planned Parenthood</option>                                   <option value='Sixth International Neo-Malthusian and birth control Conference, the'>Sixth International Neo-Malthusian and birth control Conference, the</option>                                   <option value='Socialisme et malthusisme'>Socialisme et malthusisme</option>                                   <option value='Socialisme et population'>Socialisme et population</option>                                   <option value='Solider Takes a Wife, the'>Solider Takes a Wife, the</option>                                   <option value='Soul of Man Under Socialism, the'>Soul of Man Under Socialism, the</option>                                   <option value='Soul of Spain, the'>Soul of Spain, the</option>                                   <option value='Spermicidal Times of Samples of Commercial Contraceptives Secured in 1942'>Spermicidal Times of Samples of Commercial Contraceptives Secured in 1942</option>                                   <option value='Spermicidal Times of Samples of Contraceptives Secured in 1944'>Spermicidal Times of Samples of Contraceptives Secured in 1944</option>                                   <option value='Story of Two Families, the'>Story of Two Families, the</option>                                   <option value='Studies of Spermicidal Times of Contraceptive Materials'>Studies of Spermicidal Times of Contraceptive Materials</option>                                   <option value='Study of British Genius'>Study of British Genius</option>                                   <option value='Sunday Chronicle'>Sunday Chronicle</option>                                   <option value='Survey, the'>Survey, the</option>                                   <option value='Sweet Land of Liberty'>Sweet Land of Liberty</option>                                   <option value='Taiho-rei'>Taiho-rei</option>                                   <option value='Teaching of Contraceptive Measures in Small Colleges'>Teaching of Contraceptive Measures in Small Colleges</option>                                   <option value='Technique of Conception Control, the'>Technique of Conception Control, the</option>                                   <option value='Techniques of Conception Control'>Techniques of Conception Control</option>                                   <option value='THE BIRTH CONTROL REVIEW'>THE BIRTH CONTROL REVIEW</option>                                   <option value='THE INTERNATIONAL'>THE INTERNATIONAL</option>                                   <option value='THE MENACE'S'>THE MENACE'S</option>                                   <option value='THE NEW GENERATION'>THE NEW GENERATION</option>                                   <option value='THE NEW MOTHERHOOD'>THE NEW MOTHERHOOD</option>                                   <option value='the North American Review'>the North American Review</option>                                   <option value='Theory of Population'>Theory of Population</option>                                   <option value='Theraputic Contraception'>Theraputic Contraception</option>                                   <option value='Third International Conference'>Third International Conference</option>                                   <option value='Tierra Y'Libertad'>Tierra Y'Libertad</option>                                   <option value='Time'>Time</option>                                   <option value='To Those Denied a Child'>To Those Denied a Child</option>                                   <option value='To Those Denied a Child; A Guide for Husbands and Wives Seeking Parenthood'>To Those Denied a Child; A Guide for Husbands and Wives Seeking Parenthood</option>                                   <option value='To Those Denied a Child.'>To Those Denied a Child.</option>                                   <option value='Tomorrow's Children'>Tomorrow's Children</option>                                   <option value='Training of Children'>Training of Children</option>                                   <option value='Treaty of Versailles'>Treaty of Versailles</option>                                   <option value='Tribune'>Tribune</option>                                   <option value='Truths of Philosophy, the'>Truths of Philosophy, the</option>                                   <option value='Two Billion People'>Two Billion People</option>                                   <option value='U.S. versus one Package'>U.S. versus one Package</option>                                   <option value='U.S. vs. One Package'>U.S. vs. One Package</option>                                   <option value='United States Criminal Codes'>United States Criminal Codes</option>                                   <option value='Va. Medical Monthly'>Va. Medical Monthly</option>                                   <option value='Valeur scientifique du malthusianisme'>Valeur scientifique du malthusianisme</option>                                   <option value='volume'>volume</option>                                   <option value='Wall Street Journal'>Wall Street Journal</option>                                   <option value='War and Population'>War and Population</option>                                   <option value='Western Watchman'>Western Watchman</option>                                   <option value='What Birth Control Can Do For India'>What Birth Control Can Do For India</option>                                   <option value='What Every Girl Should Know'>What Every Girl Should Know</option>                                   <option value='What Every Mother Should Know'>What Every Mother Should Know</option>                                   <option value='What Mussolini Thinks of Women'>What Mussolini Thinks of Women</option>                                   <option value='White House Conference on Child Health and Protection'>White House Conference on Child Health and Protection</option>                                   <option value='Who's Who'>Who's Who</option>                                   <option value='Woman and the New Race'>Woman and the New Race</option>                                   <option value='Woman and the New Race,'>Woman and the New Race,</option>                                   <option value='Woman and the New Race.'>Woman and the New Race.</option>                                   <option value='Woman Rebel, the'>Woman Rebel, the</option>                                   <option value='Woman Rebel'>Woman Rebel</option>                                   <option value='Woman's Home Companion'>Woman's Home Companion</option>                                   <option value='Woman's Journal, the'>Woman's Journal, the</option>                                   <option value='Womanâ€™s Home Companion'>Womanâ€™s Home Companion</option>                                   <option value='World Population Conference'>World Population Conference</option>                                   <option value='Zarathrustra'>Zarathrustra</option>  
						</select> 
					</td> 
				</tr>  
				<tr> 
					<td></td> 
					<td> 
						<i>(find documents that mention the title of a work)</i>
					</td> 
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>
				<tr>
					<td>
						&nbsp; 
					</td>
				</tr>


				<tr>
						<td class="searchLabelCell">
							&nbsp;
						</td>
						<td>
							<input type="submit" name="submit2" value="Search!" />
							<input type="reset" name="reset" value="Reset" /> 
						</td>
				</tr>
			</table>
		</form>
			  </div>
</div>
	<div><br /></div>

	<p style="margin-top: 0px; margin-bottom: 0px;">
		<a href="http://www.nyu.edu/projects/sanger/aboutms/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c1','','../images/sanger_foot_r1_c1_f2.gif',1);"><img id="sanger_foot_r1_c1" src="../images/sanger_foot_r1_c1.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/documents/electroniced.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c2','','../images/sanger_foot_r1_c2_f2.gif',1);"><img id="sanger_foot_r1_c2" src="../images/sanger_foot_r1_c2.gif" width="104" height="20" alt="" /></a><a href="search.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c3','','../images/sanger_foot_r1_c3_f2.gif',1);"><img id="sanger_foot_r1_c3" src="../images/sanger_foot_r1_c3.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c4','','../images/sanger_foot_r1_c4_f2.gif',1);"><img id="sanger_foot_r1_c4" src="../images/sanger_foot_r1_c4.gif" width="104" height="20" alt="" /></a><a href="http://www.nyu.edu/projects/sanger/contactus/" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('sanger_foot_r1_c5','','../images/sanger_foot_r1_c5_f2.gif',1);"><img id="sanger_foot_r1_c5" src="../images/sanger_foot_r1_c5.gif" width="104" height="20" alt="" /></a><img id="sanger_foot_r1_c6" src="../images/sanger_foot_r1_c6.jpg" width="105" height="20" alt="" />
	</p>
	<p style="margin-bottom: 0px; margin-top: -1px; /*\*/margin-top: -4px;/**/">
		<img src="../images/spacer.gif" width="545" height="1" alt="" /><a href="http://validator.w3.org/check/referer"><img src="../images/xhtml11.gif" alt="valid" /></a>
	</p>
</div> <!-- end of Container --> 
</body>
</html>
