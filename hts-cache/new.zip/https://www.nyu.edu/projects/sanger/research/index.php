<html lang="en">
<head>

  <meta charset="utf-8">
   <title>MSPP / Research /</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
  </head>

<body>
	
	<div id="top">
    <div style="width: 1000px;">
  	<a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
	
  	
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    		<div id="wrap">
            	<div id="header">
       		 <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"> <img src="../images/logo.png"></a> 
			
			   <ul id="nav"> 
			
   	<li>
		<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/msbio.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
		</li>
	<li>
		 <a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/former_interns.php">Former Interns</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>
	
	<li>
		<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		<li><a href="../publications/microfilm-online.php">Online Microfilm</a></li>
		</ul>
		</li>
	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
		</li>
	<li>
		<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Speeches and Writings --Digital Edition</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
		</li>
	<li>
		<a href="index.php" title="Research Resources">Research Resources</a>
		<ul>
		<li><a href="index.php">About</a></li>
		<li><a href="editorsnotes.php">Editors' Notes</a></li>
		<li><a href="nhday.php">National History Day</a></li>
		<li><a href="bibliography.php">Sanger Bibliography</a></li>
		<li><a href="images.php">Sanger Images</a></li>
		<li><a href="links.php">Links</a></li>
		</ul>
		</li>
	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>
    
    </ul>
    
        </div>
        </div>
        <div id="main">
     
	 <center>   
    <img src="mainimage.png">
	</center>
    <br><br>
    
  			<h1>Research Resources</h1>
	
	<!---BEGIN CONTENT--->

<p>The Margaret Sanger Papers Project's primary goal is to publish material about Margaret Sanger in microfilm, book, and electronic forms. We are neither an archive 
nor a research library and we do not own any of the collections of Sanger's original papers. Moreover, as we no longer maintain an office, we do not have the facilities or staff to 
copy documents or undertake extensive research. We do try to respond to all queries, but if you require detailed or time-consuming research we will try to direct you towards 
researchers who might be willing to undertake the work.</p>

	
				<!---END CONTENT--->
		</div>
		</div>
      	  <div id="sidebar">
		
			<h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
			
			<h1>Research</h1>
			<div id="subnav">
			<!---LINKS (bold current section)--->
			<b><a href="index.php">About</a></b><br>
				<a href="editorsnotes.php">Editors' Notes</a><br>
				<a href="nhday.php">National History Day</a><br>
				<a href="bibliography.php">Sanger Bibliography</a><br>
				<a href="images.php">Sanger Images</a><br>
				<a href="links.php">Links</a><br>
			
        
			</div>
			</div>
	
		 <div id="mainend"></div>
        
        </div>   
		   
		 <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    		</div>
    
	</body>
	</html> 