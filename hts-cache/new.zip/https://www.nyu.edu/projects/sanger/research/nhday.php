
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Resources / National History Day</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources" class="selected">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>National History Day</h1>

<div class="maintext">

<p>The Margaret Sanger Papers Project encourages students working on <a href="http://www.nationalhistoryday.org/">National History Day</a> to consider projects based on Margaret Sanger and the birth control movement.  To that end we have mounted brief topic guides.</p>

<p><strong>Topic Guide Archive:</strong></p>
<p><em><a href="https://www.nhd.org/node/14063">Breaking Barriers in History, 2020</em></p>
<p><em><a href="https://www.nhd.org/awards-result?field_year_tid=252&field_acategory_tid=All&field_class_tid=All">Triumph and Tragedy, 2019</em></p>
<p><em><a href="https://www.nhd.org/conflict-and-compromise-history">Conflict and Compromise in History, 2018</a></em>,</p>
<p><em><a href="http://nhd.org/taking-stand-history">Taking a Stand in History, 2017</a></em>,</p>
<p><em>Exploration, Encounter & Exchange in History</em>, 2016</p>
<p><em>Leadership &amp; Legacy, 2015</em> </p>
<p><em>Turning Points,</em> 2013</p>
<p><em>Debate &amp; Diplomacy in History: Successes, Failures, Consequences</em>, 2011 </p>
<p><em>The Individual in History: Actions and Legacies, 2009</em></p>
<p><em>Conflict and Compromise in History,</em> 2008</p>
<p><em>Taking a Stand in History,</em> 2006</p>
<p><em>Communication in History: The Key to Understanding</em>, 2004</p>
<p><em>Rights and Responsibilities in History</em>, 2003</p>
<p><em>Revolution, Reaction, Reform in History</em>, 2002</p>
      <br />
  </em>We do ask that you begin your research using the resources on this web site and secondary readings before contacting the Project with any follow-up research. </p>
<p>Due to the number of students involved in National History Day, Sanger Project staff cannot participate in student projects as interview subjects except in extraordinary circumstances. </p>
<hr />
<h2>Winners</h2>
<p>Many students working on Sanger-related topics have won NHD competitions

using the resources gathered by the Sanger Project. <em>If you have won a National History Day competition using Sanger documents,

please let us know by e-mailing <a href="mailto:sanger.papers@nyu.edu">sanger.papers@nyu.edu</a>. </em></p>
<p><strong>Below are some of the latest winners:</strong></p>

<p>Sarah Schoellhorn, Fifth Place, National in Senior Exhibit, Second place, Senior Exhibit (Florida) for "Margaret Sanger: Choosing a Life of Conflict to Gain Women�s Reproductive Rights," (Florida, 2018)</p>
<p>Vinita Cheepurupalli, First Place, Individual Senior Entry (Indiana) for <a href="https://94793431.nhd.weebly.com/">Margaret Sanger, Woman Rebel: Crusading Against the Censorship of Women</a></p>
<p>Caroline Katzive, First Place, Junior&nbsp;Paper <em><a href="https://www.nhd.org/wp-content/uploads/Katzive_Junior.pdf" target="_blank">Margaret Sanger: Demonstrating Leadership and Legacy Through Her Crusade For Women&rsquo;s Reproductive Rights</a></em> (Washington, DC, 2015) 
<p>Mia Radovanovic, Third Place, Senior Individual Exhibit for <a href="http://nhd.org/contest-affiliates/examples/#toggle-id-12">Margaret Sanger: The Birth of Women�s Control</a>, (Florida, 2013)
<p>Connor Davies, Senior Individual Performance, for &quot;Nine Days of Innovation for a Lifetime of Change" about Margaret Sanger's birth control clinic in Brooklyn. (Maryland, 2010) </p>
<p><a href="https://www.breckschool.org/news/breck_news/news_09_05_04/">Alayna O'Bryan, individual exhibit on Margaret Sanger (Minnesota, 2010) </a></p>
<p><a href="https://www.chattanoogan.com/articles/article_173657.asp">Michelle Woodruff, Senior Individual Performance for her project on &quot;Margaret Sanger and the Birth Control Movement.&quot; (Tennessee, 2010).</a> </p>
<p><a href="https://www.allbusiness.com/trends-events/awards-prizes/14103680-1.html">Sarah Goolsby, third place, Senior Individual Paper, "Innovation Through Disobedience: Margaret Sanger's Social Impact." (Missouri, 2010)</a> </p>
<p>Cailin Nolte, Kyra Ellis-Moore and Emily Williams, &quot;Margret Sanger: Crusader for Contraceptives" (Outstanding State Entry, New Mexico, 2009). </p>
<p><a href="https://www.tennesseehistoryday.org/EastTNDistrictCompetition.htm">Sophie Yates, Senior Individual Performance, National Finalist, for &quot;Margaret Sanger: A Voice of Controversy.&quot;</a> (Tennessee, 2009) </p>
<div>
  <p><a href="https://www.cjonline.com/news/local/2009-04-25/youths_compete_at_history_day">Evan Arnold, Senior Historical Papers, National Finalist for &quot;Margaret Sanger.&quot; </a>(Kansas, 2009) </p>
  <p><a href="https://history.ky.gov/news.php?articleID=225&pageid=16&sectionid=5">Georgetta Robinson, first place in district competition, senior  paper, for &ldquo;Remembering Margaret Sanger</a>&rdquo; (Kansas, 2009) </p>
  <p>Emma Cooper, second place in the Maine Junior Individual Documentary competiion, for &quot;Margaret Sanger, The Pioneer of Birth Control.&quot; (Maine, 2009)</p>
  <p><a href="http://nhs.needham.k12.ma.us/nhs_media/nhslibrary/stulinks/nationalhistday09.html">Rachel Maremont and Nina Das, first places in the Group documentary competition in the Greater Boston Area Competition</a> for "Margaret Sanger: Pioneer for Contraception" (Massachusetts, 2009) </p>
  <p><a href="http://vermonthistory.org/index.php?option=com_content&task=view&id=173&Itemid=93">Elle Ross, Senior Historical Paper, for &quot;Margaret Sanger: Actions and Legacies of the Champion of Birth Control&quot; (Vermont, 2009)</a> </p>
  <p>Monica Caballeros-O'Rourke, National Finalist in Senior Individual Performance, for &quot;Margaret Sanger Story.&quot; (Michigan, 2008).</p>
  <p>Darya Pruitt, Rose Olson &amp; MacAulay Steenson, Honorable Mention for Junior Group Exhibit, &quot;'No Woman Can Call Herself Free' Margaret Sanger and the Birth Control Movement&quot; (State History Day, Minnesota, 2008) </p>
  <div style="position: absolute; top: 2360px; left: 86px;"></div>
  <div style="position: absolute; top: 2360px; left: 365px;"><font size="3" face="Times"></font></div>
  
  <p><a href="http://www.timesargus.com/apps/pbcs.dll/article?AID=/20060409/NEWS/604090393/1003/EDUCATION05">Lynn Williams, first place in Senior Individial Exhibit category for her work on Margaret Sanger</a> (Vermont, 2006) </p>
</div>
<p>Connie Tran of Pascagoula High School took third place for her poster exhibit on Margaret Sanger. (Mississippi, 2006) </p>
<p>Sophia Nguyen and Neha Mukunda, won the New Jersey's Junior Group Performance with their presentation, &quot;Margaret Sanger: A General in the Battle for Birth Control, A Soldier in the War for Women's Rights.&quot; (New Jersey, 2006) </p>
<p class="style2">Annie Kjar and Jesa Wolthuizen, &quot;The Woman Rebel--Margaret Sanger--Taking a Stand by Giving Women a Choice&quot; (Iowa, 2006) </p>
<p><span id="StoryText"><span id="StoryText">Chelsea Gilchrist and Josie Gomez</span>, came in third place in the junior division for their documentary, "Margaret Sanger and the Birth Control Movement," which placed third in the junior division. (Hawaii, 2006) </span></p>
<p>Keanna Cohen, "Margaret Sanger: Her Stand for Birth Control" individual senior project, division winner (New Mexico, 2006) </p>
<p><a href="http://www.georgiahumanities.org/programs/history/2006_history_day.html">Isabella Lugo, won an honorable mention in the Junior Division Performances for her "Margaret Sanger: Taking a Stand for Women's Rights"</a> (Georgia, 2006) </p>
<p><a href="http://www.shaker.org/news/releases/2004/statehistory05.htm">Tarresha Poindexter, Katherine Campbell-Morrison and Allison Tillman, were national alternates for their group performance of "Margaret Sanger and the Birth Control Revolution."</a> (Cleveland, OH, 2005.)</p>



<p><a href="http://www.wisconsinhistory.org/teachers/historyday/finalists2003.asp">Lauren Korthof, Senior Individial Finalist for "The right not to be a mother: Margaret Sanger & Birth Control"</a> (Waukesha, WI, 2003)</p>



<p>Chloe Woodward's project "Margaret Sanger: The Woman Rebel".

(National, 2002)</p>



<p>Alexandra Bispo, Sara Hunt, Lauren Blum, "Margaret Sanger: A Woman Rebel," (Monteray County, CA,  finalists, 2002)</p>



<p>Trina N. Assur, "Margaret Sanger: Woman Rebel" (Connecticut, 2002)</p>



<p>Scott Buckley, "Margaret Sanger" (Delaware, 2002)</p>



<p>Casey Lynch and Tiffany Zehner, "Margaret Sanger: Champion of Birth Control" 

(Pennsylvania, 2002)</p>



<p>Michelle Cordes, "Margaret Sanger and Birth Control in America" (National, 2001)</p>



<p>Nicole Desrosiers, "Margaret Sanger" (Massachusetts, 2001)</p>



<p>Martha Graham's "Margaret Sanger's Work: The Development of Birth Control" 

(Ohio, 2000)</p>



<p> Latasha Hailey, "Margaret Sanger: A Woman Rebel" (Maryland, 1999)</p>
<p><a href="http://muse.jhu.edu/journals/journal_of_womens_history/v012/12.1freeman.pdf">Susan Frreman's article</a>, &quot;Women's History in the New Millennium: The Next Generation of Scholars,&quot;  <em>JOURNAL OF WOMEN&rsquo;S HISTORY</em>, VOL. 12 NO. 1 (SPRING 2000) describes Serene Myers's winning individual performance project on Margaret Sanger. (1999, North Carolina, National)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Resources</h1>
		<div id="subnav">
			<a href="../research/index.php">Research Requests</a><br>
			<b><a href="../research/nhday.php">National History Day</a></b><br>
			<a href="../research/bibliography.php">Sanger Bibliography</a><br>
			<a href="../research/images.php">Sanger Images</a><br>
			<a href="../research/links.php">Links</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
