<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>MSPP / Resources / Research Resources/title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href='http://fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
	 
	 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	 <script src="../aboutms/responsiveslides.min.js">
  	
 		 <link rel="stylesheet" href="../style.css">
 	     <link href="../style.css" rel="stylesheet" type="text/css">
		
  <script>
 // You can also use "$(window).load(function() {"
  $(function () {

      // Slideshow 1
      $("#slider1").responsiveSlides({
        maxwidth: 1000,
        speed: 800
      });


    });
  </script>
  
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
  <div id="fb-root"></div>
		<script>(function(d, s, id) {
  		var js, fjs = d.getElementsByTagName(s)[0];
  		if (d.getElementById(id)) return;
  		js = d.createElement(s); js.id = id;
  		js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  		fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));
		
		</script>


	<body>
  
  
  

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="https://nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
	<a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png" width="25" height="50"></a>
	<a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
	</div>
	</div>
	</div>
	
	<div id="wrap">
		<div id="header">
		<div align="center">
			<a href="../aboutms/index.html"><img src="../images/logo.png" width="682" height="100"></a> 
			
	  </div>
   </div>
   </div>
   	<ul id="nav">

<li>
			<a href="../aboutms/aboutms.php" title="About Margaret Sanger" class="selected">About Sanger</a>
			<ul>
				<li><a href="../aboutms/msbio.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The Project">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About the Project</a></li>
				<li><a href="../aboutmspp/staff.php">Staff</a></li>
				<li><a href="../aboutmspp/interns.php">Interns</a></li>
				<li><a href="../aboutmspp/funders.php">Funders</a></li>
				<li><a href="../aboutmspp/..aboutmspp/reviews.php">Reviews</a></li>
				<li><a href="../aboutmspp/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../Publications/about.php">Publications</a>
			<ul>
				<li><a href="../Publications/publications.php">About</a></li>
				<li><a href="../Publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../Publications/microfilm-online.php">Online Microfilm</a></li>
				<li><a href="../Publications/microfilm.php">The Microfilm Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/about.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		
		<li>
		<a href="../documents/about.php" title="Documents Online">Documents Online</a>
		<ul>
				<li><a href="../documents/about.php">About</a></li>
				<li><a href=../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Digital Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		
		<li>
		<a href="..research/index.php" title="Resources">Resources</a>
			<ul>
			<li><a href="../research/index.php">Research Resources</a>
			<li><a href="../research/nhday.php">National History Day</a></li>
			<li><a href="../research/editorsnotes.php">Editors' Notes</a></li>
			<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
			<li><a href="../research/images.php">Sanger Images</a></li>
			<li><a href="../research/links.php">Links</a></li>
			</ul>

			<li>
			<a href="../contactus.php" title="Contact Us">Contact Us</a>
			</li>
		
	</ul>
		</div>
		</div>
		
		<div id="main">
		<center>
		<img src="../research/mainimage.png">
		</center>
		
		
<div class="maintext">


<p>The Margaret Sanger Papers Project's primary goal is to publish material about Margaret Sanger in microfilm, book, and electronic forms. We are neither an archive 
nor a research library and we do not own any of the collections of Sanger's original papers. Moreover, as we no longer maintain an office, we do not have the facilities or staff to 
copy documents or undertake extensive research. We do try to respond to all queries, but if you require detailed or time-consuming research we will try to direct you towards 
researchers who might be willing to undertake the work.</p>

<p>If you are interested in research your first step should be to consult secondary sources, such as the major Sanger biographies and histories of the birth control movement as well as 
pertinent writings by Margaret Sanger. Then you may want to look for more detail on our website, especially our biographical sketch and newsletter articles.</p>

<p>You may then want to consult one of our four printed volumes <a href="../aboutmspp/publications/book.php"><ital>The Selected Papers of Margaret Sanger</ital></a>. Our microfilm edition is available in many libraries in the United States 
and abroad. And our electronic editions,<ital>Speeches and Articles of Margaret Sanger<ital>, and an older edition covering <a href="https://modeleditions.blackmesatech.com/mep/MS/docs/ms-table.html">Margaret Sanger and The Woman Rebel</a> are available online.

<p>When contacting the Project, we ask that you to provide your full name (not just an e-mail address) and your mailing address (which helps us to locate the nearest library that holds 
our microfilm edition), as well as a complete description of the project you are working on. You may contact us by e-mail at <a href="../aboutms/sanger.papers@nyu.edu">sanger.papers@nyu.edu</a></p>.
    

		</div>
				</div>
	
		<div id="sidebar">
			
			<h2>Search</h2><script>
			(function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
	        </script>
	        <gcse:searchbox-only></gcse:searchbox-only>

	  	<br><br>
		<h2>Research</h2>
    		<div id="subnav">
		
		<!---LINKS (bold current section)--->
			<a href="../research/resources.php">Research Resources</a><b><br>
			<a href="../research/nhday.php">National History Day</a><br>
			<a href="../research/editorsnotes.php">Editors' Notes</a><br>
			<a href="../research/bibliography.php">Sanger Bibliography</a><br>
			<a href="../research/images.php">Sanger Images</a><br>
			<a href="../research/links.php">Links</a><br>
		

	
		</div>
		</div>
			
		</div>
	
		<div id="mainend"></div>
		</div>
	
	
	    <div id="footer">
		<div align="center">
		All contents copyright © The Margaret Sanger Papers. All rights reserved.
		
		</div>
			</div>
	   
	</body>
	 </html>
	
	
	