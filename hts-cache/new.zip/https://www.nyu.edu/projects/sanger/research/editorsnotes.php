﻿
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Resources / Editors Notes</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources" class="selected">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Editors Notes</h1>
<div class="maintext">

<img border="1" img src="../images/images/Editors_-Notes-ICPP-and-British-planning-for-Third-ICP-2.jpg" align="right" width="250" style="margin-left: 15px;">
<p>So much of the research undertaken for editions never appears in the printed volume, though the gathering of it informs the annotation in the volumes. From 2012-2014, 
the Margaret Sanger Papers Project joined a collaborative effort, known as <a href="http://editorsnotes.org/">http://editorsnotes.org/></a>Editors' Notes</a>, to investigate taking 
notes and conducting research in an open-source web-based tool. The idea is that research conducted by scholarly editors, archivists, and librarians could be shared, both with each 
other and with the public. The Editors' Notes project is headed by Michael Buckland (University of California, Berkeley), assisted by Ryan Shaw (University of North Carolina) and 
Patrick Golden (University of North Carolina).</p>
<p>The Sanger Papers editors included research on Sanger's work in India, including summaries of documents and secondary sources, and materials from 1914, which was more likely to 
overlap in content with materials from the other participating projects. For the Sanger Project page, see To see the notes and documents on Editors' Notes, <a href="http://editorsnotes.org/projects/sanger/index.html">CLICK HERE</a>

<p>Among the other projects working with Editors' Notes are: <a href="http://editorsnotes.org/projects/ecssba/index.html">The Elizabeth Cady Stanton & Susan B. Anthony Papers</a>, the <a href="http://editorsnotes.org/projects/labadie/">Labadie Collection</a>, and the <a href="http://editorsnotes.org/projects/emma/index.html">Emma Goldman Papers Project</a>.</p>

<p>For more on Editors' Notes, see:</p>

   <li><a href="http://metadata.berkeley.edu/adests2015.pdf">Editors' Notes as a Genre</a> by by Ryan Shaw, Patrick Golden, and Michael Buckland, 2015.</li>
	<li><a href=../documents/http://metadate.berkeley.edu/using2015.pdf%22>Using Linked Library Data</a> in Working Research Notes by Ryan Shaw, Patrick Golden, and Michael Buckland, 2015.</li>
   <li><a href="https://www.cni.org/wp-content/uploads/2013/04/cni_taking_shaw.pdf">Taking Scholarly Note-Taking to the Web</a>, Michael Buckland and Ryan Shaw<br /></li>
	<li><a href="http://dh2013.unl.edu/abstracts/ab-297.html">Open Notebook</a>: Open Notebook Humanities: Promise and Problems by Ryan Shaw, Patrick Golden, and Michael Buckland</li>
</div>

<br><br>
		
	<div id="sidebar">
		<h2>Search</h2>
<script>
  (function() {
    var cx = '016619794450116726182:r0pm5z5tz6e';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
	</script>
	<gcse:searchbox-only></gcse:searchbox-only>

	<br><br>
	
		<div id="sidebar">
		<h2>Research</h2>
	
		<div id="subnav">
		
		<!---LINKS (bold current section)--->
		<p><b><a href="index.php">Research</a></b><br>
		    <a href="editorsnotes.php">Editors' Notes</a><br>
			<a href="nhday.php">National History Day</a><br>
		    <a href="bibliography.php">Bibliography</a><br>
		    <a href="links.php">Links</a><br>
		    <a href="images.php">Images</a></p><br>
          <!---END LINKS--->
		    
		  <!--END RIGHT HAND NAVIGATION--->
		
		</div>
				


        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Resources</h1>
		<div id="subnav">
			<a href="../research/index.php">Research Requests</a><br>
			<a href="../research/nhday.php">National History Day</a><br>
			<a href="../research/bibliography.php">Sanger Bibliography</a><br>
			<a href="../research/images.php">Sanger Images</a><br>
			<a href="../research/links.php">Links</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
