
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Resources / Links to Related Sites</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources" class="selected">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Links to Related Sites</h1>
<div class="maintext">

<ul id="menuC">
  <li><a href="#nyu">New York University</a></li>
  <li><a href="#repro">Reproductive Rights Groups</a></li>
  <li><a href="#popcon">Population Control Organizations</a></li>
  <li><a href="#women">Women's History Sources</a></li>
  <li><a href="#histed">Historical Editing Sites</a></li>
  <li><a href="#other">Other Sites of Interest</a></li>
</ul>

<a name="nyu"></a>
<h2>New York University</h2>
<p><a target="_new" href="http://www.nyu.edu/">NYU's Home Page</a><br />
<a target="_new" href="http://www.nyu.edu/gsas/dept/history">NYU's Department of History</a><br />
<a target="_new" href="http://history.fas.nyu.edu/object/history.gradprog.archivespublichistory.html">NYU's
Program in Archival Management and Historical Editing</a>


<a NAME="repro"></a>
<h2>Reproductive Rights Groups</h2>

<p><a target="_new" href="http://www.guttmacher.org/">The Alan Guttmacher Institute</a><br />
<a target="_new" href="http://www.ippf.org/">International Planned Parenthood Federation</a>
<br /><a target="_new" href="http://www.naral.org/">National
Abortion and Reproductive Rights Action League</a><br />
<a target="_new" href="http://www.plannedparenthood.org/">Planned Parenthood Federation
of America</a>
<br />(Planned Parenthood's page has links to other groups)
<br /><a target="_new" href="http://www.alexandersanger.com/">Alexander Sanger's web site</a>
</p>


<a NAME="popcon"></a>
<h2>Population Control Organizations</h2>

<p><a target="_new" href="http://populationaction.org/">Population Action
International</a>
See their educational page <a target="_new" href="http://www.dayof6billion.org/">Day
of 6 Billion!</a>
<br /><a target="_new" href="http://www.popcouncil.org/">The Population Council</a>
<br /><a target="_new" href="http://opr.princeton.edu/">Office of Population Research</a>
at Princeton University
<br /><a target="_new" href="http://www.prb.org/">The Population Reference Bureau</a></p>

<a NAME="women"></a>
<h2>Women's History Resources</h2>

<p>The <a target="_new" href="http://www.smith.edu/libraries/libs/ssc/">Sophia Smith Collection</a>, Smith College
<br /><a target="_new" href="http://www.radcliffe.harvard.edu/schlesinger-library">The Arthur &amp; Elizabeth
Schlesinger Library on the History of Women in America</a> at Radcliffe
College
<br /><a target="_new" href="http://frank.mtsu.edu/~kmiddlet/history/women.html">American
Women's History: A Research Guide</a> from the Middle Tennessee State University
<br /><a target="_new" href="http://www.wcwonline.org/">The Center for Research
on Women</a> (<a target="_new" href="http://www.wellesley.edu/WCW/crwsub.html">old link</a>)
<br /><a target="_new" href="http://www.nwhp.org/">National Women's History Project</a>
<br /><a target="_new" href="http://www.greatwomen.org/">National Women's Hall of Fame</a>
<br /><a target="_new" href="http://www.h-net.org/~women/">H-Women Discussion List Home
Page</a>
<br /><a target="_new" href="http://womhist.binghamton.edu/">Women and Social Movements
in the United States, 1830-1930</a>
<br /><a target="_new" href="http://www.aahn.org/">American Association for the History
of Nursing</a> web page
<a target="_new" href="http://www.genesis.ac.uk/">Genesis</a>:
Developing Access to Women's History Sources in the British Isles
<br /><a target="_new" href="https://www.yourlawyer.com/library/19th-amendment-womens-suffrage-movement/">The 19th Amendment and the Woman's Suffrage Movmenet</a></p>

<a NAME="histed"></a>
<h2>Historical Editing Sites</h2>


<p><a target="_new" href="http://www.documentaryediting.org/wordpress/">The Association for Documentary
Editing </a>(Has links to more Project pages)
<br /><a target="_new" http://modeleditions.blackmesatech.com/mep/MS/docs/lb.html/">The Model Editions Partnership</a> 
<br /><a target="_new" href="http://janeaddams.ramapo.edu/">Jane Addams Papers Project</a>
<br /><a target="_new" href="http://www.wwp.brown.edu/">The Women Writers Project</a> at
Brown University
<br /><a target="_new" href="http://www.nyu.edu/leisler/">The Jacob Leisler Papers</a> at
New York University
<br /><a target="_new" href="http://www.gwu.edu/%7Eerpapers/">The Eleanor Roosevelt Papers</a> at George Washington
University
</p>


<a NAME="other"></a>
<h2>Other Sites of Interest</h2>

<p><a target="_new" href="http://www.miriamreed.com/">Miriam Reed's</a> one-woman shows on Margaret Sanger and other historic women.
<p><a target="_new" href="http://www.pbs.org/wgbh/amex/pill/index.html">&quot;The
Pill&quot;</a> a web-site on the PBS documentary, featuring Margaret Sanger's role in its
development that aired as part of the <span class="italicText">American Experience</span> on February 24,
2003.</p>

<p>If you would like us to add your group or organization to our links
page, contact <a href="mailto:sanger.papers@nyu.edu">sanger.papers@nyu.edu</a></p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Resources</h1>
		<div id="subnav">
			<a href="../research/index.php">Research Requests</a><br>
			<a href="../research/nhday.php">National History Day</a><br>
			<a href="../research/bibliography.php">Sanger Bibliography</a><br>
			<a href="../research/images.php">Sanger Images</a><br>
			<b><a href="../research/links.php">Links</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
