﻿
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Resources / Sanger Bibliography</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources" class="selected">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Sanger Bibliography</h1>
<div class="maintext">

<ul id="menuC">
<li><a href="#bio_ms">Biographies of Margaret Sanger</a></li>
<li><a href="#bio_young">Biographies for Younger Readers</a></li>
<li><a href="#genbc">General Birth Control Histories featuring Sanger</a></li>
<li><a href="#encyc">Encyclopedia Articles</a></li>
<li><a href="#vid">Videos/Audio</a></li>
</ul>

    <p><em>* </em><span style="font-style:italic;"> Recommended</span>
    <img border="1" src="msflowers.jpg" align="right" width="195" height="200" style="margin-left: 15px;">
    </p>

<a name="bio_ms"></a>
<h3>Biographies of Margaret Sanger</h3>

<p><em>* </em>Jean H. Baker. <span class="title">Margaret Sanger: A Life of Passion</span>. New York: Hill &amp; Wang, 2011.</p>
<p><em>* </em>Ellen Chesler. <span class="title">Woman of Valor: Margaret Sanger and the Birth Control Movement in America.</span> New York: Simon &amp; Schuster, 2007.</p>
<p>Patrricia Walsh Coates, <span class="title">Margaret Sanger and the Origin of the Birth Control Movement, 1910-1930: The Concept of Women's Sexual Autonomy</span>, <span dir="ltr">Edwin Mellen Press, 2008</span>. </p>
<p>    Joan Dash. <span class="title">A Life of One's Own: Three Gifted Women and the Men They Married.</span> New York: Paragon House, 1973.</p>
<p>Emily Taft Douglas. <span class="title">Margaret Sanger: Pioneer of the Future.</span> New York: Holt, Rinehart and Winston, 1970.</p>
<p><em>* </em>Margaret Forster. <span class="title">Significant Sisters: The Grassroots of American Feminism 1839-1939.</span> New York: Alfred Knopf, 1985.</p>
<p>Madeline Gray. <span class="title">Margaret Sanger: A Biography of the Champion of Birth Control.</span> New York: Richard Marek Publishers, 1979.</p>
<p>David Kennedy. <span class="title">Birth Control in America: The Career of Margaret Sanger.</span> New Haven: Yale University Press, 1970.</p>
<p><em>* </em>Lawrence Lader. <span class="title">The Margaret Sanger Story and the Fight for Birth Control.</span> Garden City: Doubleday), 1953.</p>

<a name="bio_young"></a>
<h3>Biographies for Younger Readers</h3>

<p>Nancy Bachrach, <span class="title">Margaret Sanger.</span> Lucent Books, 1993.</p>
<p>Peter Bagge, <span class="title">Woman Rebel: The Margaret Sanger Story</span> (graphic novel) 2013.
<p>Vicki Cox, <span class="title">Margaret Sanger: Rebel for Women's Rights</span>. Chelsea House Publications, 2004.</p>
<p><em>* </em>Nancy Whitelaw. <span class="title">Margaret Sanger: Every Child a Wanted Child.</span> New York: Dillon Press, 1994.</p>
<p>Elyse Topalian. <span class="title">Margaret Sanger.</span> New York: Franklin Watts, 1984. <p>Virginia Coigney. <span class="title">Margaret Sanger: Rebel With a Cause.</span> Garden City: Doubleday, 1969.</p>


<a name="genbc"></a>
<h3>General Birth Control and Population Control Histories featuring Sanger</h3>

<p><em>* </em>Simone Caron. <span class="title">Who Chooses? American Reproductive History Since 1830.</span> 2010. </p>
<p><em>* </em>Jonathan Eig. <span class="title">The Birth of the Pill: How Four Crusaders Reinvented Sex and Launched a Revolution.</span> 2014. </p>
<p><em>* </em>Peter C. Engelman. <span class="title">A History of the Birth Control Movement in America.</span> 2011. </p>
<p><em>* </em>Matthew Connelly. <span class="title">Fatal Misconception: The Struggle to Control World Population.</span> 2008.</p>
<p><em>* </em>Linda Gordon. <span class="title">The Moral Property of Women: A History of Birth Control Politics in American.</span> Urbana: Illinois University Press, 2002. </p>
<p>    Linda Gordon. <span class="title">Woman's Body, Woman's Right: A Social History of Birth Control in America.</span> New York: Grossman Publishers, 1976.</p>
<p><em>* </em>Cathy Moran Hajo. <span class="title">Birth Control on Main Street: Organizing Clinics in the United States, 1916-1939.</span> Urbana: Illinois University Press, 2010. </p>
<p><em>* </em>Carole R. McCann. <span class="title">Birth Control Politics in the Unites States, 1916-1945.</span> Ithaca: Cornell University Press, 1994.</p>
<p><em>* </em>Angus McLaren. <span class="title">A History of Contraception: From Antiquity to the Present Day.</span> Oxford: Basil Blackwell, 1990.</p>
<p><em>* </em>James Reed. <span class="title">The Birth Control Movement and American Society: From Private Vice to Public Virtue.</span> Princeton: Princeton University Press, 1978.
<p>Beryl Suitters. <span class="title">Be Brave and Angry: Chronicles of the International Planned Parenthood Federation</span>, London: IPPF, 1973.</p>
<p><span class="style1">*</span>Andrea Tone, <span class="title"> Devices and Desires: A History of Contraceptives in America</span>. Hill &amp; Wang., 2001.</p>
<a name="encyc"></a>
<h3>Encyclopedia Articles</h3>
<p><span class="title">American National Biography. John Garraty, ed. New Haven, Yale University Press, 1999 Esther Katz, "Margaret Higgins Sanger", pp. 264-267.</span></p>
<p><span class="title">Dictionary of American Biography, Supplement 8 1966-1970.</span> John Garraty and Mark C. Carnes, eds. New York: Charles Scribner's Sons, 1988.  David Kennedy, "Margaret Higgins Sanger," pp. 567-570.</p>
<p><span class="title">Encyclopedia of Leadership</span>, Volume 3. Eds. George R. Goethals, Georgia Jones Sorenson, and James MacGregor Burns, Sage, 2004. Denise R. Johnson, &quot;Birth Control,&quot; pp. 100-105. </p>
<p><span class="title">Encyclopedia of New York City.</span> Kenneth T. Jackson, ed. New Haven: Yale University Press, 1995. 
Esther Katz, "Margaret Sanger," p. 1041.
<p><span class="title">Encyclopedia of New York State.</span> Peter Eisenstadt, ed. Syracuse University Press, 2003. Esther Katz, "Margaret Sanger."
<p>    <span class="title">Handbook of American Women's History.</span> Angela Howard Zophy and Frances Kavenik, eds. New York: Garland Press, 1990.  Esther Katz, "Margaret Sanger," p. 529.
<p><span class="title">National Cyclopaedia of American Biography</span>, Vol. 52. New York: J.T. White, 1970. "Margaret Sanger," pp. 325-326.</p>
<p><span class="title">Notable American Women: The Modern Period.</span> Barbara Sicherman, Carol Hurd Green, Ilene Kantrov, and Harriette Walker, eds. Cambridge: Belknap Press, 1980.  James Reed, "Margaret Sanger," pp. 623-627.</p>
  
 <a name="vid"></a>
<h3>Videos/Audio</h3>
<p>Esther Katz. <a href="http://www.loc.gov/locvideo/womenact/" target="_new">Women's Activism and Social Change: Documenting the Lives of Margaret Sanger and Jane Addams</a> BOOKS &amp; BEYOND, March 24, 2003 at the Library of Congress' Center for the Book (with Jane Addams Papers Editor, Mary Lynn McCree Bryan). </p>
<p><a href="http://www.pbs.org/wgbh/amex/pill/index.html" target="_new">"The Pill"</a> a PBS documentary, featuring Margaret Sanger's role in its development, broadcast as part of the <span class="title">American Experience</span> on February 24, 2003.</p>
<p><a href="http://www.barnaalper.com/" target="_new">Barna-Alper Productions</a> released "The Woman Rebel," in the series <span class="title">Turning Points of History</span>, broadcast in Canada's History Television on June 21, 2002.</p>
<p>Cobblestone Films released "Margaret Sanger" on PBS in October 1998. This one and a half hour video is available through <a href="http://www.films.com/ecTitleDetail.aspx?TitleID=9878&r=SR" target="_new">Films for the Humanities and Sciences</a>.</p>
<p>"Margaret Sanger: A Public Nuisance," a half-hour video produced in 1992 by Terese Svoboda and Steve Bull, is available through <a href="http://www.wmm.com/filmcatalog/pages/c147.shtml" target="_new">Women Make Movies</a>.</p>
 <p> Margaret Sanger's 1953 <a href="../documents/this_i_believe.php" target="_new">"This I Believe"</a> speech (mp3 file). </p>
 
 <hr>
 
 <p>1940s photo courtesy of the University of Arizona, Department of Special Collections.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Resources</h1>
		<div id="subnav">
			<a href="../research/index.php">Research Requests</a><br>
			<a href="../research/nhday.php">National History Day</a><br>
			<b><a href="../research/bibliography.php">Sanger Bibliography</a></b><br>
			<a href="../research/images.php">Sanger Images</a><br>
			<a href="../research/links.php">Links</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
