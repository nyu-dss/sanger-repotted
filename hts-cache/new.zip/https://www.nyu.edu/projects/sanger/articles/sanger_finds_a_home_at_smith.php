
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #10 (Fall 1995)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #10 (Fall 1995)</h1>
<div class="maintext">
<h1>"Sanger Finds a Home in the Sophia Smith Collection"</h1>

<p>     In the spring of 1946, Margaret Sanger sorted through boxes of letters that had long gathered dust in the
closets of Willowlake, her home in Fishkill, NY.  Sanger was selling Willowlake and preparing to make her final
move to Tucson, Arizona where she had been living for most of the past nine years.  The work of sifting through
and repacking letters and photographs that dated back to her childhood was physically and emotionally exhausting. 
She re-read forgotten letters from old lovers, her husbands, and her children.  With the recent death of her second
husband, J. Noah Slee, and the infirmity of many of her close friends, including H. G. Wells, who would die
later that summer, the well-traveled bundles of letters took on greater emotional and historical significance for
Sanger than ever before.</p>

<p>     Endeavoring to preserve the history of the birth control movement (the "Cause" as she called it), Sanger had
begun depositing records of the various birth control organizations she founded in the Library of Congress in
1942.  While depositing her papers in the Library of Congress gave Sanger an added dose of respectability, the
irony of the situation surely attracted her to the arrangement.  While the nation's venerated library sought to
acquire and preserve the records of her life's work, the U.S. government steadfastly repelled her repeated
attempts to legalize birth control.  But Sanger soon grew disenchanted with the Library's bureaucracy and became
worried that her collection was under-appreciated in the large repository she referred to as "the cold barn."  (MS
to Florence Rose, June 13, 1946, <em>MSM</em> S25:783).</p>

<p>     She would continue to send organizational material to the Library of
Congress until her death in 1966, but during this last stay at Willowlake in
May and June of 1946 Sanger decided she did not want her personal papers to
be overshadowed by the growing collection of birth control records in
Washington.  She wanted her personal letters to be protected and highlighted
on her own terms:  "...they are rather precious and much more interesting
than the material on the Cause, or letters relating to the Cause." (MS to
Florence Rose, June 10, 1946, <em>MSM</em> S25:773)</p>

<p>     Sanger approached the New York Public Library (NYPL) in May of 1946
with a letter of intent to deposit unknown quantities of material there.  The
NYPL had long sought Sanger's papers,  but she insisted on maintaining some
control over access. "We must have a few restrictions," she wrote, 
"inasmuch as our material is very personal + the movement is still on the
wing."  (MS to Dorothy Brush, May 27, 1946 <em>MSM</em> S25:705).  The NYPL, however, wanted complete control over its manuscript collections. 
The negotiations dragged on, but a satisfactory agreement could not be
reached.</p>

<p>     As Sanger was
negotiating with the
NYPL, her good
friend Dorothy Brush,
an active alumna of
Smith College, wrote
to Margaret Storrs
Grierson, the director
of the Sophia Smith
Collection, a
repository of primary
sources in women's
history founded in
1942 in the Smith
College Library:  "I
am a close personal
friend of Margaret
Sanger and have
worked with her for
years," Brush wrote.  "It is just possible I might
persuade her to turn over to the Library her papers at
least when she dies, and possibly sooner since she is about to break up her home." 
(Brush to Margaret Grierson, May 2, 1946, the Sophia Smith Collection, Dorothy Brush Papers, Box 13, Folder
19) </p>

<p>     Grierson responded enthusiastically and plans were made for Sanger to visit Smith College in late June of
1946.  Excited by Brush's description of  the Sophia Smith Collection and flattered by Margaret Grierson's
interest in her papers, Sanger ended negotiations with the NYPL.  She wrote to her secretary Florence Rose: "I
am considering quite seriously giving Smith most of my correspondence as they are now building up a library
around noted women in this country where they hope future historians will come for the intimate material on these
women of America." (MS to Florence Rose, June 10, 1946, <em>MSM</em> S25:773).  Rose responded with
encouragement, reminding Sanger that donating her papers to Smith College would in a sense keep an old
promise: "That was what Mary Beard was trying to do with her WOMEN'S ARCHIVES.  You did promise her a
lot of your personal material &ndash; but that all was washed up when the WOMEN'S ARCHIVES idea was abandoned
early in the 1940s, as I recall it."  (Florence Rose to MS, June 17, 1946, <em>MSM</em>
S25:808; for more on World
Center for Women's Archives, see Margaret Sanger Papers Project Newsletter, Spring/Summer 1994.)</p>

<p>     Sanger and Brush arrived in Northampton, MA on June 22 and met with Smith College President Herbert
Davis, Margaret Grierson, and several of the librarians.  Sanger came away from the visit feeling less than warm
towards President Davis, noting that she thought him pro-Catholic.  But she was delighted with Margaret Grierson
and excited about her plans for further developing the Sophia Smith Collection.  Nevertheless, she still hesitated. 
Two weeks later, Brush informed Margaret Grierson that Sanger  "...fell in love with you...[but was] not too
certain the College really wanted her papers...I think it would be an awful blot on our escutcheon if we let this
slip through our fingers now!" (Brush to Margaret Grierson, July 8, 1946, in the Sophia Smith Collection,
Dorothy Brush Papers, Box 13, Folder 19)</p>

<p>     With great care and the utmost respect for Sanger's position in history, Grierson wrote Sanger to express her
"joy and excitement" over the possibility of receiving the papers: "The possession of your papers would, of
course, be to the great glory of Smith College ... you can make possible the creation on this campus of a
distinguished research center for the study of the forces of women in shaping human destiny." (Margaret Grierson
to MS, July 3, 1946, <em>MSM</em> S25:874)  Grierson also assured Sanger that every effort would be made to collect
additional material on the birth control movement and that Sanger would be given free rein on imposing any
restrictions she desired.  </p>

<p>     Delighted at having found a suitable home for her collection, Sanger began sending periodic gifts of her
personal papers, along with many organizational records to the Sophia Smith Collection.  Hesitant at first to send
love letters and other personal material, Sanger cautioned Brush who was helping her pack boxes for Smith: "...
(don't let my morals get out of line until I'm dead and gone) I'll trust you to hold back anything not fit for these
young modern Smith minds." (MS to Dorothy Brush, October 1946, <em>MSM</em> S26:332)  But by the 1950s Sanger
had given the Sophia Smith Collection most of her early personal correspondence including some very
combustible letters from her first husband William Sanger, along with correspondence chronicling her intimate
relationships with such figures as H. G. Wells, Havelock Ellis, and Hugh de
Selincourt.  Always she admonished
Grierson to restrict the most sensitive correspondence until after her death: "The letters from Wm. Sanger will be
most revealing to a biographer should one wish to delve into personalities of a Career Woman....But they must
not be given to anyone to read or use during my lifetime Please". (MS to
Grierson, July 1949, <em>MSM</em> S30:467)</p>

<p>     After each Sanger donation, Grierson responded with a long letter of gratitude expressed in her inimitable
way: "The actual possession of your records has...acted as fruitful stimulus  to the acquiring of other valuable
records in the woman's field.  While none of our acquisitions can compare to your collection in intrinsic value and
eventual service in the study of civilization, we owe to your gift the encouragement and strengthening of our
enterprise." (Margaret Grierson to MS, November 22, 1947, <em>MSM</em> S27:769) </p>

<p>     In 1949, after an intense lobbying effort by Dorothy Brush, Smith College bestowed an honorary LL.D. on
Margaret Sanger, citing her as "one who with deep sympathy for the oppressed and disinherited, yet with a
dispassionate and scientific approach, has made a conspicuous contribution to human welfare through her
integrity, courage, and social vision."  (Smith College Honorary LL. D., Statement,
<em>MSM</em> S77:645) 
Extremely pleased with this recognition, Sanger began sending the bulk of her public as well as her private papers
to Smith, rather than the Library of Congress.  She encouraged her friends and associates in the movement to
donate their birth control-related papers as well, many of which were incorporated into the Sanger collection. 
With the Sanger papers as its cornerstone, Sophia Smith Collection staff were subsequently able to lure the
Planned Parenthood Federation of America, the Margaret Sanger Research Bureau, and the Planned Parenthood
League of Massachusetts into donating their records; and personal collections for Dorothy Brush, Florence Rose,
and several other pioneers of the birth control movement were also established.  After Sanger's death, the Sophia
Smith Collection also acquired Sanger's personal library and photo collection. </p>

<p>     Modest about their mission, but fully aware of the significance of their friendly compact, instigated and
cultivated by Dorothy Brush,  Grierson and Sanger helped to insure that the Sophia Smith Collection is home to
the preeminent collection of archival and manuscript material on the birth control movement in America.  The
Sanger Papers Project microfilmed Sanger's papers in the Smith College Collections.  Published by University
Publications of America, the 83-reel Smith College Collections Series includes material drawn from the Margaret
Sanger Papers and 19 other collections in the Sophia Smith Collection and College Archives.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
