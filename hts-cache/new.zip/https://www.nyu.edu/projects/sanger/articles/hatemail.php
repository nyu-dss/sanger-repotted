
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #47 (Winter 2007/2008)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #47 (Winter 2007/2008)</h1>
<div class="maintext">
<h1>"'Dear Madam, I Abhor You,' and Other Selections from Sanger's Hate Mail"</h1>

<p>When Sanger told a reporter back in 1916 that &ldquo;I have been called in turn a vile female, a person with a barnyard philosophy, a God-send, the greatest woman of the century, the counterpart of Abraham Lincoln and a horrible creature,&rdquo; she could have been describing the epithets that she read in each day&rsquo;s mail. (<em>Portland Oregonian</em>, June 17, 1916.)</p>

<p>By every indication Sanger received far more letters of support and letters from women and men seeking advice than the hate-filled variety, but at certain periods in her career, usually following a nationally broadcast radio or television speech or a mainstream article, attack and crank letters stormed into her mail box by the hundreds.</p>
<p>Relatively few of the hate letters survive today. Like the thousands of client letters she received, most of the hate mail ended up in the circular file. While we have few letters from the first two decades of Sanger's career, there are many written between 1930 and 1960,most by Catholics and, more often then not, by women. </p>
<p>Those angry letters are remarkably consistent in theme and tone. A number of the letter writers had in common the clever idea of turning Sanger&rsquo;s godless rationalism on its head by asking her some version of the unanswerable question, &ldquo;Where would you have been if your mother had practiced birth control?&rdquo; </p>
<p>What follows are excerpts from a selection of Sanger&rsquo;s hate mail, taken from the barrage of letters written in response to several key events: Sanger&rsquo;s April 11, 1935 ABC radio address on &ldquo;Family Planning&rdquo;; the July 1951 <em>Reader&rsquo;s Digest</em> profile, &ldquo;Margaret Sanger: Mother of Planned Parenthood,&rdquo; by Lois Mattox Miller; her 1957 Mike Wallace interview and her public declaration during the 1960 election that she would leave the country if John F. Kennedy was elected president. </p>
<p>The letters have been transcribed with spelling and typographical errors intact. We have removed the names of the authors, if they appeared, out of concern for their privacy.</p>
<p>Many of the offended individuals wrote to denounce Sanger and contraception on the grounds that her work defied God's will, resulted in murder and denied human souls the kingdom of heaven. </p>
<p>&ldquo;Mrs Margaret Sanger: I have just listened to your radio talk on Birth Control. It was only through chance that I heard you. I abhor you. Your talk sounded very plausible to one that has had no experience, but for those that have tried your devilish ideas, it is disgusting. . . . I am the Father of six children, all well, born in the period of 10 years. My wife unbeknown to me took up Birth Control and after these six I have two more in the cemetery and my wifes ovaries &amp; womb is hanging in a bottle in the Pres Medical Centre in N.Y. City. My wife never had any trouble in any way with the first six children and after the use of Birth Control she had plenty and very near put herself in the Cemetery. Account for that? . . . I can name you 50 cases within a radius of 15 miles where the results of Birth Control have been as terrible if not worse than mine. My seventh child was horribly crippled and the Dr. told me I could thank God that it did not live. Account for that? You are doing a terrible work. I can lay the death of my Babies and the wrecking of my married life right to your writings. Be Careful old girl. Look-- Stop--Listen. I would not be in your shoes for all the world.&rdquo; (Apr. 11, 1935, Sagaponack, N.Y. [LCM 9:375].)</p>
<p>&ldquo;Dear Madam: Your father should have practices birth control. Better still, he should have practiced total abstinence. An American Catholic.&rdquo; (July 19, 1960, Glenview, Ill. [<em>MSM</em> S57:395] .)</p>
<p>&ldquo;Mrs. Margrett Sangers, Dear Madam we see in our papers that you are disturbed about your Birth controle bill, they is undoubtedly something wrong with you, we are not allowed to make laws to kill without cause what difference is they in takeing the ax and going to the cradle of the incubator to destroy innocence, thugh shall not kill . . . . Your disobedience as a Woman has brought it all on them, For God told you when you went and took up with that snake there in paradise that your troubles was then doubled, so at the best you must take your medicine, for you had no business of being borned a woman, and God could not make a man out of you being spoiled in the making, So you stand to day a enemy of Gods Creation and should a never a been borned . . . . Now if you women would do what God created you to do you would be just earthly angels, but your education, has spoilt you, and your sins will find you out. Your doctrine cant work.&rdquo; (Feb. 9, 1935, Logan Okla. [LCM 50:119A] .)</p>
<p>&ldquo;Dear Madam: You have been a shameless &ldquo;murderess on parade&rdquo; for a long while. However, you never looked more hellishly ludicrous than at present when the government is about to launch a campaign to encourage as many births as possible as has been done for sometime in Europe. Perhaps this will see and end to your shameless debaseing of Parenthood. You, if you ever had any real Christian upbringing, must have developed a cast iron conscience to be able to carry on your soul the innumerable times you are guilty of having the Commandment--Thou shalt not kill--broken by poor innocent people who listened to your advice. The average schoolboy or girl knows more about contraceptives than you do and that is well-known; which makes your birth-controllers hopelessly out-dated. If you were a sincere person you would devote your time to something cleanworthwhile.&rdquo; (Aug. 28, 1941, Brooklyn, N.Y. [LCM 50:135].)</p>
<p>&ldquo;Dear folks, To stop birth by operating or rubber is murder as I see truth. The way, to secure benefits, is teach every child the laws of God. Living according will do away with abnormal desire--gratefying abnormal desires causes people want to control births.&rdquo; (Feb. 6, 1935 [LCM 50:117].)</p>
<p>&ldquo;Dear Madam: A few words of comment on your article in the Jan. 27, 1932 Nation. . . . It is evident that you get your &lsquo;facts&rsquo; from story books as you accuse the pope of doing. A person with natural normal experience would not write such nonsense. Probably not one pregnancy occurs in a thousand acts of coition. Several things may happen between impregnation and birth. Conception, pregnancy, mis-carriage, murder, and most of all, murder-unfinished. The most unfortunate of births.&rdquo; (Apr. 16, 1932 [LCM 50:8].)</p>
<p>One argument focused on the danger of practicing birth control because it eliminated the birth of potential great men. It was always great men, such as the Founding Fathers, who were cited as the &ldquo;what if&rdquo; example, never famous women. &ldquo;Remember Paul Revere was one of sixteen children and what a [gift] he was to America,&rdquo; one enraged woman wrote. (Aug. 17, 1957 [<em>MSM</em> S35:114].)</p>
<p>&ldquo;I certainly do not endorse any such bill for Birth Control. Is it possible that Communism has crept into our country so deeply that we ape the manners of those so inclined? I'd like to know what human being knows how to regulate such an action? Where would many of our great men of the past be, had parents had one to five children only? Look at Ben Franklin about 13th of a family of 17. Where would there be a country for these people who advocate such a thing had he not been born? There is Henry Clay, Daniel Webster, I needn't go on. Yes, regulate birth control &amp; give us only mediocre people.&quot; (May 12, 1932, Minneapolis, Minn. [LCM 50:23].) <br />
</p>
<p>&ldquo;Madam, In the Book of Exodus, chapter 20th verses 13-14, we read: &ldquo;Thou shalt not kill.&rdquo; &ldquo;Thous shalt not commit adultery.&rdquo; I write this for your information, because the <em>St Paul Pioneer Press</em> of Saturday Aug 17, 1935 quotes you as saying &ldquo;the anti birth control movement takes its orders from Rome.&rdquo; There is a possibility you do not believe in a God. Your mother had enough belief in a Supreme giver of life that she spared you for the light of day, a blessing your murdering policy denys to millions of the unborn. Who are to inherit this land if your policies are carried out? There will be no Americans for America. Can you intelligently reason that? From one who pities you,&rdquo; (Aug. 17, 1935, Franklin, Minn. [LCM 50:119B] .)</p>
<p>&ldquo;Mrs. Margaret Sanger, It was sickening to hear you spout off on Mike Wallace&rsquo;s interview! You should have been cut off the air. If your own Catholic mother had heard you speak how unhappy she would have been. Thank God, she was called to her reward before she could have heard her own daughter. Where would you have been if she had practiced birth control? Why waste 30 years on wasted effort to try to get people to sin because of your efforts. I am a Catholic. I am sure your being on that interview will help us all to renew our efforts against birth control. We know birth control is a grevious sin against God&rsquo;s law. I am the mother of six darling God-given children, the oldest is seven years old. God willing we will have more. I am glad your sons arent listening to you. I am sure they are very happy with their fine families.&rdquo; (Sept. 1957 [<em>MSM</em> S52:853].)</p>
<p>Most of the hate mail she received was from Catholic opponents. Of course Sanger had a way of egging them on through her public denunciations of the Pope, frequent reminders that the celibates who run the Church shouldn&rsquo;t give advice on matters related to sex, procreation and parenting, and the occasional blasphemous zinger, like &ldquo;Jesus . . . had no children.&rdquo; The responses were not surprising. </p>
<p>&ldquo;Dear Mrs. Sanger, After hearing your broadcast last night, and as a Catholic, I feel I owe you a debt of gratitude. You, of all people, strengthened my faith as it has never been touched before. Your complete lack of morality coupled with the inconsistencies of your answers, make me doubly firm in my beliefs and so thankful to have a Church that defines them.&rdquo; (Sept. 21, 1957 [<em>MSM</em> S52:773].)</p>
<p>&ldquo;Dear Mrs Sanger When you said the Catholic Hierarchy &ldquo;thinks they are God,&rdquo; you were just a little mixed up. You see they know they are representatives of God on earth, It was and is God who puts the natural law in everyman&rsquo;s heart. I feel very sorry for you though, the devil&rsquo;s written his law in your heart, and has thereby hidden God&rsquo;s from you. It doesn&rsquo;t happen to be just the Hierarchy of the Catholic church who believe in God and His laws, Even the poor misguided ones, who seek your help (to Hell), know they are doing wrong. As I looked on your poor face on the television I saw none of the divinity you claimed for yourself, Yet I know that God made you and is keeping you alive and I felt so sorry for you. You know, Mrs. Sanger, death comes quickly, but then for you, that should be no surprise, for many years, you and your clinics have meant death for eternity. What will your life after death be like? Have you ever thought of that? You should, because God is just! God bless you!! A Catholic Parishoner, and mother of 6 beautiful children.&rdquo; (Sept. 21, 1957 [<em>MSM</em> S52:729].)</p>
<p>Some opponents assumed that Sanger disliked children and didn&rsquo;t have any of her own.</p>
<p>&ldquo;Dear Mrs. Sanger, . . . According to the paper you&rsquo;re some ones wife but don&rsquo;t suppose you were ever a mother. It would take some one like that to crusade for some thing like birth controll. I&rsquo;m a mother of two &amp; a grand mother of 3 lovely grandchildren. I&rsquo;d be real happy to have more children if that were Gods wishes. Just who are you to estimate who is or who isn&rsquo;t an American. There were lot of Catholics on the battlefield fighting for this country. My husband was one of them. I&rsquo;m not ashame to admit I&rsquo;m a Catholic. What are you. Nothing I imagine.&rdquo; (July 18, 1960, Marinette, Wisc. [<em>MSM</em> S57:365] .)</p>
<p>Some traditionalists wrote to object to birth control for creating a permissive society and altering domestic patterns &ndash; more women in the work place. Anti-Communists saw red in Sanger&rsquo;s old wardrobe and linked her to radicals and revolutionaries from the past. </p>
<p>&ldquo;My dear Miss Sanger: The evil you wish to avoid in advocating birth control is in plain sight,--but it seems to me that the real cure is to be found in the fear of God and in love to woman and not in contraceptive devices and applications. Your remedy, it seems to me, will tend to give free reign to men&rsquo;s desires and to women&rsquo;s willingness to please to the destruction of morality and of that self-denial which is the law of Jesus Christ. Your remedy condons indulgence in the married and fornication in the unmarried. You may say you do not mean this, but is not one responsible for the known and practically certain consequences of what he advocates? You many say that these sins are inevitable and that we must just try to do away with the evil consequences. But what would Jesus do? Can you imagine Jesus, Paul or John serving on your Committee?&rdquo; (June 22, 1932 [LCM 50:30].)</p>
<p>&ldquo;Dear Margaret, We have some nice lots in Moscow please advise if you want to move Nov. 2nd or 3rd. Moscow Realty Corp. Moscow USSR.&rdquo; (July 19, 1960, Ridgewood, N.J. [<em>MSM</em> S57:385].)</p>
<p>Others were appalled at the fact that she had inserted herself into the political campaign with her comments about Kennedy.</p>
<p>&ldquo;I am 13 years old and I am a Roman Catholic. You aren&rsquo;t a Democrat, nor Republican, American or Chinese, but at least I&rsquo;m a Roman Catholic. You&rsquo;re sick! You ain&rsquo;t nothin&rsquo;! If I were Kennedy I&rsquo;d sure see to it that you did live elsewhere. I&rsquo;d stone you right out of America. It&rsquo;s a shame people like you are allowed to live within America&rsquo;s boundaries. Please don&rsquo;t write back. I don&rsquo;t want your cooties in the house.&rdquo; (July 18, 1960 [<em>MSM</em> S57:377].)</p>
<p>&ldquo;Dear Mrs. Sanger, . . . In my estimation your statement &ldquo;I&rsquo;ll find another place to live if John F. Kennedy becomes president,&rdquo; is the smartest thing you have ever said. These United States would be far better off without you and your kind. The good thinking people of this country would gladly contribute transportation charges to wherever you would like to go. The further, the better.&rdquo; (July 16, 1960 [<em>MSM</em> S57:327].)</p>
<p>&ldquo;A normal salutation had been abstained from as it is difficult to imagine you a person let alone a Miss or Mrs. As a member of the republican party and one of a large family which has been active in and fully supported the republicans for years, I can only say that your comments in the attached article, will probably turn more votes to the Kennedy camp than the democrats could ever hope for. Keep up the good work; you&rsquo;ll help get Senator Kennedy elected. What your shrunken mind cannot possibly absorbe is the fact that most intelligent people realize that THE RICHEST WAY TO GO THROUGH THIS WORLD IS WITH WARMTH TOWARDS OTHERS. When you move, may I suggest Russia? Deepest sympathy, A New Democrat&rdquo; (July 16, 1960 [<em>MSM</em> S57:321].)</p>
<p>&ldquo;Dear Mrs. Sanger, . . . First of all, I wish to explain I am not the sort of person who writes crank letters. This is the first. But I feel so strongly that I must protest. . . . How you expect &ldquo;controlled infanticide&rdquo; to achieve world peace is beyond me. If electing John Kennedy forces you to find another place to live, I say &ldquo;Three cheers for Kennedy and let&rsquo;s get out the vote.&rdquo; (July 20, 1960, Tacoma, Wash. [<em>MSM</em> S57:397].)</p>
<p>In these attack letters, Sanger was not vilified as she is today&mdash;as a racist, Nazi sympathizer or a friend of the Klan. She was seen as an equal opportunity purveyor of sin and, no matter how often she untangled contraception from its erroneous association with abortion, accused of doling out death in the form of small rubber devices.</p>
<p>Unlike the client letters, which she or an assistant always replied to, even if only by form-letter, Sanger rarely responded to hate mail. There are a few exceptions. She received a letter in October 1951 following a lengthy profile that appeared that summer in <em>Reader&rsquo;s Digest</em>. A reader in Cleveland informed Sanger that she still had time to &ldquo;put a &lsquo;good&rsquo; motive to your efforts&rdquo; and teach &ldquo;self control&rdquo; rather than &ldquo;self indulgence.&rdquo; The author continued, </p>
<blockquote>
<p>We no longer think it is nice, as the old Romans did, to gorge ourselves and then induce vomit &ndash; what applies to this appetite for food applies to our sex appetites. If we do not want the responsibilities that the privilege implies, then we should not indulge.</p>
</blockquote>
<p>The letter was similar to scores of others Sanger received from Catholics and though it was exceedingly patronizing, it was also kinder in tone. But Sanger had evidently had enough and scribbled a hasty response on the back that her secretary typed and sent out several days later. &ldquo;It&rsquo;s always the same with Roman Catholic objections,&rdquo; she wrote:</p>
<blockquote>
<p>"The same dark age ignorance. The same distortions of truth. The same old: The Romans gorge themselves, etc. It shows such ignorance of the marriage relations, of decent young people who want to have only the number of children they can support and bring up properly . . . it takes but one sexual act between husband and wife in a whole year to give some parents a baby every year through the child bearing period of the woman&rsquo;s life. Parents do practice continence and self control. Also your churches wrongful advice to have sexual contact during a period in the woman&rsquo;s cycle when she does not want it! That&rsquo;s a spiritual wrong your celibate Hierarchy must undo."</p>
</blockquote>
<p>(Pauline C. Hogan to MS, Oct. 5 and MS to Hogan, Oct. 15, 1951 [<em>MSM </em>S35:407, 409].)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
