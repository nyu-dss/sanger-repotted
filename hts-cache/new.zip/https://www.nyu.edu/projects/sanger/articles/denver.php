
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #46 (Fall 2007)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #46 (Fall 2007)</h1>
<div class="maintext">
<h1>"Sanger Leagues: Rocky Mountain Birth Control"</h1>

<p>When Sanger arrived in Denver in late May 1916, a full month into her historic cross-country tour, she ran into a figure even more far-famed and controversial than she, Judge Ben B. Lindsey. A leading figure in the Progressive party, Lindsey had built a national reputation for establishing a separate court for juveniles, the first in the nation. He was also an early advocate of birth control, woman suffrage and more liberal divorce laws. He railed against government corruption and attracted ridicule for joining Henry Ford&rsquo;s failed 1915 &ldquo;Peace Party&rdquo; mission to Europe. He was widely accused of corrupting American youth with his progressive ideas and would later come under fire for his controversial book <em>Companionate Marriage</em> (1927). </p>

<p>Upon Sanger&rsquo;s arrival in Denver, she and Lindsey established an immediate camaraderie; they may have already known each other from radical circles in New York. Lindsey chaired Sanger&rsquo;s well-attended meeting in Denver, which took place at Marble Hall despite mounting pressure in the state legislature to ban birth control literature and meetings. &ldquo;It was a high point for me at the time,&rdquo; Sanger remembered, &ldquo;so soon after my own court appearance, to have Judge Lindsey preside at my meeting.&rdquo; More importantly, she was addressing a new kind of audience. &ldquo;Formerly my listeners, with the exception of Indianapolis, had been chiefly of the working class,&rdquo; she notes, &ldquo;Here they were wives of doctors, lawyers, petty officials, members of clubs. I was more than delighted to have an audience which had the power to change public opinion.&rdquo; Sanger was especially impressed with the women she met in Denver: &ldquo;It seemed to me the women there were the most beautiful I had seen &ndash; fresh, charming, alive. They had long had the vote and used it effectively.&rdquo; (MS, <em>Autobiography</em>, 201-202.) </p>
<p>Sanger won an endorsement for birth control in the Denver Express, and inspired a small group of activists to distribute contraceptive information even though it remained against the law. As in other stops on her tour she also left a positive imprint on those she met or who heard her speak. Many expected a hardened, flame-throwing radical and were surprised at Sanger&rsquo;s &ldquo;gentlewoman&rdquo; appearance; as one Denver reporter wrote, she looked &ldquo;more interested in darning socks than defying the government.&rdquo; (Denver Chapter of Planned Parenthood, &quot;Denver Celebrates Silver Anniversary,&quot; May 7, 1951 [MS Papers, Sophia Smith Collection, Smith College]; <em>Denver Post</em>, May 27, 1916, quoted in Kevin E. McClearey, The Noonday Devil: Margaret H. Sanger&rsquo;s 1916 American Lecture Tour, [unpublished manuscript], 4:23. ) </p>
<p>Sanger returned to Denver in November 1923 to give several addresses and meet with the newly formed Denver Birth Control Committee, which was planning a state campaign. Three years later, organizers opened the first Denver clinic in the basement of the Universalist church. It served 150 married women in its first year. The driving force of the clinic and the transformation of the small Denver committee into a full fledged Birth Control League was community activist Ruth Vincent Cunningham, who had worked with Lindsey in the Denver juvenile court, and later headed the western division of Sanger&rsquo;s National Committee on Federal Legislation for Birth Control in the 1930s. The success of the Denver League and clinic led to the rise of clinics in other parts of Colorado in the 1930s and 1940s. These clinics and leagues banded together with those of neighboring states in 1986 to form Planned Parenthood of the Rocky Mountains. Acknowledging Sanger&rsquo;s 1916 visit as its founding, the organization celebrated its 90th anniversary last year. In a 1928 letter Judge Lindsey told Sanger that &ldquo;If we have been able to do anything worth while, it is largely due to your inspiration.&rdquo; (&ldquo;News Notes,&rdquo; <em>Birth Control Review</em> 7 [December 1923]: 324; Lindsey to MS, October 16, 1928 [LCM 9:168].)</p>
<p><em>Thanks to Tina Garbin at Planned Parenthood of the Rocky Mountains for the photographs and additional historical information.</em></p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
