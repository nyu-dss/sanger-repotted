
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #17 (Winter 1997/1998)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #17 (Winter 1997/1998)</h1>			

<div class="maintext">			
<h1>"The Unrecorded Battle (Part I)"</h1>

<p><em>This unpublished short by Margaret Sanger was probably written in the early 1910s when she worked as a visiting
nurse in New York City.  This and the only other short story (also unpublished) that we know of, both appear to have
been written haphazardly and show little evidence of rewriting or editing.  But it demonstrates one more side of
Sanger the writer, who around this same time is working as a free-lance reporter on labor issues and writing sex
education articles for The Call. The story also exhibits a pretty, strong-willed heroine, Peggy Taylor, who just might
resemble the author in more than name. So here, in its original form, we offer the world a first glimpse of Margaret
Sanger's fiction</em>.</p>

<p><em>We have not corrected Sanger's spelling errors, though we have added missing quotation marks to clarify the story.</em></p>

<p><hr noshade size="1"></p>

<h3>THE UNRECORDED BATTLE</h3>

<p>"A case a case &ndash; My kingdom for a case" were the words which rang through the room, where several nurses were
gathered one afternoon in June.  The words were uttered by a small, fair and healthy specimen of the female sex, and
tilting her nose a trifle more, if possible than it was naturally inclined, threw the stockings she was darning from her,
gathered her knees within her folded hands and continued: "No joking girls, its three weeks to day since Ive had a
case, and tomorrow not only my rent here is due, but &ndash;" she was interrupted by the telephone &ndash; "yes, &ndash; yes,
certainly, Ill take it, Ill go right down good bye" She turned from the phone, and the light in her eyes, the expression
of happiness on her face, made one who saw it, say what a pretty girl she is.  "Lucky Dog" said the girls in a chorus,
"Where is it"? said one.  "What is it?" said another, "No time for questions girls, I must don my best togs and see if I
can cinch that job &ndash; get out of here all of you and come back later on   I must dress."  A half hour later, she was
neatly attired, boarding a down town car in her hand was a card upon which was written the address of the Physician
who wanted an office nurse.</p>

<p>     She arrived at the address given "ah yes she thought, I expected a brown stone front well so be it, now
Peggy Taylor smile your prettiest".  A colored butler took her card, told her to be seated but before she had time to
glance at her surroundings, the Dr. stood before her, in operating gown, "Ah Miss Taylor yes Im glad to see you, Yes
I want an assistant nurse, one who is capable and understands her business, I require a certificate of health, a
reference from two reliable Physicians, and your Hospital diploma, I wish it understood that I pay well for your
services Miss Taylor, twenty-five dollars a week and board, five dollars for every operation done outside, and two
and a half for all done in the house, we average ten operations a day"   At this information she beamed happiness, her
heart beat so loudly she straightened in her chair to get control of herself; he saw the look and was satisfied, yes he
thought to himself, she will do nicely.  "Is there anything you do not understand Miss Taylor? very well, then if you
wish to accept the position bring the required references at ten A.M. tomorrow and consider yourself engaged."  He
arose, shook hands in a most business like way, ushered her to the door, closed it after her, watched her as she
boarded an uptown car, smiled as only he could smile, and went back to his work.</p>

<p>     Peggy had no knowledge of when she got back to her room, she had known what it was to be happy, but
never before had she been so favored by the gods that she called herself "lucky" until now.  "Me" she said aloud,
"me Peg Taylor to fall into such luck, and what a dress Ill give to Kit for her graduation, &ndash; Ill write at once to mother
and tell her about it," she wrote the following:</p>

<p>Dear dearest mother mine: Stop that garden work get a man to do it for you, and Ill pay him, or get
one to peddle the milk and let father do the garden work, delay your trip to New Haven until my
next letter, when I shall send you money enough to buy a new dress for yourself and one for Kit, I
want her graduation dress to be a real dress Muddy dear, a point de spirit over silk with baby
ribbon, would be right, I should think, oh I'M so happy.  Dont you worry about that horrid old
mortgage and note which fall due soon, for
I'm coining money.  Will write to you
about it later on,
love to all the kiddies and be happy, your
devoted Peggie.</p>

<p>She finished writing this and with pen upraised she
sat pondering for a moment then brought forth
another sheet of paper and wrote:</p>

<p>Dear old Dick; Yours rec'd, if I had answered it
yesterday as I was inclined to do, you should have
had "yes" for an answer instead of the one I am
going to give to you to day.</p>

<p>Dick for three weeks I have not earned one cent, all
the nurses were desperate, I have had only a few
cases so far this spring and short ones too.  I was
foolish to come to New York when I did summer is
always bad so I am told.  Yesterday I felt I could
keep it up no longer and was strongly tempted to
shake it all of and go back to the farm and &ndash; be &ndash;
yours.; but the thought of the mortgage due shortly,
of mother bending over the strawberry bed trying to
sell enough to make ends meet, the thought of the
thousand little things needed for those little [ones]
and I their only hope, &ndash; I thought of all these Dick
and I just could not give up; but today I am well
rewarded, for Yours truly is to be [assistant] to a M.
D. and you Dick dear must be content to wait, oh,
just a little longer and then Ill be forever your Peg.</p>


<p>She caressingly sealed this letter, took her hat and
gloves and departed to get the required references. 
Let me see there is Dr. Clark, yes Ill go to him I
nursed his wife and sick baby and he will be glad to
hear of the turn of fortune Ive had.  She had not
long to wait before she was telling this great
specialist of the wonderfol opportunity before her
and the part he was to have in her realization of it.</p>

<p>     This man of experience looked at her fondly as he would a child he hesitated to dampen the spirits of this
happy girl, and yet he was suspicious of the location, and urged her to delay going there until he could find out for
her a little more concerning this generous Physician who was not registered among the legitimates.</p>

<p>She laughed at his concern and called him "stupid" assured him she was capable of judging conditions
better than he was as she had seen the person in question and if he would just jot down a few words which would
serve as a reference, she would be off and not trouble him again, &ndash; until she wanted something else.  At which they
both laughed, and she is soon on her way to the general practitioner where she obtained the required health
certificate and reference.  Back again to her little room to say good bye to this "dinky box" and dream the dreams
which should have come true to so faithful generous and loyal a girl.  She had not long to dream however for she was
soon aroused from her reveries by a loud knocking at the door, and girls voices saying "hallo Taylor, let us in &ndash; Say
did you get the Job? bully for you. Tell us about it. She told them simply.  "Ye gods!" said one girl a Miss Ryan
"was ever such luck.  Ill give you fair warning girls if I dont get a case in twenty-four hours Ill marry &ndash; a street
cleaner."  "Indeed," said Miss Willets a auburn haired girl with a twinkle in her eye who was a staunch Suffragist 
"You'd have done that long ago had you the slightest
opportunity."</p>

<p>"Well" said Miss Ryan "so would you Willie if you were
on twenty four hour duty, with a typhoid for six weeks without
one cent, and then after you had pulled this living skeleton out of
the jaws of &ndash; well it might be presumption on my part to say just
where, but the nerve of [those] people to refuse to pay me twenty
five dollars a week, to question the right of a Woman to demand
such a price, and Willie you" &ndash; "Oh yes, of course," interrupted
Miss Willetts "they dispute your right they question your price but
would they dare to question a Doctor?  Would they refuse a man
the salary he asks?  No" she continued, "rising from the bed on
which she was sitting, they would not dare to, but we Women, &ndash;
we are so alone and foolishly divided, that not until we demand
our rights politically, will we be respected in any  vocation." </p>

<p>"Hooray, hooray," cheered the voices "Go on Willie."
"keep it up."  She was willing to but was silenced by the tall
figure of the Matron of the Registry, who had knocked several
times and receiving no response &ndash; walked in.  She smiled as she
heard the closing words of the enthusiastic orator, upon seeing
Miss Daly who was next on the list, informed her  she had been
called by Dr. Russell for an obstetrical case, to report at once.  A
groan from the croud, "beat it Daly" and "twins for yours".  She
was off.  The Matron told Miss Ryan to get her bag ready, for it was her turn next.  "Ready, why Mrs Robinson Ive
been ready for weeks" They all laughed and the Matron, a kindly woman of middle age, left them to their follies.</p>

<p>Miss Willetts had not forgotten her subject, she began; "No Ryan there is no use in kicking about abuses,
here and there, the first thing all working women must do is to Organize, do you hear girls, to organize Thats the first
step out of the darkness for Women."</p>

<p>"Why look at us, we nurses do practally all the work in many cases, and what do we get out of it?  We pay,
first five dollars to belong to a Registry, then out of every case we pay the Registry ten per cent, on all our earnings,
and our room rent and telephone, figure it up how much we get out of it.  We do the work thats the point, and what
right has these parasitical registrys to take ten percent, or any percent?  Why not work together, have one Central
Registry, where all nurses [register] and any Doctor wanting a nurse can call for one there, how much more
economical, think of the three hundred or more registrys with there three hundred telephones, clerks, and other
encumbrences, and a Doctor not knowing where to get a nurse, and hundreds of nurses hanging in the air lots of them
on the verge of starvation waiting for a call.</p>

<p>Isn't it foolish? Why even Taylor, the Innocent from Conn. can see it cant you Hon?" "If you mean me Miss
Willetts," said Miss Taylor, "I can see that point all right, but I can not understand why you are so hard on the
Matrons of the Registrys, they must do something in order to live, why not that?" "Yes" said the Suffragist
sarcastically, "they must live that [is] true, but dont you, personally find it rather expensive charity?  Could not such
an intelligent woman as Mrs. Robinson for instance, be doing something worth while? and I dare say if you talk to
her you will find she is longing to do something, some service to humanity. Instead of this monotonous existence."</p>

<p>"Say Willie," said Miss Ryan, who had been closing her eyes in boredom "if ever you get a patient with
insomnia, reel off that rot you just gave us and he will either be cured, or he will be compelled to change his
residence, &ndash; to Bellview.  For heaven's sake, cut it out and let us hear about Taylors case." "Is he handsome Peggy?"
said Miss Willetts. "Well Yes and no." "Thats a bad sign to begin with," "cant you say which?" said Miss Willetts. 
Peggy thought a minute and then said "no I cant just tell, he has a peculiar face, but Im not going to disect his looks
until I know him better.  All I know is its a good job girls and I need the money" "Thats true" Said Miss Willetts "but
are you sure everything is straight down there?  You are such a kid in some things Peggy, and yet &ndash; and yet" she said
thoughtfully, "I sometimes think it is your innocense which somehow protects you."  "Perfect nonsense," said Miss
Taylor "Im sure he is a [gentleman],  &ndash; he's very courteous &ndash; , and even if he isnt, nurses must stand the cross and
dissagreeable, as well as the polite people."</p>

<p>So they chatted and discussed the problems that trouble the thinking people of all nations, until bed time,
when wishing each other good night and Peggy good luck, they left her; she threw herself upon her knees and poured
out her heart felt thanks to the Great Unknown for this happiness this great and beautiful happiness, of being able to
do for others, and especially for those we love &ndash; so she slept the sleep that only youth and a clear conscience can
sleep (LCM, 131: 0087).</P>

<p><em>Discover Peggy Taylor's fate and fortune in the <a href="unrecorded_battle-2.php"> next issue</a> of the MSPP newsletter.  The dramatic conclusion is
coming soon &ndash; stay subscribed!</em></p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
