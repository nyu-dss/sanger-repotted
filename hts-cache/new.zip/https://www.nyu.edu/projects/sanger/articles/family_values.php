
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #4 (Winter 1992/1993)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #4 (Winter 1992/1993)</h1>
<div class="maintext">
<h1>"Family Values in Margaret Sanger's Time"</h1>

<p>   The presidential victory of Bill Clinton seems to have quieted
the debate on family values for the time being, but it is hardly a
new issue, as anyone familiar with Margaret Sanger's life can
attest.  Much in the same way that conservative defenders of the
American family blame feminists and homosexuals for a
perceived erosion of family values, Sanger and the birth control
movement were criticized as a threat to the family for advocating
sex education and reproductive choice for women.</p>

<p>    The frenzy of recent attacks against Hilary Clinton and even
the fictional "Murphy Brown" by the Republican and religious
right also echo the efforts of conservatives, traditionalists, and
the religious right to limit women's choices in Sanger's day.  For
her advocacy of birth control, Sanger was painted as a dangerous
radical bent on destroying the American family in order to
achieve a subversive feminist agenda.  Sanger was scorned for
promoting women's sexuality in her groundbreaking books
Woman and the New Race and Happiness in Marriage, particularly her insistence that sexual pleasure should be enjoyed
independent of its procreative function.  Others claimed, without
any validity, that Sanger advocated birth control in order to profit
from the sale of contraceptives.</p>

<p>    Although careful to aim her message towards married couples, arguing that birth control would strengthen marriage and the
family, Sanger was still blamed for everything from divorce,
infidelity, and promiscuity to a lack of work ethic among
oversexed men.  One conservative critic linked Sanger and the
promotion of birth control with the sins of the "cultural elite" in
terms similar to those that Vice President Dan Qualye used in his
election year speeches:</p>

<blockquote></p>
"... in the circles &ndash; artistic, literary, theatrical and social &ndash; where
birth control is notoriously common, scandals, divorces, infidelities,
and general sex laxness are equally notorious... Birth Control has
given whole groups morals which would shock a savage." (Daniel
Lord, Speaking of Birth Control, Aug. 15, 1934)</p></blockquote>


<p>Sanger was even blamed for the influx of women into the
workforce during World War II.  An author of a Catholic
pamphlet wrote:  "Can America be grateful to Margaret Sanger
who forced women, mothers and grandmothers to work in
munitions plants because we did not have enough men to do the
job?" (<em>Novena Notes</em>, July 1951).</p>

<p>    Sanger countered her critics by offering an alternate view of
family values.  By speaking to the tragedy of unwanted children
and the self-destructive nature of large and over-burdened
families, she turned the arguments of her critics on end.  Citing
government statistics on the rising rates of infant mortality, child
labor and poverty, she adopted the rhetoric of her adversaries by
linking family planning with a "new morality &ndash; a vigorous,
constructive, liberated morality" and a stronger, healthier family.</p>

<p>    Sanger resisted all efforts to classify her as a sexual radical by
controlling the iconography of the movement and focusing her
argument for birth control on its impact on children.  One of her
more innovative discussions can be found in a 1926 article for
<em>Holland's Magazine</em> entitled "Passports for Babies," in which
Sanger fantasizes about parents being subjected to an interview
by a prospective baby.  The demanding child inquires whether
the parents have paid for their last baby, how many other
children they have, and whether or not the parents can supply a
happy home, proper food, a sunny nursery, and love and
affection.  Summarizing the prospective parents' responses, the
baby exclaims: "Five children already? Two dark rooms in the
slums? No! Thank you! I don't care to be born at all if I cannot
be well born.  Good-bye!" </p>

<p>    Sanger was careful to present herself to the press as a
traditional mother (and after she remarried as a modern wife).  
Privately Sanger was far less traditional in her views of the
acceptable family ideal.  As her own life clearly reflected,
Sanger was convinced that for women to attain true autonomy
they must be able to exercise their rights and pursue a
"motherhood unchained."   She risked public censure by
separating from and later divorcing her first husband, William
Sanger in 1914 to pursue not only a more independent sexual and
romantic life, but a successful career as an organizational leader,
activist, writer and lobbyist.  When she faced a marriage
proposal in 1922 from an older man, oil-rich tycoon, J. Noah
Slee, Sanger negotiated an agreement which allowed her to
maintain her independence both personally and professionally.</p>

<p>While Sanger's own family life was not traditional, her advocacy
of birth control was firmly rooted in a deep concern for the lives
and health of women and children.  Her goal was not to destroy
the family, but strengthen it by making it a more flexible and
varied institution.</p> 

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
