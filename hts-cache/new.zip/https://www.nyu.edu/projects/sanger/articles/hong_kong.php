
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #16 (Fall 1997)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #16 (Fall 1997)</h1>
<div class="maintext">
<h1>"Hong Kong"</h1>

<p>        With all that has been written about Hong Kong
this past summer, leading up to China's reclamation
of the territory from Britain on July 1, we thought it
timely to look back at Sanger's visits there and share
her brief description of the area during her first visit 
in 1922.</p>

<p>        Sanger arrived in Hong Kong in early May of
1922, winding up a two-and-a-half month tour of
Japan and China.  She, her second husband-to-be J.
Noah Slee, and her youngest son Grant, stayed for
five days before boarding a ship bound for Egypt.
The following is taken from her 1922 diary of the
trip:</p>

<blockquote>
  <p>     &quot;Arrived in Hong Kong 7th.  The harbor is a
     wonderful sight.  Thousands of sampans &
     launches on the water front.  While Hong
     Kong seems to be built upon a mountain
     side.  The sampans are filled
     with Chinese, women rowing
     & children helping also. They eat, sleep & live there for a life time.</p>

  <p>     Are born & die in these boats.  [. . .]</p>

<p>The first sight that shocks your senses is the women coolies, carrying coal to the
     steamers.  They carry two baskets on a pole across their shoulders and bare feet,
     hundreds of them do this hard work.  Old & young.  Their faces are strained, their
     bodies thin & emaciated.  They
      do not sing as do the carrying men coolies up north. </p>

<p>They work hard.</p>

<p>Carry bricks to the brick layer, break stone instead of a stone crusher, work bare foot in the  rice fields, in fact do any job a man can do.  I never saw women do this work before.</p>

<p>Hong Kong is a British possession & yet the Chinese speak less English here than they do in either Peking or Shanghai.</p>

<p>We drove out to Republic Bay Hotel, a delightful drive along the bay.  A Hotel like the best in Switzerland.</p>
<p>Lunch & drive around the bay & back to our hotel.</p>

<p>Large rooms with baths but dismal atmosphere like the foreign hotels all are in the Far East.</p>

<p>The morning Post gave a good write up of my visit & an editorial on b.c.  [. . .]</p>

<p>Sail on the SS. Plassy May 10 for Port Said&quot; (World Trip Journal, <em>MSM</em> S70:156-158).</p>
</blockquote>

<p>     Sanger returned to Hong Kong in February of 1936 following a world tour that took her through India,
Ceylon, Burma. Malaya and the Chinese mainland.  During a brief stay made shorter by illness, Sanger met with
leaders of the Hong Kong birth control movement and gave several notable addresses.  "The richest man in HK
gave a wonderful luncheon Chinese for me & twenty eight people were there. . ." Sanger wrote to husband J. Noah
Slee.  "Twenty courses were served & such delicious food we never had when we were here before." Five days later
she writes "Well dearest here I am in the Memorial Hospital trying to get over one of those very painful attacks. . . I
was visiting a nice English Professor & his wife & in the night this came upon me like a vice of pain . . . All I could
do was be in agony all night until my heart began to go back on
me & then they rushed me to the hospital to die!" (MS to Slee,
February 22 and 27, 1936, <em>MSM</em> S11:83-85).  Sanger
recuperated from a severe and recurrent gallbladder affliction
(she had it removed the following year) in the hospital and at a
friends house before returning home in early March. Even
though her illness considerably reduced her schedule in Hong
Kong, two birth control clinics were established in the wake of
her visit.</p>

<p>        In 1959 Sanger, now eighty and ailing, passed through
Hong Kong two more times.  In February she spent three days
attending receptions in her honor on her way back from the
Sixth International Conference on Planned Parenthood in New
Delhi.  Later that year she escorted her two granddaughters and
their friends to Asia on a rare pleasure trip.  They spent several
days in Hong Kong, where Sanger reported that American GI's
entertained her teenage granddaughters, before heading on to
Japan, Sanger's home away from home.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
