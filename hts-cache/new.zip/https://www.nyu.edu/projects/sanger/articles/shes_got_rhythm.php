
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #31 (Fall 2002)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #31 (Fall 2002)</h1>			

<div class="maintext">			
<h1>"She's Got Rhythm? A Safe Period for Sanger and the Church"</h1>

<p>In reaction to the recently disclosed sexual abuse epidemic within the Catholic Church, Catholic prelates in the U. S. have moved from damage control to salvaging their very institution. Indeed, Church leaders are debating whether to reform the priesthood and lift the requisite vows of celibacy. In effect, this will involve changes to an institution notable for its resistance to
change.</p>
<p>When faced in the early 1930s with what many in the Church considered an even greater evil, the widespread acceptance and use of birth control which threatened the salvation of its members from both outside and within, several prominent Church leaders sought a practical and ecclesiastical solution, all the while affirming the wickedness of contraception. As if in answer to Catholic
prayers, new evidence emerged from several research studies in the late 1920s and early 1930s that women could reliably predict the infertile period of their cycles. Catholic birth control was born.</p>
<p>Blind-sided in 1932 by a Catholic book on the "rhythm method" and the Church’s endorsement of rhythm as the only acceptable means of fertility control, Margaret Sanger witnessed for herself that the Church could and would change. In many ways this shift in thinking only confirmed Sanger’s triumph in her decades long cat-and-mouse propaganda war with the Church. But it also complicated her campaign for legislative reform and a public relations strategy, both built upon the image of an enlightened social movement pitted against an arrogant medieval and immutable institution. The one last enemy of birth control
left standing had become, almost overnight, Sanger’s partner in crime.</p>
<p>In 1930 Pope Pius XI confirmed for Catholics what Margaret Sanger had long been reporting to her faithful &ndash; that many Catholics used birth control. In a clear reference to the growing popularity of contraception, the Pope wrote in his December 1930 <em>Casti connubii</em> &ndash; "Encyclical on Christian Marriage," that "a new and utterly perverse morality" that led to "most pernicious errors" had begun to spread "even amongst the faithful" and was "gradually
gaining ground." While calling any act to "deliberately frustrate" the "natural power and purpose" of the conjugal act "shameful and intrinsically vicious," the Pope offered up an ecclesiastical mulligan: a married couple would not be
"acting against nature" if because of "natural reasons either of time or
of certain defects, new life cannot be brought forth." In other words, if
sexual intercourse occurs when it is not conducive to generating life, so be it
&ndash; "as long as the intrinsic nature of the act is preserved." (Claudia
Carlen Ihm, ed., <em>The Papal Encyclicals</em>, 1903-1939 [Raleigh, 1990], 400.)</p>
<p>The "Rhythm method" was not a new idea; the practice of confining sexual
relations to a woman’s natural sterile period in order to avoid pregnancy had
been written about since antiquity. Even the Catholic Church, since the 19th
century, had counseled "onanists"&ndash; those that practiced withdrawal which
the Church viewed as sinful &ndash; to take advantage of this presumed safe period.
But no one had much confidence in it; the method was often ineffective due to
miscalculations and because women’s reproductive cycles do not operate with
machine-like certainty. More significant was the fact that never before had a
Pope so publicly tipped his skullcap, so to speak, in approval of sex for
decidedly non-procreative reasons, including the "quieting of concupiscence."
This Pope did not go so far as to condone planned parenthood &ndash; it would be two
more decades before a Pope (Pius XII) would approve the regulation of births&ndash;
but implicit in this doctrinal and recondite document was the idea that a
married couple could actually have sex for pleasure or satisfaction. (John T.
Noonan, Jr., <em>Contraception: A History of Its Treatment by the Catholic
Theologians and Canonists</em> [Cambridge, 1966], 16, 447.)</p>
<p>Though Sanger responded to the entirety of the Pope’s Encyclical with
evident disgust, calling his conclusions "illogical," full of "nonsense"
and bent on frustrating "human enjoyment," she was somewhat relieved that
the Pope, at long last "admits that sexual desire is in itself something that
can at least claim respectful consideration." She did not, however, foresee
the almost immediate ramifications of the Encyclical and how the liberalization
of Catholic policy toward birth control would muddle a heretofore predictable
battlefield in the public relations war over birth control legislation. (MS, "My
Answer to the Pope on Birth Control," <em>The Nation</em>, Jan. 27, 1932.)</p>
<p>In October of 1932, less than two years after <em>Casti connubii</em>, Leo J.
Latz, a 29-year old Chicago doctor and a practicing Catholic, published <em>The
Rhythm of Sterility and Fertility in Women</em>. It followed closely on the heels
of a German manual by J. N. J. Smulders written a year earlier which had been
circulating through Europe. Known before long simply as <em>The Rhythm</em>, Latz’s
small book promised to solve the "Big Problem of Married People." In a
question and answer format, the book explained how a woman could determine her
infertile days. Latz advised keeping an accurate record for at least six months
of the exact dates on which menstruation began and then counting the days in
between. Once a regular cycle had been established, a woman could determine her
infertile days based on evidence that indicated ovulation takes place 12 to 16
days before the next menstruation. Those numbers were based primarily on the
research of Dr. Hermann Knaus of Austria and K. Ogino of Japan, who arrived at
similar conclusions working independently and published their findings starting
in the late 1920s. The woman then would note variations from month to month in a
"record calendar." Latz claimed that the method was reliable in "a
normally functioning woman in normal conditions." (all quotes from Leo J. Latz,
<em>The Rhythm of Sterility and Fertility in Women </em>[Chicago, 1934 edition].)</p>
<p>Latz presented the rhythm method as "natural," "rational," "in
harmony with nature," and in keeping with God’s laws. He contrasted rhythm
with "artificial" contraception, "the deliberate use of some artificial
means (such as voluntary interruption, chemicals or mechanical devices), in
order to prevent the father cell from meeting the mother cell, in other words,
to prevent conception. It means, then, interfering directly with the workings of
nature in the marital act." Latz further stated that "contraception
represents a violence to nature, a degradation, desecration, and perversion of
the utmost seriousness."</p>
<p>The book was published with ample ecclesiastical approval and with frequent
reference to the<em> Casti connubii</em> which anchored Latz’s moral and
religious justifications for the method. The introduction by Joseph Reiner, S
.J. of Chicago declared that rhythm is "the way out of the difficulty" with
birth control "without a compromise of principle." Latz quoted prominent
Catholic theologians past and present, and several Catholic doctors in support
of periodic abstinence or without objection to a married couple enjoying the
pleasures of sex "without having to bear the burdens ordinarily resulting
therefrom." Latz failed to note that many Church authorities did not find his
justifications for the rhythm in keeping with ecclesiastical tradition, but
their repudiations, heard mostly in Catholic circles, were drowned out by the
curious and the relieved.</p>
<p>When Sanger first encountered the book she remarked to a friend, "The
Catholics have just issued a little book called ‘The Rythum’ Its annoying!
at last they have come to say that marriage is <u>not</u> solely for the
procreating of children! <u>Nor is sex!</u> I’m reading it carefully. . .
Really its significant. . . ."(MS to Juliet Rublee, Jan. 9, 1933 [<em>MSM</em>
C5:470].)</p>
<p>Interest in natural birth control surged in 1933, giving rise to reprints and
knock-offs of the Latz book. The influential American theologian, Monsignor John
A. Ryan, endorsed the deliberate use of the rhythm method in a 1933 <em>Ecclesiastical
Review</em> article, prompting many priests to recommend rhythm to their
parishioners. Most infuriating to Sanger was that <em>The Rhythm</em> and other
similar literature on "natural birth control" circulated, with few
exceptions, freely through the mails while her pamphlets continued to be
regularly confiscated by postal authorities. As Sanger prepared to give
testimony before Congress in January of 1934 in favor of H.R. 5978, the newest
incarnation of a birth control bill that, if passed, would lift many of the
obscenity laws that prohibited the circulation of contraceptives and
contraceptive information, <em>The Rhythm</em> was making the rounds on Capitol
Hill.</p>
<p>In rebutting testimony given by several Catholic leaders before the House
Judiciary Committee, Sanger argued on January 19, 1934 that <em>The Rhythm</em>
was no different, in the eye of the law, than her own pamphlets: "This book
here, Rhythm, is going through the mails, not by right, but by privilege, and it
gives illegal information just as any book I might write on preventing
contraception." Furthermore she found <em>The Rhythm</em> to be a potentially
dangerous publication in that it had not yet been proven effective and reliable:
". . . I feel it will do harm to send it through the mails until there is a
study made of it." (All excerpts from Congressional testimony taken from "Testimony
on HR5978," Jan. 18-19, 1934 [<em>MSM</em> S69:499]).</p>
<p>But several Congressmen, having listened to Catholic priests and prelates
expound on the physical and moral dangers of "artificial" birth control
during the previous day’s testimony, saw the rhythm method as a preferred
alternative to continence, and contrasted it favorably to "artificial"
contraceptives that were tantamount to abortion. "The method you advocate,"
asked Arthur Healey, a Catholic Democrat from Massachusetts, "is an
interference with life?"</p>
<p>"It prevents conception," Sanger responded, referring to barrier methods
such as the diaphragm. "It is not an interference with life."</p>
<p>"It does interfere with it," insisted Healey.</p>
<p>"So does remaining single; so does continence," Sanger retorted, growing
weary of what she later called in her autobiography "the hoary ‘nature’
argument which should have been in the grave long since." The Pope interferes
with life and interrupts the natural process by shaving, she liked to point out.
After another exchange she elaborated: "I am not opposed to this book, if we
can find a safe method. We are coming down now not to a question of principle,
but a question of methods." (MS, <em>Autobiography</em>, 412.)</p>
<p>Refusing to let her Catholic opponents gain the upper hand, Sanger reiterated
that they agreed in principle that "children should be spaced and women should
not have a large number of children." Catholic approval of the rhythm method
represented for Sanger the Church’s profound acceptance of the fundamental
need for birth control &ndash; for reasons of health, economy and population, and to
hold on to their parishioners. To her the distinction between scheduling sex on
specific days and inserting a diaphragm was largely irrelevant. "We are both
together on the principles," she said again in her Congressional testimony as
if no one heard or fully appreciated the irony and significance of this new
situation.</p>
<p>Sanger’s greatest fear over the rhythm method was that it would sabotage
her argument that doctors, relying on individual examination, should be the only
ones to dispense birth control. <em>The Rhythm</em>, though it advised
consultations with a physician, was written for a do-it-yourself audience, as
Sanger commented in her Congressional testimony: ". . . if I picked up that
book and read it and believed as a Catholic, and saw an ecclesiastical approval,
I would follow it to the letter." This represented a real threat to the
legislation that her lobbying group, the National Committee on Federal
Legislation for Birth Control, had carefully crafted to appeal to the medical
community. Moreover, Catholics in Congress and much of the public, also welcomed
a method that insured privacy (no clinic visits), cost nothing, and was free of
the taint associated with contraception &ndash; promiscuity, pre-marital sex,
prostitution, perversion and lust. Latz went so far as to explain that the
rhythm method was not conducive to young, unmarried women because of the
unpredictable nature of their menses, nor would immoral individuals use it since
they would likely be tempted by the greater sexual freedom afforded by
artificial contraceptives. Even if a married couple took advantage of the safe
period to indulge their personal appetite for sex rather than celebrate their
union, it would be viewed, Latz assured his readers, as no more than a venial
sin.</p>
<p>Thus Sanger had many reasons to strike down the rhythm method even as she
exploited the Catholic conversion to birth control. Despite Latz’s certainty
about this method and several positive research studies, Sanger questioned the
existence of a predictable safe period, citing the work of the most respected
names in contraceptive research, including Norman Haire in England ("offers
little security") and Robert Dickinson in New York ("no general rule can be
formulated that will safeguard all women"), who had been conducting studies on
the safe period for several years. No one rejected the notion that some women
might be able to avoid pregnancy by following a rhythm calendar, but few experts
in the early 1930s were willing to recommend it as anything but an auxiliary
method. (Norman Haire, <em>Birth Control Methods</em> [London, 1936], 54; Robert
Latou Dickinson and Louise Stevens Bryant, <em>Control of Conception</em>
[Baltimore, 1931], 54.)</p>
<p>Sanger also attacked the rhythm method as too restrictive for a couple and
counter to a woman’s natural period of sexual desire. As she told the
Congressional Committee: "I will say if there is a period of sexual sterility
and a day when nature makes the woman sterile, it is most likely that is the
time she would repulse the idea of relationship, and so far as any natural law
is concerned, I think that is the period to stay away." Again she had many
experts to back her, including Dr. Carl Hartman, who saw great potential in a
rhythm method but admitted in 1933 that there was a "low ebb of sex desire in
women" noted in nearly all of the safe period studies. (Carl G. Hartman, "Catholic
Advice on the Safe Period," <em>Birth Control Review</em> [May 1933], 120.)</p>
<p>The debate over the rhythm method carried into the late 1930s and peaked when
the <em>Pictorial Review</em> ran a long article in May 1938 that was ostensibly a
digest of Latz’s book. By then, however, the American Medical Association had
endorsed birth control and polls reported that well over two-thirds of the
country supported legalized contraception. "The birth control idea," Sanger
wrote in her autobiography, "was rolling merrily along." And she was
right&ndash;the debate really had boiled down to one over methods rather than
principle. (MS, <em>Autobiography</em>, 412.)</p>
<p>Though Sanger continued to rail against "natural" birth control, even her
clinic in New York relented in the mid-1930s and began a "safe period service"
for women who refused, for religious reasons, to use contraceptive devices, and
as part of a research study on the efficacy of the method. This and other
studies continued to demonstrate that a safe period method produced many
failures, was difficult to teach and suited only a small number of women. Even
very recent studies have found rhythm unforgiving of imperfect use.</p>
<p>Whether the introduction of the rhythm method in the 1930s helped or hindered
Sanger’s ultimately unsuccessful lobbying campaign is impossible to know, and
less important in retrospect and in light of today’s events than gauging
whether the Church knowingly set out to reform its stand on birth control. There
was no doubt for Sanger and other birth control activists that the Church
capitulated and that <em>The Rhythm</em> was its white flag. As a birth control
clinic director and researcher in Florida wrote to Sanger in 1935, "The Church
was licked so they came out and offered them the Rhythm." (Lydia DeVilbiss to
MS, Aug. 17, 1935 [LCM 8:320].)</p>
<p>Those today who say the Church can’t change need to look back to the Pope’s
1930 encyclical on marriage and the emergence of a natural birth control
movement. Maybe the Catholic Church of 2002 can even borrow some of the same
strategies &ndash; anyone for periodic abstinence for priests?</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
