
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #47 (Winter  2007/2008)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #47 (Winter  2007/2008)</h1>
<div class="maintext">
<h1>"The Soul-less Maid"</h1>				

<p><em>Some of you may remember reading "The Unrecorded Battle," an unpublished short story by Sanger that we included in the <a href="unrecorded_battle-1.php">Winter 1997-98</a> and <a href="unrecorded_battle-2.php">Spring 1998</a> newsletters. That story focused on the experiences of a young visiting nurse in New York City. It was a fictional account based on Sanger&rsquo;s several years of part-time nursing work. We recently ran across another of Sanger&rsquo;s attempts at fiction, again with a possible autobiographical component. She dated the story August 19, 1913, about the time she was in the midst of a heated love affair with the Greek anarchist writer and importer John Rompapas. Sanger&rsquo;s husband, William, probably learned of the affair that summer, when the family decided to spend the summer away from the city in Provincetown, Mass. They decided to sail for France in the fall of 1913 in an attempt to preserve their marriage. Is the &ldquo;Juan&rdquo; of the story modeled after John Rompapas, who might have felt spurned by Sanger&rsquo;s attempt to rejoin her marriage? The transcription below has not been altered or corrected in any way.</em></p>

<h3 align="center">The Soul-less Maid (a &ldquo;rough short story&rdquo;)<br />
by Margaret Sanger</h3>
<p>She entered the florist shop, looked searchingly about as if to find something which she did not expect to find. Then her search rested on a vase of large blood red peonies, which she purchased &amp; departed.</p>
<p>She felt satisfied and gently crushed them to her dress, feeling that in these lay her power to win forgiveness from her love.</p>
<p>Today she must be beautiful. True she was always beautiful but to day she must be dazzling in that beauty &ndash; superb, magnificent &ndash; and to this purpose she had most carefully adorned herself. She had chosen a soft clinging cream white silk gown &ndash; showing beneath the faintest outline of two perfectly formed limbs &ndash; fluttered about in a delicate pink which gave one a sensation of a stolen glance at the forbidden mysteries of the sex.</p>
<p>Her golden hair was coiled about her head like a halo &ndash; so when the white fur toque was to be removed &ndash; it would give the expression desired. </p>
<p>This she knew. All her arts &amp; charms were needed today to win back that love in which she had basked like sunshine for the past six months &ndash; for she had cruelly hurt him. Often had she hurt him before &ndash; but a few caresses &amp; smiles brought him to her feet. This time however she felt it was different and the woman&rsquo;s intuition was right &ndash; </p>
<p>She unlatched the door of his room &ndash; &amp; found him lying on his back on a couch, one hand under his head, his black hair carefully parted &amp; brushed as if a certain determination had dominated the act. He had heard the click of the latch &amp; knew it was she &ndash; but he did not turn his head &ndash; he closed his eyes as if indifferent to her presence.</p>
<p>She knew she had felt the truth &ndash; Here was a difficult task. She had relied upon her great beauty, but . . . . perhaps it would fail her &ndash; she glanced hastily in the mirror over the mantle, threw off her long coat &amp; placed her hat aside &amp; pinned one of the peonies to her bodice. The others she arranged in a tall white vase &amp; stood before them in all the innocence of a vestal virgin pretending to arrange them. &ldquo;I&rsquo;ve brought you something Juan&rdquo; &ndash; she said gently. She glanced slyly at him, but he did not move. She saw tho the color run red over his face &amp; neck as if her voice had thrilled him to life. She knew the power of her voice. She grew encouraged as she thought of it, &amp; spoke again. &ldquo;Juan I&rsquo;ve come to be forgiven.&rdquo; As he did not move she went to him &amp; knelt on the floor beside him. She took his hand in one of hers &amp; purred a gentle voluptuousness in his [being?]. She smoothed back his hair, an act he ever loved, &amp; she softly bit his chin and lobe of his ear. The golden ringlets of her hair swayed across her face &amp; whispered memories to him. Her hand crept close to his body &amp; she felt his heart beat ever a determined beat.</p>
<p>&ldquo;Juan,&rdquo; she whispered &ndash; &ldquo;look upon me just once again &amp; say I am forgiven &amp; I shall go then. </p>
<p>She pressed her face to his &ndash; she lay full length beside him &amp; sought his lips in extacy &amp; delight.</p>
<p>He had felt lifeless. He knew had he trusted himself to open his eyes, his sense would leave him, all his resolve &ndash; for nought &ndash; but now that kiss &ndash; and that was that. An odor &ndash; peonies. He opened his eyes, sat straight upward, &amp; caught her madly in his arms. </p>
<p>God &ndash; how beautiful she was! Both arms were now about his neck, he was mad, with joy, passion. Her eyes opened &amp; he looked into her being, into the debts of her being to find the traces of a soul. She closed them &amp; he knew it was not there. All his life &ndash; his hope, his desire, ambitions he had given for this &ndash; &amp; found it souless. She clung to his lips &amp; sucked them into her own, as if she must have felt his loss. He was mad, wild &amp; happy. One thrust of the dagger <br />
through the peony which lay upon her heart &amp; she lay quite still &ndash; and was forgiven. [LCM 130:575]</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
