
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #26 (Winter 2000/2001)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #26 (Winter 2000/2001)</h1>
<div class="maintext">
<h1>"Birth Control and the Good Old Boys in Congress"</h1>

<p><em>In 1929, Margaret Sanger formed the National Committee on Federal
Legislation for Birth Control (NCFLBC) with the aim of overturning the
Federal Comstock laws. On the books since 1873, the Comstock laws classified
contraceptive information and supplies as obscene material and made it
unlawful to send birth control devices or literature through the mails.
While the NCFLBC also sought endorsements of medical, religious and social
institutions, and ran a sophisticated public relations campaign across
the country, the organization concentrated its efforts on lobbying Congress
to support a birth control bill.</em></p>
<p><em>The first NCFLBC bill, drafted in 1930, proposed to amend sections
211, 245 and 312 of the Federal Penal Code to allow doctors to freely dispense
birth control. From 1930 to 1936 the NCFLBC secured seven Congressmen to
sponsor ten versions of the same bill. However, few in Congress guaranteed
her their vote. While some were preoccupied with financial crises, New
Deal legislation and growing instability overseas, most Congressmen were
either vehemently opposed or were unwilling to confront certain controversy.
In the end seven bills died in Committee, one was tabled without discussion,
one was held up by the Ways and Means Committee on a technicality, and
one made it all the way to the floor of the Senate before being recalled.
Though the NCFLBC's Congressional lobbying efforts proved futile, the bills
did force four hearings on birth control in the Senate and two in the House,
providing Sanger and other prominent birth control proponents with a very
public forum to argue the scientific and social merits of their crusade.</em></p>
<p><em>Sanger later claimed that by the end of 1934 every member of Congress
had been contacted regarding the birth control bill. Yet not surprisingly,
many Congressmen went to great lengths to avoid even being seen with a
birth controller. NCFLBC staffers spent much of their time just trying
to get a face-to-face meeting or settling for a few words exchanged in
the Capitol hallway.</em></p>
<p><em>What follows are excerpts from NCFLBC staff reports of these meetings
with individual Representatives and Senators. Though perhaps a bit more
colorful than the rest, they are representative of the most common responses
NCFLBC staff received from Congressmen. Apart from an interview synopsis,
the reports generally include information on party affiliation, marital
status, family size, residence, religion, committees served on, and number
of times elected. Most reports also contain handwritten notes on past votes,
contacts, press reports and previous lobbying efforts. The excerpts below
provide the date and name of the NCFLBC staff person conducting the interview.
All are drawn from the Margaret Sanger Papers microfilm at the Library
of Congress (LC), and we have provided the reel and frame numbers for each
excerpt. We have not corrected any of the text.</em></p>

<p STYLE="text-align: CENTER"><b>HANDS OFF</b></p>
<p><b>Sen. Ellison D. Smith, SC (Democrat)</b></p>
<p>May 24, 1934: "'We should let it alone. It jars me. It is revolting
to interfere in people's personal affairs.' I explained to him the nature
of the bill and that the present law was the thing that was interfering
in peoples' personal affairs." - Guy Irving Burch (LCM 82:183)</p>
<p><b>Rep. Roland J. Kinzer, PA (Republican)</b></p>
<p>Jan. 21, 1932: "Listened to me with great attention and then took my
name and address and from his manner I almost felt he was about to call
the guard and have me arrested. After a little further discussion, however,
he became less menacing and we had quite an argument as to whether birth
control would decrease the consumption of agricultural products." - Alice
Palache (LCM 82:77)</p>
<p><b>Rep. Charles Finley, KY (Republican)</b></p>
<p>Dec. 9, 1932: "Opposed to bill - 'conscientiously, because we have not
the right to deny the joy of life to millions;' morally and politically
we need 'more people.' Only way to control births is self control. War
- a glorious opportunity for the individuals and a good way to control
population." - Flora B. Estabrook (LCM 79:27)</p>
<p><b>Rep. Oliver Harlan Cross, TX (Democrat)</b></p>
<p>Mar. 25, 1934: Said he did not know much about the bill. Government
should not get mixed up with birth control. Showed him the bill. He said [e]very nigger knew all about birth control. Said he would be against it.
But I think he might be won over." - Guy Irving Burch (LCM 82:322)</p>

<p STYLE="text-align: CENTER"><b>HANDS TIED</b></p>
<p><b>Rep. William M. Citron, CT (Democrat)</b></p>
<p>Apr. 3, 1936: "Took me into his private office, and said: 'You know
this is only a political matter with me. . . I'm a jew and the Catholics
would crucify me if I voted for this bill.'" - Guy Irving Burch (LCM 77:457)</p>
<p align="center"><b>ADVICE AND SUPPORT</b></p>
<p><b>Sen. Robert Marion La Follette, Jr., WI (Progressive)</b></p>
<p>Dec. 5, 1931: "Long conference, fully half hour, found him intelligent
and understanding. As expected he had such a big program this year he was
afraid now that he would be unable to do the things that he has already
undertaken. He does not make a practice of introducing a bill just for
the sake of introducing it. . . I got the impression that he was absolutely
for us . . ."- Margaret Sanger (LCM 83:303)</p>
<p><b>Rep. T. Alan Goldsborough, MD (Democrat)</b></p>
<p>Feb. 3, 1932: "Very much interested but very much disturbed about it.
Realized it touched the very foundation of our economic and spiritual structure.
. . . He was greatly concerned about the immorality of the younger generation
and not convinced that legislation is the right approach. He is however
very much convinced that there are many women to whom the information should
be given, particularly the foreign element of our population." - Alice
Palache (LCM 79:201)</p>
<p><b>Sen. Huey P. Long, LA (Democrat)</b></p>
<p>Feb 23, 1934: "He stated that he would not give us any information as
he would not want to be quoted but that he would assure us that we had
nothing to fear from him. He said our best chance was to do this thing
quietly without a hearing and without a lot of hullabaloo . . . We mentioned
the weakness of the Catholic Church when they agreed to a method of birth
control by advocating a natural method. He asked us what we referred to
and [we] suggested 'safe period.' He said 'there aint no such thing' .
. . There was considerable amusement of getting . . . myself to join SHARE
OUR WEALTH SOCIETY, on which we were well posted and while [Long's] secretary
insisted I become president of the club in Washington, Mr. Long came to
my defense and stated I shouldn't do it because it would only hurt my cause.
He then very seriously said 'we are both crusaders. Your cause is nearer
being won than mine because most people don't worry so much about lives
as they do about property and I have a bigger battle than you.'" - Hazel
Moore (LCM 79:100)</p>

<p STYLE="text-align: CENTER"><b>A WOMAN'S PLACE</b></p>
<p><b>Rep. Andrew J. Montague, VA (Democrat)</b></p>
<p>Jan. 11, 1932: "Mr. Montague listened to my story and then said quite
quietly he did not believe there would be any virtue among women any longer
if such a law was passed. He said that it would tend to put men and women
on the same standard and he also felt that it would increase immorality
by removing the fear of pregnancy." - Alice Palache (LCM 82:669)</p>
<p><b>Rep. Hatton W. Sumners, TX (Democrat)</b></p>
<p>Mar. 9, 1932: "I am not opposed to this legislation. I am a little old
fashioned perhaps, and I have very definite ideas as to a woman's place
in the world. I will not discuss this subject with a woman . . . it embarrasses
me . . . and nothing annoys me more tha[n] to have some blankety blank
woman approach me on this or any other public issue that could be handled
by a man. On the other hand I have the most profound respect and consideration
for the woman in the home . . . mothers and children . . . the welfare
of the young boys and girls." - Col. J. J. Toy (LCM 82:352)</p>
<p><b>Rep. Robert Lincoln Ramsay, WV (Democrat)</b></p>
<p>Jan. 28, 1935: "Had a long talk with him and he agreed with me on a
number of points, but seemed to be greatly concerned about 'interfering
with the conception of life.' He was also concerned about the Anglo-Saxon
birth rate, and 'women out of the home.'" - Guy Irving Burch (LCM 83:233)</p>

<p STYLE="text-align: CENTER"><b>REVELATIONS</b></p>
<p><b>Rep. Thomas Birch, VA (Democrat)</b></p>
<p>Feb. 4, 1931: "This was a splendid interview as Mr. Birch had evidently
never thought of B.C. and certainly not of the bill of last year. . . He
was relieved to know it did not include abortions . . . He feels it all
should be placed in the hands of physicians, hospitals and clinics and
was concerned that those who needed it most would not receive the proper
help. (tenant farmer and negro)" - Hazel Moore (LCM 82:653)</p>
<p><b>Sen. Morris Sheppard, TX (Democrat)</b></p>
<p>May 7, 1934: "A very interesting interview - came off the floor and
we went to a quiet place to talk over the legislation - he agreed that
we were crusaders like he was - and stated he wasn't in favor of bootlegging
in birth control any more than in liquor. He was very much interested in
the fact that Dr. Minnie Maffett of Dallas the family physician for his
nieces was giving information and was a 'bootlegger' - and he agreed very
definitely on the need for clinics in Texas." - Hazel Moore (LCM 82:347)</p>

<p STYLE="text-align: CENTER"><b>RACE SUICIDE</b></p>
<p><b>Sen. William H. Dieterich, IL (Democrat)</b></p>
<p>Apr. 11, 1934: "Rather impossible [for him to support bill] at present
time. 'I'm afraid I'm a little old fashioned on that. I'm not ready to
teach our children to become whores yet.' Muttered something under his
breath. 'We don't get along very well on that subject.'"- Guy Irving Burch
</p>
<p>Second interview, Apr. 20, 1936: "He said that intelligent people have
been hoodwinked and misled about the bill, even religious people and organizations
- that birth control was unChristian and ungodly. It would really open
up the country to abortion and abortionists . . . every healthy couple
should have six children, and [he] pointed out that at the present rate
in a few generations the country would be overrun with the Negro race which
multiplies so rapidly." - Helen Harper (LCM 78:260)</p>
<p><b>Sen. Peter Norbeck, SD (Republican)</b></p>
<p>May 28, 1934: "He stated 'I might vote for that but I think your theory
is wrong. If we don't watch out Japan will take the country - our rich
people aren't having children. Your bill is only to legalize what is already
in practice - therefore not so important to change law.'" - Hazel Moore (LCM
82:203)</p>
<p><b>Rep. Arthur W. Mitchell, IL (Democrat)</b></p>
<p>Mar. 30, 1935?: "He stated he had discussed the subject with other Congressmen
who wondered if the practices of birth control by the White Race would
eliminate them and the fact that birth control was not practiced by the
Colored Race would make them supreme. . . . He mentioned that colored people
were very much more devoted to their children then white people and wanted
larger families, and he stated he did not believe there was a high maternity
death rate either. Throughout his conversation, he showed his confusion
between birth control and abortion." - Hazel Moore (LCM 78:290)</p>

<p STYLE="text-align: CENTER"><b>DEFERENCE TO GOD</b></p>
<p><b>Rep. Nat Patton, TX (Democrat)</b></p>
<p>Apr. 21, 1936: "He read the bill and then made an explosion, damning
any one, doctor or otherwise, who would go against God's law by teaching
how to prevent birth. I told him birth control was not abortion, but it
did not seem to have any noticeable effect." - Guy Irving Burch (LCM 82:341)
<p><b>Rep. Edward E. Eslick, TN (Democrat)</b></p>
<p>Apr. 14, 1932: "Mr. Eslick was very busy, and when I mentioned our bill
he said: 'Please don't take my time; I am opposed to it and will vote against
it.' I recalled to his mind that yesterday a Representative mentioned before
the Ways and Means Committee the eight millions of unemployed fathers who
look across the breakfast table and wonder where they would get the next
breakfast for their wives and children. I told him that eight millions
of mothers were also concerned and fearful there might be more mouths to
feed during the coming year. His answer was: 'Jesus said: Suffer little
children to come unto me.' I replied by telling him of the high infant
mortality rate in the United States . . . He again stated: 'Jesus said:
Suffer little children to come unto me, and he did not say whether they
should be living or dead.'" - Hazel Moore (LCM 82:272)</p>

<p STYLE="text-align: CENTER"><b>NO INTEREST</b></p>
<p><b>Sen. Hugo L. Black, AL (Democrat)</b></p>
<p>Jan. 4, 1933: "Had interview in the hall. Not particularly interested
in the legislation. Said he would vote on it if it comes before the full
committee but would not commit himself one way or the other. 'After all,'
said Senator Black, 'I have all the information I need and so do you.'
I replied, as he hurried off, that his people in the cotton mills and tenant
farms needed this information desperately - and he replied 'they have it
too.' He was cordial and pleasant but not at all interested." - Hazel Moore (LCM
77:97)</p>
<p><b>Rep. Effie Wingo, AR (Democrat)</b></p>
<p>Feb. 11, 1932: "Entirely too busy to consider the subject. 'When war
is in the air we cannot consider something that cannot come about for years.'"
- Hazel Moore (LCM 77:194)</p>

<p STYLE="text-align: CENTER"><b>BIRTH CONTROL = ABORTION</b></p>
<p><b>Sen. Henry F. Ashurst, AZ (Democrat)</b></p>
<p>Apr. 27, 1932: "I asked Senator Ashurst pointedly if he was opposed
to a physician prescribing effective harmless contraceptive methods in
a case where the indication was that a pregnancy would result in death.
He replied: 'Certainly not. I am not inhuman but I have not considered
birth control from that standpoint. I have considered it only from the
conditions that are existing throughout the country today where every boy
and girl or anybody can buy what they want and there seems to be no restriction.'"
- Col. J. J. Toy</p>
<p>Second interview, Feb. 8, 1933: "Ashurst most discouraging - there is
no doubt of his opposition - He feels B.C. is murder and that life is taken."
- Hazel Moore (LCM 77:135)</p>
<p><b>Rep. Harry A. Estep, PA (Republican)</b></p>
<p>Jan 20, 1932: "I had a long argument with Mr. Estep who is a comparatively
young man. I found out very soon that he confused contraception with abortion
and tried to straighten him out on it. . . . He considered the subject
only from the point of view of its possible abuse both by young people
and by the 'scallywags of the medical profession.' Was convinced that poor
people who need it could not be taught to use it properly; with his mind
still confused on the subject of abortion." - Alice Palache (LCM 82:52)</p>

<p STYLE="text-align: CENTER"><b>BIRTH CONTROL PROFITEERS</b></p>
<p><b>Rep. Charles L. Gifford, MA (Republican)</b></p>
<p>Jan. 16, 1932: He was skeptical about Mrs. Sanger's and my motives in
working for the cause . . . had to be assured we were not doing it just
for the sake of having a job or possibly getting one thru it in the future."
- Alice Palache (LCM 79:383)</p>
<p><b>Rep. Joe Henry Eagle, TX (Democrat)</b></p>
<p>Mar. 25, 1934: "Said he was against the bill. Said we earned ou[r] living
by birth control that was why we were for it. When I called his bluff he
said he did not want to argue. . . when near the door he said he practiced
birth control as every sensible person did." - Guy Irving Burch (LCM 82:325)</p>
<p><b>Rep. William V. Gregory, KY (Democrat)</b></p>
<p>Jan. 22, 1934: "Not encouraging. Said women could get all the information
they wanted now. Thought sending contraceptives through the mails was a
'racket.' I told him differently but he kept saying it was a 'racket.'"
- Guy Irving Burch (LCM 79:30).</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
