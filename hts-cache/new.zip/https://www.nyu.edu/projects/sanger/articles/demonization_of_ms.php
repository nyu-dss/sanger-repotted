
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #16 (Fall 1997)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #16 (Fall 1997)</h1>
<div class="maintext">
<h1>"The Demonization of Margaret Sanger"</h1>

<p>On May 5, 1997, the <em>Wall Street Journal</em> ran an editorial piece titled "The Repackaging of
Margaret Sanger," by Steven Mosher, vice president for international affairs of Human Life
International, an anti-abortion group based in Front Royal, Virginia.   Mosher objected to a
Planned Parenthood award named for Margaret Sanger that was given to "The Dying Rooms," a
BBC documentary on China's state-run orphanages.  While Mosher praised the documentary (in
which he appeared), he was "personally offended" that the award bore the name Margaret
Sanger, someone he claimed had "contempt for the Asiatic races." He went on to attack Sanger
for what he called her  "bigotry," "racist views," and her associations with eugenicists.  In doing
so, he misappropriated several Sanger quotations, highlighted seemingly inflammatory Sanger
comments without providing any context, and indicted her for the words and deeds of several
prominent eugenicists who supported birth control.</p>

<p>The Mosher piece is typical of many anti-Sanger letters-to-the-editor written by
representatives of anti-choice groups that have appeared over the past few years whenever
Sanger is mentioned in the context of an article on Planned Parenthood or contraception. In fact,
the Mosher piece and many others like it borrow freely from anti-Sanger materials that have been
in circulation for at least twenty years, including an offensive little pamphlet entitled
<em> Margaret
Sanger: Father of Modern Society</em> written by Elasah Drogin.  The pamphlet,
written in 1979, "exposes" Sanger as a eugenicist, racist and war-monger, but is most intent on
proving her a sexual maniac with insatiable desires.  It displays a portrait of Sanger on its cover,
her head rising up above a modern metropolis, war planes swirling above her and a Nazi prison
camp in the foreground.  While this is one of the more absurd examples of anti-Sanger material
in circulation, the Drogin pamphlet and most other attacks from anti-choice groups rely on the
same small group of Sanger documents over and over again, including letters she wrote in the
late 1930s to birth control movement contributors and black leaders expressing her concern that
blacks living in the South would view her "Negro Project" as an attempt to limit their race.  For
instance she wrote to philanthropist Clarence Gamble in 1939:

<p>
The ministers work is also important and also he should be trained, perhaps by the [Birth
Control] Federation [of America] as to our ideals and the goal that we hope to reach.  We
do not want word to go out that we want to exterminate the Negro population and the
minister is the man who can straighten out that idea if it ever occurs to any of their more
rebellious members. (MS to Clarence Gamble, <em>MSM</em> S17:574).
</p>

<p>Anti-choice groups attempting to discredit Sanger frequently extract the line "we don't want
word to get out that we want to exterminate the Negro population" without offering context or
intelligent explanation.</p>


<p>Such written attacks on Sanger often fail to divulge the author's identity and real agenda.  In
the case of the <em> Wall Street Journal</em> piece readers are not told that  Mosher is part of an extremely
conservative Roman Catholic organization that not only opposes abortion and the work of
PPFA, but strongly opposes contraception as well.  Human Life International accepts only "natural"
family planning, the "one [<em>method</em>] worthy of the dignity of man," according to an article on the
organization's web page (see <a href="http://www.hli.org">www.hli.org</a>).  It is clear from this Internet site that HLI's goal is to
undermine the PPFA and international family planning, by attacking Sanger, who it portrays as
the ideological foundation of the pro-choice and family planning movements.</p>

<p>The Margaret Sanger Papers Project has chosen not to respond to most such attacks against
Sanger, even when they misuse or ignore the documentary record, as it is nearly impossible to
offer point-by-point corrections and clarifications to the countless misquotations and
misrepresentations of the historical record that appear in newspaper articles around the 
country.</p>

<p>In this instance, MSPP editor and director Esther Katz thought it necessary to respond to the
<em>Wall Street Journal</em> because of the prestige and large circulation of the paper.  She based her
response on a close reading of the documents in question, offering more complete extractions of
Sanger's writings.  "The textual evidence reveals," she wrote, "that Sanger did not rationalize her
support for birth control on racist grounds, that she never advocated genocidal policies aimed at
racial, ethnic or religious groups, and that she, in fact, believed access to birth control would
benefit, not eliminate minority populations."</p>

<p>Alexander Sanger, the president of Planned Parenthood of New York City, Sanger's
grandson and member of the MSPP advisory board, also sent a reply to the <em>Journal</em>, emphasizing
Sanger's commitment to helping all women "regardless of race or nationality," and highlighting
her egalitarian language and phrases such as "Let every child be a wanted child."</p>

<p>The frequent misuse of historical resources on Sanger is further evidence for the need to
provide a complete, accurate and accessible edition of her papers.  There is certainly a credible,
well-researched body of scholarship that argues persuasively that Sanger naively or carelessly
accepted too much of the racist and nativist rhetoric that characterized early twentieth century
eugenics.  These writings are the product of good faith efforts that rely on the proper use of
historical resources and a comprehensive understanding of Sanger's life.  They further a valuable
ongoing discussion about a highly controversial figure.  Sanger's writings should be the subject
of intelligent debate rather than an opportunity for preconceived distortion.</p>

<p>As Dr. Katz noted in her published response, "I certainly do not challenge Mr. Mosher's
right to hold any view he wants on the issue of abortion or population control, but as a historian I
take issue with his gross misuse of historical sources to support those views."</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
