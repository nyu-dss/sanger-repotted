
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #25 (Fall 2000)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #25 (Fall 2000)</h1>
<div class="maintext">
<h1>"Sanger on Trial: The Brownsville Clinic Testimony"</h1>

<p>Though there was no smoking gun or glove that would not fit, no surprise
witnesses or unexpected testimony, the trials of Margaret Sanger, her sister,
Ethel Byrne, and a translator, Fania Mindell were dramatic public events
quelled only by the efficiency – at least by today’s standards – of the
court system, which assured prompt verdicts once the trials were under
way.  Arrested on October 26, 1916 for operating a contraceptive clinic
in the Brownsville section of Brooklyn in defiance of Section 1142 of the
New York State Penal Code, the three defendants openly defied the law and
publicly defended their actions as humanitarian and integral to the health
of women and families.  Their attorney, Jonah Goldstein, set his sights
on a later constitutional battle, filing one motion after another. 
He had little reasons to challenge the evidence or impeach witnesses. 
With guilty verdicts preordained, Goldstein simply tried to keep his clients
out of prison.</p>
<p>The Brownsville Clinic, the first clinic to operate in the U.S., served
about 450 women before the police shut it down. Sanger reopened the clinic
in November of 1916 only to be rearrested and saddled with the additional
charge of creating a public nuisance. After numerous delays and failed
attempts by the defense to obtain a jury trial, Ethel Byrne, who served
as the clinic’s nurse, came to trial first on January 4, 1917.  The
judges severely limited Goldstein’s summation and opportunities to promote
the benefits of birth control.  They found Byrne guilty and sentenced
her to thirty days in the workhouse.  She immediately went on a hunger
strike, a tactic that drew scores of reporters to the story. She endured
five days of fasting before being force-fed through a tube by prison staff.
She was released on February 2 following Sanger’s negotiations with New
York State governor Charles Whitman, who granted a pardon.</p>
<p>Sanger’s trial began on January 29 before a courtroom of socialites
and about fifty Brownsville women who had visited the clinic.  Presiding
justice John J. Freschi, and associate justices Moses Herrman and George
G. O’Keefe of the Court of Special Sessions tried to avoid making Sanger
a martyr in the wake of Byrne’s hunger strike. On February 2 the court
offered to grant a suspended sentence if  Sanger would promise to
abide by the law.  She replied on the stand: "With me it is not a
question of personal imprisonment or personal disadvantage.  I am
today and have always been more concerned with changing the law and the
sweeping away of the law, regardless of what I have to undergo to have
it done." Presiding justice Freschi pressed her for a final answer on whether
she would accept their clemency; Sanger replied: "I cannot respect the
law as it exists today. " She was found guilty, and on Feb. 5, against
the wishes of her attorney, chose a thirty-day prison sentence over a $5000
fine. Fania Mindell was also convicted by the Court of Special Sessions
on February 2, for selling an indecent book (WHAT EVERY GIRL SHOULD KNOW)
and fined $50. On appeal, Sanger’s conviction was affirmed by the New York
Appellate Division of the Supreme Court on July 31.  However, the
liberal opinion of the court had positive ramifications – it offered legal
justification for the operation of a clinic under medical auspices. 
Sanger petitioned the U.S. Supreme Court for Writ of Error in January 1918,
but her case was dismissed on November 17, 1919.  (<em>Autobiography</em>,
229-237)</p>
<p>A seminal event in the birth control movement, the Brownsville Clinic
(and the ensuing arrests, trials and imprisonments) has been recounted
in every biographical treatment of Sanger and in most studies of the birth
control movement. Yet we still have only sketchy details of  how the
clinic operated and lack documentation to confirm the various accounts
of the police infiltration and arrests. There are no surviving letters
or diary entries by Sanger about the clinic until several months later.
And only a few photos of the clinic survive. To document the clinic in
the first volume of The Selected Papers of Margaret Sanger, due to be published
early next year, we include a compilation of newspaper interviews, reports
and articles by Sanger written many months later, as well as her prison
diary and letters which discuss aspects of the Brownsville trials. One
source we relied on heavily in completing annotation for the first volume
is a partial transcript of Sanger’s trial before the Court of Special Sessions. 
Since it does not include Sanger’s testimony, we did not include the transcript
in the book edition.  Nevertheless, the transcript is valuable for
providing police and other witness testimony on the clinic arrests.</p>
<p>What follows are excerpts from this transcript of Sanger’s trial that
describe the clinic, arrests and evidence seized by the police.  Apart
from offering details about the clinic, the testimony also shows how the
police – or at least the arresting officer – tried to escalate the charges
against Sanger, most likely in an attempt to counter the rising tide of
public support for her, by claiming that Sanger turned to the crowd outside
the clinic and declared that she wanted to obliterate the race, a reference
presumably to Jews in the Brownsville neighborhood.</p>
<p>Deleted portions of the transcript are indicated by [...].  For
a complete version see New York v Sanger, 222 NY 192, 118 N.E. 637 (Court
of Appeals 1917),  National Archives, Records of the U.S. Supreme
Court, RG 267 (<em>MSM</em> C15: 298).</p>

<p>COURT OF SPECIAL SESSIONS OF THE CITY OF NEW YORK
<br />PEOPLE OF THE STATE OF NEW YORK, Plaintiff,</p>
<p>against
<br />MARGARET H. SANGER, Defendant</p>
<p>Brooklyn, N.Y., January 29, 1917</p>
<p>Before &ndash; Hons. JOHN J. FRESCHI, Justice Presiding; GEORGE J. O’KEEFE,
MOSES HERRMAN, Associate Justices.</p>
<p> Appearances:</p>
<p>EDWARD W. COOPER, Esq., Assistant District Attorney, for the People.
<br />JONAH J. GOLDSTEIN, Esq., for the Defendant.
<br />[...]</p>
<p>MARGARET WHITEHURST, police officer, attached to Special Squad No. 1,
called as a witness for the People, being duly sworn, testified as follows:
[...]</p>
<p> DIRECT EXAMINATION BY MR. COOPER.</p>
<p>Q. What is your business?   A. I am assigned to detective
work in Special Squad No. 1.</p>
<p>Q. On the 26th day of October, 1916, did you go to the premises No.
46 Amboy Street, in the County of Kings?   A. I did.</p>
<p>Q. Now, just describe these premises, briefly.   A. There
are two rooms; one front and one rear room; one a little bit smaller than
the other &ndash; the back one is a little smaller than the front room &ndash; both
covered with brown oilcloth or linoleum; the windows had cheese cloth or
scrim on the windows &ndash; looked more like cheese cloth &ndash;[...]</p>
<p>Q. Did you see the defendant, Margaret Sanger, there on that occasion?  
A. I did.</p>
<p>Q. Where did you see her?   A. Seated in the back room.</p>
<p>Q. Where were you at the time?   A. Just entering the back
room. [...]</p>
<p>Q. Was anybody else with the defendant, Margaret Sanger, in the back
room?   A. There was.</p>
<p>Q. Who?   A. There were three women seated opposite her.</p>
<p>Q. Tell the Court what you saw her do.   A. The defendant
had a box of pills named Aseptikon Vaginal Suppositories. They were half
open and the silver leaf wrapper was unwrapped on one of them. There were
also two kinds of pills; one boric acid and quinine, and one carbozene
tablets, supposed to be the Berlin method of treatment.</p>
<p>MR. GOLDSTEIN: I move to strike that out as a characterization.</p>
<p>THE COURT: Motion granted. [...]</p>
<p>Q. What else took place there on the 26th of October, 1916?  
A. I then told Officer &ndash; Detectives Mooney and Boylan that we would make
a summary arrest in this case, as Mrs. Sanger was violating the law &ndash;</p>
<p>MR. GOLDSTEIN: I ask that that be stricken out.</p>
<p>THE COURT: Motion granted.</p>
<p>Q. Did you have any conversation with Mrs. Sanger at that time?  
A. I did.</p>
<p>Q. What did you say to her and what did she say to you?  
A. I told her she was placed under arrest. She said she intended to break
the law, as it was unconstitutional.</p>
<p>BY JUDGE FRESCHI.</p>
<p>Q. She intended to break the law because it was unconstitutional?  
A. Because it was unconstitutional.</p>
<p>Q. Did she say who had made that decision?   A. She didn’t
say, Judge, no, sir.</p>
<p>BY MR. COOPER.</p>
<p>Q. Did any other conversation take place at that time?   A.
Yes, sir. Walking out to the outer room and addressing herself to Miss
Mandel, she said: "This dirty, slimy thing here in the form of a woman
to make this arrest."</p>
<p>Q. Did you arrest her then?   A. She had already been arrested.
[...]</p>
<p>Q. Did you see the defendant have anything else in her hand except this
box of pills?   A. I did later on.</p>
<p>Q. When?   A. Immediately after she laid the pills down she
took up two rubber articles.</p>
<p>Q. What kind of rubber articles?   A. One the same as I had
purchased there&ndash;</p>
<p>Q. Don’t say the same as you had purchased there.   A. One
for the female sex and one for the male sex.</p>
<p>Q. She took up a rubber article. Did she take it out of a box?  
A. She had them in her hand when I looked around and saw her.</p>
<p>Q. Had you seen articles similar to them before?   A. I purchased
two.</p>
<p>Q. Where?   A. Right at the same address. [...]</p>
<p>Q. Now, do you remember any other conversation you had with the defendant?  
A. Then addressing &ndash; there was quite a number of people out in front,
outside the door, and addressing me about the people on the outside, she
said: "Could you blame me to try to obliterate that race," pointing to
this crowd that was outside the door. [...]</p>
<p>CROSS-EXAMINATION BY MR. GOLDSTEIN.</p>
<p>Q. Did you testify in this case in the magistrate’s Court?  A.
I did.</p>
<p>Q. Do you remember your testimony?   A. I do.</p>
<p>Q. Did you use the words or testify in the Magistrate’s Court that Mrs.
Sanger said anything to you about not wanting to be blamed in her desire
to obliterate that race?   A. No, sir; I didn’t. [...]</p>
<p>Q. When did you first remember it after the Magistrate’s Court?  
A. Immediately after I had testified. [...]</p>
<p>Q. You think you have told us everything that is important now?  
A. Except going up in the patrol wagon &ndash; the defendants didn’t want to
walk or to ride in a car to the station house, she wanted the patrol wagon
brought, to go up in the patrol wagon&ndash;</p>
<p>BY JUSTICE FRESCHI.</p>
<p>Q. Did you accommodate her? I mean did you get the patrol wagon?  
A. We did. Then she wanted to stop at the steps of the premises, No. 46
Amboy Street, and lecture to the people around there, and the officers
in the case said: "Come along." She stopped on the step of the patrol wagon
and said to the audience there: "This is what you term free America." And
then she has got in the patrol she said she was sorry there was any Irish
blood in her veins. Somebody asked her why. She said because most of her
countrymen were on the police force. [...]</p>
<p>Sergeant DAVID J. BARRY, of the 11th Inspection District, called as
a witness for the People, being sworn, testified as follows: [...]</p>
<p>DIRECT EXAMINATION BY MR. COOPER.</p>
<p>Q. Are these books you found there, "What Every Girl Should Know"? 
A. "What Every Girl Should Know" and "What Every Mother Should Know."</p>
<p>Q. How many copies?   A. Two in English, I believe.</p>
<p>Q. How many in Jewish?   A. About twenty.  We found over
four hundred of these circulars (indicating) "Can you afford to have a
large family?  Do you want any more children?  If not, why do
you have them?  Don’t kill.  Don’t take life, but prevent. 
Safe, harmless information can be obtained and trained nurses at 46 Amboy
Street."</p>
<p>JUSTICE FRESCHI: You are reading from the circular?</p>
<p>THE WITNESS: I have it by heart. "Tell your neighbors.  All mothers
welcome.  Registration fee, ten cents, entitles you to the information."</p>
<p>Q. How many registrations did you find there?   A. Over four
hundred. [...]</p>
<p>Q. Did you have any conversation with the defendant with regard to any
of these articles?   A. Well, I had on the 14th of November,
if that is admissible.
<br />Q. The 14th of November you had a conversation?</p>
<p>JUSTICE FRESCHI: About these articles that you seized?</p>
<p>THE WITNESS: Yes, sir.</p>
<p>Q. Articles similar to these pessaries?   A. She mentioned
one pessary of the Mizpah make.</p>
<p>Q. What conversation did you have with her and what did she say?</p>
<p>MR. GOLDSTEIN: I object to that as not within the information, and incompetent,
irrelevant and immaterial.</p>
<p>THE COURT: Objection overruled.  It relates, as we understand it,
to the articles now in evidence. [...]</p>
<p>A. On the 14th &ndash; To start with, I asked her what brought her back to
No. 46 Amboy Street, and she said she came here to speak&ndash;</p>
<p>Q. Get right down to these articles.   A. She said to speak
of hygiene and cleanliness, in no way would she give information or treat
for abortions.  She said the best method of birth control &ndash; No, there
were two methods of birth control, one for the man and one for the woman,
the man should take care of the woman, with a rubber covering a week following
menstruation, and after that week the woman &ndash; there were many things that
could be done by the woman herself, and she said there  &ndash; the best
method of birth control was the covering for the womb.  "There are
many womb supporters on the market, costing from seventy-five cents to
ten dollars, but I would recommend a pessary called the Mizpah as strongest
and cleanest, which costs for one dollar and a half to two dollars in any
drug store."  She said: "A doctor or midwife may fit this for you,
or if you bring it to me, why, I shall adjust it myself."  This is
what she said her lecture was that she would give. [...]</p>
<p>Officer BERNARD M. BOYLAN, of the 11th Inspection District, called as
a witness for the People, being sworn, testified as follows:</p>
<p>DIRECT EXAMINATION BY MR. COOPER.  [...]</p>
<p>Q. What did you see Mrs. Sanger do?   A. I saw the defendant,
Mrs. Sanger, exhibiting to three women in the rear room at premises No.
46 Amboy Street articles, rubber articles for men and women. I entered
the room with Mrs. Whitehurst and Sergeant Barry, [...] Mrs. Whitehurst
stated that she had a warrant for her arrest.  Sergeant Barry said
to the three women, in the presence of the defendant, what they were doing
there; and the defendant, Mrs. Sanger, said: "Don’t speak to those women."
Sergeant Barry says: "Yes I will speak to them." So they walked out to
the front office or the front room of the premises, and in the presence
of the defendant Sergeant Barry question the three women as to their names
where they lived, and they gave the names and addresses, but they wouldn’t
give any information.  The one in the middle, the woman in the center
did give information.  [...] And the woman in the center said she
came here to have no more babies, that by coming here you could get enough
information off Mrs. Sanger for ten cents that if she went to a doctor
she would have to pay a dollar for, and that she had four, five and six
babies at home and she didn’t want to have any more.  I searched the
premises, and up against the wall inside the closet I found a piece of
paper with a two dollar bill on it, and I asked Mrs. Sanger who owned the
money, and she said, "A woman spy gave it to me the other day," or some
words to that effect.  I said, "Do you own it?"  She said, "Yes,
I own this and everything in the place."  That was all. [...]</p>
<p>CROSS-EXAMINATION BY MR. GOLDSTEIN.</p>
<p>Q. Did you hear Mrs. Sanger say about wanting to obliterate that race? 
A. No, sir. [...]</p>
<p>Brooklyn, N.Y. February 2, 1917</p>
<p>Appearances:</p>
<p>THOMAS P. PETERS, Esq., EDWARD W. COOPER, Esq., Assistant District Attorneys,
for the People.
<br />JONAH J. GOLDSTEIN, Esq., for the Defendant.
<br />EDWARD M. CLEARY, of No. 140 West 103rd Street, Borough of Manhattan,
called as a witness for the People, being sworn, testified as follows:</p>
<p>DIRECT EXAMINATION BY MR. PETERS. [...]</p>
<p>Q. What is your business, Mr. Cleary?   A. Newspaper man [...]</p>
<p>Q. And by what newspaper were you employed?   A. Brooklyn
Eagle. [...]</p>
<p>BY JUSTICE FRESCHI.</p>
<p>Q. Did Mrs. Sanger show you a two dollar bill?   A. Either
Mrs. Sanger or Miss Mindel.  I think it was Mrs. Sanger.</p>
<p>Q. They were both there at the time?   A. Yes, sir.</p>
<p>Q. Where was the money?   A. It was pasted on a piece of paper.
[...]</p>
<p>Q. Now, what did she say about it?   A. She read it out to
me.</p>
<p>BY MR. PETERS.</p>
<p>Q. What did she read?   A. "A filthy greenback given by Mrs.
B&ndash;, a suspecting Kings County spy, October 20th, 1916." […]</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
