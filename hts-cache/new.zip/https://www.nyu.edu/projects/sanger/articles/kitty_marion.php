
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #37 (Fall 2004)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #37 (Fall 2004)</h1>
<div class="maintext">
<h1>"Birth Contol on the Streets of New York"</h1>

<p>For many New Yorkers in the 1920s, Kitty Marion &ndash; not Margaret Sanger &ndash; was the face of birth control. Nearly every day for thirteen years she stationed herself on midtown street corners and held up copies of the <em>Birth Control Review</em> for passersby, introducing quizzical men and women to this new social protest movement and, in many cases, the very concept of fertility control. </p>
<p>&ldquo;She became,&rdquo; wrote the <em>New Yorker</em>, &ldquo;as familiar a figure to you as your favorite traffic cop.&rdquo; Usually she stood in front of Macy&rsquo;s in Herald Square, or waited for exiting theater-goers on Seventh Avenue and 42 nd Street, in the heart of Times Square, where she took in, in her words, &ldquo;the most fascinating, the most comic, the most tragic, living, breathing movie in the world.&rdquo; She also hawked the <em>Review</em> in Grand Central Station, in front of the World Building on Park Row, in the summertime on the boardwalk at Coney Island, and on many other busy sidewalks of Manhattan. She made herself conspicuous, calling out &ldquo;<em>Birth Control Review</em>, 20 cents a copy,&rdquo; in her acquired British accent, loud enough to be heard above the grinding city sounds. Rain or shine, Sundays or holidays &ndash; and for about $20 a week pay &ndash; Kitty Marion flew the movement&rsquo;s flag. (Jared L. Manley, &ldquo;Crusader,&rdquo; <em>The New Yorker </em>[July 4, 1936], 22; &ldquo;The Birth Control Review on Broadway,&rdquo; <em>Birth Control Review </em>[Sept. 1918], 7; &ldquo;Report on the Birth Control Review, 1924" [LCM 20:839].) </p>
<p>Marion lived several lives in a lifetime dedicated to women&rsquo;s equality. Born Katherina Maria Schafer in 1871 in Germany, she moved to England at the age of fifteen to escape an abusive father and pursue an entertainment career in the English music halls. She changed her name to the more marquee-friendly Kitty Marion and found some success in pantomimes and musicals. After she joined the Women&rsquo;s Social and Political Union in 1908, her work with the campaign for women&rsquo;s suffrage quickly eclipsed her acting career. Working with Emmeline Pankhurst in the militant wing of the English suffrage movement, Marion gained notoriety for her violent, confrontational tactics: she threw stones through a postoffice window in Newcastle; she helped set fire to a grandstand at the Hurst Park racecourse near London and participated in house burnings in Liverpool and Manchester; she broke windows and set off fire alarms on several other occasions. Over a span of five years, she was arrested seven times. During one prison stay she set her cell on fire by burning a Bible. Joining other suffragettes in prison hunger strikes, Marion was forcibly fed, by her count, a remarkable 232 times. Soon after the outbreak of war in 1914, Marion was deported, unwanted in Britain both for her militancy and her German ancestry. She came to the United States to aid in America&rsquo;s suffrage cause. (<em>New York Times</em>, October 10, 1944; content note for the papers of Kitty Marion, The Women&rsquo;s Library, London.) </p>
<p>Living in New York in 1916, Kitty Marion closely followed news of Sanger&rsquo;s 1916 arrest for opening a birth control clinic in the Brownsville section of Brooklyn. She later wrote, &ldquo;... I realized more and more that here was the most fundamental plank, even more important than Woman&rsquo;s Suffrage, in the abolition and prevention of future poverty, over-crowding, un-employment, war, and all the unspeakable misery they bring in their wake.&rdquo; When Marion called Sanger&rsquo;s office to get tickets to Sanger&rsquo;s Carnegie Hall rally in January 1917, one of the birth control workers recognized her name and asked if she would be willing to help the cause. She promptly joined-up with the small group of activists in the initial stages of planning the<em> Birth Control Review </em>and was impressed immediately by Sanger: &ldquo;Margaret Sanger with her quiet, forceful, determined way of presenting her argument won my heart at once.&rdquo; Having had years of experience selling <em>Votes for Women </em>and other suffrage publications in England, Marion naturally took to hawking the birth control movement&rsquo;s chief propaganda tool. (Kitty Marion&rsquo;s Autobiography [unpublished], Alice Park Papers, Huntington Library, 253-5.) </p>
<p>Sanger described Kitty as &ldquo;strong, stoutish, tow-headed, her blue eyes bright and keen.&rdquo; &ldquo;Many people still think I must be Kitty Marion,&rdquo; Sanger wrote in her autobiography in 1938. &ldquo;Everywhere they say to me, &lsquo;I saw you twenty years ago outside the Metropolitan Opera House. You&rsquo;ve changed so I wouldn&rsquo;t know you.&rdquo; Sanger admitted that street selling was &ldquo;torture&rdquo; for her. She tried it a few times to get a sense of what Kitty Marion and the few others who did it were up against, but she never lasted long, and remained in awe of Marion&rsquo;s ability to withstand the side effects of the trade: rudeness, insults, fatigue, bad weather and regular encounters with the police. (MS, <em>Autobiography</em>, 257.) </p>
<p>Kitty Marion was arrested nine times for her birth control activism, hauled off to jail in 1918 for thirty days, once attacked &ldquo;vigorously&rdquo; with an umbrella, spit at, egged, subjected to countless people &ldquo;crossing themselves,&rdquo; forced to endure having the papers knocked out of her hands over and over again, called about every name imaginable, and told she ought to be &ldquo;shot,&rdquo; and &ldquo;hanged,&rdquo; among other punishments less dignified. A birth control organizer from Detroit wrote to Sanger in 1923, following a trip to New York and a chance meeting with Marion in Grand Central Station: &ldquo;How you ever inspired a girl to do that work alone in such a conspicuous place, the target for thousands of eyes with all kinds of hostile and sneering thoughts plainly showing,&ndash; is a mystery to me, I certainly was astounded when she told me that there was no one in the back ground &lsquo;covering&rsquo; her. I have been shot, stabbed, wrecked, run over, thro the war and etc. but I&rsquo;ll take my hat off to that girl for her bravery.&rdquo; (Kitty Marion&rsquo;s Autobiography [unpublished] , Alice Park Papers, Huntington Library, 260; Marion, &ldquo;Ye That Pass By,&rdquo; <em>Birth Control Review </em>[Feb. 1923], 45; Eric Widdas to MS, Oct. 18, 1923 [<em>MSM</em> C2:827].) </p>
<p>Through it all Marion remained positive and good-humored. She called all the insults and attacks nothing more than &ldquo;water on a duck&rsquo;s back,&rdquo; and said she was &ldquo;more than compensated by wonderful compliments on my courage and perseverance.&rdquo; In one of her many articles in the <em>Review</em>, she wrote about her stints on Coney Island: &ldquo;though some people give me scornful glances and remarks and &lsquo;look daggers,&rsquo; many give encouraging smiles and nods and call out &lsquo;that&rsquo;s the stuff,&rsquo; &lsquo;that&rsquo;s the best on earth,&rsquo; &lsquo;That&rsquo;s what we need,&rsquo; &lsquo;Birth Control, I should say so, look at &lsquo;em,&rsquo; &lsquo;You&rsquo;ve come to the right place,&rsquo; &lsquo;Fine work, keep it up,&rsquo; and so forth.&rdquo; Even stuck inside the Tombs, lower Manhattan&rsquo;s notorious house of detention, Kitty kept up her spirits by holding meetings on birth control. Jail mate and fellow Sanger worker Agnes Smedley remembered that &ldquo;Kitty came clattering down the stone corridors every morning with her scrub pail in hand. &lsquo;Three cheers for birth control,&rsquo; she greeted the prisoners and matrons. And &lsquo;three cheers for birth control,&rsquo; the prisoners answered back.&rdquo; (Marion, &ldquo;Ye That Pass By,&rdquo; <em>Birth Control Review </em>[Feb. 1923], 45; Marion, &ldquo;Coney Island,&rdquo;<em> Birth Control Review </em>[Oct. 1924], 291; Janice and Stephen MacKinnon, <em>Agnes Smedley </em>[Berkeley, 1988], 48-9.) </p>
<p>The <em>Review </em>did not contain instruction on birth control methods, nor was Marion qualified to dispense practical advice on the street, but she did refer hundreds of women to the Birth Control Clinical Research Bureau. By some estimates, in the mid-1920s 15% or more of the clinic&rsquo;s patients came via &ldquo;the lady on the street.&rdquo; &ldquo;Street selling of the Birth Control Review,&rdquo; stated a League summary report, &ldquo;is our only permanent piece of popular educational work, and ... it has proved itself so far the most fruitful single piece of publicity the League has undertaken.&rdquo; Marion was a patient listener for many women who needed to talk about their states of perpetual pregnancy and problems at home. She would debate anyone who confronted her, often drawing a crowd and thereby educating strangers and boosting sales. </p>
<p>Who did she sell to? As Sanger wrote, &ldquo;the majority bought with the utmost seriousness in the hope that it might solve their personal problems&rdquo;; they included &ldquo;radicals, the curious, girls about to be married, mothers, fathers, social workers, ministers, physicians, reformers, revolutionaries, foreigners . . . some looked and looked and then strolled on. Others walked by only to return with the money ready, hastily stuff the magazine in their pockets, and move away, trying to seem unconcerned.&rdquo; Quite a few who took notice of Marion misread the <em>Review </em>title as &ldquo;British Control&rdquo; and objected to it. &ldquo;We don&rsquo;t want no British Control here!,&rdquo; one of them said. (MS, <em>Autobiography</em>, 257-8; Mary Sumner Boyd, &ldquo;Report on Birth Control Review for 1928,&rdquo; 1927 [MSM S62:785]; Kitty Marion&rsquo;s Autobiography [unpublished], Alice Park Papers, Huntington Library, 296, 304.) </p>
<p>Not everyone in the movement appreciated Kitty Marion&rsquo;s work or supported street selling. Some of the society women who increasingly made up the ranks of the birth control movement in the 1920s, as well as the doctors advising Sanger, wanted to get the propaganda off the streets; it was &ldquo;unladylike&rdquo; and &ldquo;undignified,&rdquo; they argued, to hawk the <em>Review </em>like it was a daily tabloid. And &ldquo;the more influential classes,&rdquo; wrote one birth control worker, &ldquo;. . . seem to abhor the selling of the <em>Review </em>in the streets which they frequent.&rdquo; In some cases, book stores and newsstands refused to sell a publication sullied by its street reputation. (Kitty Marion&rsquo;s Autobiography [unpublished], Alice Park Papers, Huntington Library, 267, 307-8; Guy I. Burch to Editor, <em>Birth Control Review </em>[Apr. 1926], 135.) </p>
<p>When Sanger resigned as president of the American Birth Control League in 1928, Marion knew her days were numbered; incoming president Eleanor Dwight Jones had disparaged street selling. Jones also viewed Marion as one of the last holdovers of Sanger&rsquo;s radical beginnings and representative of a confrontational activism that was clearly out of step with the new professionalism Jones sought to establish. The League notified Marion in January 1930 that her services were no longer needed; street sales would be discontinued. For severance, the League gave Kitty $500 and threw a luncheon to thank her for selling nearly 100,000 copies of the magazine. Kitty later wrote that her dismissal &ldquo;fell upon me with a sickening thud,&rdquo; though at the time she said she welcomed the change and chance to rest. (Kitty Marion&rsquo;s Autobiography [unpublished], Alice Park Papers, Huntington Library, 307-8; Marion to Annie Porritt, Jan. 28, 1930 [Sophia Smith Collection &ndash; Records of the PPFA].) </p>
<p>&ldquo;A long fight of years has ended,&rdquo; Sanger wrote upon learning of Marion&rsquo;s forced retirement. &ldquo;As long as I was President of the League I insisted upon Kitty&rsquo;s work being done. Now it is over.&rdquo; Sanger and others close to Marion tried to find her other work, but she lacked office skills and, at age 60, did not interest many employers. She worked part-time for a contraceptive manufacturer and a number of peace and reform groups, before finding a job with the public school system as a speech teacher to children of foreign parents. She also worked steadily on an autobiography that was never published. (MS to Alice Park, Feb. 4, 1930 [<em>MSM</em> C5:19]; Jared L. Manley, &ldquo;Crusader,&rdquo; <em>The New Yorker </em>[July 4, 1936], 23.) </p>
<p>Marion never sought tributes or accolades. Her motto was &ldquo;deeds not words.&rdquo; In 1935 Sanger invited Kitty to attend a birth control anniversary dinner to honor pioneers. Marion declined the invitation, writing: &ldquo;I have had all the &lsquo;Honors&rsquo; I want in standing on the street with the Birth Control Review, fighting for the cause, &lsquo;educating the public,&rsquo; and others, sending women to the clinic, making &lsquo;invaluable&rsquo; contacts as you called them, etc.&rdquo; She died in the Sanger (no relation) Nursing Home in New York in 1944 at age 71, having survived her final years on a meager pension. In her will she forbid a funeral. (Kitty Marion to MS, Feb. 6, 1935 [LCM 9:466]; <em>Herald Tribune</em>, Oct. 11, 1944.) </p>
<p>Today the famous photograph of Kitty Marion holding up a copy of the <em>Review </em>is still mistaken for Sanger and remains one of the most familiar images of the birth control movement &ndash; her statue of liberty photo, she and others called it. &ldquo;May all who see me sell the Review,&rdquo; she wrote in 1923, &ldquo; have the same impression as one of a group of little urchins who called out &lsquo;Aw, lookit the Statya of Liberty!&rsquo; For Birth Control stands for Liberty, &ndash; Liberty far more concrete than the Lady in the harbor herself!&rdquo; ( Marion, &ldquo;Ye That Pass By,&rdquo; <em>Birth Control Review </em>[Feb. 1923], 46.)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
