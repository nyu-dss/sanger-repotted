
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #49 (Fall 2008)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #49 (Fall 2008)</h1>
<div class="maintext">
<h1>"<em>Il Duce</em> v. the Woman Rebel: It's Birth Control or War!"</h1>

<p>&ldquo;Women never created anything,&rdquo; wrote Italian dictator Benito Mussolini in an American magazine in 1937. &ldquo;Look around you in any direction you like&ndash;art, drama, law, medicine&ndash;and you cannot point to any single instance where a woman has created anything that has been passed down to posterity.&rdquo; (Benito Mussolini, &ldquo;What Mussolini Thinks of Women,&rdquo; <em>Plain Talk Magazine </em>14:5 [May 1937]: 12.) </p>

<p>&ldquo;Ludicrous,&rdquo; replied Margaret Sanger in a response published a month later. &ldquo;Women never created anything?&rdquo; she asked incredulously, &ldquo;What about babies? What about you, Signor Mussolini. You would not be here to rant and shout, nor we to read and fight, if women had never created anything.&rdquo; (MS, &ldquo;What Margaret Sanger Thinks of Mussolini,&rdquo; <em>Plain Talk Magazine </em>14:6 [June 1937]: 14.) </p>
<p>Few other antagonists to Sanger&rsquo;s cause offended or provoked her as much as Mussolini. One could argue that <em>Il Duce </em>filled the role of Sanger&rsquo;s nemesis on the world stage in the interwar years in much the same way that Anthony Comstock had at home in the early years of the movement. </p>
<p>Comstock, the overzealous anti-vice crusader, personified a boorish rectitude that Sanger cast in villainous terms as a clear impediment to women&rsquo;s sexual freedom and to free speech. It&rsquo;s hard to think of Sanger&rsquo;s earliest birth control activism without picturing Comstock&rsquo;s thick-set figure in dark overcoat looming over her. His insistence on lumping contraception with obscenity and indecency pushed her to define birth control as something decent, worthy and sacred. It has often proved more effective in social movements to rouse support in condemnation of intolerance than in pursuit of controversial ideals, and Sanger used Comstock, even after his death in 1915, as a repugnant symbol of repressive morality. </p>
<p>Mussolini served a similar purpose. Sanger characterized him as the epitome of a ruthless dictator bent on conscripting motherhood to grow armies and expand power. He opposed the sound population policies and expansion of birth control programs she had been espousing in Europe since the end of the first world war. &ldquo;His fanatical male egotism,&rdquo; Sanger wrote, &ldquo;is a threat to the development of women in Italy, to the advancement of all women, and to the peace of the world.&rdquo; Sanger inveighed against him to spark efforts to organize an international movement in the 1920s and 1930s. Unfortunately just as the work was starting to show signs of real progress the world was descending into another massive conflict, dashing Sanger&rsquo;s hopes for a viable international birth control organization. (MS, &ldquo;What Margaret Sanger Thinks of Mussolini,&rdquo; <em>Plain Talk Magazine </em>14:6 [June 1937]: 14.) </p>
<p>Like Comstock, Mussolini was a comical, buffoonish anachronism and easy fodder for cartoons. Also like Comstock, he was sanctimonious and exhibited a puritanical streak. The two bullies even looked alike: bald and squarely built with thick necks, barrel chests and short legs. Fittingly, the actor Rod Steiger played them both on the screen: Mussolini in &ldquo;Lion of the Desert&rdquo; (1981) and &ldquo;Last Days of Mussolini&rdquo; (1974), and Comstock in &ldquo;Choices of the Heart,&rdquo; the television biography of Sanger that first aired in 1995. </p>
<p>However, unlike Comstock, Mussolini at one time advocated birth control. He told an Italian paper in 1913, during an anti-Christian, socialist phase nearly a decade before becoming premier of Italy, that &ldquo;to me, procreative prudence is not only not an immoral and pornographic doctrine, but is an act of wisdom, responsibility and honesty which ought to be common to all men. . . .&rdquo; And he gave his &ldquo;complete and active&rdquo; support to the idea of a neo-Malthusian or birth control league in Italy. (William Robinson, &ldquo;Mussolini, a Birth Controller,&rdquo; <em>The Medical Critic and Guide </em>[Mar. 1935], 67-68.) </p>
<p>Mussolini&rsquo;s short-lived support of family limitation, gave way to a vehement pro-natalist and anti-birth control position shortly after he came to power in Italy in 1922. He even wrote an anti-birth control play, &ldquo;The Cloud,&rdquo; around this time that dealt with a husband and wife quarreling, following the birth of a blind baby, over her refusal to use birth control. By 1924 he began to implement a demographic plan to expand Italy&rsquo;s population and increase its economic and military strength. At the core of his campaign to increase the birth rate was a prohibition on the dissemination of contraceptive information and government control of all medical devices used for contraception and abortion. Anti-birth control laws were codified in 1926 and strengthened in 1930. Not surprisingly, the contraceptive prohibition did not affect condoms, which were viewed as a necessity in combating venereal disease. (<em>Chicago Daily Tribune</em>, May 22, 1925.) </p>
<p>In his famous Ascension Day speech in May 1927, Mussolini called for Italy to increase its population from forty to sixty million in just twenty-five years in order to achieve a position of authority in Europe. Calling for Italian women to have at least a dozen children each, Mussolini instituted a series of pro-natalist measures to go along with the prohibitions on fertility control. These included a tax on bachelors and tax exemptions for large families, and policies that discouraged emigration and encouraged internal migration and colony settlement. By 1929, when internal opposition to fascist programs had largely been eliminated, Mussolini had established the legislative and bureaucratic framework to carefully monitor population growth and impose ever stronger policies to promote more and larger families, including preferential workplace treatment for married workers, a lowering of the legal age for marriage, nuptiality and fertility prizes, and marriage loans. (Denis Mack Smith, <em>Mussolini</em> [London, 1982], 159-161; Carl Ipsen, <em>Dictating Demography: The Problem of Population in Fascist Italy </em>[Cambridge, 1996], 73-74, 173-181; <em>New York Times</em>, May 29, 1927.) </p>
<p>Sanger saw the threat posed by Mussolini before many other observers of the international scene. Mussolini had his admirers in the U. S., including a number of liberals Sanger could call friends, such as the muckraker journalists Lincoln Steffens and Ida Tarbell, and the historian Charles Beard. Emil Ludwig, known for his popular biographies of great leaders, told Mussolini during an interview in the early 1930s that &ldquo;in the course of my travels I have found you more popular in America than anywhere else.&rdquo; The American public was favorably inclined toward Mussolini for much of his first decade as Italian dictator. It was not until Italy&rsquo;s brutal invasion of Ethiopia in 1935 that the public perception on this side of the Atlantic began to change. (John P. Diggins, &ldquo;Flirtation with Fascism,&rdquo;<em> American Historical Review </em>71 [Jan. 1966]:487-506; Emil Ludwig, <em>Talks With Mussolini </em>[London, 1932], 155.) </p>
<p>Sanger began attacking Mussolini&rsquo;s expansionist policies as early as 1925, annoyed that the U. S. was expected to &ldquo;take care of the hapless fruits of Italy&rsquo;s reckless and uncontrolled activity.&rdquo; She foresaw Italy&rsquo;s &ldquo;explosive expansion&rdquo; leading to &ldquo; more colonies by conquest,&rdquo; and believed any entreaties to Mussolini on this issue were futile: &ldquo;Let us recall here that the Fascist mind resents criticism and cannot forgive those who puncture its own delusions of grandeur.&rdquo; ( MS, &ldquo;The Incident at Williamstown,&rdquo; <em>Birth Control Review </em>[Sept. 1925], 246-247 [<em>MSM</em> S71:32].) </p>
<p>In 1929 she warned that &ldquo;the conscription of motherhood appears to be the inevitable next step in the Fascist policy of Mussolini.&rdquo; She was particularly charged up over the public comments made by Mario Carli, a magazine editor and one of Mussolini&rsquo;s most trusted spokesman in the press. Carli said that &ldquo;Every Italian woman must give to her country at least one son every two years,&rdquo; and he equated the evasion of this responsibility to &ldquo;the desertion of soldiers in the face of the enemy,&rdquo; and &ldquo;the attempt of the taxpayer to escape the payment of taxes.&rdquo; He railed against &ldquo;voluntary barrenness&rdquo; calling it and the growing trend to stay thin, and thereby be less inclined to multiple pregnancies, &ldquo;the greatest crimes a woman can commit under the Fascist regime.&rdquo; (MS, &ldquo;Motherhood Enslaved in Italy,&rdquo; 1929 [LCM 130:166] [quote 1]; no author, &ldquo;Italy, Thin Ladies Flayed,&rdquo; <em>Time</em> 13, No. 3 [Jan. 21, 1929], 20 [quotes 2-5].) </p>
<p>Sanger worried that many people, especially in the U.S., were not taking Mussolini, with his &ldquo;Napoleonic complex and <em>folie de grandeur,</em>&rdquo; and his &ldquo;strutting theatricals&rdquo; very seriously. But they ought to, she stressed, because &ldquo;Every ambitious militarist in the history of the world has called upon women to undertake the rapid multiplication of cannon-fodder. History from the forgotten potentates of the East to Julius Caesar, Napoleon Bonaparte to the rulers who brought about the Great War, is crowded with such instances.&rdquo; Sanger accused Mussolini of trying to assert &ldquo;his own godlike superiority over the rest of humanity. Thus he makes of all men soldiers and of all women slaves and breeding-machines.&rdquo; His aims to expand the Italian population would result, Sanger argued, in a lower standard of living, internal strife, expansionism and war. She cited his policies as a clear threat to stability in Europe. &ldquo;The alternatives appear to be,&rdquo; she wrote, &ldquo;either Birth Control or War.&rdquo; She called on women to cease traveling to Italy in protest of <em>Il Duce&rsquo;s </em>destructive population program. (MS, &ldquo;Motherhood Enslaved in Italy,&rdquo; 1929 [LCM 130:166] .) </p>
<p>Sanger disregarded her own directive in 1932 when she traveled to Cortina d&rsquo;Ampezzo, the ski resort town located in the Dolomites in Northern Italy. She had been taking a &ldquo;cure&rdquo; at the natural springs in Marienbad, Czechoslavakia, and a doctor there recommended she complete her therapeutic holiday in the higher altitude of the Italian Alps. She spent about three weeks in Cortina d&rsquo;Ampezzo under her married name, Mrs. J. Noah Slee. &ldquo;May the Pope &amp; Benito be kept in the dark as to who Mrs. Slee is!!&rdquo; she wrote to her secretary, Florence Rose. &ldquo;It is so beautiful here,&rdquo; she added, &ldquo;it is well worth risking poison or prison for.&rdquo; (MS to Florence Rose, Aug. 1932 [<em>MSM</em> S7:415 [quote1], 416 [quote 2].) </p>
<p>What would have happened if the Italian authorities figured out her true identity is not known, but the <em>New York Times </em>reported that &ldquo;Mrs. Sanger is generally understood to be barred from Italy, owing to Premier Mussolini&rsquo;s opposition to her views.&rdquo; Sanger later said that news of her arrival somehow leaked out and she was &ldquo; overwhelmed with requests from women&rsquo;s clubs for secret meetings, for information and help.&rdquo; She claimed she risked arrest by holding several small birth control meetings in Venice and Milan, though there is nothing in her personal papers that offers confirmation that such meetings ever took place. She also told the press that she became aware of a &ldquo;great underground movement&rdquo; for birth control in Italy. (<em>New York Times</em>, Sept. 22, 1932 [quote 1]; MS, &ldquo;What Margaret Sanger Thinks of Mussolini,&rdquo; <em>Plain Talk Magazine </em>14:6 [June 1937]: 16 [quote 2];<em> New York Herald Tribune</em>, Oct. 2, 1932 [quote 3].) </p>
<p>There was little evidence of an organized movement in Italy in the 1930s, but there is no doubt that women, on the whole, refused to comply with Mussolini&rsquo;s command to increase the birth rate, despite the incentives to bear children and the penalties against limiting family size. Though the population increased because of a decreasing death rate, the Italian birth rate dropped steadily from the time Mussolini launched his population program in 1926 to the beginning of World War II in 1939, and by all accounts a large number of women and couples used birth control, either practicing withdrawal or abstinence, obtaining condoms or a contraband birth control device, or resorting to abortion. Sanger and others have suggested that women waged an underground birth strike in response to a birth promotion policy they found offensive and a threat to female emancipation, but it seems more likely that women opted to control their fertility as part of a long-term trend toward urbanization and smaller families &ndash; a trend that continues today and has many politicians and demographers in a panic over a birth rate that is near the lowest in the Western world. (Ipsen, Dictating Demography, 74, 183.) </p>
<p>Sanger never let up in her condemnation of Mussolini, along with Hitler and the Japanese leaders, for attempting to create through population increase an &ldquo;inevitable need&rdquo; for territorial expansion which would certainly lead to war. Egged on by her good friend Carlo Tresca, the Italian-born editor, anarchist, and labor activist who worked with Sanger in the early 1910s, and who was one of the most outspoken anti-fascists in America, she kept up a steady stream of invective aimed at Mussolini, but also designed to convince Americans that birth control paved the way for peace. In 1941, she even went so far as to assert, following a ban on a birth control exhibit at the New York State Fair, that Mussolini had been exerting a subversive influence on the birth control politics in the U.S. While she had no &ldquo;concrete evidence,&rdquo; she offered a motive: &ldquo;if birth control is done away with here misery and poverty will abound in this country and only in countries where such conditions exist can a dictatorship take hold.&rdquo; (Carlo Tresca to MS, Feb. 6, 1932 [LCM 10:850]; <em>New York Times</em>, Jan. 18, 1937 [quotes].) </p>
<p>Mussolini&rsquo;s failure to push Italian women to increase their fertility is yet another reminder that women who have some knowledge of and access to birth control usually make their own choices about when and if to have children. As Sanger wrote in 1920, when Mussolini was in the midst of creating the Fascist party in Italy, &ldquo;Woman must have her freedom &ndash; the fundamental freedom of choosing whether or not she shall be a mother and how many children she will have. Regardless of what man&rsquo;s attitude may be, that problem is hers &ndash; and before it can be his, it is hers alone.&rdquo; (MS, <em>Woman and the New Race </em>[New York, 1920], 100.) </p>
<p align="center"><strong>Sanger v. Mussolini in <em>Plain Talk</em> </strong></p>
<p>In consecutive issues in the summer of 1937, the monthly forum magazine, <em>Plain Talk</em>, offered its readers Mussolini&rsquo;s views on women followed by Sanger&rsquo;s rebuttal. Here are some excerpts of Mussolini&rsquo;s statements followed by excerpts of Sanger&rsquo;s responses. </p>
<p><strong>M</strong>: &ldquo;The modern woman is liable to forget the primary duties she owes to civilization, and therefore, I am not in favor of women&rsquo;s dabbling in politics.&rdquo; </p>
<p><strong>S</strong>: &ldquo;Women realize poignantly the obligation and privilege they carry as race bearers because they are the mothers of the race, and it is because of this that they must, perforce, enter the political arena. For only by so doing can women make the world a fit place for children to live in.&rdquo; </p>
<p><strong>M</strong>: &ldquo;Women in parliament are meddlers and muddlers. They are seldom able to gauge soberly and properly the real depths and boundaries of a law, and they try to assert their position and vote by ranging themselves on the opposite side of all common sense and parliamentary philosophy. Women cannot look after the future of the human race in the home and in the nursery and govern at the same time. It has got to be either one thing or the other, and since Nature and God have ordained that woman shall be the mother of the human race &ndash; then, the sooner she realizes that the governing of the community should be left to the male sex, the better.&rdquo; </p>
<p><strong>S</strong>: &ldquo;And a fine mess the male sex has made of it. We, the mothers, look today upon a world threatened by war, upon nation arming against nation. We look upon poverty in the midst of plenty, upon millions of able-bodied men unable to find work, upon hunger and disease. We see men, women and children without adequate food, shelter or clothing while billions are spent for armaments and the upkeep of armies. Women cannot look after the future of the human race without taking an active part in shaping their nation&rsquo;s laws, without entering the fields of politics and government. I am no rabid man hater who thinks that women should rule the world. But I do believe, and my belief is grounded in a study of history, that our problems must be met by men and women acting together, by a fusion of male and female power, by cooperation between the sexes.&rdquo; </p>
<p><strong>M</strong>: &ldquo;I am not in favor of total emancipation of women. It has not advanced the world as much as many people believe; rather, has it imperilled the domestic security of the home and the safety of the world from the point of view of eugenics.&rdquo; </p>
<p><strong>S</strong>: &ldquo;What, I ask, is the greatest threat to domestic security, to the safety of the world? War. And men are responsible for war. Women, because they know the glory of motherhood, because they are the life bearers, the creators of men, feel a horror unknown to mere man at the spectacle of thousands upon thousands of young men mowed down, maimed and crippled in the glory of their youth. It is the women who champion the cause of peace, who have made articulate the voiceless protest of the masses.&rdquo; </p>
<p><strong>M</strong>: &ldquo;Beyond a certain modernist minority, women do not want to enter politics.&rdquo; </p>
<p><strong>S</strong>: &ldquo;Perhaps they do not WANT to enter politics; perhaps they would rather still depend upon their males as did their primitive sisters who stayed at home while the male went forth to stalk his game. But since man today does not, and perhaps can not, provide for all women, they must go out and fend for themselves and their children. Woman has entered the public life, industry, politics, in order to FULFIL, not to ESCAPE, her biological function, in order to be able to bear and bring up children, and make the world a fit place for them. It is because man has failed to use the power he has held through so many centuries intelligently, that women are in public life today. But with wisdom we can turn that failure into good.&rdquo; </p>
<p><strong>M</strong>: &ldquo;Women are unnecessary and unwanted in politics. It will take centuries before they will ever get to understand the political game sufficiently to be a political force of use. In the meantime they are meddling in matters that would be much better left solely in the hands of those who understand them.&rdquo; </p>
<p><strong>S</strong>: &ldquo;The unmarried woman, the women who is childless through no fault of her own, the woman whose childbearing and child rearing tasks are behind her, and whose years of highest mental and psychological activity stretch ahead, are needed in the affairs of public life. They have a contribution to make, and thoughtful men will be glad of their cooperation. Male and female together must work shoulder to shoulder if we are to achieve the best for future generations.&rdquo; </p>
<p><strong>M</strong>: &ldquo;Women are amusing, sentimental and born romantic. It is the contrary with men. The fair sex are confident, credulous, little animals. Sufficient to them that a man says, &lsquo;I love you&rsquo; &ndash; they are happy.&rdquo; </p>

<p><strong>S</strong>: &ldquo;But the women of Italy are doing their own thinking, despite the fact that, according to Mussolini, they have no initiative, no brains, no function, save to amuse and charm and soothe their men folks, and bear children.&rdquo; </p>
<p><strong>M</strong>: &ldquo;Women have no wills of their own.&rdquo; </p>
<p><strong>S</strong>: &ldquo;Truth and freedom cannot be killed nor entirely suppressed. It lives, submerged, to do its work and rise again. The women of Italy are silently telling Mussolini WHAT THEY THINK OF HIM. They are telling him that there can be no life unless they will it, and that, with their sisters the world over, they will not bear children to be slaughtered on the battlefield.&rdquo; </p>
<p>(Benito Mussolini, &ldquo;What Mussolini Thinks of Women,&rdquo; <em>Plain Talk Magazine </em>14:5 [May 1937]: 12-13 and MS, &ldquo;What Margaret Sanger Thinks of Mussolini,&rdquo; <em>Plain Talk Magazine </em>14:6 [June 1937]: 14-16 [<em>MSM</em>:944-46].)  </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
