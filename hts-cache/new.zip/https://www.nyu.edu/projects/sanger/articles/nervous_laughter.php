
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #20 (Winter 1998/1999)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #20 (Winter 1998/1999)</h1>
<div class="maintext">
<h1>"Nervous Laughter"</h1>

<p>Humor proved to be a highly effective way to broadcast the message of birth control to a wide audience.  Contraception and its dual purposes, family limitation and women's sexual liberation, were subjects that many in the first quarter of this century associated with prostitutes and sex radicals.  Humor, and cartoons in particular, brought it home in an acceptable fashion. </p>

<p>Cartoons ridiculed the prohibition of contraception and heralded the coming out of women's sexuality and organized birth control.  Graphic humor aided the crusade for legalized birth control by deflating its opponents and methodically building public approval. When the once omnipotent censor, Anthony Comstock, was reduced to a hideous caricature slashing a sword at the naked breast of a female in a cartoon in <em>The Masses</em>, it was apparent he no longer had the upper hand.  And when the <em>New Yorker</em> included cartoons on birth control, it insured that the topic was perfectly safe for cocktail conversation. </p>

<p>Not surprisingly, Margaret Sanger &ndash; the most identifiable symbol of birth control until the advent of the Pill &ndash; was often the featured image or punch line in cartoons about birth control.  The <em>Birth Control Review</em>, which she founded in 1917 and edited until 1928, used cartoons and illustrations to dramatize the plight of mothers or lampoon the establishment for its dangerous prudishness and disregard for women. </p>

<p>The cartoons in the <em>Review</em> were a welcome relief from the sometimes plodding, repetitive articles; they added sharp barbs to the drone of propaganda.  They were also effective in reaching a working class audience that may have been put off  by the sociologists, eugenicists, physicians and literary figures who wrote most of the articles.  Two women, Cornelia Barns and Lou Rogers, who built reputations with their suffrage cartoons and illustrations in publications such as <em>The Masses</em> and other radical journals, supplied most of the <em>Review's</em> cartoons.  Both had different styles but shared a humor fed by irony more than parody.  And they included cartoons or illustrations that were dramatic and disheartening, like Barns' "We Accuse Society." </p>
 
<p>The edgy, often scornful humor of the cartoons in the <em>Birth Control Review</em> and other radical journals gave way in the late 1920s to the highbrow, chuckle-humor of the <em>New Yorker</em> cartoons and its imitators.  For the most part, these cartoons endorse the need for family planning and poke fun at large families and ignorant adversaries of birth control.  A Donald McKee cartoon from the early 1930s shows a typical living room with a radio blaring "Mrs. Margaret Clangor will now deliver a lecture on Birth Control," while at least a dozen children play and fight on the floor.  A middle-aged couple sit, sound asleep in armchairs.   Other cartoons from mainstream periodicals and daily newspapers underscore Sanger's popularity and the ubiquity of birth control in the inter-war years.  Few cartoons depicted birth control in anything but positive terms.  An exception is a cartoon in the <em>Providence Visitor</em> in 1933 showing a birth control worker who resembles death, holding a doctor's kit labeled with the words "Birth Control" between two skulls and cross-bones, knocking at the door of a family of four. The caption reads:  "Lock the Door!" Generally, storks were the only victims of birth control that appeared in cartoons in the main-stream press.</p>

<p>Sanger lived long enough to follow the journey of birth control, from agitation to acceptance, through cartoons; in fact, several files of cartoons were preserved in her papers.  From the disturbing image of infanticide in <em>The Masses</em> in 1915 to a 1963 <em>Playboy</em> cartoon showing a restaurant scene where a waitress offers a couple "Cigars, Cigarettes, Pills. . ."  Sanger amassed both an unorthodox chronicle of her crusade and evidence of the power of images to mold public opinion.  </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
