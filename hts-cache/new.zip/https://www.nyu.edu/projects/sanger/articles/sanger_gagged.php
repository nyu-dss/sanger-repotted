
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #36 (Spring 2004)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #36 (Spring 2004)</h1>
<div class="maintext">
<h1>"Margaret Sanger Gagged!"</h1>

<p>In 1999, Barbara Walters called it "Perhaps this
century's first photo op."</p>
<p>It is probably the most famous photograph of Margaret Sanger (see page 2):
her intense gaze directed just beyond the camera; a two-inch wide white gag
running across her mouth; her hand pressed to a large corsage that covered her
mid-section; a young woman tying the gag at the back of Sanger's head. The
picture was captured on April 16, 1929 at Boston's Ford Hall Forum when a
silenced Margaret Sanger appeared on stage and handed her prepared speech to
Harvard professor Arthur M. Schlesinger to read to an audience of 800.</p>
<p>The image has become a symbol of censorship, often cropped and captioned to
appear as though Sanger was an unredeemed captive of the free-speech wars that
peaked a decade earlier; that she was gagged by coercion, forced to endure
ridicule as punishment for her sin of speaking freely about sex and birth
control. Planned Parenthood groups have printed the photo on calendars and
cards, indicating that Sanger put on the gag after Boston authorities told her
she cold not deliver a speech on birth control. There was much truth to this;
Boston prohibited Sanger from making a public presentation. But the startling,
disquieting sight of Sanger standing with her mouth forcibly shut is also
steeped in theater. There's a smirk beneath that gag.</p>
<p> </p>
<p>First let's backtrack a few years. Since the formation of the American
Birth Control League in 1921, Sanger had tried to arrange a public appearance in
Boston, a hub of censorship under the control of Mayor James Michael Curley, the
colorful defender of Boston's morals. Curley's crackdown on obscenity and
unpopular political discourse brought forth the phrase "banned in
Boston" in the 1920s. And though he exerted censorious powers against a
number of writers and lecturers, he was most consistent in interfering with
birth control and Ku Klux Klan meetings. He referred to Sanger's crusade as
"her child murder propaganda." Mayor Malcolm E. Nichols, Curley's
successor, continued the ban against speech promoting birth control during his
mayoralty from 1926-1929. However, birth control opposition meetings were freely
held in the city. (Zechariah Chafee, Jr.,<em> The Censorship in Boston </em>[Boston,
1929], 15-16; <em>Boston Globe</em>, Feb. 24, 1925.)</p>
<p>Despite the protests of the American Civil Liberties Union (ACLU) and other
organizations, Curley prohibited public meetings in Boston for Sanger in 1923,
1924 and 1925. "I ache all over," Sanger wrote ACLU founder Roger
Baldwin in 1924, "every time I think of Boston." And Mayor Nichols
blocked an attempt in March 1929 by the Boston Community Church to rent Symphony
Hall for a Sanger appearance. (MS to Baldwin, Sept. 15, 1924 [<em>MSM</em>
C3:188]; <em>Industrial Solidarity</em>, March 13, 1929.)</p>
<p>Enter the Ford Hall Forum on Beacon Hill, one of the oldest and most well
known public speaking forums in the U.S. Founded in 1908, the Forum quickly
became an outlet for social discontents and gained a reputation for defending
free-speech and inspiring tolerance. Lecturers represented all facets of society
and discussed the vital issues of the day including birth control, war, women's
rights, the failings of democracy, as well as topics in literature and the arts.
Regular speakers at the Forum included Carl Sandburg, Rev. John Haynes Holmes,
W. E. B. DuBois and Clarence Darrow. Generally praised from diverse quarters for
its commitment to fairness and enlightenment, the Forum came under heavy
criticism in the late 1920s for being too radical. In 1928 the Daughters of the
American Revolution blacklisted the Forum, condemning it as "Red."
Conservative religious leaders claimed it was anti-Christian and tried to close
it down. (Millicent Kindle, <em>The Ford Hall Forum: 75 Years of Public Discourse
</em>[Boston, 1983], 1-7.)</p>
<p>The Forum persevered and annually celebrated its distinction as a beleaguered
stronghold of free-speech and diversity with a banquet and "frolic."
For the 1929 banquet, the Forum invited a cross-section of authors, playwrights,
civil libertarians and activists who had been a target of Boston's censors.
Billing itself as "Boston's most undesirable institution," Ford Hall
warned on a program poster for the event, "NO ONE ADMITTED UNLESS
UNDESIRABLE." Regarding Sanger, "the outstanding social warrior of the
century," the program advertised that since "Those Who Sit in High
Places insist that we must be protected from this dangerous woman, she will make
no Speech." And that "Although Mrs. Sanger is muzzled, she will not be
handcuffed." The cuffs were reserved for author of banned books Percy Marks
to keep him from writing. In his invitation to Sanger, the associate director of
the Forum wrote "that by laughing in this way at those who are responsible
for the censorship we can do more good than in any other way." (David. K.
Niles to MS, March 5, 1929 [LCM 8:696].)</p>
<p>Sanger arrived at the banquet with gag in place, though it was briefly
removed so that she could eat. Following the dinner she was again muzzled and
introduced to the audience. According to the <em>Boston Post</em>, she
"received an ovation which brought a flush of surprise and happiness, the
entire assembly rising to its feet in her honor." (<em>Boston Post</em>, Apr.
17, 1929.)</p>
<p>The frolic began with several introductions and opening speeches. Forum
director George W. Coleman told the audience, "I assure you there will be
nothing unseemly at this frolic. Mrs. Sanger has been gagged." He then gave
way to a group of actors who put on a sketch titled "The Suppressed
Bookshop," which included a shop keeper fumigating the nasty books with
disinfectant. Actors paraded by in the costumes of characters from famous banned
books. Posters advertising censored books hung from the balcony rails. The
audience sang a verse of "America," followed by "The Battle Hymn
of the Republic," then whistled "Rally ‘Round the Flag Boys,"
after being informed they were not allowed to sing the words. They were urged to
sign a petition to suppress Percy Marks's newest book so that his sales would
increase in other parts of the country. "I am pleased that reformers are
using the weapons of satire and humor," Oswald Garrison Villard, the editor
of <em>The Nation</em>, said from his table, "we are often too serious."
(<em>Boston Globe</em>,<em> </em>Apr. 17, 1929<em>; Boston Herald</em>, Apr. 17, 1929)</p>
<p>Regrets on being unable to attend were read from Upton Sinclair, Sinclair
Lewis, Judge Ben B. Lindsey and H. L. Menken, before Professor Arthur
Schlesinger, the distinguished historian, rose to complain that the one woman
that Forum organizers chose to speak at the frolic happened to be banned from
speaking in Boston. After the laughter cleared, Sanger was again introduced to a
standing ovation. (<em>Boston Post</em>, Apr. 17, 1929.)</p>
<p>Securely gagged, she handed her speech to Schlesinger. The laughter and
mischievous chaos of the evening subsided. The audience sobered as Schlesinger
read Sanger's words: "To inflict silence upon a woman is supposed to be a
terrible punishment. It is. But there are certain advantages and benefits to be
derived from this awful punishment. . . . Silence inflicts thoughts upon us. It
makes us ponder over what we have lost &ndash; and what we have gained. Words are,
after all, only the small change of thought. If we have convictions, deep
convictions, let us not waste them in words. Let us act them out. Let us live
them!"</p>
<p>As most people in the audience were aware, Sanger's clinic in New York had
the previous day been raided by police. Five of her staff members had been
arrested and patient records confiscated. Sanger accompanied the arrested
doctors and nurses to the police station, notified her lawyers, and gave a
number of newspaper interviews before dashing to Boston to make the Forum
banquet. In light of this event, emblazoned in the headlines of major news
dailies, Sanger's words took on added urgency. Her emphasis turned from
free-speech to action.</p>
<blockquote>
<p>"I care nothing for Free Speech in and by itself. All of us place
too much value on the power of the printed word and the power of the spoken
word. We read too much. We listen too much. We live too little. We act too
little. . . . I speak to you by my actions past and present. I have been
gagged, I have been suppressed, I have been arrested, I have been hauled off
to jail. Yet every time, more people have listened to me, more have
protested, more have lifted their own voices, more have responded with
courage and bravery. . . . As a propagandist, I see immense advantages in
being gagged. It silences me, but it makes millions of others talk about me,
and the cause in which I live." (Ford Hall Forum Speech, Apr. 16, 1929
[LCM 129:484-485)</p>
</blockquote>
<p>Sanger's attorney, Morris Ernst, a vocal defender of First Amendment
rights, followed Sanger to the stage. "The authorities may gag Mrs.
Sanger," he said, "but they can't gag the truth." (<em>Boston
Globe</em>, Apr. 17, 1929.)</p>
<p>The evening concluded with a speech by Clarence Darrow, at the time the
country's most famous lawyer following his 1925 Scopes trial defense of the
teaching of evolution in the schools. "The only time I ever feel
funny," he told the audience, "is when I am serious. Then I am apt to
look on the whole thing as a huge joke. You know, it takes a sense of humor to
live in this world where asses are serious so intelligent people can laugh at
them." He suggested that liberals "should organize a watch and ward
society of our own to watch the bigots and oppressors, and to watch over this
divine liberty, without which life would not be worth living." He turned to
the topic of birth control, indicting the rich and powerful for keeping
information from the poor. "Why," he asked. Because "Somebody has
to have children so they can keep on being rich. They want to have a monopoly of
the good things of life." In a rousing defense of Sanger he declared
"Error and ignorance is often supreme and often intrenched by law. But no
power on earth can stop the work Mrs. Sanger began." (<em>Boston Globe</em>,
Apr. 17, 1929; <em>Boston Herald</em>, Apr. 17, 1929.)</p>
<p>Sanger and Ernst returned to New York to successfully defend the legal
existence of the Birth Control Clinical Research Bureau in a case that greatly
accelerated the nullification of the Comstock Laws. Another attempt to silence
Sanger's message and impede her progress had failed.</p>

<p>The complete text of Sanger's Ford Hall Forum Speech is being published in
Volume II of the <a href="../publications/volume_ii.php">Selected Papers of Margaret Sanger: Birth Control Comes of Age, 1928-1939</a>.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
