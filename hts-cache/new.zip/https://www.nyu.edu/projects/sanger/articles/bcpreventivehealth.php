
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #26 (Winter 2000/2001)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #26 (Winter 2000/2001)</h1>
<div class="maintext">
<h1>"An MSPP Editorial: Birth Control as Preventive Health Care--A Hundred Years in the Making"</h1>

<p>One hundred years ago this spring, Margaret Sanger introduced into the public debate the radical notion that women should have access to affordable contraception for reasons of health and well-being.  A century later, we are still arguing—all the way to the Supreme Court—over whether or not contraception should be considered preventive health care.  Why is this still an issue?</p>
<p> On March 25, the Supreme Court heard arguments in two cases, <span class="italicText">Sebelius v. Hobby Lobby Stores, Inc</span>. and <span class="italicText">Conestoga Wood Specialties Corp. v. Sebelius</span>, on whether the religious objection of a corporation’s owners is sufficient cause to deny insurance coverage of contraception, entitled to employees under the Affordable Care Act as a free preventive health service.  The top court’s decision will be released sometime in June.  If the Court rules against the government it will mark a significant setback in the long struggle to achieve health care equality for women.

</p>
<p>That struggle has its roots in the birth control movement, which set out to protect women from dangerous abortion procedures, reduce maternal and infant deaths, and prevent diseases and other adverse health effects associated with unplanned pregnancies—especially among the poor.</p>
<p> In March of 1914, the thirty-four year old Sanger, a socialist organizer, nurse and mother of three, announced in the first issue of her monthly paper, <span class="italicText">The Woman Rebel</span>, her intention to “advocate the prevention of conception” and “impart such knowledge in the columns of this paper.”  For postal authorities that amounted to a threat to circumvent the 1873 Comstock Act, which prohibited the circulation of contraceptive information.  The Postmaster notified Sanger that the paper was unmailable.  Defiant, she continued editing the paper, publishing six more issues, five of them flagged by postal officials who ordered copies seized.  She ceased publication in the late summer when a federal prosecutor indicted her on obscenity charges. (MS, “The Aim,” <span class="italicText">The Woman Rebel</span>, March 1914, p. 1.)

</p>
<p>Sanger never did print contraceptive advice in the Rebel.  Her transgressions did include unveiling the phrase “birth control,” linking contraception to women’s sexual autonomy and reproductive health, and bemoaning the high number of unsafe abortions in America.  But the authorities would have been smart to ignore her.  Instead, the postal rulings and obscenity charges made headlines, spreading Sanger’s message far beyond the limited readership of her paper and agitating women in the activist community and with deep purses in the society set. 

</p>
<p>That fall, Sanger raised the stakes–to ““give them something to really indict me on,” she wrote to her muckraker friend, Upton Sinclair.  She printed 100,000 copies of <span class="italicText">Family Limitation</span>, her plainspoken contraceptive manual, the first of its kind.  Over the next decade it would change many women’s lives. Then she fled into exile on the eve of her Woman Rebel trial, sailing to England under an assumed name and arriving on the doorstep of World War I.  Her confrontational activism during that portentous year launched the American birth control movement. (MS to Upton Sinclair, Sept. 23, 1914 [<span class="italicText">MSM</span> C1:39].)		

</p>
<p>Today a major premise of that social reform, that contraception is preventive medicine, has come under challenge.  Catholic groups, most prominently the U.S. Conference of Catholic Bishops, have gone on record stating that contraception should not be considered preventive health care “because pregnancy is not a disease.” Religious conservatives have echoed that declaration, claiming that birth control is not health care any more than “oatmeal or your gym membership is.” And, according to conservative radio host Rush Limbaugh, if it’s not for health care purposes, then taxpayers are “pimps”” for subsidizing women’s sex lives.  Former Republican presidential candidate Mike Huckabee suggested that, through the health care mandate for contraception, Democrats have codified their belief that women “cannot control their libido or their reproductive system without the help of the government.” (<span class="italicText">New York Times</span>, Feb. 11, 2012; Joy Miladin, “Is birth control really health care?,” LifeSiteNews.com, Aug. 8, 2012; <span class="italicText">The Blaze</span>, Feb. 29, 2012; <span class="italicText">Washington Post</span>, Jan. 23, 2014.)

</p>
<p>In the March 25 arguments before the Supreme Court and in the debate being waged in the media, both sides have failed to acknowledge that birth control has always been a central component of women’s preventive health care: it was promoted from the very beginning and strengthened over the last hundred years by medical endorsement, legal affirmation and government support.     </p>
<p>Under Sanger’s leadership, the birth control movement shifted aims and alliances, advocating contraception for women’s sexual autonomy, for eugenic improvement, for population control and as a hedge against war.  But it never veered from her mainstay belief that birth control is the most critical preventive health measure available to women.     </p>
<p>Early on, Sanger made a strategic decision to get birth control off the streets and under medical supervision in order to improve safety and effectiveness and increase public acceptance.  She argued that birth control should be treated as a doctor-prescribed medication and medical treatment, and dispensed in a clinic or other medical setting. Sanger did this, at least in part, to attract working-class women for whom a subsidized birth control clinic might serve as their only source of health care.</p>
<p> In 1916, she opened the nation’s first clinic in the Brownsville section of Brooklyn.  Police closed it down after two weeks and hauled Sanger off to prison.  But her appeal of the case produced the first real crack in the law.  While a New York State appellate court upheld her conviction in 1918,  Judge Frederick Crane, writing for the court, underscored an exemption to the state prohibition of contraception, which read, in part, that physicians could dispense contraception for “the cure or prevention of disease.” This exception had been added as a public health measure to allow for men to legally obtain condoms as a prophylactic against venereal disease.  It other words, men could legally use contraception to protect themselves from syphilis and gonorrhea if they engaged in sex with prostitutes and outside of marriage, but married women could not choose when to become mothers.  Few at the time recognized the sexist double standard. (<span class="italicText">People of New York v. Margaret Sanger</span>, Court of Appeals of New York, 222 NY 192; 118 NE 637, 1918.)</p>
<p>Nevertheless, Sanger used this exemption as legal sanction to open a doctor-supervised clinic in 1923, the Clinical Research Bureau in Manhattan, which dispensed contraceptives for specific medical indications.  The clinic withstood intense Catholic opposition, hostility from physician’s groups, and a police raid to become the premier contraceptive dispensary and research facility in the nation. Similar clinics opened in other major cities later in the decade and into the 1930s, further expanding public acceptance of birth control.

</p>
<p>As birth control use became more widespread, a number of gynecologists and public health physicians broke ranks with the conservative medical establishment and testified in court and congressional hearings about the health benefits of child-spacing for women and children.  For much of the first half of the twentieth century, the conservative medical establishment had associated birth control with promiscuity and licentious behavior, and remained troubled, as did religious conservatives, with the prospect of women’s sexual autonomy.
  
</p>
<p>The cautious American Medical Association finally endorsed the use of contraception for health reasons in 1937, following a key federal appellate court decision a year earlier in <span class="italicText">U.S v. One Package</span> to strike down the Comstock Law as it pertained to medically-prescribed contraception. In his historic opinion in that case, Judge Augustus Hand wrote that in crafting the prohibition, the 1873 Congress understood the immoral use of contraception only and could not have envisioned that it might be prescribed by physicians “for the purpose of saving life or promoting the well being of their patients.”  (<span class="italicText">U.S v. One Package</span>, 86 F. 2d 737 [May 23, 1936].)
    
</p>
<p>With the advent of the birth control pill in the early 1960s, the medical use of contraception expanded to include hormonal therapies to address menstrual irregularities and a growing list of other health concerns.  
      
The landmark 1965 Supreme Court decision in <span class="italicText">Griswold v. Connecticut</span>, which lifted remaining prohibitions on contraception for married couples, went a step further than <span class="italicText">One Package</span>, declaring birth control a basic human right, protected under a newly articulated right to privacy. The ban for unmarried couples was lifted completely in 1972 in <span class="italicText">Eisenstadt v. Baird</span>.  Just a year later,  Roe v. Wade  extended the right to privacy to include legalizing women’s access to abortion to preserve and protect women’s health.     </p>
<p>A flood of compelling data in the postwar era on the health benefits of preventing unintended pregnancies persuaded the government to incorporate contraception into public health programs.  Starting in 1965, President Johnson’s administration added birth control funding to the War on Poverty, and by the end of the decade, a majority of state governments had established low-cost family planning programs.     </p>
<p>President Nixon expanded access to affordable birth control for the poor when he signed into law Title X of the Public Health Service Act in 1970.  He told Congress the year before, “We know that involuntary childbearing often results in poor physical and emotional health for all members of the family. . . It is my view that no American woman should be denied access to family planning assistance because of her economic condition.” (Richard Nixon, “Special Message to the Congress on Problems of Population Growth,” July 18, 1969, The American Presidency Project [ http://www.presidency.ucsb.edu/ws/?pid=2132].)     </p>
<p>Since then, the major medical organizations–most recently the non-partisan Institute of Medicine in 2011–have consistently recommended that contraceptive services and education be a part of women’s preventive care.     </p>
<p>Even Catholic organizations opposed to “artificial” contraception tacitly accept that birth control is a preventive health measure every time they recommend “natural” family planning to space children and ease the burdens of childbearing for women.  As Margaret Sanger said back in the 1930s, when the rhythm method received ecclesiastical approval from the Catholic Church, “we are coming down now, not to a question of principle, but a question of methods.”  (<span class="italicText">Extract from Testimony on H. R. 5978</span>, Jan. 19, 1934 [<span class="italicText">MSM</span> S69:506].)     </p>
<p>In the March 25 Supreme Court debate, some of the justices struggled with this question of methods. The business owners, in arguing against the contraceptive mandate, have stated that they object to certain contraceptives that they claim, without scientific substantiation, are really abortifacients. Justice Scalia, for one, appeared to accept the owner’s classification of these methods, such as the IUD, as abortion devices.     </p>
<p>The court’s decision should directly address contraceptive methods, an issue on which the court must defer to medical science—as it should, as well, on the underlying question regarding women’s health.  After a hundred years of hard-won reproductive rights and medical approval, it’’s time, once and for all, to agree on principle: that birth control is basic preventive health care and must not be set apart from other health care services because of religious objection. </p>
</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
