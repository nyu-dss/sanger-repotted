
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #3 (Fall 1992)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #3 (Fall 1992)</h1>
<div class="maintext">
<h1>"Sanger in the USSR"</h1>

<p>    "Russia today is the country of the liberated woman," remarked Margaret Sanger upon her return from a 1934
tour of the Soviet Union.  "The attitude of Soviet Russia toward its women...would delight the heart of the
staunchest feminist," she wrote in 1935 for the Birth Control Review.  But while Sanger was impressed with a
growing Soviet effort to liberate women from "housework drudgery...and no pay or recognition tasks," she
witnessed severe limitations in reproductive choices for women and foresaw a crisis in Soviet women's healthcare
that has received extensive coverage in the media since the dismantling of the Soviet state.</p>

<p>    Like most Westerners visiting the USSR, Sanger traveled with a tour group (led by American writer Sherwood
Eddy) under official state guidance.  But her international reputation, friendships with American and European
expatriates, and sheer audacity enabled her to see "anything that I asked to see and many things I was not
supposed to see," including dispensaries, hospitals, clinics, and Institutes for the Protection of Motherhood in
Lenigrad, Moscow, Stalingrad, Odessa, and several smaller cities and towns.</p>

<p>    What Sanger observed during her six week tour led her to label the USSR a country of "great contradictions." 
While she found posters urging the use of contraceptives, and was told repeatedly that people were learning about
birth control from the government, she was disappointed on several occasions to find devices too old to use, or
clinics that had long ago run out of supplies.  </p>

<p>    Sanger also disapproved of the Soviet dependence on abortions.  While she applauded the Soviets for giving
official sanction to abortion and thereby taking the practice out of "the hands of quacks" and under the auspices of
hygenic and professionally staffed hospitals, she criticized Soviet doctors for using abortion as a means of family
planning.  When Sanger pleaded for the adoption of birth control as a safer and more humane alternative to repeat
abortions, one Soviet doctor responded that as long as women 
had to depend on the state doctors 
for abortions, the state could control 
its rate of population growth.  In her 
speeches after the trip, Sanger warned 
of the danger of growing state control over 
women's reproductive choices.  Just ten 
years later, Stalin imposed an edict which 
provided monetary incentives 
for childbearing, outlawed 
abortions and made 
access to contraceptives 
more difficult.</p>

<p>    Traveling with her son, Grant, and her secretary, Florence Rose, Sanger saw more than clinics and hospitals
on her trip.  She and her tour visited many of the popular tourist sites, including the Kremlin and the Hermitage,
sailed down the Volga, and took a harrowing bus ride through the mountains of Georgia and then on to the Black
Sea, where Sanger boasted that she bathed <em>au naturel</em>.</P>

<p>   Although frustrated with the unfulfilled potential of the Soviet Union, Sanger returned home
optimistic about
aspects of the Soviet system; for instance she spoke enthusiastically about the special care given to mothers and
children and the equality of women in the workplace.  And she thought, at a time when free distribution of birth
control was still officially illegal in America, that the U.S. could learn from the Soviet example, however flawed
it may have been:  "The right of women to birth control is clear.  And this right need not be bulwarked, as in our
country by health reasons, economic reasons, eugenic reasons, but is granted as a simple human right."</p>

<p>&nbsp;</p>

<p><em>(The record of Sanger's trip is preserved in letters, articles, and clippings, and fragments of speeches and
writings at Smith College that we have recently identified, linked together, and reorganized in preparation for the
microfilm edition.  All quotes above have been drawn from these documents at the Sophia Smith Collection.)</em></p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
