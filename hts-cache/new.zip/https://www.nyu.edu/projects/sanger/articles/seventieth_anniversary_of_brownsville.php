
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #2 (Winter 1991)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #2 (Winter 1991)</h1>
<div class="maintext">
<h1>"Seventy-Fifth Anniversary of the Brownsville Clinic"</h1>

<p>    On October 16, 1916, Margaret Sanger opened the first
American birth control clinic at 46 Amboy Street in
Brooklyn.  Located in the Brownsville section, a poor,
congested area populated by working-class immigrants, the
clinic's services were advertised in English, Yiddish, and
Italian leaflets.  </p>

<p>    When the clinic opened on the morning of October 16th,
the line of Jewish and Italian immigrant women stretched
almost around the block.  Some 140 arrived on its first day
and the women kept coming.  Unable to persuade a doctor to
provide contraceptive services, Sanger and her sister Ethel
Byrne, a registered nurse, ran the clinic themselves with the
help of friend and interpreter Fania Mindell.  Nine days
later, police closed down the clinic and arrested the three
women.</p>

<p>    In opening the clinic Sanger had deliberately violated a
New York State law which classified contraception as
obscene and banned it.  She believed that by making possible
the separation of sexuality from reproduction, birth control
was the key to ensuring women's autonomy, but she
recognized that in 1916 birth control was too radical for
widespread acceptance.  She understood that in order to
change the laws she would first have to change the climate of
public opinion which associated birth control with
promiscuity and licentiousness.</p>

<p>    The Brownsville
clinic is the story of a
media event &ndash; an event
designed and led by
Sanger to bring birth
control out of the
shadows and into the
light of respectable
public debate.  It was a
sophisticated campaign
that dramatically
identified birth control
with the promise of
happier marriages, healthier children, and overall social
benefit.  What Sanger was trying to get the public to accept
was the notion of birth control as a socio-economic and
medical issue rather than a moral one.  Her strategy was
aimed at courting the support of the moderate middle- and
upper-class women who themselves had access to birth
control, but remained reluctant to advocate it publicly. </p>

<p>    Because she had broken a New York State law prohibiting
anyone from giving contraceptive information for any reason,
Sanger knew that the clinic would be quickly closed and she
would be arrested.  Indeed, the arrests and trials provided
her with the opportunity to keep the issue of birth control in
public view.  When Ethel Byrne, tried, convicted and
sentenced to thirty days on Blackwell's Island, went on a
hunger strike and became the first American woman prisoner
subjected to forced feeding, Sanger made certain Ethel's
ordeal was so well-publicized that it shared the front page of
the New York Times with the news of World War I.</p>

<p>    At Sanger's own trial,
she sought to connect
birth control with a range
of socio-economic issues. 
Among the witnesses
called on her behalf were
some 25 Brownsville
women whose testimony
was marked by tragic
accounts of miscarriages,
failed abortions, and an
endless cycle of
pregnancy and childbirth.  While they did not convince the
court to acquit her, the judge did offer Sanger a pardon if she
promised not to break the law again, but Sanger replied "I
cannot respect the law as it stands today."  Like her sister,
Sanger was convicted and sentenced to thirty days
imprisonment.  She spent her time in the Queens County
Penitentiary lecturing fellow inmates on birth control.</p>

<p>    Sanger appealed her conviction, insisting that the law
compelled women "to unnecessarily expose themselves to the
hazardry of death."  Her arguments still did not impress the
court which upheld Sanger's conviction.  However, the court
did sufficiently broaden its interpretation of the law to enable
physicians to prescribe birth control to women when
medically indicated.  This laid the legal groundwork for the
establishment of a system of physician-staffed birth control
clinics.</p>

<p>    To continue her educative and lobbying efforts, Sanger
went on to establish the American Birth Control League in
1921.  In 1923 she opened the Birth Control Clinical
Research Bureau, the first doctor-staffed birth control clinic
in the U.S.  In 1938, the Bureau merged with the American
Birth Control League to form the Birth Control Federation of
America, which in 1942 changed its name to the Planned
Parenthood Federation of America.</p>
<p>   But the significance of the Brownsville Clinic lay as much
in its impact on public attitudes towards birth control as in
the legal and organizational changes it signaled.  In opening
the Brownsville clinic, Sanger not only launched a public
debate about birth control on her terms but expanded the
public spaces in which it was discussed. </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
