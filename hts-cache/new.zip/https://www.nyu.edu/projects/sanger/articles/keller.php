
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #53 (Winter  2009/2010)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #53 (Winter  2009/2010)</h1>
<div class="maintext">
<h1>"Battling the Powers of Darkness--Helen Keller, Margaret Sanger and Birth Control"</h1>

<p> &ldquo;No one has ever given me a good reason why we should obey unjust laws,&rdquo; wrote Helen Keller (1880-1968) in 1914, the same year that Margaret Sanger purposely flouted the obscenity laws by publishing articles about birth control and abortion in the Woman Rebel. A year later, Keller, the activist, reformer and advocate for the blind, publicly endorsed Sanger&rsquo;s controversial, and newly-named &ldquo;birth control&rdquo; movement, outlining her socioeconomic and eugenic rationales for legal and accessible contraception. One of the most recognized and celebrated women in America, Keller gave the incipient birth control movement some of its best publicity to date and furthered the national public debate over the question of birth control legalization. (Keller, Introduction to Arturo Giovannitti, <em>Arrows in the Gale</em>, [Riverside, Conn., 1914], 13; <em>New York Call</em>, Nov. 26, 1915.)</p>
<p> Despite Keller&rsquo;s early support of birth control, she and Sanger did not meet until 1944. This is all the more remarkable when you consider that they moved in many of the same circles in the pre-World War I and wartime years and later even worked on the same block. Sanger and Keller joined the Socialist Party and the Industrial Workers of the World (the Wobblies) within a year of each other. Both were outspoken pacifists, and they both wrote articles for the <em>New York Call</em>, the popular socialist daily. They shared a number of radical friends, including Eugene Debs, Elizabeth Gurley Flynn and William (&ldquo;Big Bill&rdquo;) Haywood. Not surprisingly, the FBI kept files on both women. Each also starred in a silent autobiographical propaganda film: Sanger in &ldquo;Birth Control&rdquo; in 1917 and Keller in &ldquo;Deliverance&rdquo; in 1919. And they also shared the honor of having Hitler burn their books in the mid-1930s. Apart from their political solidarity, they worked literally side by side; starting in 1934 they had offices just one door away from each other on West 16th Street in New York: Keller and the American Foundation for the Blind at number 15; and Sanger and the Margaret Sanger Research Bureau at number 17. Yet it would take another ten years before they were introduced to each other at a mutual friend&rsquo;s home in upstate New York. (Philip S. Foner, Helen Keller: <em>Her Socialist Years</em> [New York, 1967], 7,12-15; Kim E. Nielsen, <em>The Radical Lives of Helen Keller</em> [New York, 2007], 7, 36-7.)</p>
<p>    Their names were joined for the first time in Keller&rsquo;s extraordinary November 26, 1915 article that appeared in the <em>New York Call</em>, with a longer version published in the Columbus Georgia <em>Ledger</em> and later other newspapers around the country. The piece was written in response to a number of articles and editorials that had mentioned Keller&rsquo;s name in connection with the Bollinger baby case, a news story that swept the nation in the late fall of 1915 and competed on the front pages with the war news in Europe. The story came to light when the Illinois commissioner of health and others tried to pressure Dr. Harry J. Haiselden, head surgeon at the German-American Hospital in Chicago, to operate on a baby boy born on November 12, 1915 with multiple physical deformities, brain damage and partial paralysis. Haiselden advised the parents, Anna and Allen Bollinger, to forego surgical intervention that would probably have saved the baby&rsquo;s life but would have left him, in the words of the doctor, with nothing better than &ldquo;an animal existence and imbecility.&rdquo; The baby died after five days, at which time Haiselden admitted he had let other severely deformed and disabled infants die, and had, in some instances, hastened their deaths. He said he believed he had done the human race &ldquo;a favor.&rdquo; (<em>Chicago Daily Tribune</em>, Nov. 17, 18 and 20, 1915; <em>New York Times</em>, Nov. 18, 1915; Martin S. Pernick, <em>The Black Stork: Eugenics and the Death of &lsquo;Defective&rsquo; Babies in American Medicine and Motion Pictures Since 1915</em> [New York, 1996], 3-7.)</p>
<p>    Many prominent Americans agreed with Haiselden&rsquo;s decision, including several of Sanger&rsquo;s friends, such as the juvenile court system pioneer Judge Ben Lindsey, civil rights attorney Clarence Darrow, and socialist editor and writer Anita Block. Historian Charles Beard and nationally known nurse and social worker Lillian Wald also applauded the doctor&rsquo;s judgement. Surprisingly, Catholic Cardinal James Gibbons of Baltimore said that Haiselden was &ldquo;not obliged&rdquo; to take &ldquo;extraordinary means&rdquo; to prolong life. </p>
<p>     Haiselden&rsquo;s action and public statements aroused a storm of protest from clergy of all denominations, from social workers, health and children&rsquo;s advocates, physicians, and from many other social reformers. Settlement House movement leader Jane Addams said that &ldquo;Under no circumstances has any human being the right to pass judgment of death for unfitness on any other human being.&rdquo; Dr. Ira Wile, a vocal birth control and Sanger supporter, thought that physicians should never refuse to save a life, and that Haiselden, at the very least, should have consulted with other doctors, something he admitted he did not do. Several who spoke out against Haiselden argued that a mere mortal should not play God and divine the fate of a child when there were many examples of individuals who triumphed over serious disabilities. The prime example cited repeatedly in the press was Helen Keller. &ldquo;Defectives have reached great heights,&rdquo; said Bishop Samuel Fallows, &ldquo;Note Helen Keller, the blind, deaf and dumb girl.&rdquo; An editorial in the Biloxi, Miss. <em>Daily Herald</em> was typical of this line of reasoning, pointing out that &ldquo;Theodore Roosevelt was born a weakling . . . Caesar . . . was an epileptic . . . Byron was a degenerate . . . Helen Keller, born dumb, blind and deaf, give[s] to the sightless new hope in her guttural exclamations of delight at new-found speech.&rdquo; (<em>Chicago Daily Tribune</em>, Nov. 20, 1915; <em>New York Times</em>, Nov. 18, 1915; Pernick, <em>The Black Stork</em>, 33-35; <em>Daily Herald</em> (Biloxi), Nov. 25, 1915.)</p>
<p>    Keller, who became blind and deaf following an illness when she was 19 months old, did not appreciate being used as a prop for these infant euthanasia opponents. She wrote that Haiselden &ldquo;performed a service to society as well as to the hopeless being he spared from a life of misery . . . the world is already flooded with unhappy, unhealthy, mentally unsound persons that should never have been born.&rdquo; She believed that the baby&rsquo;s death was not in vain, for he &ldquo;has brought us face to face with the many questions of eugenics and control of the birth rate &ndash; questions we have been side-stepping because we are afraid of them.&rdquo; Keller then referred to William Sanger&rsquo;s fall 1915 arrest and imprisonment which had primed the press on the birth control issue:</p>
<blockquote>
  <p>&ldquo;The case of William Sanger, whose wife formed the Birth Control League, should open the eyes of all intelligent persons to the forces at work against the spread of this new idea. A short time ago Sanger was giving away a pamphlet, <em>Family Limitation</em>, that his wife had written. It was her answer to many appeals for information from men and women who could not support their families and who could not pay a competent physician for the information they wanted. Its purpose was to help distressed parents to limit the number of their offspring and give a better chance of health and happiness to the children they did have.&rdquo;</p>
  </blockquote>
<p> She argued that capitalists wanted workers to have large families to supply cheap labor to factories, and &ldquo;If the families of the workers are left to the uncontrolled caprice of nature, we shall have a larger percentage of children that are forced to toil in the mills and factories &ndash; who are denied their birthright of education and play.&rdquo; Keller wrote of the countless children of the poor who &ldquo;waste away . . . like plants in sandy soil . . . .Those that survive bring into the world, in spite of themselves, an even larger number of deformed, sickly, feebleminded children.&rdquo; &ldquo;Only by taking the responsibility of birth control into their own hands,&rdquo; she continued, &ldquo;can they roll back the awful tide of misery that is sweeping over them and their children.&rdquo; Keller concluded, &ldquo;Once it was necessary that the people should multiply and be fruitful, if the race was to survive. But now, to preserve the race, it is necessary that people hold back the power of propagation.&rdquo; (Helen Keller, &ldquo;Helen Keller, Blind, Deaf and Dumb Genius, Writes for Daily Ledger on Defective Baby Case,&rdquo; <em> Ledger</em> (Columbus, Georgia), Nov. 26, 1915.) </p>
<p>    Keller&rsquo;s support of Haiselden and her stunning advocacy of a eugenics-based birth control program reinforced the unsolicited link between the Bollinger baby case and the birth control question. &ldquo;No other event in recent months,&rdquo; ran the editorial in the <em>Salt Lake Telegram</em>, has been so widely discussed in the newspapers, in the pulpits, in meetings of scientific societies and in the homes of the people. . . The movement for birth control has gained new recruits through the discussion of the Bollinger baby case.&rdquo; Several birth control advocates, including Sanger&rsquo;s rival, Mary Ware Dennett, head of the new National Birth Control League, and William Robinson, the leading physician-proponent of birth control, appealed to both sides in the debate over infant euthanasia by arguing that the careful planning of births would greatly reduce the number of children born with abnormalities. Margaret Sanger, however, remained silent. Her five-year-old daughter, Peggy, had died of pneumonia on November 5, and the devastated Sanger refrained from public comment on any matter, including the Bollinger case. (<em>Salt Lake Telegram</em>, Nov. 28, 1915; Pernick,<strong> The Black Stork</strong>, 33, 70.) </p>
<p>    Keller&rsquo;s comments on birth control and eugenics to this point, seemed to be consistent with Sanger&rsquo;s. Both of them viewed birth control as the most successful means, short of a social revolution, by which to improve health and reduce debilitating poverty. They rejected &ldquo;cruel sentimentalism&rdquo; (Sanger) and &ldquo;cowardly sentimentalism&rdquo; (Keller) which unwittingly promotes life at any cost and disregards human suffering. But both also acknowledged the difficulties of, in Sanger&rsquo;s words, determining who is &ldquo;&lsquo;fit&rsquo; and &lsquo;unfit.&rsquo;&rdquo; Keller asked, how can we trust &ldquo;any mortal with so responsible and delicate a task.&rdquo; Sanger, however, did not publicly supported euthanasia. But while Sanger believed that parents should not procreate when one of them suffers from a serious transmissible mental or physical impairment, she did not support Keller&rsquo;s views on infant euthanasia, and she and Keller went their separate ways. (Sanger, &ldquo;The Eugenic Value of Birth Control Propaganda,&rdquo; and &ldquo;When Should a Woman Avoid Having Children?&rdquo; <em>Birth Control Review</em> [Oct. 1921], 5 and [Nov. 1918], 7; Helen Keller to Editor, <em>New Republic</em> [Dec. 18, 1915), 174-74; Sanger, <em>Pivot of Civilization</em> [New York, 1922], 181.) </p>
<p>    Keller continued to advocate for birth control but never as publicly as she had in 1915. By the time she began corresponding with Sanger, in 1938, the dissemination of birth control was legal in most states, widely accepted by the American public and no longer a radical pursuit. Keller found &ldquo;more than a symbolical relationship&rdquo; between their causes, and she underscored &ldquo;our common interest in defending man&rsquo;s faculties against the powers that prey upon his life.&rdquo; After Sanger added her voice to an organized tribute to Keller in 1938, writing that she had &ldquo;drawn courage&rdquo; from Keller&rsquo;s achievements, Keller responded by calling Sanger&rsquo;s life work &ldquo;the greater achievement.&rdquo; By this stage in their careers, both women represented a radical self-independence and were thought of as two of the most skilled self-promoters and publicity generating figures of their time. They finally met in July 1944 at the home of well known atheist and Freethinkers of America president Joseph Lewis in Purdys, New York. (Keller to Sanger, Mar. 13, 1938 [LCM 8:1264].) After that first meeting, Keller wrote a friend: </p>
<blockquote>
  <p>&quot;I had wanted to know her for many years, and when the 'crisis' of contact came, her warm, rich personality justified my enthusiasm. She is indeed a truly great soul. Her instructive talk confirms my ideal as I picture her, despite imprisonment and calumny, choosing her own destiny and enabling unnumbered women to take independent charge of their lives and ensure the improved health and joy of their children.&quot;( Keller to Nella Braddy Henney, September 18, 1944, Henney Collection, Perkins School for the Blind; quoted in Nielsen, <em>The Radical Lives</em>, 27.) </p>
</blockquote>
<p>Keller later told Sanger that &ldquo;it seemed that we had known each other long as fellow-crusaders to liberate humanity. . . .&rdquo; Indeed, with their shared radical past and being just a year apart in age, they were immediately at ease with each other and enjoyed a warm friendship and correspondence over the next fifteen years. (Keller to Sanger, Aug. 5, 1944 [LCM 117:363].)</p>
<p>    About a week later the two were together in New York to help Pearl Buck launch a lecture series for her cultural exchange organization, the East and West Association. The three women joined other guests for a viewing of the film version of Buck&rsquo;s novel, Dragon Seed. A few days later Keller wrote, &ldquo;as we watched the nemesis of &lsquo;rugged individualism&rsquo; in that powerful film &lsquo;Dragon Seed,&rsquo;Then in September, Sanger had Keller and Polly I recognized your spirit in Jade who . . . .was ready to go down fighting for her people&rsquo;s freedom and woman&rsquo;s responsibility towards China&rsquo;s integrity.&rdquo; Thomson, Keller&rsquo;s interpreter and companion, to dinner at her Willowlake estate in Fishkill, New York to celebrate Sanger&rsquo;s birthday. Afterward, Keller thanked her profusely, writing in her usual gracious but florid style, &ldquo;There are many memorable days in my life, but none more precious than the day of exquisite hospitality, comradeship and stimulating talk you gave me at Willowlake . . . . Every moment . . . was vibrant with the inspiration and power your nobleness radiates and luminous with the dearness of family.&rdquo; Keller&rsquo;s description of the evening was filled with sensuous details: &ldquo;In what a poetically complete setting we passed the evening!--the house Mr. Slee had built for you after the pattern of Shelley&rsquo;s Sussex home, the delicate art in selecting the stones, the rain-sweet grounds sloping down to the lake, the laughter of little ones playing from room to room, the tall bayberry candles and fragrant garlands on the festive board, the turkey dinner both delectable and tenderly appealing in its associations.&rdquo; (Keller to Sanger, Aug 5 and Sept. 18, 1944 [<em>MSM</em> S24:363 and 308].)</p>
<p>    A few years later, following a fire that destroyed Keller&rsquo;s Arcan Ridge home in Westport, Conn., Sanger asked Keller and Thomson to live with her while they rebuilt. Keller, who had already found a temporary home, compared the offer to &ldquo;a warm hand clasping mine,&rdquo; and took the opportunity to tell Sanger that &ldquo;we think of you as we often do and give thanks at the remembrance of the countless mothers and children you are snatching from the sooty flames of ignorance and social injustice.&rdquo; (Keller to Sanger, Jan. 25, 1947 [MSM C8:161].) </p>
<p>    In 1952, Sanger invited Keller to attend the Third International Conference on Planned Parenthood in Bombay, prompting Keller&rsquo;s most extensive comments on birth control since 1915. In her extravagant prose, she told Sanger: </p>
<blockquote>
  <p>&ldquo;Not only have I continued to follow your work with loving admiration and expect ever greater results from your beneficence, I have also known of Nehru's statesmanlike interest in birth-control, and now I behold you and him and Lady [Dhanvanthi] Rama Rau working together -- a triple Hercules -- for the deliverance of a land long cursed with excess of population. . . . Now a tide of enlightenment, slow but sure, shall lift its healing waves from one end of the world to the other until every child has a chance to be well born, well fed and fairly started in life -- and that is woman's natural work as the creator of the human race.&rdquo; (Keller to Sanger, Dec. 8, 1952 [<em>MSM</em> C9:810].)</p>
</blockquote>
<p> The two aging reformers traded tributes into the 1960s. When they died two years apart, Sanger in 1966 and Keller in 1968, each was eulogized for humanitarian efforts to enlighten a new age, or in Sanger&rsquo;s words, for their common &ldquo;battle against the powers of darkness.&rdquo; (Sanger to Keller, Mar. 3, 1938 [LCM 8:1262].)
</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
