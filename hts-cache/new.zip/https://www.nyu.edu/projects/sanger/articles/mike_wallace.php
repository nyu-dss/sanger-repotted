
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #38 (Winter 2004/2005)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #38 (Winter 2004/2005)</h1>

<div class="maintext">
<h1>"30 Minutes with Mike Wallace"</h1>

<p>By 1957, birth control had gained wide acceptance in America. The movement&rsquo;s founder, Margaret Sanger, president of the International Planned Parenthood Federation since 1953, regularly accepted honors in recognition of her pioneering work for family planning. Yet Sanger and the subject of birth control had not fully broken through the television barrier, where topics in any way related to sexuality remained largely taboo. She had been interviewed on local Los Angeles television in 1952&ndash;a pseudo debate that deteriorated into a shouting match&ndash;but television had otherwise resisted the temptation to run a profile or network interview of Sanger, most likely due to the threat of Catholic boycotts of a program&rsquo;s sponsors. </p>
<p>Then along came Mike Wallace, a rising young television broadcaster with a blunt, often confrontational interview style, who was quickly building a reputation as a pioneer of substantive television journalism. After more than a decade as a successful radio announcer, narrator and actor, and several television shows, Wallace introduced the breakthrough <span class="title">Night Beat </span>in the fall of 1956. In this local New York show he established the interview technique that would make him among the most watched, respected and feared television journalists of all time; &ldquo;the Inquisitor,&rdquo; some labeled him then. He soon left <span class="title">Night Beat </span>for a national audience on the <span class="title">Mike Wallace Interview</span> on ABC in April 1957. </p>
<p>The 39 year old Wallace made contact with Sanger through Anne Kennedy, a mutual friend and Sanger&rsquo;s former secretary, then called Sanger on June 3, 1957 to invite her to appear on his program. His producer, Ted Yates, Jr., followed up with a letter in which he wrote: &ldquo;The issue is so vital, and so controversial that both Mike and myself feel that, despite the explosion it will cause, such a discussion is long overdue.&rdquo; Sanger had little time in her schedule for an interview in New York, but her secretary told Yates that she would not want to pass up the opportunity. (Ted Yates, Jr. to MS, June 4 and Jonathan Schultz to Yates, June 7, 1957 [<span class="title">MSM</span> 52:102, 137].) </p>
<p>However, sometime in early August, Sanger apparently indicated she was reluctant to be interviewed by Wallace because of &ldquo;things&rdquo; she had heard about the program. She also wrote Anne Kennedy that she had &ldquo;heard all sorts of rumors of how he sets traps for one and so forth!&rdquo; Yates responded with a letter that emphasized the historic importance of a national network interview for Sanger, claiming it would be a &ldquo;milestone.&rdquo; Wallace and his production company, he added, were fully prepared for the inevitable &ldquo;barrage of controversy&rdquo; that would be ignited. Wallace then called Sanger himself and convinced her to appear on his show in mid-September. She wrote her young granddaughters excitedly that soon &ldquo;you can see Mimi on television!&rdquo; (Ted Yates, Jr. To Jonathan Schultz, Aug. 12; Secretary to MS, Aug. 21; MS to Margaret and Nancy Sanger, Aug. 26; MS to Anne Kennedy, Aug. 28, 1957 [<span class="title">MSM</span> S52:512, 577, 595, 609].) </p>
<p>Just two weeks later, according to a secretary&rsquo;s transcriptions of Sanger&rsquo;s telephone calls, Wallace cancelled the interview due to Catholic pressure mounting against the show&rsquo;s sponsor, the Philip Morris tobacco company. According to Wallace, two priests threatened to expose him as an anti-Catholic, and also equated birth control with murder. Sanger responded: &ldquo;That&rsquo;s such an old gag, I&rsquo;ve heard that for years.&rdquo; She told Wallace not to act rashly but to sleep on it, and wrote her friend, the philanthropist Mary Lasker: &ldquo;It looks like Mike doesn&rsquo;t have the experience and courage to let the R. C.&rsquo;s [Roman Catholics] threaten as they wish but retaliate against them by standing firm on his agreement. But you know this has happened to me before.&rdquo; She whipped off another letter to Iphigene Sulzberger, wife of the <span class="title">New York Times </span>publisher, fully aware of its repercussions: &ldquo;To me this is most amazing conduct by Mike because once he lets the Roman Catholic Church tell him who he can and cannot have on his program, that is a threat to everything we stand for in this country!&rdquo; That letter resulted in an article in the <span class="title">Times</span>, stating that Wallace cancelled the interview because of &ldquo;pressure from two prominent Roman Catholic priests.&rdquo; Wallace denied that the Church had any influence and told the <span class="title">Times </span>he had never definitely scheduled Sanger, though &ldquo;Mrs. Sanger would make a valuable and worth-while interview.&rdquo; (MS, Mike Wallace, telephone conversation, Sept. 5; MS to Mary Lasker Sept. 5; MS to Iphigene Sulzberger, Sept. 5, 1957 [<span class="title">MSM</span> S52:658, 660, 662]; &ldquo;TV Interview in Doubt, <span class="title">New York Times</span>, Sept. 6, 1957.) </p>
<p>Infuriated by the Catholic threats and Wallace&rsquo;s indecision, Sanger went on the offensive, tentatively lining up an interview with a competing program&ndash;Wallace&rsquo;s old <span class="title">Night Beat</span>. As soon as Wallace learned of Sanger&rsquo;s gambit, he expedited a contractual agreement for an exclusive interview and scheduled Sanger for September 21 st, despite growing Catholic opposition. Sanger, still steamed, tried to firm up an appearance on <span class="title">Night Beat</span>, but that show&rsquo;s host, Leonard Zweig, deferred to Wallace out of professional courtesy. So Sanger packed her bags for New York, a reluctant guest on a controversial show in the one communications medium she had not yet mastered. (Telephone Conversations between MS and Wallace; and MS and Leonard Zweig, Sept. 6, 1957 [<span class="title">MSM</span> S52:667, 676].) </p>
<p>&ldquo;Good evening,&rdquo; Wallace began his live program in its new time-slot at 10pm on Saturday night, up against the formidable <span class="title">Gunsmoke</span>, &ldquo;what you&rsquo;re about to witness is an unrehearsed, uncensored interview on the issue of Birth Control. It will be a free discussion of an adult topic, the topic that we feel merits public examination. My name is Mike Wallace, the cigarette is Philip Morris.&rdquo; Filling the bare, darkened set with cigarette smoke, one spotlight on him, one on her, Wallace introduced Sanger as a crusader who opened the first birth control clinic, went to jail eight times, and suffered long separations from her children, a break-up of her first marriage and &ldquo;constant harrowing social abuse&rdquo; because of her allegiance to the cause of birth control. </p>
<p>Sanger looked all of her 78 years, the poor lighting and smoky haze accentuating a withered appearance. Weakened by heart problems over the past decade and a host of other ailments, her eyes showed the weariness of her battle to stay vital. She also seemed uncomfortable, fidgety, unsure where to look at times. But the interview started off well. She handled Wallace&rsquo;s first question, about the origins of her crusade, with relative ease, telling him: &ldquo;I saw women, who asked to have some means whereby they wouldn&rsquo;t have to have another pregnancy too early, after the last child, the last abortion, which many of them had. Certainly there are numerous things [...] that really made you feel that you had to do something.&rdquo; She also cited as a motivating force her mother&rsquo;s premature death after bearing eleven children. </p>
<p>Wallace, sounding like a prosecutor at times, suggested that maybe Sanger was &ldquo;driven emotionally toward the birth control movement because of antagonism toward the church&rdquo; stemming from her troubled upbringing with a Catholic mother and atheist father. She responded: </p>
<p>SANGER: No I don&rsquo;t think I had anything of the kind in mind&ndash;I was&ndash;I was what I would call a born humanitarian. I don&rsquo;t like to see people suffer, I don&rsquo;t like to see cruelty even to this day and in nursing you see a great deal of cruelty and unnecessary suffering. At that time, there was no opposition as far as the church was concerned, any church. It was mainly the law, Federal Laws and State Laws, that one had to&ndash;to think of. The church was not in my mind at all. </p>
<p>On the issue of population control, however, Sanger seemed less sure of herself. She seemed to have trouble hearing Wallace&rsquo;s questions and she began stumbling over her words, beginning a thought but not having a clear sense of where she was taking it. When Wallace turned again to the Catholic Church, Sanger regained some of her old vigor. Wallace asked her to comment on the official position of the Catholic Church on birth control&ndash;that any contraception is used &ldquo;unethically and unnaturally&rdquo; since &ldquo;the immediate purpose and primary end of marriage is the begetting of children.&rdquo; </p>
<p>SANGER: It&rsquo;s very wrong, it&rsquo;s not normal&ndash;it&rsquo;s&ndash;it has a wrong attitude towards marriage, toward love, toward the normal relationships between men and women. </p>
<p>WALLACE: Well the natural law they say is that first of all the primary function of sex in marriage is to beget children. You don&rsquo;t disagree with that? </p>
<p>SANGER: I disagree with that a hundred percent. </p>
<p>WALLACE: Your feeling is what then? </p>
<p>SANGER: My feeling is that love and attraction between men and women, in many cases is the very finest relationship; it has nothing to do with bearing a child, it&rsquo;s secondary many, many times and we know that&ndash;you see your birth rates and you can talk to people who have very happy marriages and they&rsquo;re not having babies every year. Yes, I think that&rsquo;s a celibate attitude [...] It&rsquo;s an unnatural attitude to take&ndash;how do they know? I mean after all, they&rsquo;re celibates. They don&rsquo;t love, they don&rsquo;t know marriage, they know nothing about bringing up children nor any of the marriage problems of life, and yet they speak to people as if they were God. </p>
<p>When Wallace asked Sanger what she thought the Church&rsquo;s motive was in forbidding birth control, Sanger refused to give an answer. </p>
<p>WALLACE: Have you heard it said, that the reason that the Church is against birth control is because they want more Catholics? </p>
<p>SANGER: I&rsquo;ve read it. </p>
<p>WALLACE: Do you believe it? </p>
<p>SANGER: Yes. If you read their papers at Boston, that that&rsquo;s what had happened in Boston in Massachusetts. They had simply outbred the Protestants and they&ndash;they&ndash;in Boston in Massachusetts they had control. I read that in their own papers. </p>
<p>The interview disintegrated from this point on as Sanger grew flustered over Wallace&rsquo;s successful reduction of the topic to a personal debate between Sanger and the Church. She now looked for traps and unfounded accusations, and sounded defensive and unsure&ndash;almost as if she was hiding something. She had prepared some index cards with possible answers to some of his questions, but never referred to them or used the material in any way. </p>
<p>Wallace presented the argument that birth control encouraged promiscuity, quoting from a magazine article that claimed it &ldquo;tends to weaken the moral fibre of the community. Immunity from parenthood encourages promiscuity, particularly when unmarried persons can so easily avail themselves of the devices. Do you doubt that?&rdquo; </p>
<p>SANGER: I doubt it. </p>
<p>WALLACE: You do. </p>
<p>SANGER: Certainly. </p>
<p>WALLACE: Then let me read from a news story in the Philadelphia Daily News on June 10th, 1942. The story quotes YOU as urging the Women&rsquo;s Army Auxillary Corps to give its members quote preventive measures against pregnancy&ndash;end quote and you add quote abortion and illegitimacy are bound to result if the Government doesn&rsquo;t recognize human nature. End quote. In other words you were not advocating&ndash;Christian morality, but rather ways [<span class="title">for</span>] single women to avoid bearing illegitimate children. </p>
<p>SANGER: Where was it taken from. </p>
<p>WALLACE: Philadelphia Daily News&ndash;June 10, 1942 direct quote from Margaret Sanger. </p>
<p>SANGER: I doubt it. I don&rsquo;t believe I ever made such a remark. </p>
<p>Wallace had dug up an apparent contradiction, for Sanger had in the past inferred that increased access to birth control reduced illegitimacy rates. She would not, however, publicly advocate birth control for unmarried women; it would have been politically detrimental to the movement to have its founder appear to support non-marital sexuality. Indeed, it was not until the 1972 Supreme Court decision in <span class="title">Eisenstadt v. Baird</span> that unmarried women could legally gain access to contraception. But instead of clarifying her beliefs and using the opportunity to comment on the immense burdens all women faced, especially during the war when they were often left to raise children alone, Sanger opted out with a denial. </p>
<p>Wallace then returned to Sanger&rsquo;s frustration with the Catholic Church, reminding her that she had earlier told one of the show&rsquo;s reporters that it was &ldquo;not only wrong it should be made illegal for any religious group to prohibit dissemination of birth control&ndash;even among its own members&ndash;in other words you would like to see the government legislate religious beliefs in a certain sense.&rdquo; </p>
<p>SANGER: Honestly,&ndash;the strangest things come from&ndash;that I said them (LAUGHS). I should like to know when. </p>
<p>WALLACE: Well, now you know that my reporter spent a good deal of time with you. He&rsquo;s a very accurate young-man&ndash; </p>
<p>SANGER: Yes. </p>
<p>WALLACE: And this is a&ndash;this is a specific quote. </p>
<p>SANGER: Well, I don&rsquo;t think I put it quite that way. </p>
<p>Wallace then quickly asked a question about Sanger&rsquo;s own religious beliefs: </p>
<p>WALLACE: Do you believe in God in the sense of a Divine Being&ndash;who rewards or punishes people after death? </p>
<p>SANGER: Well, I have a different attitude about&ndash;about a&ndash;the divine I feel that we have a divinity within us. [&hellip;] </p>
<p>WALLACE: Do you believe in sin&ndash;When I say believe I don&rsquo;t mean believe in committing sin&ndash;do you believe there is such a thing as a sin? </p>
<p>SANGER: I think the greatest sin in the world is bringing children into the world&ndash;that have disease from their parents that have no chance in the world to be a human being practically. Delinquents, prisoners, all such a thing just marked when they&rsquo;re born. That to me is the greatest sin&ndash;that people can&ndash;can commit. </p>
<p>WALLACE: But sin in the ordinary sense that we regard it&ndash;do you believe or do you not believe. </p>
<p>SANGER: What&ndash;what would they be? </p>
<p>WALLACE: Do you believe infidelity is a sin? </p>
<p>SANGER: Well, I&rsquo;m not going to specify what I think is a sin. I stated what I think is the worst sin. </p>
<p>After a commercial break, Wallace turned to the subject of divorce, asking Sanger&rsquo;s recommendations for reducing the divorce rate. When she focused on marriage counseling services at birth control clinics, he cut her short and asked the question that the interview had been building toward since his introduction: </p>
<p>WALLACE: May I&ndash;may I ask you this could it be that women in the United States have become too independent&ndash;that they followed the lead of women like Margaret Sanger by neglecting family life for a career? </p>
<p>He referred specifically to the independence she maintained in her second marriage to J. Noah Slee. Sanger responded by claiming she had enjoyed a happy marriage, but failed to explain how birth control allowed women to balance family life and careers or to respond to the veiled accusation that she neglected her own family to pursue a cause. Dumbfounded by Wallace&rsquo;s questions, and out of time, she could only muster a grandmotherly smile as she showed the camera snapshots of her grandchildren. She then obediently plugged the sponsor with an awkward endorsement: </p>
<p>SANGER: Mr. Wallace, I&rsquo;ve never smoked, but I&rsquo;m going to begin and take up smoking and use Philip Morris&ndash;as my&ndash;the cigarette for me to take. </p>
<p>When the smoke cleared, Sanger must have wished she had stayed in Tucson. Though friends and supporters congratulated her and uniformly attacked Wallace&rsquo;s interview technique, Sanger knew she had missed a rare opportunity to communicate her message to a wide audience. She wrote her niece: &ldquo;Don&rsquo;t be too distressed over the Mike Wallace Interview. I had a good time at those moments of his confusion! He was, of course, speaking for the R. C.&rsquo;s as instructed. It was sad I did not get in anything about world wide Birth Control work.&rdquo; To a friend who missed the interview, she wrote that Wallace &ldquo;got a few replies that knocked him pale in the face. I had a good time, even though the time was wasted as far as Birth Control was concerned. The questions he asked were old stuff to me. I&rsquo;d almost forgotten how I used to answer them.&rdquo; The <span class="title">Times</span> TV critic generally sympathized with her, regretting that &ldquo;Mr. Wallace seemed determined to explore the personal life of Mrs. Sanger rather than the truly significant aspects of her career. . . . Mrs. Sanger is far more stimulating to meet than Mr. Wallace&rsquo;s program suggested. (MS to Olive Byrne Richard and to Ellen Watumull, Oct. 9, 1957 [<span class="title">MSM</span> S52:940, 950]; <span class="title">New York Times</span>, Sept. 23, 1957.) </p>
<p>The mail Sanger received in response to the show was, according to her secretary, 2-1 in favor of birth control. Many women and couples wrote to request contraceptive information. The hate mail that survives is particularly odious. A Los Angeles viewer wrote her: &ldquo;Its just too bad that your mother didn&rsquo;t practice birth control 95 yrs ago when she had you &ndash; (because you look that old you old bag).... You&rsquo;re the most disgusting thing I ever had the misfortune to listen to&ndash;.&rdquo; A &ldquo;Catholic Parishioner and Mother of 6 beautiful Children&rdquo; wrote: &ldquo;You know, Mrs. Sanger, death comes quickly, but then for you, that should be no surprise, for many years, you and your clinics have meant death to many souls destined for eternity.&rdquo; Others offered prayers to save her soul. One woman told Sanger she was &ldquo;low in morality,&rdquo; but she seemed most concerned over Sanger&rsquo;s televised declaration to take up smoking with Philip Morris cigarettes: &ldquo;Now Mrs. Sanger, I doubt you ever learned nursing or you would know what effect tobacco has on the heart and mind.&rdquo; (Jonathan Schultz to Rita Quinn, Oct. 3; D. Savoie to MS, Sept. 21; &ldquo;Catholic&rdquo; to MS, Sept. 21; &ldquo;Friend&rdquo; to MS, Sept. 23, 1957 [<span class="title">MSM</span> S52: 892, 760, 792, 786].) </p>
<p>In December, Wallace sent Sanger an engraved cigarette box for the holidays. She wrote back: &ldquo;It is certainly a good reminder of a most amusing evening. . . . I have had so many letters, phone calls, and personal talks about the Mike Wallace interview. Some of my admirers hope to get a chance to &lsquo;kill&rsquo; you one day, because you caused them to spend their valuable time listening to &lsquo;crazy&rsquo; questions about the Roman Catholic religion and not a word about the world-wide spread of birth control practice and education. I have a letter from a listener who writes she is convinced that &lsquo;Mike Wallace is a Roman Catholic.&rsquo; So it goes.&rdquo; (MS to Wallace, Dec. 19, 1957 [<span class="title">MSM</span> S53:121].) </p>
<p>In a recent telephone conversation, Mike Wallace called Sanger a &ldquo;genuine pioneer.&rdquo; He did not remember her as being flustered or nervous, but rather &ldquo;sure of her ground.&rdquo; He certainly did not feel that his interview took her by surprise or that she was not fully aware of the kinds of questions he would ask and added that he is often asked for copies and transcripts of that interview. </p>
<p>If Sanger knew beforehand what to expect when she and Wallace went on camera&ndash;and she had been warned by others about his style and had presumably viewed his program prior to her appearance&ndash;she seemed wholly unprepared to have Wallace question her fundamental beliefs. Still, as the <span class="title">Times</span> TV critic wrote, &ldquo;It is not every day that birth control is discussed on evening network television.&rdquo; For Sanger, who had several times earlier in her career been arrested for discussing birth control in public, just to be on television was, as she told a supporter, &ldquo;a victory.&rdquo; (<span class="title">New York Times</span>, Sept. 23, 1957; MS to Helen Gorelick, Oct. 10, 1957 <span class="title">MSM</span> S52:962].) </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
