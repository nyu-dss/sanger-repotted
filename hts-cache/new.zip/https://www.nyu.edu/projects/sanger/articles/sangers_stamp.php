
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #45 (Spring 2007)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #45 (Spring 2007)</h1>
<div class="maintext">
<h1>"Sanger's Stamp of Approval"</h1>

<p>In February 1966, Senator Ernest Gruening of Alaska, a long-time Sanger friend and birth control supporter, wrote to Postmaster General Lawrence O&rsquo;Brien, the well-known Democratic Party strategist and advisor to Presidents Kennedy and Johnson, to ask the Post Office to issue a commemorative stamp in honor of Sanger. He had hoped to win approval of the stamp during Sanger&rsquo;s lifetime. O&rsquo;Brien replied that the Post Office was prohibited from using the portrait of a living individual. </p>

<p>Following Sanger&rsquo;s death in September of that year, Gruening contacted O&rsquo;Brien again. &ldquo;She was one of the great pioneers, and she was a woman who made a tremendous impact on history,&rdquo; he wrote, &ldquo;I feel that she is now entitled to recognition for her great, courageous, lone pioneering work in the birth control field.&rdquo; Gruening suggested that the Post Office announce plans for a Sanger stamp at the October 18 presentation to President Johnson of the first Margaret Sanger Award, given out by Planned Parenthood. (Ernest Gruening to Lawrence O&rsquo;Brien, Oct. 5, 1966 [Records of Harper &amp; Row, Columbia University Rare Book &amp; Manuscript Library].)</p>
<p>The Post Office could not meet such a short deadline but promised to present the Sanger stamp proposal to the Citizens&rsquo; Stamp Advisory Committee for consideration in 1967. The Committee was charged with narrowing down proposals and making a handful of recommendations, but the final decision rested with Postmaster O&rsquo;Brien. </p>
<p>Planned Parenthood sparked its lobbying network into action, asking the White House, congressmen and other political leaders on both the state and federal levels to write to the Postmaster and members of the Stamp Advisory Committee, which included the artist Andrew Wyeth. The wealthy editor and publisher Cass Canfield, then chairman of Planned Parenthood World Population, and Cordelia Scaife May, heiress to the Mellon fortune, took a special interest in the project and pressed the Planned Parenthood leadership to make the stamp a priority. (Jeannie Rosoff to Cass Canfield, Oct. 10, 1966 and Ira Kapenstein to Ernest Gruening, Oct. 12, 1966 [Records of Harper &amp; Row].)</p>
<p>From most perspectives, the timing could not have been better. Sanger&rsquo;s death renewed interest in her accomplishments and bought a reprieve from the controversy that followed her name. President Johnson did indeed accept a Sanger Award, something that could not have happened in any previous administration (though he did not accept in person). And the pill had proven wildly successful and had revolutionized family planning. Gruening and his growing stamp brigade could not be blamed for feeling optimistic that the time had come for the federal government to give Sanger her due. </p>
<p>However, a year passed and still no action had been taken. By late October 1967 several members of the Citizen&rsquo;s Stamp Committee and a number of congressmen had endorsed the idea, but Gruening&rsquo;s office now concluded that &ldquo;it will obviously take considerable public pressure.&rdquo; Planned Parenthood&rsquo;s Washington representative, Jeannie Rosoff, believed that the decision on a Sanger stamp would be made by Postmaster O&rsquo;Brien regardless of political pressure from family planning supporters. She wrote to Canfield and other Planned Parenthood officers that &ldquo;Larry O&rsquo;Brien . . . made it plain that he considers anything related to birth control controversial enough to bring him an additional problem, which he does not need.&rdquo; She went on to explain that &ldquo;the Post Office is now being sued for issuing a Christmas Stamp depicting a religious scene of Madonna and Child!&rdquo; In Rosoff&rsquo;s judgement O&rsquo;Brien wanted nothing to do with a birth control controversy and &ldquo;is pretty much impervious to pressure.&rdquo; O&rsquo;Brien was also in the midst of trying to convince Congress to replace the Post Office Department with a nonprofit governmental corporation; stamp selection was not a priority. (Laura Olson to Jeannie Rosoff and Jeannie Rosoff to Cass Canfield, Oct. 27, 1967 [Records of Harper &amp; Row].)</p>
<p>  Rosoff recommended that they back off for a while and see if positive Congressional action toward pending family planning legislation might affect O&rsquo;Brien&rsquo;s &ldquo;judgement of what is controversial.&rdquo; Or, she continued, Planned Parenthood could undertake a &ldquo;full blown 2- to 5-year campaign to enlist the support of women&rsquo;s groups all around the country, secure resolutions, petition Congressmen and Governors, etc. . . and promote the STAMP by whatever means possible.&rdquo; (Jeannie Rosoff to Cass Canfield, Oct. 27, 1967 [Records of Harper &amp; Row].)</p>
<p>It is not clear which strategy Planned Parenthood opted to follow as the paper trail grows thin after 1967. The Sanger stamp proposal was placed on the 1968 agenda for consideration by the Citizens&rsquo; Stamp Advisory Committee, but it did not make the cut in O&rsquo;Brien&rsquo;s final year as Postmaster &ndash; he resigned in the spring of 1968 to coordinate Bobby Kennedy&rsquo;s short-lived presidential campaign and then become Democratic national chairman (it was O&rsquo;Brien&rsquo;s office in the Watergate complex that President Nixon&rsquo;s re-election campaign broke into in June 1972). (Virginia Brizendine to Cass Canfield, Oct. 30, 1967 [Records of Harper &amp; Row].)</p>
<p>It may not have been controversy alone that kept Sanger&rsquo;s image off a stamp in the late 1960s. Each year some 4,000 organizations and individuals campaigned for their own commemorative stamp, and only about fifteen per year were selected. Requests came in from every group imaginable: Morgan horse owners, the National Basketball Association, Hemingway enthusiasts, the Naval Air Station in Lakehurst, NJ, and even a Hungarian group that wanted to celebrate the 1,000 birthday of the first king of Hungary. Everyone who was anyone in Washington had a stamp proposal they were pushing as a political favor or to please some constituency. With that sort of competition, could Sanger&rsquo;s image ever make it onto a stamp? (&ldquo;The Licker Lobby and the Stamp Wars,&rdquo; <em>Washington Post</em>, Apr. 9, 1971.)</p>
<p>It didn&rsquo;t seem likely. But in the spring of 1971, Postmaster Winton M. Blount announced that a family planning stamp would be issued later that year. Further delays pushed the unveiling to 1972. Finally, on March 18, 1972, despite objections from the Catholic Church about the government&rsquo;s intrusion into private lives, the Post Office issued a multicolored 8 cent stamp featuring the words &ldquo;Family Planning&rdquo; and depicting a husband and wife with their young son and daughter. And while the Postmaster made no reference to Sanger in his official launch of the stamp, he did acknowledge &ldquo;the need for family planning so that we may have a better America &ndash; a better world,&rdquo; and allowed for a &ldquo;first day cover&rdquo; &ndash; an envelope for collectors showing the stamp and cancellation marks &ndash; to carry Sanger&rsquo;s image and the quotation &ldquo;No Woman can call herself free . . . . until she can choose whether or not to be a mother.&rdquo; (<em>Washington Post</em>, Jan. 16, 1972; <em>New York Times</em>, Jan. 30 and Mar. 11, 1972.) </p>
<p>Planned Parenthood made the best of their long and ultimately unsatisfying wait by noting that the stamp constituted a form of acceptance by the Nixon Administration. &ldquo;We are still looked upon as kooks by many people,&rdquo; said PPFA president Dr. Alan F. Guttmacher at the unveiling ceremony. Guttmacher noted Sanger&rsquo;s battles with the Post Office earlier in the century when several of her publications were banned from the mails. Postal confiscations led to the 1914 indictments against Sanger for publishing the Woman. &ldquo;And now, a half century later,&rdquo; concluded Guttmacher, &ldquo;the Post Office has dignified the birth control movement by giving its stamp of approval.&rdquo; (&ldquo;Family Planning Stamp is Shown Here,&rdquo; <em>New York Times</em>, Mar. 18, 1972.)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
