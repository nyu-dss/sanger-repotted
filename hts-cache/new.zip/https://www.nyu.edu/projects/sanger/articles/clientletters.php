
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #57 (Spring 2011)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #57 (Spring 2011)</h1>
<div class="maintext">
<h1>"Client Letters--via Air Mail"</h1>

<p>Of the many thousands of letters that Margaret Sanger received from women and men seeking contraceptive advice, only a fraction came from outside the United States. Yet these letters, from all parts of the world, are among the most interesting client letters that survive today in the Sanger archive. As we are finding in our research on Sanger&rsquo;s international work for Volume 4 of<em> The Selected Papers of Margaret Sanger: Round the World for Birth Control, 1920-1959</em>, these letters are varied and revealing, providing a very different perspective on contraceptive knowledge and availability in certain countries and regions than we get from government and press reports or organizational materials. </p>
<p>As with the domestic client letters, only a fraction sent to Sanger survive today. Some were undoubtedly lost and many others probably destroyed for privacy reasons by one of Sanger&rsquo;s organizations. In most cases we do not have a personal response from Sanger. Because U. S. law prohibited sending contraceptive information through the mails, Sanger usually sent a form letter with instructions to contact a regional group or a birth control organization in England. </p>
<p>The foreign letters she received share many similarities with the American client letters, including a tendency to conflate contraception and abortion. Nearly all exhibit an honest poignancy and a sense of urgency. As a group these letters differ from the American ones in that they tend to be more formal (in part because of difficulties writing in English), and include many more letters from men. </p>
<p>Quite a few of the clients wrote to Sanger after reading Judge Ben B. Lindsey&rsquo;s <em>Companionate Marriage</em>, published in several international editions in the late 1920s and early 1930s. Lindsey included in his book information about Sanger and the American Birth Control League in New York (including its address). </p>
<p>What follows are excerpts from a selection of these overseas client letters, some of which will be included in Volume 4. The first letter is followed by a personal response from Sanger that is unusual in that it is one of the only times on record that she recommended a vasectomy. </p>
<h3><strong>From a husband and father in Gulbarga, India, Dec. 24, 1935 (LCM 17:1176-80)</strong></h3>
<blockquote>
<p><em> Ever since your advent in this country of hoary civilization I have been reading your lectures with the greatest interest and my wife and I myself want to follow your advice in regard to Birth control. As for morals and morality both of us have never as yet in all our lives gone for anybody else. My wife has given birth to 9 children out of which 6 are alive and we pray and put forth all our resources for their support and long prosperous life. But we are now at the end of our resources: my wife has lost all her vitality allthough she is still 28, and I can not earn more than what is barely sufficient for the present family. More than this it is most hard to get a good bridegroom of equal status &amp; respectability for the girls. </em></p>
<p><em>I am under a religious vow that I must not go to any woman other than my married wife. I am just over 40 when I am bound by a similar solemn vow not to marry again. What am I to do then? </em></p>
<p><em> Total abstinence or continence is not possible. I am not only a moral being but a religious man bound by many moral vows. Shall I break these vows? It is impossible while there is a flicker of life in me. </em></p>
<p><em> There is no alternative but the adoption of your method, and I crave your advice and guidance. </em></p>
<p><em> In your broadcast address in Bombay you declared that you have a safe and unfailing device which does not cost more than 14 annas and remains for a lifetime. I am amazed at the statement. </em></p>
<p><em> I have already used leather caps but they have neither been unfailing nor lasted more than a month. In spite of spending a lot on the leather caps I have had a child. </em></p>
<p><em> I beg therefore request you most earnestly to let me have an apparatus or two which may be easily fitted and may prove really &lsquo;unfailing&rsquo;. If you can supply such material your movement is bound to percolate to the masses in India in spite of organised opposition if any. </em></p>
<p><em> Please let me know where I can get your apparatus &amp; who can fit it. </em>(LCM 17:1176-80.) </p>
</blockquote>
<h3>Sanger&rsquo;s response, Dec. 30, 1935 </h3>
<blockquote>
<p><em>I received your interesting letter. I think you have a difficult problem but perhaps no more difficult than thousands of others who, like yourself, are trying to live fine, religious, ideal lives. I should suggest, after deep consideration, the following: </em></p>
<p><em> You already have as large a family as you are able to provide for. You have already taken a vow not to marry again. Total abstinence would not be advisable for you and yet it would probably bring you great unhappiness to break your vows. </em></p>
<p><em> As an answer to your problem I should suggest that you have the slight operation of vasectomy performed. </em>[...] </p>
<p><em>This may mean a trip from home for you but I assure you that the method is very simple. It takes no more than ten or fifteen minutes, only a little local anaesthetic is used, and you can leave for your home the same day. You will be in no way incapacitated in your sex life or in any other way. Thousands of men are having this done all over the world to save their wives from the hardships of too many pregnancies when other methods are not available. I personally know dozens of men who had it done ten or twelve years ago and have enjoyed good health and a happy love life every since. </em>(LCM 17:1212.) </p>
</blockquote>
<h3><strong>From a fianc&eacute;e in Tel-Aviv, Palestine, Dec. 11, 1930</strong></h3>
<blockquote>
<p><em>I am getting married in the near future, but as my bridegroom, as well as my economical condition obliges me to continue my work in the office, I am compelled to take steps not to become pregnant for some time. </em></p>
<p><em> I shall be therefore much obliged if you would kindly write me how to prevent pregnancy. </em>(LCM 19:628) </p>
</blockquote>
<h3><strong>From a wife and mother in Cotabato, Philippines, Sept. 4, 1951</strong></h3>
<blockquote>
<p><em>I have already five children and I suspect I shall have my sixth very soon. My husband often tells me to see the doctor about contraceptives. Both of us a agree to the idea but I cannot gather enough courage to have premature birth. </em></p>
<p><em> I shall therefore by very grateful if you can tell me a way to avoid conception without resorting to contraceptives to induce abortion. </em>(<em>MSM </em>S35:185) </p>
</blockquote>
<h3><strong>From a husband and father in St John&rsquo;s, Antigua, July 10, 1951 </strong></h3>
<blockquote>
<p><strong> &nbsp;</strong><em>I do not want to be an imposter, but I am just asking you to throw a little light on my ignorance </em>[. . . ] </p>
<p><em>Why I write to you, is not because I am a play boy that do not want any children, but I am a married father of 4 children the first one a boy was borned 1947 the second 1948 the third 1949 then I found things was getting too bad so I inquired and found out about this Randell Pessary which I used but June this year my wife gave birth to a little girl. I am 30 years of age and my wife is 28 years, we got married in 1946 and the cost of living have changed and its real tough to bring them the way one would like too. When my wife is to have a baby she always want me to be with her and I having to be there feel like a condemed murder. Please write as I am anxiously waiting to hear from you and I hope will not tell me to sleep on the roof. </em>(<em>MSM</em> S34:921) </p>
</blockquote>
<h3><strong>From a fianc&eacute;e in Riga, Latvia, Aug. 27, 1932</strong></h3>
<blockquote>
<p><em>I am now about to be married, but as I can&rsquo;t afford to have children in the first years, and as I do not wish to ruin my health by using uncomplete things, I beg you to send me informations about the newest and most secure scientific acquisitions on this matter. </em></p>
<p><em> I am 25 years old and my husband will be the first man in my life. I&rsquo;m stating this fact, because I wish you to give me your information not with the supposition, that I have had already experiences. </em>(LCM 20:479) </p>
</blockquote>
<h3><strong>From a wife and mother in Santiago, Chile, Nov. 30, 1931 </strong></h3>
<blockquote>
<p><em>In my deep distress I take the liberty to call upon you, as nobody else in this strange and oldfashioned country seems to be able, or wants to help me in my problem. </em></p>
<p><em> Six years ago I married a Chilean, and have had since then four babies, and a fifth is coming next month. My husband has a factory, but in these hard times same is not producing enough to keep his family properly. We had to give up our home and had to go and live with my husband&rsquo;s mother </em> [. . .] </p>
<p><em>We cannot go on like this having children every other year. The economic stress is too much for my husband and for me too. My health is suffering seriously. </em>[. . .] </p>
<p><em>I have a doctor, friend of the family, who would only be too glad to help me, but strange enough, doctors in this country never are trained in this most important knowledge. All they may ever chance to know are the usual dangerous chemicals etc. </em>[LCM 19:1147] </p>
</blockquote>
<h3><strong>From an American? wife and mother in Beirut, Syria, Aug. 28, 1932</strong></h3>
<blockquote>
<p><em>Kindly advise me how to prevent further pregnancies until we are ready for more children. </em></p>
<p><em> We are married 6 years. I&rsquo;ve had 3 children. 1 died and just recently I&rsquo;ve had to undergo an abortion because we cannot afford to keep servants and my youngest is still quite a baby and needs all my attention </em></p>
<p><em> It is very difficult to get this information here in the East. </em>[LCM 19:635] </p>
</blockquote>
<h3><strong>From a wife in Manchuria, Northeast China, July 20, 1932 </strong></h3>
<blockquote>
<p><em>I will be very grateful to you, if you will help me in sending some remedy to prevent conception. </em></p>
<p><em> I am a woman of fairly good health, but to have children will be dangerous for me and the babies. </em></p>
<p><em> I am married half a year, and am 20 years old. </em></p>
<p><em> To go visiting doctors every month is not good. </em></p>
<p><em> Please let me know the expense of the remedy and your advice. </em>(LCM 19:244) </p>
</blockquote>
<h3><strong>From a polygamist husband in Gold Coast, Africa, circa 1943 </strong></h3>
<blockquote>
<p><strong> &nbsp;</strong><em>I have the honour most respectfully to apply for of your special and particular catalogue. I have married two women, so try your best and send me some of catalogue. </em></p>
<p><em> Try your best and send it to me very instantaneous.</em> (<em>MSM</em> S23:510).</p>
</blockquote>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
