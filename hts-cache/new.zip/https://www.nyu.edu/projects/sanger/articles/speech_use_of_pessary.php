
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #27 (Spring 2001)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #27 (Spring 2001)</h1>
<div class="maintext">
<h1>"The Use of the Pessary"</h1>

<p><em>The Selected Papers of Margaret Sanger</em> will be published in four
volumes by the University of Illinois Press.  The first volume, The
Woman Rebel, 1900-1928, will be published later this year.  Approximately
250 letters, diary entries, speeches  and articles have been transcribed
and annotated.  Here's one example, an address by Sanger given at
a roundtable meeting for  members of the medical profession at the
First American Birth Control Conference.  The meeting, which took
place two days  before the Town Hall raid, gave doctors an opportunity
to compare notes on the effectiveness and safety of diaphragms and 
other available contraceptives.</p>

<p><em>The First American Birth Control Conference, held in New York City
from Nov. 11-13, brought together leading scientists, physicians, economists
and social workers, and other movement supporters and activists to undertake
a "wider investigation of the subject of birth control."  Sessions
were offered on health, social problems, population and war, as well as
the legal aspects of birth control in America.  At the conference,
Sanger launched the American Birth Control League (ABCL) and announced
plans for the opening of a clinic.  The following is an extract from
an invitation-only roundtable meeting for members of the medical profession
on contraceptive techniques and devices.  Prior to MS's comments,
chairman Lydia Allen DeVilbiss introduced the session and the four topics
under discussion: surgical methods; sterilization; mechanical and chemical
contraceptives; and miscellaneous methods.  Discussants included doctors
Edward W. Lee, William F. Martin, S. Adolphus Knopf, Alice Butler and Isabelle
McMillan. (Mistranscriptions by Sanger's staff have been corrected by the
editors, in brackets.) (MS to Friends, Sept. 28, 1921 [<em>MSM</em> S67:740];
First American Birth Control Conference, Program, Nov. 11-13, 1921 [<em>MSM</em>
S67:794].)</em></p>

<br />
<p><hr noshade="noshade" size="1" /></p>
<div align=right>
<p><em>[New York, NY, November 11, 1921]</em></p>
</div>

<p>MRS. MARGARET SANGER: Madam chairman, and friends.  In Holland the
particular method that is recommended there is the [occlusive] pessary. 
More than thirty five years ago at the medical congress of Amsterdam, the
physicians decided that this subject of birth control was one that must
be [taught] to their people if they would remain within their borders.
(<a href="#1">1</a>)  At once the medical profession began to test
out the use of a pessary.  They have from that time on used and recommended
what is called the [Mensinga] pessary, which has, I believe, seven sizes. 
It is a little different from the one used in England and also the one
used in the United States.  This is made of different material and
different sizes.  Altogether I have seen as many as fourteen different
pessaries devised and effected in Holland.  Now, the physicians soon
came to recognize that it was quite necessary to take their time, to find
a way to teach the woman who was normal the use of a pessary, and so Dr.
Rutgers, who was most interested in this subject at that time, has instructed
the nurses how to fit the pessary upon a normal woman who is not suffering
from disease.  It is most interesting to see these women come to these
clinics and to be there and to witness the instruction.  They are
first taught to douche.  A small syringe is used, and they are taught
the use of this syringe.  Next this pessary is inserted with soapsuds
and is fitted.  The nurse does this until she gets the correct size. 
When this round one does not fit, there is another kind which does fit
almost always. You see what that does?  It covers the whole wall.
(<a href="#2">2</a>)  It is not like the small American pessary which
I will show you later.  That is the kind of pessary that is used in
Germany, and in Austria, and in Holland.</p>

<p>This small pessary is the one that is used in France and now has been
taken on in England.</p>

<p>My personal experience from women whose records I have is that this
is the kind of pessary that accidents happen from.  This can be pushed
aside. (<a href="#3">3</a>)  It does not seem to have the same skin,
and it does not seem to fit so well over the cervix as that other kind
which is called here the ["mizpah"].  The top comes off and seems
to be a more practical kind. (<a href="#4">4</a>)</p>

<p>This kind, the little one, the French pessary, has been used in France
for many years, and of course there have been no records kept so you cannot
tell how many times this has failed.</p>

<p>In England today this is the method being used there in the so-called
mother clinics. (<a href="#5">5</a>)  In America we have the records
of the 1250 families who have used methods successfully for at least one
year; the pessary, 335 families have used the pessary followed by a douche,
of which 265 have used the douche following the use of the pessary; the
condom&ndash;355 people have used the condom successfully, and 171 of these
people have followed the use of it by a douche; next on record is the suppository,
181 families have used suppositories, and 108 have followed it by a douche. 
The other methods that are here, an antiseptic douche, only 264 people. 
Most of us know that an antiseptic douche is not a preventative, but is
a hygienic measure.  Coitus [interruptus], 175 families have used
that method, 61 have followed by a douche. (<a href="#6">6</a>)</p>

<p>This is recent information we have had of people in the United States
who have used those methods and have been willing to give us the information.</p>

<p>As far as pessaries are concerned, I think that the kind used in Holland
is the best.  The records there for five years show that there were
only 1% failure, and five years previously 3% were failure. (<a href="#7">7</a>) 
But they claim that if a woman is normal, if her organs are normal, and
if she is taught and knows how to insert a pessary, that this practice
cannot fail.</p>

<p>Now, they do not advise the woman to leave this in the body only over
night.  The next day when the husband is gone and the children are
out at school, the woman is advised to take a cleansing douche and to wash
the pessary and put it away.  The reason they like it best is because
it is not expensive; the only cost is its first outlay.  And before
the war they had the right kind of rubber and it was supposed to last from
three to five years, and the charges were something like a gilder or a
gilder and a half, which meant about sixty cents.  Altogether the
pessary is considered in Holland and in France the most successful method
of birth control. (applause)</p>

<p>THE CHAIRMAN:  I have asked Mrs. Sanger if this type of pessary
was available in America.  And she told me not this kind.  In
as much as this is the kind we are able to get in America, I would like
to ask her if they use an ointment or something like it in connection with
this.</p>

<p>MRS. SANGER:  The idea is this.  A little powder, any antiseptic
dry powder in the cup before it is put on doubly secures against pregnancy,
particularly if it is well fitted. (<a href="#8">8</a>) That is always
one reason why I have stood so definitely for the principle of birth control
being disseminated by the medical profession.  As a nurse myself,
I know that all women are not alike, that they are different.  That
it means individual examination or individual instruction.  And with
powder placed in the cup before it is inserted, and with the woman taught
how to insert it, we have had a great deal of success, and very few failures
with the right kind of pessary.</p>

<p>QUESTION.  Will you kindly state what kind of powder?</p>

<p>MRS. SANGER:  Boric powder, and even bicarbonate of soda. (<a href="#9">9</a>)</p>

<p><hr noshade="noshade" size="1" /></p>
<p>Notes:</p>

<p><a NAME="1"></a>1. The Sixth International Medical Congress was held
Sept. 7-14, 1879, in Amsterdam. ("The Population Question in Amsterdam,"
The Malthusian [Oct. 1879], 66-71.)</p>

<p><a NAME="2"></a>2.  German physician Wilhelm Mensinga (using the
pseudonym Karl Hasse) designed the occlusive pessary in 1881. First used
widely by Johannes Rutgers in his Dutch clinics, it was nicknamed the Dutch
pessary or Dutch cap.  Because the occlusive pessary covers the entire
vaginal wall, rather than just the opening to the cervix, many American
birth control reformers preferred it to the cervical cap.  The Mensinga
pessary, made of a flat watch spring covered with black opaque rubber,
was produced in many sizes and required accurate fitting.  But the
Mensinga had a tendency not to return to its original shape after repeated
use.  As a result, Americans began using the Ramses, a slightly smaller
version of the Mensinga pessary, which used a coiled watch spring to more
effectively maintain its shape.  Because of the slight possibility
that some spermatozoa could pass round the edge of the cap, spermicidal
cream or jellies were used to seal this off. (Cooper, Technique of Contraception,
135-137; Himes, Medical History of Contraception, 318-21.)</p>

<p><a NAME="3"></a>3.  MS probably displayed a French cervical cap,
which just covered the mouth of the cervix. (Cooper, 54-61.)</p>

<p><a NAME="4"></a>4. The Mizpah, an American variation of the French cervical
cap, was constructed in two parts.  In Family Limitation, MS cited
it as <span class="italicText">one of the best</em>, but Marie Stopes attacked it on the mistaken assumption
that the user was supposed to leave the rim inside the vagina between use.
(Cooper, 57; Stopes, Contraception, 166.)</p>

<p><a NAME="5"></a>5. Stopes's Mother's Clinic used the "Pro-Race" cap,
a French cervical cap which she modified by adding a higher dome. (Cooper, 
54-61.)</p>

<p><a NAME="6"></a>6. Using the letterhead of the "Margaret Sanger Research
Bureau," MS sent out 31,000 questionnaires earlier that year to her client
list asking for information about family size, reasons for using birth
control and contraceptive methods employed.  Compilations of the results,
as well as transcriptions of nine responses, can be found on <em>LCM</em> 34:60-73.</p>

<p><a NAME="7"></a>7. MS probably got her figures on the efficacy of the
Dutch pessary at the recent International Congress on Contraceptives in
Amsterdam.</p>

<p><a NAME="8"></a>8. It was commonly held that neither pessaries or contraceptive
ointments by themselves offered the desired level of protection, but in
combination women could come close to 100% protection.  As Dr. James
Cooper noted, &quot;the pessary prevents a 'direct hit' or ejaculation into
the cervical canal, while the acid jelly kills all the sperms much more
quickly than would otherwise be possible." (Cooper, 145.)</p>

<p><a NAME="9"></a>9. Following MS's remarks, more than a dozen doctors
joined the discussion, debating the efficacy and safety of the pessary. 
The discussion then moved on to miscellaneous methods, including the safe
period, withdrawal, various suppositories, x-ray sterilization, and the
use of iodine drops in Russia.  Several doctors interrupted to warn
of the potentially harmful effects of chemical and mechanical contraceptives. 
A few doctors also broached the subject of how sexual positions and technique
could improve the effectiveness of coitus interruptus.  MS concluded
with a statement on the legal aspects of dispensing birth control. </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
