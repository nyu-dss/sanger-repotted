
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #17 (Winter 1997/1998)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #17 (Winter 1997/1998)</h1>
<div class="maintext">
<h1>"The Birds and the Bees With More Buzz"</h1>

<p>Short biographical treatments of Sanger in many encyclopedias and textbooks continue to portray
her as a suburban mom who stumbled into the issue of birth control on her rounds as a visiting
nurse in New York's Lower East Side. Her gradual education on this issue during a decade of
diligent work as a nurse, a mother, an organizer within the Socialist Party, and as a writer and 
reporter for several leftist publications remains a relatively unexplored area of Sanger's life.
Sanger's involvement in radical politics and society, starting a good five years before she
invented the term birth control, is often glossed over largely due to her autobiographical
subterfuge. In mid-career, in order to keep herself respectable in the midst of an increasingly
popular and broad-based movement, Sanger depicted herself during her more radical years as a
tag-along to her Socialist husband and a passive receptor of the latest political trend. "Almost
without knowing it," she wrote in her <em> Autobiography</em> about moving to New York City around
1911, "you became a comrade'" (<em>Autobiography</em>, p. 69). </p>

Likewise, many scholarly discussions and biographical sketches of Sanger fail to adequately
consider her sex education writings previous to the publication of her famously infamous 1914
pamphlet, <em> Family Limitation</em>. Several years before she began agitating for legalized birth
control, Sanger's articles on sex education secured many early followers of her work and
established her as a credible expert on sex hygiene and a transitional figure in the history of sex 
education writing. </p>
<p>
Two series of articles, <em> What Every Mother Should Know</em> and <em> What Every Girl Should
Know</em>, provoked serious discussion about sexuality and served as a primer on sexual hygiene and the
birds and the bees for several generations of Americans. Both series appeared in the New York
Socialist daily, <em> The Call</em>, from 1911 to 1913, and were republished in book form for more than
fifty years. They seem rather straight-laced and sanitized to our present-day, sexually enlightened
sensibilities, but few publications at the time included the type of frank language and explicit
instruction about basic sex functions found in Sanger's Socialist-tinged articles. Especially in
<em>What Every Girl Should Know</em>, Sanger tackled issues such as venereal disease and
masturbation, that were seldom mentioned at the time outside of medical literature or were
heavily bundled in euphemism.</p>

<p>Sanger's first major writing venture was a kind of accident of assiduous parenting. She and a
group of women in the New York suburb of Hastings, where the Sangers resided from about
1906 to 1911, put together little discussions and field trips on the facts of life for their children.
Sanger eventually wrote out each "lesson" in story form when Anita Block, the women's page
editor of <em> The Call</em>, requested material on sex hygiene and women's health. Titled
<em> What Every Mother Should Know, or How Six Little Children Were Taught the
Truth</em>, the series included seven chapters (stories) that illustrate and celebrate the "sex function" in both the plant and
animal world. Written for mothers to share with their young children (she recommended
discussing reproduction with them at about age four), the series is an account of how Sanger and
her friends engaged their children in learning about reproduction. Each lesson was crafted
around the family unit: the father stamen and mother pistil (alias Mr. and Mrs. Buttercup) who 
lived within the petals of their bright buttercup house; Mr. and Mrs. Toad, who feel the joy of
spring and "together go to the breeding pond;" Mr. and Mrs. Thrush, who did most of their
"love-making at sundown in song;" and so on. Though overly cute at times, Sanger does not let
her anthropomorphic characters distract the reader from the matter at hand. "I attempted," wrote 
Sanger in her <em>Autobiography</em>, ". . . to introduce the impersonality of nature in order to break
through the rigid consciousness of sex on the part of parents, who were inclined to be too
intensely personal about it" (<em>Autobiography</em>, p. 77). Yet Sanger's writing was anything but
impersonal; the stories were warm and light and the major themes unfolded gradually. It was in
sharp contrast to the facts of life literature of the time which tended to read like a cross
between medical text and Sunday school teaching.</p>
<p>
Sanger challenged the repressiveness of the day by completely separating sex from the obscene
and reintegrating it with nature. She even scolds mothers, parenthetically, for allowing their own
prudish natures to restrict their children's understanding. If there is one overriding message in the
series it is to be relaxed, open and honest with children in relation to sexuality, advice that
seemed innovative at the time, bolstered by examples that may have been better suited to 1960s
sensibilities, such as: </p>
<blockquote>
<p>    When children are very young get them accustomed to the naked body. Let them run about    naked at night, perhaps while undressing for bed. Let them bathe together with you. If this is    done very early at any early age you will soon find that his thoughts are clean regarding the    naked body. You can then tell him the names of the different parts, for he will most likely    ask, and his curiosity will often entirely cease. This is the type of boy who looks back upon
life and feels he has "always known" the clean and beautiful of life (<em>What Every Mother    Should
Know</em>, 1914, p. 56; LCM, 131:274).</p>
</blockquote>
<p>Yet Sanger remained quite timid, in this first project, about addressing human sexuality in any
depth, a noticeable weakness in the stories that may have prompted Anita Block to request a
second series dealing specifically with coming of age issues for girls. <em> What Every Girl Should
Know</em>, which appeared in installments every Sunday in <em> The Call</em> from November of 1912 to
March of 1913, began with a much more fallen view of the world, with Sanger sounding like a
troubled preacher: </p>
<blockquote>
<p>    Students of vice, whether teachers, clergymen, social workers or physicians have been    laboring for years to find the cause and cure for vice, and especially for prostitution . . .    Upon one point they have been compelled to agree, and that is that IGNORANCE OF THE
SEX FUNCTIONS is one of the strongest forces that sends young girls into unclean living    (Introduction,
<em>MSM</em> C16:0024).</p>
</blockquote>
<p>Her essays then were a remedy for such ignorance, presented without "technicalities" or "my
own ideals of morals." In rapid fire fashion, Sanger wrote columns on girlhood, puberty, "sexual
impulse," reproduction, "some of the consequences of ignorance and silence," and menopause.
She discussed sexual anatomy, menstruation, virginity, pregnancy, abortion, masturbation and
venereal disease in frank terms devoid of euphemism. Sanger did not, as some critics charged,
condone pre-marital sex or legalized abortions, she simply upended a few of the sexual myths of
the day (such as the male "sexual organs will become useless unless they are used in early<br />
manhood"), gave her stamp of approval to a few other age old beliefs (masturbation "drains and
exhausts the system of the vitality necessary for full development") and shared her knowledge as
a mother and trained nurse. Nevertheless, the rendering of such basic information, even in a
Socialist newspaper, generated a considerable response. <em> The Call</em> received both letters of
outrage: "I am very sorry, indeed, that <em> The Call</em> . . . should be so polluted
and have to be banished from our home circle as a paper unfit to be read by our sons and daughters. Such a
revolting article I have never read before" (<em>The Call</em>, December 29, 1912). And letters of
appreciation: "I am a women of most 66 years and I have learned more from them [Sanger's
columns] than from any books or even from my own life, and I am the mother of eight children!"
(<em>The Call</em>, March 2, 1913). 
</p>
<p>Regular readers were not the only ones raising eyebrows and clipping copy. Sanger's explicit
discussion of syphilis and gonorrhea under a column headed "Some Consequences of Ignorance
and Silence" lured anti-vice crusader Anthony Comstock from his censor's perch. The Post
Office banned <em> The Call</em> from the mails forcing the editors to omit Sanger's column. They
replaced it by printing "Nothing!" vertically in large type followed by "By Order of the Post Office." The ban was lifted several weeks later following public and political pressure, and
<em> The Call</em> published the censored column which also survives in all of the book editions of the series.
In one of the first of many comic government turnarounds during Sanger's life, the article on
venereal disease, according to historian Linda Gordon, was distributed by the government to 
U.S. troops during World War I, with of course no credit to the author. </p>
<p>
Sanger's brand of feminism may have been even more troubling to the old moral guards against
change, though less overtly threatening than references to anatomy and venereal disease. She
used <em> What Every Girl</em> as a kind of advertising trailer for her still evolving equation of women's
liberation and sexual freedom &ndash; the centerpiece of her monthly publication, <em> The Woman
Rebel</em>, published just a year later. In her column on sexual impulse Sanger writes, near the end: </p>
<blockquote>
<p>    "There will no doubt be a great change in woman's attitude on this subject in the next few    years. When women gain their economic freedom they will cease being playthings and    utilities for men, but will assert themselves and choose the father of their offspring . . .    There seems to be a general tendency on the part of the woman who is demanding political    freedom to demand sexual freedom also" (Sex Impulse. Part II,
p. 2, <em>MSM</em> C16:0046).</p>
</blockquote>
<p>What was ostensibly hygiene writing turned, by the end of the series, into rudimentary
propaganda for a still unformed movement for women's sexual emancipation.</p>
<p>
<em>What Every Girl Should Know</em> also found an extended life in book form. In 1927 Sanger
reissued the book with updates and additions under the title <em> What Every Girl and Boy Should
Know</em>. She included an expanded section on male anatomy and omitted critiques of capitalism
which had punctuated the original series. The book was translated into many languages and
republished numerous times in the U.S. and England, as recently as 1980.</p>

<p>Eclipsed by her leadership of the birth control movement, Sanger's contributions as a sex
educator and sexual advice writer have not been sufficiently appraised. Along with several other
contemporaries, two of whom, Antoinette Konikow and William Robinson, both published sex
education articles in <em> The Call</em>, Sanger helped lead sex education away from the chastity message
of 19th century medical advice literature, which was largely focused on the consequences of
greater sexual autonomy for men. Her writing complemented the social hygiene movement of the
early 20th century which advocated sexual education in all facets of society, chiefly to curb
venereal disease, but also to release non-procreative sex from Victorian era associations with
impurity. Sanger extended this discussion to girls (controversial even among progressives of the
day) and women who had little access to instructional or educational literature of any value
since Alice Stockham's sexual advice books published in the 1880s. Sanger contributions to sex
education literature and, of course, her leadership of the birth control movement helped make
women's sexuality, its repression, potential and liberation, the central theme for most of the
important sex education literature of the pre- and post-war eras. <em> Our Bodies
Ourselves</em>, first published in 1971, and scores of other publications devoted to educating women about their<br />
health and sexuality, can trace their lineage directly to Sanger's bold and enlightening first
publications.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
