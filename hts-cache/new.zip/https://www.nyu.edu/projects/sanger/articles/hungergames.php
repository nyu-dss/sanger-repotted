
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #61 (Fall 2012)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #61 (Fall 2012)</h1>
<div class="maintext">
<h1>"Sanger's Hunger Games: A Post-War German Odyssey"</h1>

<p>&ldquo;Dead, crushed, broken,&rdquo; was how Margaret Sanger described Berlin when she arrived in August 1920. &ldquo;People have forgotten how to smile,&rdquo; she wrote after touring one neighborhood, &ldquo;millions of children do not know how to laugh or play.&rdquo; (MS, &ldquo;Women in Germany,&rdquo; <em>Birth Control Review</em> 4:12 [Dec. 1920]: 8.)</p>
 <p>Although she had read about conditions in post-World War I Germany and heard firsthand reports from friends, including her travel companion, Ukranian-born anarchist, Rose Witcop, whose sister lived in Berlin, Sanger seemed taken aback by the hunger and misery she witnessed--and was ill-prepared to properly feed herself--during her several weeks in the defeated country. </p>
 <p>This was Sanger&rsquo;s first international trip since emerging as the leader of the growing birth control movement in the United States. For the first time she was a recognizable figure in much of Europe. She had last been overseas during her 1914-1915 exile when she traveled inconspicuously under an alias. Hastily planned and motivated in part by her quest to find the source of a new contraceptive jelly, Sanger&rsquo;s tour of several German cities in the summer of 1920 informed her reform work for years to come. Her insights into the plight of poor German women gave a new urgency to her belief in the need for women everywhere to define and assert their reproductive rights. Her observations of German children shaped her views on eugenics and humanitarianism. Everything she saw reinforced her faith in Malthusian theory--her understanding of how overpopulation inevitably leads to distress and human suffering, and forces political leaders to follow a path of expansionism and war.</p>
 <p>When Sanger crossed into Germany on August 22, she was rested and revitalized after spending much of the spring and summer in the British Isles. She had retreated across the Atlantic to escape infighting in the American movement and overcome fatigue and depression resulting from a flare-up of tubercular glands in her neck, her disintegrated marriage, and the 1915 death of her young daughter whom she still mourned. While in England and during forays into Scotland and Ireland, she indulged in physical and intellectual pleasures, rekindling her intimate relationship with the sexologist Havelock Ellis and beginning love affairs with Hugh de Selincourt, a bold writer of modest talent, and that indefatigable seducer, H. G. Wells, one of the most widely read authors in the world. She also gave an ambitious series of lectures, speaking mainly to working-class women. </p>
 <p>Flush with the bloom of new love and in better physical and spiritual (she had delved into mysticism and the occult while in England) health than she had been in months, Sanger descended into the hell on earth that was Berlin in 1920. Since the end of war, Germany had been wrestling with its inner demons and outside avengers. Defeat, political instability, and the harsh terms imposed by the Treaty of Versailles created a state of economic chaos. The country reeled from mass unemployment, severe inflation, violent agitation and widespread disillusionment. The democratic Weimar Republic, formed after the German Revolution of 1918, came under attack from both sides of the political spectrum and failed to adequately respond to shortages of food and fuel. Influenza and tuberculosis decimated the weak. Rampant venereal disease infected returning troops and refugees. Many Germans were malnourished and poorly sheltered. Berlin in particular exhibited a cruel juxtaposition: human deprivation among the poor and working-class; a perverse gluttony for luxuries and pleasure among the wealthy. &ldquo;Only those who are prepared to renounce the world and its delights should venture here,&rdquo; advised a correspondent for the <em>London Daily Mail</em>. (Alexandra Richie, <em>Faust&rsquo;s Metropolis: A History of Berlin</em> [New York, 1998], 302-24 ; <em>Washington Post</em>, Apr. 25, 1920; <em>New York Times</em>, Jan. 18, 1920 [quote].) </p>
 <p>On August 22, after a short stop in Amsterdam, Sanger and Rose Witcop arrived in Neuk&ouml;lln, a working-class area that in 1920 became a borough of Berlin. They stepped off the train late at night, and Sanger noted the eerie blackness that greeted them, with no street lamps lit or lights in windows. They stayed for a few days with Witcop&rsquo;s sister and brother-in-law, Mildred and Rudolph Rocker, anarcho-syndicalists who had been close to Lorenzo Portet, the anarchist and educator who had been Sanger&rsquo;s lover during her 1915 European exile. </p>
 <p>The Rocker&rsquo;s apartment was small, and they had no food to share with guests. As Sanger quickly learned, food was an obsession in Berlin. Life revolved around finding sustenance, and it fell to women to feed their families. She wrote,</p>
 <blockquote>
   <p>. . . the women are the sufferers. The best food must be given to the men. Charities and kind societies give the children cocoa and soup, but the mother goes without, or lives on what she can scrape together. Her life is a constant hunt for food; all her days are occupied with the problem of feeding her family. It is a terrible problem! (MS, &ldquo;Women in Germany,&rdquo; <em>Birth Control Review </em>4:12 [Dec. 1920]: 9.)</p>
 </blockquote>
 <p>It had been even worse during the Allied blockade, which had ended the year before. Women told Sanger that they subsisted on turnips for weeks at a time. </p>
 <blockquote>
   <p>They ate turnip soup, turnips raw, turnips mashed, turnip salad, turnip coffee, until the whole system revolted physically against the sight of turnips. The contact of other persons in the trains and carriages, for even a few minutes, became unbearable from the reeking odor of turnips. (MS, &ldquo;Women in Germany,&rdquo; [Dec. 1920], 9.)</p>
 </blockquote>
 <p>Mothers shared with Sanger their daily concern, &ldquo;the torture of watching their children slowly starve to death under their eyes; little faces growing paler, eyes more listless, little heads drooping day by day, until finally they did not even ask for food at all.&rdquo; (MS, &ldquo;Women in Germany,&rdquo; [Dec. 1920]. 9.)</p>
 <p>With no ration card and not enough money to buy the hyperinflated food in restaurants and hotels, Sanger complained of being &ldquo;constantly hungry.&rdquo; After two weeks she was desperate for a filling meal. &ldquo;I found myself haunting grocery stores like a hungry animal,&rdquo; she wrote, &ldquo;examining each new article avariciously.&rdquo; Nothing satisfied her hunger but eggs, &ldquo;and these,&rdquo; according to Sanger, &ldquo;along with milk, could be purchased only on prescription from a doctor.&rdquo; After ogling a tin of evaporated milk, something she had always disliked, she became &ldquo;disgusted with myself.&rdquo; But the pangs of hunger would not go away. After days of almost nothing to eat, a neighbor of the Rockers, a mother of three, gave Sanger some bread and potatoes even though she had little food to spare. Sanger broke into &ldquo;tears over her generosity.&rdquo; (MS, <em>An Autobiography</em>, 281-82.)</p>
 <p>Along with trying to satisfy her own hunger, Sanger studied how a lack of food affected the women she met--specifically how it changed fertility patterns. She later claimed that she had taken this trip, in part, to investigate the link between &ldquo;vitamins and fertility.&rdquo; Sanger had read compelling evidence put forth by a German doctor at the United Medical Societies Congress in Berlin in 1918 that &ldquo;the lack of fats and other foods necessary to the system, caused the suppression of the menses.&rdquo; While Sanger may have found some anecdotal confirmation for this thesis, population statistics did not bear it out. The German birth rate did decrease during the war when many men were off fighting and because of greater demand for and access to contraception, but it increased after the war and declined only slightly in the early 1920s. (MS, <em>An Autobiography</em>, 280 [quote]; MS, &ldquo;Women in Germany,&rdquo; <em>Birth Control Review</em> 5:1 [Jan. 1921]: 10; B. R. Mitchell, <em>International Historical Statistics</em>, 3rd Edition [New York, 1992], 102.)</p>
 <p>At least among working-class and radical women, the groups Sanger came in contact with the most, infertility did not seem to be an issue. In fact, many of these women demanded better access to contraception and spoke out for the legalization of abortion, a stand Sanger struggled with but came to understand. She wrote, </p>
 <blockquote>
   <p>The women say quite frankly, in defending abortion, that if it is right for the State to take a child and kill it in wars, after it has been brought into the world, then it is equally just to assert the mother&rsquo;s right to prevent its coming here. . . . This may sound cruel and inhuman to many of us in England and America who do not advocate abortions, but no one can refute its logic. It is a noteworthy fact that not one of the women to whom I have spoken so far believes in abortion as a practice; but it is principle for which they are standing. (MS, &ldquo;Woman in Germany,&rdquo;[Dec. 1920], 8.)</p>
 </blockquote>
 <p>A movement to reform German birth control and abortion laws had begun shortly after the war ended. Socio-economic factors created an unprecedented desire among all classes to limit family size. Contraceptives could be manufactured and sold, but the government enforced prohibitions against open advertising of products. Abortion was illegal except for specific medical needs. As Sanger found, there was growing support for birth control and the legalization of abortion as preventive measures to reduce the number of dangerous illegal abortions which had risen dramatically since the war. The Social Democratic party proposed legislation to legalize first trimester abortions, while the Independent Socialists petitioned the Reichstag to legalize abortion without restrictions. Both attempts failed. (Atina Grossmann, <em>Reforming Sex: The German Movement for Birth Control &amp; Abortion Reform</em>, 1920-1950 [New York, 1995], 8, 15; James Woycke, <em>Birth Control in Germany, 1871-1933</em> [New York, 1988], 144-45, 169.) </p>
 <p>As in the United States, significant opposition to birth control reform, Sanger learned, came from the medical profession. She interviewed a number of physicians, and none of them thought that birth control should be encouraged in Germany. Most believed &ldquo;that what Germany needed was children and lots of them.&rdquo; She added, &ldquo;I found several, however, who stood for women&rsquo;s right to have abortions--but for contraceptive advice, NO. &lsquo;It is knowledge that is too dangerous,&rsquo; said one very well known gynecologist to me.&rdquo; He added, to Sanger&rsquo;s &ldquo;horror,&rdquo; that they would &ldquo;never give over the control of our numbers to the women themselves. What, let them control the future of the human race? With abortions it is in our hands; we make the decisions, and they must come to us.&rdquo; (MS, <em>An Autobiography</em>, 286 [quote 1 and 3]; MS, &ldquo;Women in Germany,&rdquo; [Jan. 1921], 8 [quote 2].)</p>
 <p>Despite such misogynist thinking, Germany was rapidly becoming more open about sexual discourse. Long a leader in sexual science, Germany experienced a renaissance in this field in the early Weimar years that corresponded with a popular movement to end the repressive policies of the Imperial era and the increasing sexualization of popular culture. Among the most visible figures to emerge in this movement for sexual enlightenment was Dr. Magnus Hirschfeld. Best known as a pioneer advocate for homosexual rights, Hirschfeld founded the Institute for Sexual Science, a research and counseling facility, in Berlin in 1919. With a letter of introduction from Havelock Ellis, Sanger visited Hirschfeld at his Institute on September 1, writing ,&ldquo;It is the only one of its kind in the world. Here is a beautiful dwelling, with palatial and spacious rooms, which at one time belonged to a member of the royal family.&rdquo; She found Hirschfeld to be well informed on birth control and receptive to her work. He also had an idea about who might be manufacturing the contraceptive jelly Sanger sought, and he gave her the address of a firm in Dresden. (Grossmann, <em>Reforming Sex</em>, 16; MS, &ldquo;Women in Germany,&rdquo; [Jan. 1921], 8.)</p>
 <p>During the second week in September, Sanger began in earnest her search for the mysterious chemical contraceptive, traveling to Dresden on September 7. She had first learned about the jelly in 1914 when Havelock Ellis mentioned coming across an advertisement in a German medical journal. It was rumored to be safe, one-hundred percent effective, and government-approved. But the address she got from Magnus Hirschfeld was a bust. She queried several doctors in Dresden and met with the German feminist and birth control pioneer Marie Stritt, a member of the League for Protection of Motherhood and Sexual Reform. No one knew about the jelly.</p>
 <p>Sanger moved on the Munich on September 10 to investigate a working-class birth strike that, she claimed, had arisen without organization. &ldquo;The common sense of the German women has caused it,&rdquo; Sanger wrote, &ldquo;. . . the women are agreed that their condition is such that it is impossible for healthy children to be born or reared.&rdquo; While there, Sanger continued to visit radical figures and even attended a meeting of the Communist Party. Munich seemed like a vacation haven after Berlin and the north. Food was more plentiful, and Sanger enjoyed dinners in restaurants, formal teas, a Fritz Kreisler concert, and a night at the opera. (Sanger&rsquo;s 1920 Calendar [LCM 1:412-413].)</p>
 <p>On advice from someone in Dresden, Sanger also looked for her contraceptive manufacturer in Munich. More inquiries led her to a chemist in Ravensburg, a couple of hours southwest of Munich, who agreed to meet Sanger in nearby Friedrichshafen, away from his factory, fearful she would steal his formula. The chemist offered Sanger several sample tubes of jelly and made tentative arrangements to ship more through a representative in New York. In her autobiography, Sanger leaves out many details, including the name of the chemist and his product. She does boast that her discovery of this chemist &ldquo;inaugurated a new phase of the movement--the use of chemical contraceptives.&rdquo; But that was not the case. Chemical suppositories and douches had been around for many years, and jellies and pastes had been used as a stand alone contraceptive and with vaginal pessaries (diaphragms) before Sanger&rsquo;s German find. Oddly, Sanger did not share this new product when discussing contraceptives at a special meeting for doctors at the First American Birth Control Conference just a year later. In fact, at that meeting she recommended an &ldquo;antiseptic dry powder&rdquo; to be applied to the pessary before insertion, rather than a jelly. She later wrote that the ingredients in the jelly were too expensive to mass produce. (Sanger&rsquo;s 1920 Calendar [LCM 1:416; MS, <em>An Autobiography</em>, 290, 363; First American Birth Control Conference, Nov. 11, 1921 [<em>MSM</em> S67:754-57]; Norman Haire, <em>Birth-Control Methods</em> [London, 1936], 75.)</p>
 <p>Sanger may have dramatized her hunt for the contraceptive jelly to divert attention from her meetings with anarchists and other political radicals in Germany. The Red Scare hysteria in the United States after the war rendered such associations personally dangerous and potentially harmful to the birth control movement, and there was no point in raising questions about her objectives in Germany--one of which was to inspire various leftist and women&rsquo;s groups to carry the birth control torch. However, over the next decade, a number of these contacts, both on the left and among more conservative factions, helped Sanger and socialist activist, Agnes Smedley, assist in strengthening the German birth control movement and setting up clinics in Berlin.</p>
 <p>Her motives aside, Sanger returned home with new international credentials and the certain belief, as she wrote writer Theodore Dreiser, that &ldquo;the idea of birth control is the solution of not only the problems of the individual mother, but the population question as well.&rdquo; She would use the example of Germany, its rapid population growth in the nineteenth century and aggressive imperialism, to warn Japan in 1922 and Italy later in the decade, against this destructive path, and in urging international bodies to take up the population question. (MS to Theodore Dreiser, Feb. 1, 1921 [<em>MSM</em> C1:612].) </p>
 <p>If the trip confirmed Sanger&rsquo;s long-held assumptions about population pressure and war, her brief interactions with women and children caught her emotionally off guard and challenged whatever remaining faith she had in humanitarian efforts. &ldquo;The women,&rdquo; she later wrote, &ldquo;broke down all the reserves of my emotion.&rdquo; And time and again she recoiled from the pained and pitiful expressions on children&rsquo;s faces. One experience in a Munich hospital, observing children whose &lsquo;little mouths&rdquo; were &ldquo;covered with horrible sores,&rdquo; gave her nightmares &ldquo;for weeks.&rdquo; (MS, <em>An Autobiography</em>, 284 [quote 1] MS, &ldquo;Women in Germany,&rdquo; [Jan. 1921], 9 [quote 2].)<br />
 </p>
 <p>Sanger had been critical in the past of charitable efforts that would alleviate but offer no real solutions to human suffering. Hardened by her time in Germany and angry about government resistance to contraceptive programs throughout Europe, she now began to ask whether it might be more merciful and in the best interests of future generations to let the weak and suffering die. &ldquo;The old fashioned warrior who entered with sword and killed his victim outright has my respect after witnessing the &lsquo;Peace&rsquo; conditions of Germany,&rdquo; she wrote shortly after leaving Europe. She aimed for shock value a few months later in a dinner speech before the Women&rsquo;s Economic Club in Philadelphia, when she suggested that rather than sending aid for starving children in Germany and other European countries, the United States should &ldquo;send over a quantity of chloroform to put them out of their misery,&rdquo; because it would be &ldquo;the best thing for the children and for the future of the world.&rdquo; Provocative to a fault, Sanger knew how to get an audience&rsquo;s attention. She then put the responsibility for a better future squarely on &ldquo;the shoulders of the women.&rdquo; &ldquo;Diplomats may make treaties and peace,&rdquo; she told them, &ldquo;but as long as women continue to breed an explosive population they will transform these agreements into scraps of paper.&rdquo; (MS, &ldquo;Women in Germany,&rdquo; [Jan. 1921]: 9 [quote 1]; <em>Philadelphia Inquirer</em>, Feb. 4, 1921 [quotes 2-3].)    </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
