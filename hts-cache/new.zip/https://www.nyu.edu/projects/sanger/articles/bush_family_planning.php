
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #44 (Winter 2006/2007)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #44 (Winter 2006/2007)</h1>
<div class="maintext">
<h1>"Bush Family Planning"</h1>

<p>Since his arrival in the White House in 2001, President Bush has never clearly stated whether or not he supports the right to use contraception. The administration&rsquo;s policy statements on reproductive health have repeatedly conflated contraception and abortion, and the Bush team has acquiesced to the religious zealotry that rules the far right on any matter related to birth control education and contraceptive availability. The press has confronted the administration on specific policies, such as cuts to international family planning programs and the FDA&rsquo;s blatant obstructionism that for many months kept the emergency contraceptive known as Plan B under-the-counter and out of women&rsquo;s reach. Commentators have taken jabs at the administration&rsquo;s all-abstinence approach to sex education. And there has been considerable discussion about Bush&rsquo;s political calculations regarding these issues. More recently, political analysts have treated Bush&rsquo;s relentless attacks on contraceptive technology as one front in his overall war against scientific advancement whenever it encroaches on moral ground. But there has been very little attention given to Bush&rsquo;s personal views on birth control. The press has never pushed Bush to discuss birth control nor has it shown much interest in demonstrating just how far Bush has traveled from a long family history of support&ndash;though closeted at times&ndash; for planned parenthood at home and abroad.</p>

<p>Margaret Sanger shared the <a href="../aboutms/organization_ppfa.php">Planned Parenthood Federation of America</a> (PPFA) masthead with the current president&rsquo;s grandfather and George Bush, Sr.&rsquo;s father, businessman Prescott S. Bush, who in 1947 served as the treasurer of Planned Parenthood&rsquo;s first nationwide fund-raising campaign. This at a time when contraception was illegal in his home state of Connecticut. A moderate Republican, Prescott Bush soon regretted this gesture. During a tight senate race in 1950, columnist Drew Pearson disclosed Bush&rsquo;s PPFA ties in a national television commentary just days before the election. Bush lost by about a thousand votes in a state with a large Catholic population quite used to organizing to oppose birth control. &ldquo;Many political observers felt a sufficient number of voters were swayed by his alleged contacts with the birth controllers to cost him the election,&rdquo; wrote Prescott&rsquo;s son, George H.W. Bush, years later. &ldquo;The subject was taboo&ndash;not only because of religious opposition but because at that time a lot of people were unwilling to discuss in public what they considered a private matter.&rdquo; It is interesting to note that George Bush, Sr. characterized his father&rsquo;s contact with the birth control movement as &ldquo;alleged.&rdquo; The family vehemently denied that Prescott Bush had any association with the PPFA, a denial, as Kitty Kelley pointed out in her 2004 biography of the Bush clan, that the family never retracted. Turning his back on years of support for PPFA, Prescott Bush was elected to the Senate in 1952. (George H. Bush, foreword to Phyllis Tilson Piotrow, <em>World Population Crisis: The United States Response</em> [1973], vii; Kitty Kelley, <em>The Family: The Real Story of the Bush Dynasty</em> [2004], 114-16.)</p>
<p>Following his father, Prescott, George H. W. Bush became a vocal advocate for family planning while he served as a U. S. Congressman from Texas. He wrote a constituent in 1970: &ldquo;I introduced legislation earlier this year which would provide federal funds for research in family planning devices and increased services to people who need them but cannot afford them. We must help our young people become aware of the fact that families can be planned and that there are benefits economically and socially to be derived from small families.&rdquo; (George Bush to Mrs. Jim Hunter, Jr., Oct. 23, 1970 [Virginia B. Whitehill Papers, DeGolyer Library, Southern Methodist University].)</p>
<p>Congressman Bush worked in a bipartisan spirit and carefully considered PPFA proposals in helping to craft family planning bills in the late 1960s. &ldquo;. . . I was impressed,&rdquo; he wrote several years later, &ldquo;by the sensible approach of Alan Guttmacher the obstetrician who served as president of Planned Parenthood. It was ridiculous, he told the committee, to blame mothers on welfare for having too many children when the clinics and hospitals they used were absolutely prohibited from saying a word about birth control. So we took the lead in Congress in providing money and urging - in fact, even requiring &ndash; that in the United States family planning services be available for every woman, not just the private patient with her own gynecologist.&rdquo; (Bush, foreword to Piotrow, <em>World Population Crisis</em>, vii.)</p>
<p>Bush also backed increased U. S. support for international family planning programs. As chairman of the special Republican Task Force on Population and Earth resources, he was &ldquo;impressed by the arguments of William H. Draper, Jr. that economic development overseas would be a miserable failure unless the developing countries had the knowledge and supplies their families needed to control fertility.&rdquo; As the U.S. Representative to the United Nations he emphasized the need for a strong UN population control program. (Bush, foreword to Piotrow, <em>World Population Crisis</em>, viii.)</p>
<p>Again, like his father, George H. W. Bush reversed his stand and distanced himself from family planning when he ran for president in 1980. Similarly his son, President George W. Bush, has made every effort to appoint judges averse to protecting reproductive freedom and to shift the government away from the modest federal support for family planning his father helped establish. </p>
<p>Sanger once urged American women &ldquo;to have the courage to declare in public what they practice in private.&rdquo; The same should be said for American political leaders. (MS, NCFLBC Press Release, Oct. 24, 1935 [<em>MSM</em> S64:645].)</p>
<p><em>Editor&rsquo;s Note: Thanks to Kitty Kelley for first bringing the information about Prescott Bush&rsquo;s association with PPFA to our attention.</em></p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
