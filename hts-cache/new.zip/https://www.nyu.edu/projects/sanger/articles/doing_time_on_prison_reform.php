
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #18 (Spring 1998)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #18 (Spring 1998)</h1>
<div class="maintext">
<h1>"Doing Time on Prison Reform"</h1>

<p>During the first decade of Sanger's crusade to legalize birth control, she was often criticized for her unwavering commitment to a single campaign at a time when many reformers pursued multiple causes, linked together by political motif.  Sanger contemporaries ma Goldman and Elizabeth Gurley Flynn, and many less notable radicals
criss-crossing the country like Sanger in the 1910s, cultivated careers as professional agitators and are remembered today more for their political dedication and flamboyant personalities than for a single cause. But Sanger confessed disinterest in other social concerns once she declared birth control to be the most basic and most urgent solution to overcoming human misery. She privately and sometimes publicly discounted the work of other reformers, suffragists and social workers, remarking
dismissively: "Political nostrums and social panaceas are but incidentally and superficially useful.  They do not touch the source of the social disease" (<em>Woman and the New Race</em>, p. 6).</p>

<p>Yet even as the birth control movement coalesced around Sanger's leadership in the 1910s, and Sanger distanced herself from other causes, she periodically used her public prominence and access to the media to promote one issue apart from birth control: prison reform.  Sanger agreed with  the progressive prison reformers of the day, who concentrated their efforts on improving prison conditions, but she also tackled the issue from a more anarchist position, essentially challenging the need to incarcerate all but the most hardened and dangerous criminals.  </p>

<p>Sanger's interest in prison reform began as an outgrowth of her labor work in the early teens.  She joined a radical chorus that denounced the New York City corrections establishment, most notably its chief, Katharine Bent Davis, for mishandling several hunger strikes and prison uprisings, and for heartless treatment of inmates.  Sanger's brief period of public outspokenness on prison issues peaked immediately following her own and her sister, Ethel Byrne's, 1917 imprisonments for opening an illegal birth control clinic in Brownsville, Brooklyn.  But she revisited the issue a number of times during her career, aiding several convicts who wrote to her from prison, and is quoted as remarking years later that "the only great cause after birth control is won will be the investigation of the treatment of prisoners.  If I can't do it now, I'll book it for the next trip" (MS to Winthrop Cane, March 17, 1942, quoted by Ellen Chesler in <em>Woman of Valor</em>, p.  506; see also p. 158).</p>

<p>Sanger had been to prison before 1917.  As an IWW worker and New York Call reporter in 1913 she spent about a week in the Hazleton, Pennsylvania jail following an arrest for loitering while on picket lines during a mill strike. She heatedly wrote in the socialist <em>Call</em>  on the wretched conditions of the prison cells in Hazleton and the rebelliousness of the women strikers:

<blockquote>
<p>"Through the bars every morning at eleven o'clock comes the lone loaf of bread, which must serve until the next morning at the same time.  Two cups of water must serve as washing and drinking water.  No basin is provided for washing purposes; no blankets or covering of any kind; no comb, brush, soap towel, or anything for the ordinary decency of the prisoner is allowed her. Nor may any food from the outside be carried within. . . .</p>

  <p>	While we were locked up, the stench from the toilets became so strong that the girls called to an officer to flush th.  He refused to do this, and so the prisoners decided to let some of the loungers in the next room have some of the odors.  They accordingly ptied the toilets with the assistance of their tin cups into the cell corridors which all run into the Mayor's office.  The officers came running in and asked what in heavens name they were up to now!  Several officers at once cleared out the place, scrubbed and disinfected the floors, and those of the girls who could sleep in the sheetiron beds turned in for the night. . . .  Roaches and bugs infest the cells, and as you are about to get friendly with those a huge rat comes upon the scene to fight it out with you about that loaf of bread. The girls decided they'd rather be friends with the rat and give up the bread than show any fear to the	officers.  Nevertheless, a rat is a rat to a woman." ("With the Girls in Hazeltown Jail", <em>The Call</em>, April 13, 1913, <em>MSM</em> C16:65).</p>
</blockquote>

<p>Her brief prison stay and the experiences of many radical friends who had spent time behind bars convinced her that the prison system in the 1910s was badly in need of reform.  In particular, Sanger showed concern for prostitutes who, at the height of World War I, received harsh treatment from law enforcement agencies and in the prison system due to a prevalent fear that they were infecting America's man-power with venereal disease.  She stated in the first issue of the <em>Woman Rebel</em> in 1914 that one aim of the paper was to circulate among those women who work in prostitution; to voice their wrongs; to expose the police persecution which hovers over them and to give free expression to their thoughts, hopes and opinions (<em>Woman Rebel,</em> March, 1914, p.1,
<span class="italicText">MSM</em> C16:515).  Subjecting prostitutes to prison made little sense to Sanger, who said these were "girls who committed the crime of conducting themselves according to the instincts of most human
beings" (<em>Woman Rebel</em>, August, 1914, p.42, <span class="italicText">MSM</em> C16:556).</p>

<p>Sanger also devoted several articles and short columns in the  Woman Rebel to prison issues in New York City, and began a relentless attack on New York City Corrections Commissioner, Katharine Bent Davis who had served for many years as the superintendent at the Reformatory for Women in Bedford Hills, New York and was one of the country's most influential penologists.  On Davis's plan to build a large prison for prostitutes, Sanger sarcastically wrote:
"[K]ath[a]rine is considering building a structure large enough to house 14,000 prostitutes, where their natural desires shall be elevated to loftier ones, such as potato peeling, scrubbing floors, dish washing, etc.  Thus will social evil vanish!"  In the same issue she criticized "Society," for sending a young woman who committed a petty theft to prison &ndash;  "an institution especially equipped by brute creatures to break that splendid spirit; to degrade the girl; to humiliate her" (<em>Woman Rebel</em>, April, 1914, p. 11,
<em>MSM</em> C16:524).  In a later issue, under the heading "Cantankerous
Kath[a]rine," Sanger called Davis a "fossilized reactionary fale," and accused her of making "sneaks and tattlers" of the inmates during a revolt in Blackwell's Island prison (<em>Woman Rebel</em>, July, 1914, p. 35,
<em>MSM</em> C16:550).  In the August issue of the Rebel Sanger included a wordy moral reproach of Davis, although she never used her name:</p>

<blockquote>
  <p>"She is a sociologist.  She is efficient.  She is a business woman.  She is of invincible virtue.  She is indefatigable and relentless in her 'correction' of human nature.  She is a brilliant example of that rapidly growing group of respectable folk who have discovered profitable and highly honorable careers in the exploitation of the victims of our social 'law and order.'" (<em>MSM </em>C16:556)
</p>
</blockquote>

<p>In an attempt to deflate Davis's popularity as the first woman in New York City history to run a major municipal agency and an important innovator among penologists, Sanger concluded:</p>

<blockquote>
	<p>"Women have been too ready to admire other women who, with inflated ideas of self-importance, are willing to degrade themselves and their sex by assuming the barbaric posts that decent men are giving up &ndash; in short by becoming detectives, policewomen and commissioners of correction.  Let us proclaim such women as traitors and enemies of the working class!"</p>
</blockquote>

<p>Finally, writing in the August number, Sanger stated: "Kath[a]rine's position is to keep
&#12;women in bondage" (<em>Woman Rebel</em>, August, 1914, pp. 42-43, MSP-CDS C16:556-7).</p>

<p>Sanger abandoned much of the angry, socialist rhetoric of the Woman Rebel later in the decade when she emerged as the principle leader of the birth control movement and became more aware of her public image.  But she retained her intense dislike of Katharine Davis, who by 1917 had left her 
job as commissioner of corrections to chair a controversial new parole board in New York.  Following her 1917 incarceration in the Queen's County Penitentiary, Sanger publicly rebuked Davis for her treatment of inmates and enthusiasm for indeterminate sentences.</p>

<p>Following the Brownsville verdict, Sanger served her thirty-day sentence without incident.  Prison administrators worried that Sanger might repeat her sister's ploy.  Ethel Byrne received front-page coverage for conducting a hunger strike that lasted about a week before being force fed by prison staff. But Sanger's only run-in with prison officials came when she refused, on several occasions, to be finger printed (she objected to being "classed as a criminal") &ndash; finally squirming and smudging her prints so much on her final day that the prison staff simply gave up and let her go with stained fingers and a small victory.  </p>

<p>Her uneventful stay at Queens County gave Sanger time to interact with other inmates, even giving small talks on hygiene and birth control.  She also learned about the differential treatment men and women received, noting in her diary: "Women are not treated as well as men though &ndash; not allowed papers &ndash; or to send out for anything which men are allowed &ndash; no visitors only two a month. All letters read going & coming which is an outrage." She recalled other details about prison conditions in her <em>Autobiography</em>:

<blockquote>
	<p>"After morning cell-cleaning we took a fifteen-minute walk in the yard with our hooded capes over our heads.  During this cold tramp the women scanned the ground avidly for butts of cigarettes tossed away by the men. It was tragic to see human beings forced to such a low level as to dig with their fingers in the frozen earth to retrieve these mangled stubs. Each used to grab her little bit and hide it." (<em>Autobiography</em>, p. 242).</p>
<blockquote>

<p> Sanger also came to the conclusion that substance abusers did not belong in prison any more than prostitutes. Clearly ahead of her time on this issue, Sanger wrote: "horrible liberties a State takes with human lives &ndash; for a  crime' of drink &ndash; or dope which should be considered diseases. . . ." (Prison Diary, February 8-28, 1917, MSP-LCM 1:32).</p>

<p>She was released from Queen's County Penitentiary with much fanfare.  Looking back, years later, Sanger described her release as if it had been orchestrated by Cecil B. De Mille:

<blockquote>
	<p>"Gathered in front were my old friends who had frozen through the two hours waiting to celebrate 'Margaret's coming out party.' They lifted their voices in the Marseillaise. Behind them at the upper windows were my new friends, the women with whom I had spent the month, and they too were singing.  Something choked me.  Something still chokes me whenever I hear that triumphant music and ringing words, 'Ye sons of freedom wake to glory!'" (<em>Autobiography</em>, p. 250)</p>
<blockquote>
	
<p>The next day she took advantage of the public interest in her case to speak out about prison conditions and act as a "spokesman of the inmates of the Queen's County Jail." Through inmates' stories, Sanger criticized indeterminate sentencing and parole &ndash; a rehabilitation system Davis lobbied for and oversaw &ndash; for its effect in leaving prisoners in the dark about when they would rejoin families or continue careers. Apart from that specific criticism, Sanger continued her personal vendetta against Davis, begun in 1914 and never clearly justified.  ". . . every inmate in the jail," Sanger told the New York Times, "learns to hate Miss Davis with a bitterness and a depth of resentment that one would scarcely believe possible . . . her idea of prison management and of reform for prisoners seem to be a discipline so harsh and unfeeling that every decent option of her victim is killed by it" (<em>New York Times</em>, March 7, 1917).  Sanger then recounted disturbing stories about Davis passed on to her in prison. </p>

<p>Commissioner of Corrections Burdette G. Lewis called Sanger's assertions "mere twaddle." Davis defended herself in the same New York Times article, giving her side of various inmate stories and stating that "[Sanger's] personal attack on me may be due to the fact that she may know my position in regard to the methods which she has used in advocating repeal of the birth control law" (<em>New York Times</em>, March 8, 1917).  Nowhere in her writings does Sanger mention Davis posing an obstacle to birth control work, but Sanger may well have held a grudge if she perceived that Davis in any way affected the outcome of her arrest and trial or the treatment of her sister, Ethel.</p>

<p>In one of the great ironies of the birth control movement, Davis became an important force in funding birth control work in the 1920s and 1930s.  In 1924, as head of the Rockefeller-funded Bureau of Social Hygiene, Davis arranged for John D. Rockefeller, Jr. to give Sanger (through the Bureau) $10,000 to conduct research at her clinic under the auspices of a Maternity Research Council made up of medical professionals.  Rockefeller continued to fund Sanger for many years after, and Davis funneled several other large donations through the Bureau to Sanger.  Their very professional correspondence during these years makes no mention of past disputes. In 1929 Davis also completed a monumental study of female sexuality, <em>Factors in the Sex Life of 2,200 Women</em>, that, among other things, measured contraceptive use. It paved the way for later studies by Kinsey, and Masters and Johnson. It is also interesting to note that several Sanger friends and supporters, including Havelock Ellis and John Kingsbury, the Commissioner of Charities in New York, and the Rev. John Haynes Holmes, among others, publicly supported Davis and endorsed her reforms even before she became a friend of birth control.</p>

<p>Sanger quickly moved on to birth control work and did not enter into the prison reform debate again.  She did, however, use her
smaller-families-equals -less-crime argument to envision reduced prison populations and, therefore, a better quality of life for inmates. And she was in regular contact with the Osborne Association, a group founded by the iconoclastic penologist Thomas Mott Osborne who established self-governing inmate societies at Sing Sing and became something of a folk hero for many inmates at the time. </p>

<p>In the early 1940s, Sanger took up the cases of at least two convicts who wrote to her, aware of her liberal views on prison reform, to ask for assistance in arranging legal help and securing work outside of prison.  Sanger received many letters from inmates over the years, and it is not entirely clear why she devoted considerable resources to help one man, Frank Nugent, in particular.  Nugent, a Sing Sing inmate, was convicted of raping a 23 year old woman, though he claimed it amounted to a mutual, adulterous affair.  Nugent could turn a phrase and seemed to charm Sanger with his long letters, poetry and insight into human nature.  Sanger not only sent him money and gifts, but arranged for at least two jobs for him after he was released from Sing Sing &ndash; one through her son Grant Sanger at the Columbia Presbyterian Hospital in New York.  But Nugent, an alcoholic, never found solid footing and drank himself into fights and parole violations.  "What a stupid man he has turned out to be," Sanger wrote a friend in 1949 upon learning that Nugent was again behind bars (MS to Alma
Whitesell, August 10, 1949, <em>MSM</em> S30:806).</p>

<p>Ultimately Sanger's interest in prison reform and improving inmate's lives stmed from her strong belief in redption, in second chances.  Sanger wrote in her Autobiography: ". . . anyone, in an otional fragment of time. . .when the consequences are not clear, may do some forbidden thing. More often than not it is merely incidental, and in no way warrants a life of penance" (<em>Autobiography</em>, p. 249). Years later she wrote: "I am a great one to believe that one should let the past go entirely and take up life anew and build for the future" (MS to Frank Nugent, June 12, 1946, <em>MSM</em> S25:779). While Sanger was trying to boost the confidence of recidivist Frank Nugent, her words had more bearing on her own life and her ability to wipe the slate clean of radical associations and the rebellious graffiti of an earlier era &ndash; a time when she donized a prison reformer who would later dole out Rockefeller money; an era during which she rarked that it is "not really absurd to foresee a time in our glorious American life when most of the population will live in jails. . . ." (<em>The Woman Rebel</em>, August, 1914, p. 43, <span class="italicText">MSM</em> C16:557). </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
