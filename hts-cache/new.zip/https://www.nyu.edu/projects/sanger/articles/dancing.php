
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #50 (Winter 2008/2009)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #50 (Winter 2008/2009)</h1>
<div class="maintext">
<h1>"Dancing with a Voodoo Priest--Sanger, Art, and Birth Control in Haiti"</h1>

<p>When Margaret Sanger arrived in Port-au-Prince on January 2, 1948, just a day after Haiti celebrated its 144 th anniversary of independence &ndash; the first free black republic and independent state in Latin America &ndash; the island was in the midst of a party. During the two months she was there it never let up, with &ldquo;drums always going . . . laughter &amp; singing constantly, roosters crowing &amp; dogs barking just to keep up with Haitian life.&rdquo; Independence celebrations merged into welcome parties and dances that fed into the energy of carnival, the festival that runs from early January to Ash Wednesday. &ldquo;Band after band came in to sing &amp; dance,&rdquo; Sanger wrote. &ldquo;Naked bodies all painted in one group &ndash; rings in ears &amp; nose. Rather wonderful as a spectacle.&rdquo; (MS to Mary Compton Johnson, Jan. 18, 1948 [quote 1], 1948 Calendar [quote 2] [<em>MSM</em> S27:949 and S81:27].) </p>

<p>Why did Sanger, at age 68, decide to spend two months in one of the poorest, most densely populated countries in the Western Hemisphere? Though under democratic rule since 1946, President Dumarsais Estim&eacute;&rsquo;s administration had been opposed by the U. S. government, political violence remained a threat, and petty theft was an ongoing problem. The island nation was just beginning to invest significant resources in a tourist trade, and it lacked some of the conveniences and safety valves American travelers had come to expect. Sanger had also been unimpressed with Haiti in two previous visits, in 1926 and 1940 &ndash; one day excursions off of cruise ships. (Patrick Bellegarde-Smith, &ldquo;Resisting Freedom,&rdquo; in<em> Vodou in Haitian Life and Culture</em>, ed. Claudine Michel [New York, 2006], 108-109.) </p>
<p>In 1948 Sanger went to Haiti to paint, lured by the island&rsquo;s magnificent light, spectacular mountains and an artistic awakening that was being noticed around the world. Since moving to Tucson in the late 1930s, Sanger had become increasingly serious about her painting&ndash; watercolors in particular. She had experimented with different styles, working under the influence of artist Ralph Pearson when she was in New York and with well-known painter and illustrator Gerry Peirce in Tucson. In the 1940s she became deeply involved in Peirce&rsquo;s Tucson Watercolor Guild. In 1945 she enrolled in a summer class in State College, Penn. taught by Hobson Pittman, an up-and-coming painter of still lifes and interiors who entered into an on and off romance with Sanger. She studied for several weeks in 1946 with abstract artist Emil Bisttram in Los Angeles. She was also friendly with portrait painter, actor and director Rollo Peters, and took classes at his Nyack, NY art school. She may have hatched the idea of a trip to Haiti in the fall of 1947 while driving from New York to Arizona with Peters. </p>
<p>Rollo Peters&rsquo;s brother, artist DeWitt Peters, founded the Centre d&rsquo;Art in Port-au-Prince in 1944, a school, studio and exhibition space for self-taught artists in Haiti. <em>Life Magazine </em>had run a piece on Haitian art and the Centre in 1947, and several exhibits outside of Haiti made the Centre an internationally known workshop for folk art. The Centre offered Sanger an unique opportunity to work with respected teachers &ndash; the Centre&rsquo;s staff included New York sculptor Jason Seley &ndash; and see first hand some of the artwork that was receiving wide acclaim. (&quot;Haitian Painting.&quot; <em>Life Magazine </em>23:9 [Sept. 1, 1947): 58; Selden Rodman, <em>Renaissance in Haiti </em>[New York, 1948], 5-6.) </p>
<p>Sanger viewed the trip to Haiti as a vacation as well as an art retreat, an opportunity to enjoy the warm climate and colorful island life with two of her closest friends, Dorothy Brush and Anne Kennedy, both of whom had worked closely with Sanger in the birth control movement. Kennedy, whose daughter Sheelagh was living in Haiti, was also a close friend of DeWitt Peters. Sanger had one other motive in visiting the island--to find a Haitian who would be interested in moving to the States to cook for her son, Grant and his family. While there, Sanger also hoped to make contact with doctors and nurses interested in learning more about contraception, but she had limited expectations for advancing birth control activism in a Catholic country that preserved voodoo traditions and had one of the highest illiteracy rates in the Western world. </p>
<p>On Sanger&rsquo;s first day in Haiti she was feted by DeWitt Peters at the Centre d&rsquo;Art, enjoying rum punch and dancing along with 75 other guests. &ldquo;You would laugh to see me dancing,&rdquo; she wrote her friend, philanthropist Mary Lasker, &ldquo;with the famous artist Hipplite the voodoo Priest. He is both black as night &amp; frail as a grasshopper.&rdquo; Sanger referred to Hector Hyppolite (1894-1948), an artist who had been painting houses and decorating furniture using a chicken feather brush until DeWitt Peters &ldquo;discovered&rdquo; him and set him up with an easel and paints. In just a few years he became the best known of several Haitian artists working in the naive or intuitive style. He won over critics and patrons in an UNESCO exhibit in Paris in 1947, as well as exhibits at the American-British Art Center in New York and in other cities. The spontaneity evident in his painting (he also worked extremely quickly), his use of vivid colors and fondness for absurd, disproportionate figures and magical settings attracted art critics and collectors in droves. French writer Andr&eacute; Breton, bought several paintings, as did Sanger&rsquo;s friend, British biologist Julian Huxley. </p>
<p>Hyppolite had become a very wealthy man by the time Sanger met him, though he still lived in a thatched hut in the waterfront slums. Like his father and grandfather before him, Hyppolite was also a voodoo priest and a practitioner of <em>v&eacute;v&eacute;</em>, the ritual art of drawing on the ground with flour before the beginning of a voodoo ceremony. He painted in a state of religious ecstasy and believed that John the Baptist guided his paint brush. Sanger saw Hyppolite several other times during her stay, always remarking on his wiry frame and pitch black skin. &ldquo;He is very fragile &amp; dark &ndash; not much English,&rdquo; she noted in her calendar. Hyppolite died that summer at age 54 of an apparent heart attack. &rdquo; (MS to Mary Lasker, Feb. 1, 1948 [<em>MSM</em> C8:227]; Rodman, <em>Renaissance in Haiti</em>, 62-67; Leslie Bethell, ed.,<em> The Cambridge History of Latin America, Vol X </em>[New York, 1995], 414-415; 1948 Calendar [<em>MSM</em> S81:16].) </p>
<p>Sanger, Brush and Kennedy stayed about five miles outside of Port-au-Prince in what used to be the president&rsquo;s summer palace; American dollars went a long way in Haiti. &ldquo;We don&rsquo;t think it&rsquo;s a palace,&rdquo; Sanger wrote, &ldquo;but we have made it comfortable. There is a nice swimming pool in the yard &amp; flowers &amp; trees. We have an upstairs terrace where we can exercise &amp; sunbathe. We have a cook, butler, yard man &amp; home boy, laundress, chauffer &amp; Anna my personal maid who came down with me.&rdquo; (MS to Daisy Mitchell, Feb. 4, 1948 [<em>MSM</em> S27:995].) </p>
<p>The days were loosely scheduled, with Sanger using most of her time to paint and to attend art classes. &ldquo;Off early to sketch . . . dozens of people flock around to see painting,&rdquo; she recorded one day. On another she wrote, &ldquo;went down early to the market to sketch life there. It was overwhelming &amp; confusing.&rdquo; The painting sessions gave her the opportunity to observe closely the Haitian people: &ldquo;They are really beautiful of features &amp; manners. Even the poorest are polite. The French language is so beautiful &amp; they speak it in such soft voices that it is music. The women do all the hard work. They carry on their heads great baskets of vegetables or fruits to market &amp; take back the family groceries &amp; water on their heads.&rdquo; (1948 Calendar [quotes 1-2], and MS to Daisy Mitchell, Feb. 4, 1948 [quote 3] [<em>MSM</em> S81:18, 24-27, and S27:995].) </p>
<p>To a friend she summed up her first month in Haiti as &ldquo;Excursions, painting, writing, sculpting, dreaming &amp; just lazing.&rdquo; To another, she wrote, &ldquo;Another perfect day . . . So with French lessons &amp; sculpture &amp; exercises we are busy.&rdquo; She rested in the afternoons to prepare for an exciting night life: colorful spectacles created by carnival participants, parties and dancing set to the infectious rhythms of the constant drumming. &ldquo;Every night drummers, singers &amp; dancers arrive to entertain us,&rdquo; she recalled, before they moved off to cocktail parties at the Embassy, lavish dinner parties arranged by Peters, or dancing &ldquo;La Meringue&rdquo; at the &ldquo;Zanzibar night club.&rdquo; (MS to Lasker, Feb. 1, 1948 and MS to Mary Johnson, Jan. 24, 1948 [<em>MSM</em> C8:227 and S27:965].) </p>
<p>Following a cocktail party one Saturday night, Sanger and Brush were taken to a voodoo meeting. &ldquo;A very amazing performance,&rdquo; Sanger wrote, &ldquo;half Catholic &amp; voodoo.&rdquo; Dorothy Brush later described some of the ceremony in detail: </p>
<p>&ldquo;The priests . . . and priestesses performed ceremonial dances. The dance, one with the sacrificial cocks was too much for me. First the birds are wildy waved during a march around seven fires built upon the floor. Then they are plucked alive, their legs broken and their tongues bitten out. At last their pitiful necks are finally wrung and they are cooked for the gods. (I couldn&rsquo;t eat a chicken for weeks after this.)&rdquo; </p>
<p>They then witnessed the initiation of seven girls as acolytes. Hidden under white sheets, the girls were led to a priestess who pulled their hands and feet from beneath the sheets, dipped them in oil and passed them through the flames beneath a hot cauldron. Sanger and Brush were told that the girls had been confined to a room for two days, given only small amounts of food and water, and then hypnotized just before the initiation. Sanger noted in her calendar that they didn&rsquo;t get home from the voodoo ceremony until 4 am. (1948 Calendar [<em>MSM</em> S81:41]; Dorothy Brush, &ldquo;Haiti,&rdquo; manuscript fragment, n.d. [Dorothy Brush Papers, Sophia Smith Collection].) </p>
<p>Sanger, whose health was always precarious, seemed to thrive on the island&rsquo;s energy. Unlike many American tourists, she managed to avoid illness until the last week when finally her stomach turned on her, while Anne Kennedy battled &ldquo;the trots,&rdquo; and Dorothy Brush experienced such a severe sun stroke that she was forced to consult a doctor. (1948 Calendar [<em>MSM</em> S81:26-27, 38].) </p>
<p>Unfortunately Sanger&rsquo;s holiday in Haiti was interrupted twice with tragic news. On January 19 th she learned that Hazel Moore, a close friend who had worked for Sanger as a Washington lobbyist in the 1930s, had died in a hospital in China. She had suffered a nervous breakdown while trying to find her son whose plane had crashed in the Chinese countryside. Two weeks later Sanger heard the news Mahatma Gandhi was assassinated. She wrote in her calendar: &ldquo;We all await this horrible news &amp; hope it will not cause civil war in India.&rdquo; It had been twelve years since Sanger had visited Gandhi at his Ashram for two days of discussions, an event that remained one of the high points in her life. (1948 Calendar [<em>MSM</em> S81:24 and 30].) </p>
<p>About half way through her stay, Sanger allocated some of her time to birth control efforts. After speaking with a few island doctors, she agreed to give a talk on January 31 st before about 200 educated Haitians at a Port-au-Prince club. &ldquo;It was a very fine &amp; intelligent group,&rdquo; she wrote. &ldquo;The interpreter . . . was very good. As usual I was nervous but it went over very well.&rdquo; She wrote to her New York clinic, &ldquo;It was very interesting to break ground in a perfectly new territory &amp; watch the reactions.&rdquo; The event spurred talk of starting a birth control service in the main hospital, and Sanger arranged for supplies of foam powder, an inexpensive foaming spermicide that could be used with a sponge or cotton, to be sent down from New York. However, the shipment apparently went astray. She wrote in a letter after the trip: &ldquo;I have arranged with one of the physicians in the General Hospital that he will give out foam powder or any other easily applied contraceptive to the mothers who come there for delivery. . . Difficulty is getting supplies into Haiti. A large box of . . . foam powder, which was sent to me last December is wandering around the Carribean Sea, or wasting away in the Custom House at Port-au-Prince.&rdquo; (1948 Calendar [quote 1], MS to Mary Compton Johnson, Feb. 1, 1948 [quote 2], and MS to Clarence Gamble, March 10, 1948 [quote 3] [<em>MSM</em> S81:30, S27:987, and C8:247].) </p>
<p>Sanger followed up her talk with an appearance before a parent-teacher association the next week. Then in mid-February a medical case worker took her on a tour of the slum areas to see firsthand the plight of many poor and illiterate Haitian families. Later that day she met at the Port-au-Prince hospital with a small group of doctors and nurses. She then contacted Catholic leaders to make sure that they would not block any efforts to increase access to birth control. She &ldquo;talked and spent a very charming evening with Father Smith, a Roman Catholic Priest, who practically promised me he would not interfere with whatever was done in the Hospital.&rdquo; Sanger&rsquo;s visit resulted in two articles on birth control &ldquo;in one of the important papers&rdquo; and a meeting with the president&rsquo;s wife to discuss constructive birth control work. (1948 Calendar, MS to Clarence Gamble, March 10, 1948 [quote 1], and MS to Mary Lasker, Feb. 17, 1948 [quote 2] [<em>MSM</em> S81:40, C8:247, and S27:1041].) </p>
<p><strong> &nbsp;</strong>Just a few days prior to her departure Sanger was invited to give a radio broadcast, an opportunity to reach a much larger number of Haiti&rsquo;s nearly three million inhabitants. However, Sanger soon learned that she would have to share the air with a representative of the Haitian government, an attorney from Philadelphia who, rumor held, had a background in Communist organizing. Concerned that he was interested in publicizing his own political views, and advised by the American embassy to avoid contact with him, Sanger wiggled her way out of the initial agreement. Instead, she recorded her talk, alone, for broadcast several days later. (1948 Calendar [<em>MSM</em> S81:42, 46]; Brush, &ldquo;Haiti&rdquo; mss..) </p>
<p>Sanger&rsquo;s work in &ldquo;stirring up Birth Control ideas among the medicos and the intellectual Haitians&rdquo; did set the stage for later efforts to establish a birth control center, but it took a number of years. Anne Kennedy, who made her home in Haiti in the 1950s, began working in private circles to increase awareness of the need for population planning. The Haitian government invited Dr. Abraham Stone, the director of the Margaret Sanger Research Bureau, to address Haitian doctors in 1954, the same year that the national daily paper, <em>Le Jour</em>, carried a front page article headlined &ldquo;The Control of Births Must Be Realized.&rdquo; By the late 1950s there was talk of starting a Port-au-Prince clinic as part of a public health program, and the Western Hemisphere Region of the International Planned Parenthood Federation sent several American doctors to help form a birth control committee. Despite a lack of middle class support, the new clinic &ldquo;got off to a flying start&rdquo; in 1960, according to one of the clinic committee members. A family planning association, formed in 1962, developed an education program to seek broader support and reach farther into the countryside, even recruiting priests to help with the education efforts. However, few island doctors referred women to the birth control clinic, while many of the clinic&rsquo;s patients failed to return after an initial visit. Clinic staff also struggled to find affordable and practicable methods to prescribe, and within a few years the association disbanded. It was not until 1971 that a national family planning program was established in Haiti through the Division of Family Hygiene. (MS to Clarence Gamble, Mar. 10, 1948 [quote 1] [<em>MSM</em> C8:247]; Beryl Suitters, <em>Be Brave and Angry</em> [London, 1973], 94, 212-13 [quote 2]; Dorothy Brush, &ldquo;Haiti,&rdquo; <em>Around the World News of Population and Birth Control </em>30 [Dec. 1954], ii; James Allman, &ldquo;Fertility and Family Planning in Haiti,&rdquo; <em>Studies in Family Planning </em>13:8/9 [Aug.-Sep., 1982]: 237-245.) </p>
<p>Art, not birth control, was Sanger&rsquo;s primary focus in Haiti, and she returned home pleased with her output and the positive reaction of her teachers. Two of her watercolors were accepted in an exhibition in the Tucson area, and several of her paintings interested buyers, who offered between $100 and $300. She also succeeded in landing a cook, a man named Vestra, to work for Grant Sanger. All in all it was a trip she would refer to and remember fondly for years, a &ldquo;fantastic &amp; primitive &amp; enchanting&rdquo; time. (MS to Brush, Mar. 30, 1948, MS to Anne Kennedy, Mar. 17, 1948, and MS to Hobson Pittman, Feb. 27, 1948 [quote] [ MSM S28:91, S29:58, and C8:246].) &Eacute; </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
