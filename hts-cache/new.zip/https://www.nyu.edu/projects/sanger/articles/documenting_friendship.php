
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #3 (Fall 1992)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #3 (Fall 1992)</h1>
<div class="maintext">
<h1>"Documenting a Friendship"</h1>

<p>    Juliet Barrett Rublee (1876-1966), the free-thinking wife of well-to-do lawyer and advisor to the Wilson and
FDR administrations, George Rublee, was unquestioningly Margaret Sanger's closest friend and confidant. 
Sanger and Juliet Rublee met in 1916, when Rublee became active among a group of socialites who helped defray
Sanger's Brownsville trial costs by forming the Committee of 100.  Rublee emerged from this episode as one of
Sanger's most trusted friends and a life-long advocate of birth control. </p>

<p>    Following the Brownsville episode, she lent her support to several of Sanger's efforts, including the New York
Women's Publishing Company and the American Birth Control League (ABCL).  Thereafter, Rublee's public
support of birth control was unflagging.  In 1921, after Sanger was arrested and prevented from holding a public
meeting entitled "Is Birth Control Moral?" at New York's Carnegie Hall, Rublee, defending Sanger's right to free
speech, forced her own arrest. The charges against both Sanger and Rublee were later dropped.  Rublee remained
loyal to Sanger during the bitter power struggle that emerged within the ABCL; when Sanger was forced out in
1928, Rublee resigned her position in protest taking her considerable financial support with her. </p>

<p>    Juliet Rublee lived an extravagent and exotic life in the 1920s and 1930s.  She provided financial backing for a
treasure hunt off the coast of Italy in 1926.  When the expedition failed, Rublee was kidnapped by the Italian
expedition crew and had to be ransomed by her husband.  A few years later she wrote and produced a silent film
on the 1910 socialist revolution in Mexico entitled <em>Soul of Mexico</em>, filmed on location from 1928-1932.  
Though critical success eluded her, Rublee's devotion to film, art, and dance was undimmed.  Also fascinated by
the spiritual world, she and Sanger often traded their dreams in letters.</p>

<p>    Unlike Sanger, Juliet Rublee was born into a life of wealth and privilege, yet the two formed a particularly
warm and intimate union which was documented in over 250 handwritten letters.  Though both women wrote
intensely personal letters and marked them "destroy on reading," each saved many.  Rublee's concern over the
secrecy of the letters was reflected in April of 1936 when she wrote "The only reason I want my letters destroyed
is from fear that J.N. [Sanger's second husband, J.Noah Slee] or some secretary would pick them up and read
about things not meant for them."  For her part, Sanger often sent Rublee intimate letters that she had received
from others, ostensibly for safekeeping, but more likely to share them. </p>

<p>    Though close, the two friends did not always agree on matters.  Active politically in the 1930s, Rublee argued
bitterly with Sanger over the necessity of U.S. intervention in European affairs.  Rublee saw U.S. involvement as
essential to countering Nazi oppression, while Sanger, the mother of two sons of draft age, initially supported the
America First Committee which encourged isolationism.  Yet the friendship sustained and would last until
Sanger's death in September 1966.  Rublee died just months later.</p>

<p>    The Rublee &ndash; Sanger correspondence probably offers the most intimate view of Margaret Sanger's feelings
about her life, her family and her friends, as well as the birth control movement. That she derived such an
enormous level of emotional and spiritual sustenance from her friendship with Juliet Rublee seems to sustain the
historian Nancy Cott's contention that for early 20th century feminists, female friendships were the "consoling
counterpoint...for relationships with men."  </p>

<p>    Juliet Rublee's letters to Sanger formed an important part of the personal correspondence that Sanger deposited
in the Sophia Smith Collection.  However, Smith never received Sanger's letters to Rublee.  Despite Sanger's
increasing reliance on secretaries to type and prepare copies of her correspondence, most of her letters to Rublee
were handwritten and never copied. Serendipitously, in 1979 a large cache of Rublee's papers (including 166
handwritten Sanger letters) were found discarded in a trunk in Cornish, NH.  Paul Danz, who found the letters,
sold much of this collection to the Dartmouth University Library.  Unfortunately, the cache did not include letters
from Sanger written between 1947 and 1961.  Sanger's biographer, Lawrence Lader, was given a smaller
collection of letters by Sanger to assist him in his research and he has generously provided the project with copies
of his letters.  </p>

<p>    In January of 1992, Barry Oldam, a private collector in Denver contacted the project with word that he had
purchased another cache of Rublee material from Paul Danz.  He has promised the project photocopies of any
Sanger-Rublee correspondence within his collection.  We hope to reconstruct the entire run of Sanger-Rublee
correspondence in our microfilm edition, to fully document a long and close relationship between two remarkable
women.     </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
