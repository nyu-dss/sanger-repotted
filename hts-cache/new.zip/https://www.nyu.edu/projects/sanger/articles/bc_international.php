
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #58 (Fall 2011)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #58 (Fall 2011)</h1>
<div class="maintext">
<h1>"The Birth Control International Information Centre--An International Outpost for Birth Control"</h1>

<p> Early efforts to forge a global birth control movement in the twentieth century revolved around international conferences and the brief forums they created for the gathering and sharing of contraceptive information. Starting with the First International Neo-Malthusian Conference in Paris in 1900, these gatherings were sporadic and almost exclusively the domain of physicians and scientists. By the late 1920s, there was a surge in demand in many parts of the world, within and outside of the medical community, for updated information and supplies. Neither the conferences or any one organization was able to fill the need. Margaret Sanger and both the American Birth Control League, which she headed until 1928, and the Birth Control Clinical Research Bureau, her New York clinic, served as an international hub for contraceptive information, but her staff was stretched thin and did not always have the time to devote to providing the necessary resources for groups around the world that were starting clinics, hospital-based birth control services and birth control advocacy organizations. </p>
<p>    Following the World Population Conference (WPC) in 1927, Sanger and her trusted aide in international work, the British suffragette and birth control organizer, Edith How-Martyn, began to explore the possibility of creating a Europe-based organization to answer inquiries from Europe and Asia. With leftover funds from the 1927 conference, How-Martyn set up a birth control office in London in 1928 to keep up the Conference&rsquo;s momentum by building international contacts, acting as a clearinghouse for birth control information, and also lobbying for birth control in Britain during the general election. But her loosely defined work never really got off the ground as How-Martyn attended to health problems and domestic disputes within her family. Early in 1929 she wrote to Sanger that she would like to see her establish &ldquo;a world organisation to supply energy and knowledge, direction and inspiration to the workers in all countries and by Conference and headquarters opportunities to exchange views.&rdquo; Sanger had long been considering just such an enterprise, both to anchor an international movement and to give her more prestige and credibility abroad. (How-Martyn to MS, Jan. 31, 1929 and Jan. 10, 1930 [<em>MSM</em> S4:952; LCM: 14:1112].)</p>
<p>    Following the Seventh International Conference on Birth Control in Zurich in September 1930, where clinicians came together for the first time to focus on practical aspects of contraception (see MSPP Newsletter #56, Winter 2010-2011), Sanger and How-Martyn decided to enlarge How-Martyn&rsquo;s informal office into the Birth Control International Information Centre (BCIIC), with Sanger as president and How-Martyn as director. Thus was born the first birth control organization dedicated to spreading contraceptive knowledge throughout the world. </p>
<p>    The London-based BCIIC started off as little more than a supply of letterhead. The Depression made it difficult to secure sustained funding or afford additional staff. Gerda Guy, a Danish-born suffragist and anthropologist who had helped Sanger with the Zurich Conference, and her British husband, businessman John Henry Guy, kept the new organization afloat for the first two years, but it was touch and go. When the Guys faced personal financial misfortune in 1931, the BCIIC nearly closed down. How-Martyn&rsquo;s selfless dedication&ndash;she volunteered much of her time&ndash;and the assistance of other supporters and volunteers kept the operation running. For example, in 1933, a Malthusian Ball was held in London with proceeds going to the BCIIC. Sanger, facing her own economic troubles and the start-up of her lobbying group in Washington, D.C., contributed a small sum of money to the Centre but told How-Martyn that her responsibilities in the United States would keep her from devoting much time to international work until at least 1934. (How-Martyn to MS, Mar. 16, 1930 and Aug. 24, 1931 [LCM 14:1132; 15:75]; Louise Stevens Bryant to MS, Mar. 7, 1932 [LCM 63:642]; MS to How-Martyn, Oct. 20, 1932 [LCM 15:343].)</p>
<p>    The BCIIC&rsquo;s accomplishments the first two years were mostly limited to agitation in England and follow-up work on the Zurich conference. It was not until 1932 that the organization put in place an advisory council that eventually came to include Indian birth control leader Lady Dhanvanthi Rama Rau, British socialist and longtime birth control activist Frida Laski, and British physician and eugenicist Maurice Newfield. By the end of 1932 the Centre had defined its goals: to spread the knowledge of birth control; to answer inquiries; to arrange for visitors to tour clinics; and to organize international conferences. To extend the reach of the organization it developed a team of &ldquo;correspondents&rdquo; who reported on birth control activities in their countries and regions and helped carry out BCIIC sponsored functions. Initially the Centre named ten correspondents, a list that eventually grew to more than thirty.</p>
<p>    One of the more intrepid of these correspondents was Karla Popprov&aacute;-Mol&iacute;nkov&aacute;, a Czech feminist and birth control advocate who was the main impetus behind the formation in 1932 of the Czechoslovakian Birth Control Society in Brno. Relying on her BCIIC support and organizational identity, Popprov&aacute;-Mol&iacute;nkov&aacute; confronted a feisty Catholic opposition that conflated birth control with abortion, and government officials who feared depopulation. Despite considerable obstacles she translated, printed and distributed Sanger&rsquo;s <em>Family Limitation</em> and held numerous informational meetings with women&rsquo;s groups and medical societies. In the fall of 1932 she wrote Sanger that &ldquo;the Birth Control question is now in the centre of discussion of all organizations &ndash; even the Czechoslovakian YWCA is working in our committee. . . . As all women from political parties, that is to say the secretaries of all political parties womens sections/ with exception of the catholic party/ have promised to work for Birth Control, we can really speak of a national movement.&rdquo; Her achievement in Czechoslovakia was one of the early successes of the BCIIC. (Mol&iacute;nkov&aacute; to MS, Oct. 22, 1932 [LCM 12:1271].)</p>
<p>  Also in 1932 the Centre sponsored How-Martyn&rsquo;s summer trip to the Soviet Union to examine maternal care and abortion facilities. She was so enthused by the welcome she received from Soviet officials that she proposed to Sanger that the BCIIC hold a conference in the USSR, &ldquo;possibly with Stalin as the Honorary President.&rdquo; Although such a conference never materialized, How-Martyn did break ground for Sanger&rsquo;s historic tour of the Soviet Union in 1934. (EHM to MS June 23rd, 1932 (LCM 15:270); BCIIC News Letter 1 [June 1934]: 1.)</p>
<p>    While the BCIIC sought to be both a clearinghouse for birth control information and a base for visitors who wanted to tour clinics in England, it is not clear how successfully it achieved these goals. A lack of money limited the Centre&rsquo;s ability to publish and distribute literature, and many inquirers bypassed the BCIIC for the Walforth Women&rsquo;s Welfare Centre in London, Sanger&rsquo;s Birth Control Clinical Research Bureau in New York, or other clinics when seeking advice and information. Neither did the Centre generate as many conferences as Sanger and How-Martyn initially envisioned. It did organize the Conference on Birth Control in Asia, held in London in November 1933, which included a number of delegates from India, China and Japan and featured papers on those countries as well as on Syria, Iraq and Ceylon. The Conference included a series of contraceptive training sessions for Asian medical students living in Britain. Presided over by Lord Horder, physician to the King, the 1933 conference gave the Centre some much needed name recognition, but Sanger&rsquo;s absence was noticeable. (BCIIC News Letter 1 [June 1934]:1; Michael Fielding, ed., <em>Birth Control in Asia: A Report of a Conference Held at the London School of Hygiene &amp; Tropical Medicine</em>, November 24-25, 1933 [London, 1935].)</p>
<p>    The Centre&rsquo;s most effective contribution to international birth control advocacy came via the series of birth control tours it sponsored in the mid-1930s. These included How-Martyn&rsquo;s trip to the Middle East in the winter of 1934, where many women were just becoming aware of modern birth control practices. She made important and lasting contacts in Egypt, Syria and Palestine.</p>
<p>    From Aswan, Egypt, How-Martyn wrote Sanger about her constructive birth control discussions with a number of doctors and health workers. &ldquo;The luck I am having here is surprising&rdquo; especially considering that the &ldquo;emancipation of women is but beginning.&rdquo; She added, &ldquo;unless we are to delay a long time it is to the men we must turn.&rdquo; She complained that she ran into &ldquo;all the old objections,&rdquo; including &ldquo;religion&ndash;leading to immorality&ndash;superiority of self control, every mouth means pair of hands &amp; so on . . . I still find it strange that people who can become physicians, politicians &amp; economists yet can be so stupid over B. C. the poverty, the overcrowding &amp; the unemployment especially of the educated classes shouts for B. C., &amp; for sterilization &amp; yet physicians in high positions talk nonsense as they do every where.&rdquo; (How-Martyn to MS, Jan 26, 1934 [LCM 13:98].)</p>
<p>    From Palestine, How-Martyn reported that she had been &ldquo;preaching B. C. to the Head Nurse of the Child Welfare work here &amp; have made a very good contact. She has been trying to find out about B.C. &amp; eagerly asked me to give her details. She has been trying to fit the Dumas pessary but has not had much success &ndash; I discovered they leave the pessary in &amp; tell the woman to come &amp; have it removed for menstruation. With what I told her, with the books and pessaries I shall send her she should get better results than that.&rdquo; (How-Martyn to MS, Feb. 21, 1934 [LCM 20:400].)</p>
<p>    Later that year How-Martyn visited India to aid a burgeoning birth control propaganda campaign. After three weeks she wrote, &ldquo;All my meetings, seventeen in all, including six to medicals only, have been most successful. There is practically no opposition, and the eagerness to hear every detail about practical methods applicable to India is almost pathetic.&rdquo; In three months she traveled 5,000 miles, visited 20 towns and cities and addressed 79 meetings. She also met twice with Mahatma Gandhi. As with her earlier trip to the USSR, How-Martyn&rsquo;s visit to India prepared the way for Sanger to feature India on her and How-Martyn&rsquo;s 1935-36 World Tour for Birth Control. (<em>BCIIC News Letter</em> 3 [Feb. 1935]:1 and 4 [June 1935]: 1.)</p>
<p>    The World Tour proved to be the centerpiece of the BCIIC&rsquo;s relatively short existence. For six weeks starting in November 1935, Sanger and How-Martyn, traveling separately, crisscrossed India. They addressed 105 meetings, most of them with women&rsquo;s groups, and over thirty with medical organizations before which they demonstrated contraceptive devices and screened technical films. They met with government officials in large and small cities to discuss ways to incorporate birth control into public health programs, recommending the inexpensive foam powder and sponge method as a promising contraceptive for the masses. Highlights of the India tour included Sanger&rsquo;s speech to the All India Women&rsquo;s Conference, the group that officially invited her to India; her radio talk, &ldquo;What Birth Control Can Do for India,&rdquo; which aired throughout the country; her lengthy one-on-one meeting with Gandhi at his Ashram in Wardha, a historic debate between two of the world&rsquo;s most persevering reformers that made headlines around the world; and her visit to Rabindranath Tagore, the Bengali poet and philosopher. Although Sanger and How-Martyn met with resistance and, at times, opposition from religious groups and traditionalists, the positive publicity they garnered far outweighed the few setbacks. The Indian press covered all of Sanger&rsquo;s public appearances and featured interviews and profiles, educating the reading public about the health and economic benefits of birth control. Most significantly, nearly fifty contraceptive teaching centers were established for public health and hospital staffs as a result of the tour. (Sanger, How-Martyn, <em>&lsquo;Round the World for Birth Control</em>, [London, 1936], 12-17.)</p>
<p>    From India How-Martyn traveled to Ceylon (Sri Lanka) and met up with Sanger in Burma (Myanmar). Sanger moved on to the Malay Peninsula, Singapore and Hong Kong, before an intestinal flare-up shortened her trip. How-Martyn continued the tour through the major cities in China, onto the Philippines, then Japan, Hawaii, and, in the summer of 1936, Canada.</p>
<p>    The World Tour should have been an unmitigated triumph for the BCIIC, a grand achievement of the organization&rsquo;s primary goal to &ldquo;spread the knowledge of birth control all over the world.&rdquo; Instead it brought about the beginning of the Centre&rsquo;s slow demise. A conflict erupted among the BCIIC council members over How-Martyn&rsquo;s status and use of Centre funds on her trip. How-Martyn, like Sanger, resented controlling boards and sought greater freedom in conducting field work. She resigned as director in November 1935 but continued to travel through Asia using BCIIC funds. She extended her trip outside of India without the council&rsquo;s approval and against the wishes of the Centre&rsquo;s most significant supporter at the time, the Canadian rubber goods manufacturer and philanthropist, Alvin Kaufman. Kaufman demanded that his contributions be returned if the BCIIC continued to allow How-Martyn to serve as a free agent. From India, Sanger tried to make peace but was reflexively loyal to How-Martyn and predisposed to be wary of oversight boards. She too considered resigning but held on as president a little longer. (Kaufman to Edith How-Martyn, May 8, 1935; Kaufman to John Henry Guy, BCIIC, Nov. 22, 1935 [LCM 12:276, 15:959].)</p>
<p>    Financial difficulties forced the BCIIC to reorganize in 1936-37. The new honorary director, Maurice Newfield, instituted a membership structure to replace the Centre&rsquo;s reliance on a few individual donors. How-Martyn cut her ties completely by resigning from the Centre&rsquo;s council in October 1936. Sanger, who had become frustrated with internal disputes and had refocused her attention on the American movement, resigned as president in early 1937, replaced by Lord Horder. Lacking decisive leadership and suffering from a budget crisis, the Centre accomplished little in 1937 and in 1938 was absorbed by England&rsquo;s National Birth Control Association. A year later the movement in Europe and Asia all but shut down with the outbreak of war. (Edith How-Martyn to MS, Apr. 23, 1937; Harry and Gerda Guy to MS, July 11, 1938; Maurice Newfield to MS, Apr. 1, 1938 and Gerda Guy to MS, Apr. 12, 1938 [LCM 16:345, 664, 603 and 608].) </p>
<p>    The BCIIC has become but a footnote in the history of the international movement, overshadowed by Sanger&rsquo;s concurrent international work and accomplishments for which she seldom gave the BCIIC credit. It does not help matters that some BCIIC records were apparently disposed of by the National Birth Control Association when it took control of the BCIIC. Fortunately most of the voluminous correspondence between Sanger and How-Martyn, and How-Martyn&rsquo;s detailed reports for the BCIIC survive and have become important resources in our work on Volume 4 of The Selected Papers of Margaret Sanger. As we move along with our research, it is becoming more and more evident to us that the BCIIC played a significant role in guiding health and social agencies and women&rsquo;s groups in the Middle East, Eastern Europe, India and other parts of Asia in the development of birth control programs. Although the Centre and most of its projects did not survive the war, the contacts that it created, especially in India, paved the way for more sustained international organizing in the postwar era. (Matthew Connelly, <em>Fatal Misconception: The Struggle to Control World Population</em> [Cambridge, 2008], 110, 415.)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
