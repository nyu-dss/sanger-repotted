
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #43 (Fall 2006)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #43 (Fall 2006)</h1>
<div class="maintext">
<h1>"Sanger Leagues: Cleveland - the first wee voice of Birth Control"</h1>

<p><em>In the early years of the birth control movement, Sanger directly and 
indirectly influenced the creation of birth control leagues across the country, many of which later became Planned Parenthood affiliates.  With this issue we begin a regular column that will focus on how Sanger helped bring about the formation of a league, 
clinic or related organization in a particular city, state or region.</em></p> 
<h2>Cleveland - 'the first wee voice of Birth Control' </h2>

<p>In Cleveland, Ohio, Sanger brought about the establishment of an early birth control group in 1916 and influenced the creation of the eventual PPFA affiliate, the Maternal Health Association of Cleveland, in 1923.   She stopped in Cleveland in April 1916 at the start of her momentous cross-country tour to drum up support for legalized birth control.  "I spoke in the Unitarian Church in the afternoon, under the auspices of some social workers, while in the evening there was an overflow meeting arranged by a radical group.  Both meetings were splendid.  Since then a strong Birth Control League has been formed in Cleveland of over four hundred members, and I enclose the little paper they have just issued - the first wee voice of Birth Control in the U.S.A." (MS to Charles and Bessie Drysdale, Aug. 9, 1916 [Vol. 1, p. 186; <em>MSM</em> S1:638].)</p>

<p>The historic paper Sanger refers to, <em>The Birth Control News</em>, published in the summer of 1916, announced the formation of the Cleveland-based  Birth Control League of Ohio, launched on June 23 and inspired by Sanger's earlier appearance in the city.  The League's president, a young socialist leader named Frederick Blossom, had impressed Sanger as "polished, educated, and clever." And the little newspaper he edited had caught her eye.  Later that year she hired him as managing editor of the Birth Control Review.  He turned out the first issue while Sanger served a thirty-day prison sentence resulting from her arrest for opening the Brownsville clinic in October 1916.  They later had a falling out over Blossom's misuse of funds, a disputatious affair that distanced Sanger from the radical community. The Ohio League died out sometime the following year possibly due to a lack of leadership and an association with extreme radicals that may have frightened off more conservative interest as well as funding. (MS, <em>Autobiography</em>, 199.) </p>

<p>Sanger had far less influence on the establishment of the Maternal Health Association of Cleveland.  A single event appears to have ignited efforts to create an informal maternal health group in 1920 or 1921.  A Cleveland newspaper ran the story of a pregnant woman who ended her life by walking off a pier into the cold Lake Erie waters, leaving at home a disabled husband and nine children.   She had been denied birth control at a prenatal clinic.  As a result of this incident, two young Cleveland mothers, Dorothy Brush, who would later work closely with Sanger, and Hortense Shepard, began giving out contraceptive information as Junior League volunteers at the prenatal clinic.  Their decision to provide independent advice proved untenable, and they were forced to seek an organized approach. </p>

<p>Soon thereafter, Juliet Rublee, a key supporter of Sanger who later became her closest friend, invited her cousin, Dorothy Brush (it was indeed a smaller world then), Shepard and their two mothers to the first American Birth Control Conference in New York in November 1921, where they witnessed Sanger�'s impassioned leadership, the fierce opposition she faced, a police raid, and the arrests of Sanger and Rublee.  The Ohio women returned more informed, battle tested and inspired to bring together the necessary elements in Cleveland needed to form a birth control organization.  A committee was formally organized in 1923 and became the Maternal Health Association in 1928. </p>

<p>(Sources: History of the Maternal Health Association of Cleveland, June 1957 [Sanger Unfilmed, Sophia Smith Collection]; Francis McLennan Vreeland, &quot;The Process of Reform with Especial Reference to Reform Groups in the Field of Population,&quot; Ph.D. diss., University of Michigan, 1929, pp. 401-408. For more on the origins of the Cleveland Association, see Jimmy Meyer's recently published study, <em>Any Friend of the Movement</em> [Ohio State University Press, 2004].)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
