
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #3 (Fall 1992)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #3 (Fall 1992)</h1>
<div class="maintext">
<h1>"International Planned Parenthood Celebrates 40th Anniversary"</h1>

  <p>  On November 29, 1952, at an international family planning conference held in Bombay, representatives from
birth control organizations from eight nations (England, India, the Netherlands, Hong Kong, Singapore, Sweden,
West Germany and the United States) officially formed the International Planned Parenthood Federation
(IPPF).  Its joint presidents were Indian birth control leader Lady Dhanvanthi Rama Rau and Margaret Sanger. 
Long a staunch supporter of an international birth control movement, Sanger hosted the Sixth International Neo-Malthusian and Birth Control Conference in New York in 1925 and organized the World Population Conference
in Geneva in 1927.  In 1930, Sanger and British  birth control advocate Edith How-Martyn, founded the Birth
Control International Information Center in London to create a clearing-house for birth control information and
foster a network of birth control advocates around the world.</p>

<p>    Sanger cultivated close relationships with leaders of the birth control movements through a series of
international tours in the 1920s and 1930s, most notably to India, Hong Kong, China and Japan.  After World
War II, Sanger helped form the International Committee on Planned Parenthood (ICPP)
which sought to revive
the family planning movement after the devastation of the war.  But the goal of the ICPP was to establish a
permanent international organization to foster family planning on a global scale.</p>


<p>    The success of the 1952 Bombay conference was
largely due to the efforts of Margaret Sanger, who
contacted Lady Rama Rau and suggested that she
host an international conference in 1952 and who
raised money to bring delegates to India and
procured the public support of such notables as
Albert Einstein. Her colleagues, while at times
annoyed with her tendency to toward unilateral
action, acknowledged her siginificant contributions
by electing her, with Lada Rama Rau, as Honorary
Co-Chair.</p>

<p>    At a 1953 meeting held in Stockholm, an IPPF
constitution was ratified, its goals and an
organizational structure defined, and Margaret
Sanger was elected president, a position she held until 1959. Though in her seventies and increasingly frail,
Sanger nevertheless devoted her time to trying to direct the growth of the infant organization to reflect her
unwavering conviction that by reducing the number of unwanted children, birth control would facilitate a more
efficient allocation of economic and social resources.  </p>

<p>    Among the things revealed in Sanger's papers is her role in the conflict surrounding the definition of IPPF's
agenda.  While Sanger retained her commitment to birth control as a fundamental individual right of women, she
pragmatically viewed the new post-World War II interest in population control with its strong ties to neo-Malthusian interests, as useful to the goals of the organization.  "In this country," she explained to Sweden's Elise
Ottesen-Jensen, "the population problems of the world are arousing greater interest than all our lectures and books
combined could do." (MS to Jensen, April 22, 1949, Records of the IPPF).  Sanger was also adamantly opposed to
Swedish and Dutch groups who wanted to focus on marriage, infertility
counseling, and sex education, not
exclusively on population control. As president, she opposed all efforts to broaden IPPF's mission beyond the
dissemination of birth control.  When Sanger relinquished the presidency in 1959, the IPPF had grown into the
largest, private international organization devoted to promoting family planning.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
