
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #6 (Winter 1993/1994)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #6 (Winter 1993/1994)</h1>
<div class="maintext">
<h1>"Motherhood in Bondage"</h1>

<p>     Despite Margaret Sanger's belief that birth control would help working-class women,
critics then and now argue that her movement primarily benefited middle-class women.  In
1929, in response to such accusations, Sanger published <em>Motherhood in Bondage</em> (<em>MIB</em>), a
compilation of letters from urban and rural poor and working-class mothers.  Many wrote
Sanger not just as a means for getting information on birth control, but as a cathartic outlet for
their problems.  The letters selected for publication were drawn from hundreds of thousands of
letters Sanger received in the 1920s, some of which still survive at the Sophia Smith Collection
and Library of Congress.  The letters served to remind Sanger and her staff of the reasons they
began their work.  MIB was employed as an effective public relations tool to illustrate the
socio-economic rationale for birth control.  As Sanger wrote in the introduction, "It is my
conviction that the publication of these profoundly human documents will do more toward the
alleviation of the poignant miseries attested to than any other immediate step."  </p>

<p>     The catalogue of problems revealed in these "client letters" &ndash;  adolescent motherhood,
poverty, solitary confinement, failed marriages, desperate remedies, and doctors who would
not release birth control information   
depicted the painful and tragic consequences of uncontrolled childbearing.  According to Mary Sumner Boyd's analysis of these letters which was appended to the book, 80% of the mothers who wrote to Sanger were married before age twenty.  The average family had five children; one woman had eight children by the time she was twenty-one.  Letters came from women who had borne ten children after
twenty pregnancies, or had delivered fifteen children, only to have eleven die during their first year.  One wrote
of having seven miscarriages in eight years (<em>MIB</em>, Appendix).  </p>

<p>     Nevertheless, the content of these letters transcends their statistical relevance.  Their impact is in their
collective voice.  As one woman asked, "Why must a woman suffer so much?  Surely God didn't mean such a
thing if there isn't a way to provide for it all.   I love my babies but I would gladly do something to prevent any
more little ones suffering," (April 22, 1935).  Another pleaded, "I get so that at times I cannot stand just a little baby's
cries.  It works me in such a state that I pull my hair and scold and whip him merely for nothing....I dread
bringing these innocent babies into this world for me to abuse, for I am almost insane and dreadfully nervous at
times" (<em>MIB</em>, p. 63)  </p>

  <p>   Doctors warned these women against further pregnancy, but refrained from giving any technical advice
concerning contraception;  most were afraid to violate the laws banning dissemination of birth control
information.  Confused by her doctor's mixed signals, one mother writes, "directly after the birth of a child I go
insane for about three or four months.  The doctor said I Should stop giving birth to children, but will not tell me
how.  If you will please help me, I will be blessed and free from suffering" (09/15/924).   Others stressed the
medical immediacy of their dilemma: "when my second youngest was born I had kidney or uremic poisoning....I
was blind and had convulsions and since, I'm not well at all....the doctor said if I had anymore I couldn't live thru
it, but he will not tell what to do to prevent from getting any more" (December
  7, 1931)</p>

  <p>   Many of the letters reveal a sense of guilt; women blamed themselves for their failure as mothers, and
reluctantly pursued birth control, contrary to their Christian upbringing.  "Perhaps you will think I am selfish to
be asking for help," one woman implored, "but I don't want to be like the women that wrote the letters in your
book [<em>Woman and the New Race</em>]" (April 28, 1924).  Another woman, attempting to reconcile her faith with the
realities of her everyday experience, commented, "I want to lead a Christian life, but it is awful awful hard to live
it & give birth & carry babies & care for them & suffer & nearly die with misery & pain & do what is right"
  (June 23, 1924).  Still another wrote, "I am very fond of babies and I have prayed and prayed to the good Lord over
and over again for one until now I pray just for the opposite that I shall never bring any crippled children into the
world to suffer, as that I think is the greatest sin I can ever commit" (<em>MIB</em>, p. 138).     </p>

 <p>    In her book, Sanger reminds readers that none of the letters requesting contraceptive information were prompted by selfishness &ndash; nor does one find evidence of the mothers' efforts to shirk maternal duties or responsibility.  Their motives revolved around the welfare of their children and the protection of their family.  Prophetically warning those who opposed birth control, Margaret Sanger argued in <em>Motherhood in Bondage</em>, "If her past experience in bringing children into the world has been one of suffering and of a kind to strike terror to her heart, the mother is forced into a situation in which she is ready to accept the only way out - abortion" (<em>MIB</em>, p. 394).  </p>

<p>     Most of the original letters sent to Sanger
were forwarded to state birth control leagues for
responses and have not been preserved. 
Fortunately, some, including many which were
never published, are in Sanger's Papers at the
Sophia Smith Collection (which is being
microfilmed by the project) and the Library of
Congress microfilm. Sanger continued to receive
similar letters through the 1950s, often in
response to national press or an article published
by her.  For the Margaret Sanger Papers Project,
the letters created a dilemma as we sought to
insure access to this material by including these
letters in our editions, while still protecting the
privacy of authors.  After polling our Advisory
Board and several lawyers, physicians, and other
historians, we decided on a compromise solution.
To maintain the women's anonymity, the project
will remove the name of the author (though
preserving the date and place of origin).  Access
to them will be enhanced by grouping them
separately in the index as Client Letters.  Our
target notes will indicate the repository in which
the originals can be found. </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
