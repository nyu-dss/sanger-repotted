
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #3 (Fall 1992)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #3 (Fall 1992)</h1>
<div class="maintext">
<h1>"Presidential Politics: Margaret Sanger in the Voting Booth"</h1>

 <p>  Since pundits have declared 1992 the "year of the woman,"
and Democratic presidential hopefuls have enthusiastically
pursued the pro-choice vote, project staff thought it would be
interesting to see how the pioneer of reproductive rights voted
in presidential elections.</p>

<p>    Not surprisingly, Sanger generally derided party politics
and admonished the majority of politicians in both major
parties for their unwillingness to support birth control
legislation and federally-funded birth control clinics.  She cast
her vote almost exclusively for Socialist candidates: for
Eugene V. Debs in 1920 (when he ran his campaign from
prison) and for Norman
Thomas in every
subsequent election with
two exceptions.  In 1928
when the Democratic
candidate was Al Smith,
Sanger rippled with
anger over the
emergence of a Catholic
nominee and wrote in
her journal, "we are for
Hoover, tho ordinarily
I'd be for Norman
Thomas &ndash; except that Al
Smith must be kept out!"</p>

<p>   In 1960, Sanger went
public with her politics and her anti-Catholic rancor when she
openly opposed the Democratic nominee, John F. Kennedy.
Despite his public commitment to separation of church and
state, Sanger told reporters, "In my estimation a Roman
Catholic is neither Democrat or Republican.  Nor American,
nor Chinese; he is a Roman Catholic."  Not content with just
voicing her opposition, Sanger, at the age of 82, threatened to
leave the country if Kennedy won the election.  The response
to her statement was immediate. Throughout the election year,
Sanger was flooded with hundreds of letters, mostly hostile,
many in the form of farewell cards, mock plane reservations,
and an assortment of sarcastic insults signed "JFK."  From all
accounts, it appears that Sanger cast her vote for Richard
Nixon.  However, when Kennedy was elected, Sanger
reconsidered her threat, and decided to give Kennedy a year,
"and see what happens.  I will make my decision then." 
Fortunately for Sanger, by the next year the press and public
soon forgot her ultimatum and she quietly decided she could
live in the U.S. with Kennedy as president after all.</p>

<p>    If Sanger usually reserved her vote for Norman Thomas,
she did voice her preference among the other candidates.  In a
1932 letter to Havelock Ellis, she predicted that Franklin D.
Roosevelt would defeat Herbert Hoover and would be "more
agreeable" than Hoover who had "given to bossing the job
without consultation," and that "Congress does not want that
type in the White House."  After Roosevelt's election,
however, Sanger blamed him for the nation's financial woes.
More typically, she was also disturbed by what she perceived
as the increased power of Catholics in his administration. 
"Priests having tea at the White House....," she complained to
Ellis, "I want to die and leave the country never to return." 
Her only comfort was the knowledge that "well-anyway the
cause of birth control marches on!"  Sanger tolerated Truman
and liked Ike (a little), but not enough to change her socialist
vote, surely one of the few to be cast in Tucson during the
1950s.</p>

<p>     Though Sanger's participation in presidential elections
was minimal, she convinced thousands of Americans to cast
their votes for birth control in local, state, and national
elections.  And while Sanger's determined voice is notably
absent from today's rancorous debate on reproductive
freedom, her legacy is realized in the strong pro-choice and
"women's vote" that may well decide the 1992 election.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
