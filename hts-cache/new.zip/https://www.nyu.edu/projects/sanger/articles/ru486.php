
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #3 (Fall 1992)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #3 (Fall 1992)</h1>
<div class="maintext">
<h1>"The RU486 Abortion Seizure Controversy: Echoes of <em>U.S. v. One Package</em>"</h1>

<p>   Lawrence Lader, head of Abortion Rights Mobilization and
author of <em>The Margaret Sanger Story</em> (1955), took a page from
Sanger's strategy book in early July when he and his
colleagues arranged a test case challenging laws banning the
importation of RU486, the so-called French abortion pill.  The
well-orchestrated incident in which a pregnant woman, Leona Benten, attempted to bring 12 RU486 pills through a customs
check at Kennedy airport, dramatically recalls the U.S. v. One
Package case instigated by Sanger in the 1930s.  We see
striking parallels between the older case and the recent court
actions that began when a Brooklyn judge overturned the
Federal seizure of the RU486 and Justice Clarence Thomas
upheld the seizure.</p>

<p>    In 1933, after several unsuccessful years of lobbying for a
congressional amendment to repeal the Comstock Law banning
the dissemination of birth control information on grounds of
obscenity, Sanger decided to turn to the courts.  Teamed with
formidable civil liberties attorney, Morris Ernst, Sanger
arranged for a Japanese doctor to send a package of
diaphragms to Dr. Hannah Stone, director of Sanger's Birth
Control Clinical Research Bureau.  Customs agents were
alerted and the package was seized as a violation of the 1930
Tariff Act (an outgrowth of the 1873 Comstock Law) that
prohibited "all persons ... from importing into the United
States from any foreign country ... any article whatsoever for
the prevention of conception...."  Sanger and Ernst contested
the seizure, and the case, officially known as <em>United States v.
One Package Containing 120, more or less, Rubber Pessaries
to Prevent Conception</em>, began its journey through the courts.</p>

<p>    The case came up for trial in the U.S. District Court in
New York in December 1935.  Judge Grover M. Moscowitz
dismissed the case, stating that Federal restrictions should not
apply to materials intended for legitimate medical purposes, an
argument which Sanger had trumpeted publicly since her first
clinic was shut down by the police in 1916.  The Federal
Government appealed the decision and in November of 1936,
in the Second Circuit Court of Appeals in New York, Justices
Augustus N. Hand, Learned Hand, and Thomas W. Swan
delivered a landmark decision in Sanger's favor.  Not only did
they uphold the District Court's decision, but they struck at the
framework of the Comstock Law, asserting that it had become
obsolete.  Contraception, the judges argued, had proven over
time to be safe and was advocated by "a weight of authority in
the medical world."</p>

<p>    Sanger called the One Package decision "the greatest legal
victory in the birth control movement."  It opened the mails
for physicians to receive contraceptives and removed the stain
of obscenity from Sanger's now popular crusade.  However,
importation restrictions on non-physicians remained in effect
until 1971.  As the RU486 incident underscores, the Federal
government has continued to use the importation laws to
restrict access to contraceptives and abortifacients.</p>

<p>The
One
Package
decision
was
another
public
relations
triumph
for
Sanger,
who
clearly
grasped
the
importance of effective publicity during her long campaign to
legalize contraception.  As he engineers his own considerable
public relations campaign around RU486,  Lawrence Lader is
paying homage to the subject of his 1955 biography. We can
only hope that he is as successful.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
