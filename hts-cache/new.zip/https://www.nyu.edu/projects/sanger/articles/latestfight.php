
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #57 (Spring 2011)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #57 (Spring 2011)</h1>
<div class="maintext">
<h1>"The (Latest) Fight for Federal Funding for Birth Control"</h1>

<p>&ldquo;I cannot imagine anything more emphatically a subject that is not a proper political or governmental activity or responsibility,&rdquo; a Republican Party leader told reporters when asked about government funding of family planning. Many of you have probably followed the current and increasingly bitter debate over government funding of birth control and reproductive health services, and you may have heard similar statements coming from the likes of the new Speaker of the House John Boehner, and former speaker and presidential aspirant Newt Gingrich. However, the words above were uttered not by Boehner or Gingrich, but by President Dwight Eisenhower in December 1959 in response to a government committee recommendation that the U.S. provide birth control aid to developing nations. &ldquo;This government,&rdquo; Eisenhower added, &ldquo;will not as long as I am here have a positive political doctrine in its program that has to do with birth control. That&rsquo;s not our business.&rdquo; (<em>New York Times</em>, Dec. 6, 1959) </p>
<p>Those words drew sharp protest from Margaret Sanger in one of her last public utterances. At the age of 80, she challenged President Eisenhower to a debate to &ldquo;put him straight on the question of planned parenthood.&rdquo; In newspaper interviews and in a rare television appearance in Tucson, Sanger asserted that Ike &ldquo;has been misinformed. He has been influenced by the opposition&ndash;by the Irish Catholic bishops.&rdquo; (&ldquo;Sanger Blasts Ike on Births,&rdquo; <em>Independent Star </em>(Pasadena), Dec. 28, 1959; &ldquo;Mrs. Sanger Challenges Ike on Birth Curb Issue,&rdquo; <em>Tucson Daily Citizen</em>, Dec. 28, 1959.) </p>
<p>For one more time in her long career, Sanger succeeded in making headlines and keeping the issue of birth control alive in the news for several days, much to the discomfort of the leading presidential candidates for 1960, particularly the Democratic candidate, Senator John F. Kennedy. This unexpected public debate over birth control funding forced the Massachusetts Senator to answer the question of how his Catholic faith would influence his presidential decision-making. He responded that he would always act &ldquo;in the interests of the United States.&rdquo; Luckily for him, his views on including birth control in U.S. foreign aid&ndash;he was against it because &ldquo;it would be a mistake for the U.S. to advocate birth control in other nations for it was up to the nations themselves&rdquo;&ndash;was overshadowed by Eisenhower&rsquo;s unequivocal rejection of the idea (quoted in <em>New York Times</em>, Nov. 28, 1959). </p>
<p>Not surprisingly, Eisenhower did not wish to debate the issue and did not respond to Sanger&rsquo;s scolding, which she extended into a short treatise on birth control and population planning in the form of a letter-to-the-editor to newspapers across the nation, including the <em>New York Times</em>. In her letter, Sanger noted that the government was already involved in population programs around the world. She pointed to federal public health efforts to eradicate disease and other work to reduce death rates. And, although she did not mention it, the government had in the past quietly supported a few birth control programs, including a network of clinics that opened in Puerto Rico in the mid-1930s, and a Farm Security Administration project in the late 1930s that delivered contraception to migrant workers in the Southwest and California. Additionally, many states supported family planning services since North Carolina first incorporated contraceptive clinics into its public health program in 1937. Government funding of family planning was hardly a new concept (MS to Editor, <em>New York Times</em>, Jan. 3, 1960).</p>
<p>In her lengthy letter Sanger also emphasized what she believed to be the real reason Eisenhower and many other politicians refused to approve federal support of family planning services: Catholic opposition. The president came under significant pressure from the Church immediately following the recommendation issued by the Eisenhower-appointed Draper Committee to include support for birth control programs in foreign aid packages. Most notably, a conference of U.S. Catholic bishops condemned the recommendation and declared that &ldquo;the promotion of artificial birth prevention is a morally, humanly, psychologically and politically disastrous approach to the population problem.&rdquo; (&ldquo;Statement by Roman Catholic Bishops of U.S. on Birth Control, <em>New York Times</em>, Nov. 26, 1959.) </p>
<p>In her television appearance as well as in her letter to the <em>Times</em> and other papers, Sanger called for the government to reject &ldquo;the short-sightedness of the Roman Catholic hierarchy&rdquo; and stop succumbing to the dictates of a minority religious group. &ldquo;This dogmatic attitude,&rdquo; she wrote in reference to the Church, &ldquo;about their special religious belief as controlling their personal and official conduct through life is all right for Roman Catholics in the United States, but their edicts and bulls should not be allowed to stifle the basic American freedom of people who are not adherents to the Roman faith.&rdquo; &ldquo;Today,&rdquo; she concluded, &ldquo;the government needs to &ldquo;listen to the voice of a majority of its voters. We believe the majority want proper medical care and aid to be given to the sick, undernourished, troubled people&ndash;children, mothers and families everywhere in the world. Birth control and contraceptive practices are a medically recognized part of current ethical healing.&rdquo; (MS to Editor, <em>New York Times</em>, Jan. 3, 1960 [quotes]; MS, &ldquo;Statement on Television Channel 13, Tucson,&rdquo; Dec. 27, 1959 [<em>MSM</em> S72:987].) </p>
<p>Eisenhower&rsquo;s rejection of federal aid for birth control turned out to be a defensive last stand&mdash;at least for a while. By 1964, after leaving office, Eisenhower became convinced that overpopulation needed to be combated both in the United States and overseas. Along with fellow former president, Harry S. Truman, he agreed to serve as honorary co-chair of the Planned Parenthood Federation of America. A few years later birth control and population control proponents succeeded in winning government support for family planning services at home and abroad. Those 1960s initiatives culminated in Title X of the Public Health Service Act, signed into law by President Nixon in 1970 to provide funding for population research and voluntary family planning programs. It is the Title X funding that is currently under attack. (Donald Critchlow, <em>The Politics of Abortion and Birth Control in Historical Perspective</em> [University Park, Penn., 1996], p. 10.) </p>
<p>What was won back then, we are in danger of losing again. Unfortunately, today the debate over federal support for family planning is again being debated. Led by stalwart anti-abortion advocate, Representative Mike Pence (Rep., Indiana), the Republican majority in the House of Representatives voted through a budget bill on February 19 that included an amendment to eliminate the roughly $320 million in funding for Title X. They do not believe the current U.S. law prohibiting the use of federal money to fund abortion goes far enough. </p>
<p>Supporters of reproductive rights and family planning programs have been quick to object to the proposed funding cuts, highlighting the potentially disastrous health consequences and noting the taxpayer money that is ultimately saved through reproductive health care. &ldquo;This is an extreme proposal,&rdquo; PPFA President Cecile Richards said in a press release statement, &ldquo;and the new leaders of the House are pushing it forward at great risk to women and at their own political peril.&rdquo; (Statement by Cecile Richards, Feb. 9, 2011 [<a href="http://www.plannedparenthood.org">www.plannedparenthood.org</a>].) </p>
<p>Some religious groups, particularly evangelical Christians and Catholics, are leading the fight against reproductive choice. They are forthright in linking their political endeavors and specific policy positions with their religious faith. Rep. Pence recently quoted scripture as a directing force in his anti-abortion activism: &ldquo;Rescue those being led away to death; hold back those staggering toward slaughter.&rdquo; (<em>Proverbs</em> 24-11.) He is by no means alone among anti-abortion politicians in citing a religious basis for a policy decision. (Excerpts of remarks by U.S. Rep. Mike Pence to the Susan B. Anthony Campaign for Life Gala - February 16, 2011 [<a href="http://www.mikepence.com">www.mikepence.com</a>].) </p>
<p>Sanger&rsquo;s public outburst against Eisenhower in 1959 gave her one last chance to warn society to be wary of powerful figures in the Church and in public service who &ldquo;have chosen to attack the separation of State and Church which is fundamental to our government.&rdquo; It also provided her an opportunity to agitate birth control proponents and nudge Planned Parenthood to take advantage of the publicity (&ldquo;I hope PPFA goes after him with all its strength,&rdquo; she wrote another movement leader). It seems we need Sanger&rsquo;s voice again. (MS to Editor, Dec. 29, 1959 and MS to Edna Rankin McKinnon, Dec. 4, 1959 [<em>MSM</em> S56:261 and 150].)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
