
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #30 (Spring 2002)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #30 (Spring 2002)</h1>
<div class="maintext">
<h1>"Sanger and the 'Red Virgin'"</h1>

<p>Here is how Margaret Sanger was introduced in 1931 to  the Spanish
prodigy known by one name&ndash;Hildegart; who was called the "Red Virgin" by
her "comrades"; who had reached a level of notoriety uncommon for a Spanish
woman and unheard of for a girl her age; and who would, just two years
later, become immortalized by tragedy rather than her remarkable achievement.</p>

<p> The first letter, written on October 23, 1931, started out like
so many sent to Sanger from young, seemingly uneducated women seeking advice:
a short tribute in broken English followed by a plea to hear my story:
"I know that you read with special interest all letters from youths, though
this be perhaps a little longer than other you receive, I beg of you most
sincerely to lend it a bit of your attention. . . ."  But then the
letter took a strange detour from those that Sanger typically received;
this personal account had nothing to do with an unwanted pregnancy or desperate
need for contraception.  "I am a girl," it went on to say, "my age
is sixteen years and I am Spanish . . . . Though my age is not great, I
have finished my lawyer profession on September of this year, and I am
studying Philosophy and Medicine."</p>

<p>The young letter writer then rattled off a series of unbelievable achievements
for an adolescent.  In addition to having earned her law degree (though
she could not legally practice until age 21), she had studied the work
of Sanger and other birth control pioneers as well as the great European
sexologists, which inspired her to write two books (<em>Sexo y Amor</em> and <em> La
Revolucion Sexual)</em> and three pamphlets  (<em>El Problema Eug&eacute;nico</em>,
<em>
La Limitaci&oacute;n de la Prole</em> [Offspring], and <em> Educaci&oacute;n
Sexual</em>)
on the subject of sexual reform, all published in Madrid and successfully
circulating among the working-class. She was about to publish a new book: <em>
La Rebeli&oacute;n Sexual de la Juventud</em> (<em>The Sexual Revolt of Youth</em>). 
She also spoke on behalf of the Socialist Party in Madrid which she had
joined at age 14.  She needed help from Sanger, the woman she admired
"so profoundly," in obtaining information on American customs and laws
regarding sexual issues.  She closed the letter "yours sincerely true
friend and pupil," and signed it "Hildegart, Lawyer. Madrid Spain."  
(Hildegart Rodriguez to MS, Oct. 23, 1931 [LCM 19:1233]).</p>
<p>It is likely Sanger found Hildegart's story improbable until she heard
from Havelock Ellis a few weeks later that he had received a similar letter
from a Miss Hildegart, and though she "seems a miracle," she wrote in such
a "simple, natural, matter-of-fact way that I am quite inclined to take
her seriously." Sanger responded to Ellis, still unsure if this phenom
was for real: "I am laughing with you at the galloping youth of Spain.
. . I loved the jumps she made! like a race horse run wild." (Ellis to
MS, Nov. 13, 1931 [LCM 5:304]; MS to Ellis, Nov. 28, 1931 [MSM S6:517]).</p>
<p>Sanger sent Hildegart a short, formal letter in early December 1931,
enclosing bibliographies and movement literature, but held off writing
a more personal response.  Meanwhile Ellis could not stop talking
about "My Spanish lawyer girl." He wrote to Sanger on December 11 that
she "seems quite one of the wonders of the world!"  Ellis was especially
taken by the fact that Hildegart was born just a few days after he and
Sanger met in his London flat in December 1914 &ndash; as though Hildegart represented
an imaginable product of this momentous first union of famous birth controller
and noted sex philosopher.  Ellis supplied Sanger with more of Hildegart's
incredible biography, including that she "could read at 2; went to the
University at 13; knows five languages, and has published nine books."
He had also received a photo of the girl and described her as looking "very
mature, solid &amp; healthy &amp; sweet." (Ellis to MS, Dec. 11, 1931 [LCM
5:312].)</p>
<p>In a profile of Hildegart that he published in 1933, Ellis offered more
details culled from her letters to him:  "She never went to school,
her first teacher being her mother who included natural history in the
course, not omitting some sexual instruction, though at the time such a
thing was in Spain unknown."  "I remember," Hildegart wrote in one
of her letters, "that when I was about three years old, I learnt that the
rose was hermaphrodite.  At that time one of our servant girls was
named Rosa, and that same day I ran to her and said: ‘Rosa, you are a hermaphrodite!' 
She asked what that was, and when I ingeniously explained that it meant
being male and female at the same time, there was, as you may imagine,
a scene."</p>
<p>Ellis was fascinated with Hildegart's description of her "strong and
youthful" single mother, an anarchist who carefully directed her daughter's
education and accompanied her everywhere.  "I was a eugenic child,"
Hildegart wrote Ellis in explaining how her mother had developed a master
plan for her only child, and "the complete work of herself." No mention
was made of who Hildegart's father might have been. Ellis included Hildegart's
mother, Aurora Rodriguez, "among what I call the ‘New Mothers' of to-day."</p>
<p>In discussing her university education, Ellis noted in an article on
Hildegart that she had translated a rare Latin book of Spanish philosophy
and, at age 14, claimed a prize at the Barcelona Exhibition for an essay
on famous lovers in literature. He surveyed Hildegart's "clear and vigorous"
publications which apparently sold well in Spain; one pamphlet sold 8,000
copies in Madrid in its first week of publication.  Hildegart most
preferred her longest book,  <em>La Rebeli&oacute;n Sexual de la Juventud</em>,
in which she writes: "The only rule of morality for youth, however paradoxical
it may seem, is that expounded by St. Paul: ‘Everything is lawful but not
everything is convenient.'" In the epilogue to the book she exclaims: "To
your posts! Foreward! Make way for the new generation!"</p>
<p>Ellis added, "She is also active in lecturing and organizing. 
In many of the large towns in Spain she has lectured in the cause of Socialism
in halls that were crowded, and sometimes even the approaches to them,
to enthusiastic 'comrades' who acclaim her as the 'Red Virgin,' and whose
applause, on one occasion at all events (so I read in the newspaper report),
'lasted for more than five minutes.'"  And, apart from lectures on
Socialism and sexual reform, she spoke at times on religion, having once
given a series of five lectures in Madrid on "the subject of Jesus." 
(Ellis, "The Red Virgin," <em> The Adelphi </em> [June 1933], 175-179.)</p>
<p>Sanger received a second letter from Hildegart in January 1932, requesting
more information about Sanger's clinic in New York, recent contraceptive
studies and the history of the movement.  Though her uneven use of
English at times masked her intelligence, Hildegart displayed a comprehensive
knowledge of the history of Malthusianism and both the European and American
birth control crusades. And she was supremely confident that she could
quickly gain a practical understanding of contraception, despite her age
and sexual inexperience, in order to lead a clinic movement in Spain: "I
intend to do whatever is possible for birth control diffusion. . . . I
am studying Medicine profession, so that I have knowledge of technical
problems, and it is rather easy for me to learn everything." She also noted
that the timing was right, (King Alphonso XIII had been deposed in 1931
and a republic formed) for her to take on this work:  "[The] Republic
allows us greater liberty in our movements and I will try to profit it."
(Hildegart Rodriguez to MS, Jan.? , 1932 [LCM 19:1265]).</p>
<p>Impressed by Hildegart's sophistication and learning, and obviously
flattered that Hildegart wished to have Sanger's input in this area of
her education, and delighted that she hoped to duplicate in Spain much
of what Sanger accomplished in the U. S., Sanger wrote back to invite her
to join  the Birth Control International Information Centre in London:
"Your marvelous accomplishment is splendid; now that you have a new Government,
you should have Birth Control Clinics all over Spain.  They should
be established and all instruction to working women and mothers given by
women doctors (if possible). . . . I wish you would become a part of our
international work and form a center of information in Spain." With Ellis's
help, Hildegart had already arranged to open a Spanish branch of the international
educational and lobbying organization, the World League for Sexual Reform. 
In just a few months she had persuaded both Ellis and Sanger to supply
her with an abundance of intellectual and practical material on sexual
science, eugenics and birth control, and to usher her into the inner circle
of international sex reform advocates. (MS to Hildegart Rodriguez, Feb.
19, 1932 [LCM 19:1242].)</p>
<p>In several of her letters Hildegart paid tribute to Sanger as an inspiration
and guide. She kept of a photo of Sanger in the sitting room in the house
she lived in with her mother and cherished Sanger's books, "You can't know
how grateful I am," she wrote in the midst of a long request for further
literature from America, "I will speak greatly of your work." Hildegart
also offered that "My mother that has read your book [My Fight for Birth
Control] a great many times and that admires you greatly bids me to send
you her most affectionate regards." (Hildegart Rodriguez to MS, March ?,
1933 [LCM 19:1251].)</p>
<p>Over the next year and a half, Sanger continued to send Hildegart research
materials on birth control and on one occasion had a request for Hildegart. 
In March of 1932 Sanger wrote to ask for samples of contraceptive sponges
used in Spain that Hildegart had written about in one of her pamphlets. 
Then Sanger considered whether to ask Hildegart to host a major international
birth control conference in  Madrid, possibly in the fall of 1933,
as a way of jump-starting a Spanish movement.  But Ellis cautioned
Sanger about giving Hildegart too much responsibility at such a young age. 
He wrote in January of 1933 that though Hildegart was "wonderfully accomplished
&amp; energetic  . . . she is still so young &amp; inexperienced in
conference organization," not to mention that  "her youth &amp; success
arouses jealousies, especially among some of the men." Sanger went ahead,
despite Ellis's reservations, and interested Hildegart in hosting a conference
in September.  "I will try to do my best," came her humble response.
(MS to Hildegart Rodriguez, March 2, 1932 [LCM 19:1243]; Ellis to MS, Jan,
30, 1933 [LCM: 366]; Hildegart Rodriguez to MS, Apr. 16, 1933 [LCM 19:1255].)</p>
<p>But Hildegart made no firm promises as she had taken on so many other
projects. She admitted to Sanger in March, "You can't imagine how busy
I have been in the last months of past year."  By the spring of 1933
Hildegart had completed her academic studies at the University of Madrid
and had begun work on a dissertation on "sexual criminology."  
In April she helped organize a Spanish eugenic congress in Madrid, at which
she gave six lectures on birth control.  She planned to edit a three-volume
collection of papers given at the congress; "I think it will be the greatest
work done about Eugenics and Birth Control. . . ."  She led efforts
to establish a birth control clinic in Valencia and intended to open others
in Malaga and Madrid by the summer.   She had recently founded
and edited the first journal in Spain devoted to "sex subjects." Somehow
she also had found time to complete her latest book, <em> Malthusianismo y
Neomalthusianismo</em>,
a copy of which she promptly sent to Sanger. (Hildegart Rodriguez to MS,
March ? and April ?, 1933 [LCM 19:1251-1253]; Havelock Ellis, "The Red
Virgin," 179.)</p>
<p>Then suddenly it all ended. Sanger received three different letters
from friends in early July 1933, all bearing "the same horrible &amp; sad
news." "I have had a great shock this morning," Ellis wrote Sanger on June
13.  He described the news reports a friend had sent him.  On
the night of June 9th, Hildegart's mother, Aurora, entered her daughter's
room and shot the sleeping Hildegart four times.  Apparently Hildegart
had announced her intention to leave home and her mother could not bear
the thought of separation.  Hildegart was dead at age 18.</p>
<p>Ellis could not get over it: "Mother &amp; daughter were devoted to
each other, &amp; the mother constantly sent affectionate messages in the
letters that have been coming regularly from Hildegart." Sanger responded
that her friend, Dr. Johannes Stutzin, then living in Madrid, wrote to
her that Hildegart had "a friend," a lover that incensed her mother. Sanger
added that another associate, Emily Rieder, who had recently been in Spain
and briefly spent time with Hildegart and Aurora Rodriguez, said that the
"mother was insanely jealous of [Hildegart's] every independent thought."
(MS to  Ellis, July 4, 1933 [MSM S7:926]; Ellis to MS, June, 13, 1933
[LCM: 375].)</p>
<p>In May 1934 Aurora Rodriguez was found guilty of killing her daughter
and sentenced to 26 years, eight months, and one day in prison.  She
apparently said little about the murder.  She was described as "calm
and collected" in the courtroom, "continually sniffing at a bunch of red
carnations." She died in 1955 in an asylum for the criminally insane. 
Since then much has been written in Spain about the murder of the "Red
Virgin." The tragedy has inspired novels, plays and films, most of them
focused on the mother/daughter relationship. Many unanswered questions
keep the story alive in the Spanish press, such as who was Hildegart's
father, where had she told her mother she was going (some have guessed
she was planning to visit Ellis or H. G. Wells in England), and who might
have been her lover.  ("Murder of an Infant Prodigy; Anarchist Mother
Sentenced," <em> The Times</em>, May 28, 1934; Cambio16 [May 11, 1987], 130-136 [December
2, 1991], 125-126.)</p>
<p>Sanger wrote several letters in 1933-1934 trying to get more information
on "my dear friend Hildegart" and mentioning Hildegart's "splendid work"
for the cause. Little more was said in her correspondence with Ellis, and
oddly there is no trace of the books Hildegart sent Sanger, just a small
folder of letters in the Library of Congress collection, including an undated
note Sanger wrote to her secretary that reads, in part: "This girl Hildegart
is an amazing person." (MS to Jaime Menendez, Dec. 6, 1933 [LCM19:1258];
MS to Jose Maria Gomez Ullate, Apr. 5, 1934 [LCM 19:1263]; Sanger to Florence
Rose, 1933? [LCM19:1259].)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
