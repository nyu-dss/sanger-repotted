
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #32 (Winter 2002/2003)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #32 (Winter 2002/2003)</h1>
<div class="maintext">
<h1>"The Sanger-Hitler Equation"</h1>

<p>Search for Margaret Sanger's name on the Internet and you will quickly be
bombarded by claims that she supported Hitler and the Nazi's human elimination
programs, or at the very least inspired the Nazi architects of race improvement.
"Hitler and Sanger Join Hands" blares one anti-Sanger diatribe; "Margaret
Sanger, Sterilization and the Swastika" is the title of another; "Let us
look forward to the day when Planned Parenthood clinics are made into holocaust
museums," concludes another attack on Sanger's writings. One web site
features photos of Sanger and Hitler united under a Swastika. Another inserts
the phrase "concentration camps" into a 1932 Sanger speech to demonstrate
her real motives, a novel form of textual annotation that is then passed on like
a virus to other sites who point to the phrase as documented evidence of Sanger's
final solution.</p>
<p>Though this disinformation campaign, designed to arouse anger and anti-choice
activism, resides largely on the Internet, in colorful, sensationalized pages,
even the more respectable print outlets have picked up many of the most extreme
Nazi-related allegations about Sanger as voiced by anti-abortion activists at
newsworthy events or on Op-Ed pages. They then print them without comment, in
effect publishing them as fact. The Associated Press, for example, reported on
an anti-abortion march in Birmingham on October 14 of this year, quoting a
participant who described Sanger "as racist as she could be," and linked her
to Hitler's race policies. A Canadian paper, the <em>Calgary Sun</em>, ran a
Sept. 1 opinion piece that claimed Sanger "backed the Nazi race purification
program until it became unfashionable." And even though mainstream
publications are not actually calling Sanger a Nazi, they are, increasingly,
referring to her (as the <em>New York Times</em> did in a September 19 article on
the opening of the Museum of Sex in New York City) as a "eugenicist" before
associating her with birth control.</p>
<p>Every year there are dozens more characterizations of Sanger as a pro-Nazi,
genocidal racist appearing in newspapers, right-wing biographies and purported
histories of planned parenthood, and especially on the Internet. Sanger is by no
means alone among controversial social reformers and liberators painted as
grotesques by extremist opponents of their beliefs and accomplishments; Martin
Luther King, Jr., and Eleanor Roosevelt can ably compete with her for this
posthumous fame. But the attacks against Sanger resonate in a way that attacks
on others do not, largely because of the emotions generated by the abortion
debate.</p>
<p>Unfortunately these misrepresentations of Sanger as a Nazi sympathizer who
carried out her own quiet form of genocide through abortions, the spread of
harmful contraceptives and the advocacy of racist "eugenic" policies &ndash;
supported by the circulation of Sanger's controversial writings on eugenics &ndash;
have begun to infect unbiased student research that is increasingly dependent on
unverified and unsubstantiated information only a mouse click away. Granted most
of the Internet sites that link Sanger and Hitler as the dark angels of human
carnage don't hide their pro-life, anti-choice associations. But the "Big Lie"
theory works &ndash; the more you say it, the more it sticks.</p>
<p>Sanger never met Hitler, except in her unconscious (<a href="#dream">see below</a>). And the
reality is that despite the fact that Sanger's anti-militarism and
isolationism during the 1920s and 1930s at times obscured her abhorrence of the
Nazis, she was deeply shocked and horrified by the evils and dangers of fascism,
Hitler and the Nazi party. "All the news from Germany is sad &amp; horrible,"
she wrote in 1933, "and to me more dangerous than any other war going on any
where because it has so many good people who applaud the atrocities &amp; claim
its right. The sudden antagonism in Germany against the Jews &amp; the vitriolic
hatred of them is spreading underground here &amp; is far more dangerous than
the aggressive policy of the Japanese in Manchuria." (MS to Edith How-Martyn,
May 21, 1933 [<em>MSM</em> C2:536].) She joined the American Council Against Nazi
Propaganda and "gave money, my name and any influence I had with writers and
others, to combat Hitler's rise to power in Germany." ("World War II and
World Peace," 1940? [<em>MSM</em> S72:269].) For Hitler the feeling was mutual;
in 1933 the Nazis burned Sanger's books along with those of Ellis, Freud,
German sexologist Magnus Hirschfeld, and others. (Ellis to MS, Sept. 3, 1933
[LCM 3:385].)</p>
<p>How then does Sanger end up keeping company with Hitler? In this
predominantly Internet-based netherworld of revisionist Sanger profiles there
are two paths linking Sanger to Hitler, and they frequently intersect. On one,
Sanger is accused of murdering millions through abortion, either directly as an
abortionist, or as the primary force in creating a culture that devalues human
life as evidenced by the rising number of abortions through the twentieth
century. This is the unacknowledged "holocaust" commandeered by Sanger. In
these absurd depictions she was an even more efficient killer than Hitler or
Stalin. One well-quoted assault on Sanger's legacy, George Grant's 1995
book, <em>Killer Angel</em>, charges Sanger with the "brutal elimination of
thirty million children in the United States and as many as two and a half
billion worldwide." The fact that Sanger's clinic did not offer abortions
and that she advocated birth control as the only remedy for abortion does little
to dispel the myth that Sanger pressed abortion upon the masses.</p>
<p>But the main vehicle used to metamorphose this feminist liberator into a Nazi
is Sanger's limited and largely self-serving role in the short but spectacular
rise of American eugenics &ndash; a movement that sought to apply the principles of
genetics to improving the human race. By lifting passages from Sanger's
writings on eugenics and sterilization while failing to provide the complete
argument or proper context, and by linking her with notorious racists within the
eugenics movement, debunkers of Sanger's achievements have given her a
fiendish make-over.</p>
<p>In one of the seminal texts in this extremist assault on Sanger, the 1979 <em>Margaret
Sanger: Father of Modern Society</em> (both its title and cover &ndash; pictured
here&ndash; prepare the reader for the many leaps of faith to come), the author
suggests that Sanger, through her "eugenic" writings and speeches, put into
motion a "‘polite' genocide with an army of biologists, sociologists,
eugenicists and psychologists at her side," and did so without raising any
suspicions among the people. (p. 24) So effective was Sanger as a propagandist,
claims the author, that her debased "values" have become "those of modern
Western civilization and are rapidly becoming the morals which dominate the rest
of the world." (p. 9)</p>
<p>What is, of course, overlooked is that Sanger used the popular eugenics
movement to help promote birth control as a science-based remedy for
overpopulation, poverty, disease and famine. Incorporating the rhetoric of the
eugenics movement into her writings allowed Sanger to make a stronger biological
argument that fertility control was necessary for the improvement and health of
the entire human race, not only as a means to liberate women. Sanger did seek to
discourage the reproduction of persons who were, in the terms of her day, "unfit"
or "feebleminded," those, it was believed, who would pass on mental disease
or serious physical defect. And she did advocate sterilization in cases where
the subject was unable to use birth control. This was a popular position
espoused by many progressive medical leaders, scientists and health reformers of
the day &ndash; those groups who Sanger hoped to win over to the birth control fight.
But in approaching eugenics as a propagandist rather than a scientist, Sanger's
language became dehumanizing, her eugenic recommendations overly simplistic, and
her understanding of genetics flawed. Take the oft quoted 1931 "My Way to
Peace," in which Sanger recommends that the government:</p>

<blockquote>
<p>. . . keep the doors of Immigration closed to the entrance of certain
aliens whose condition is known to be detrimental to the stamina of the
race, such as feeble-minded, idiots, morons, insane, syphiletic, epileptic,
criminal, professional prostitutes, and others in this class . . . apply a
stern and rigid policy of sterilization, and segregation to that grade of
population whose progeny is <u>already</u> tainted or whose inheritance is
such that objectionable traits may be transmitted to offspring. (Jan. 17,
1932 [LCM 130:198].)</p>

</blockquote>
<p>These are harsh words intended to appeal not only to eugenicists, but social
and health workers who came in contact with all manner of sickness and
suffering. Sanger was not referring to short stature or pattern balding when she
used the phrase "objectionable traits," rather she was talking about
diseases such as syphilis that were ravaging especially the poor. Unfortunately,
she did sometimes apply the term to moral as well as mental defects, though
never as virulently as others in the eugenics community.</p>
<p>Offensive terminology aside, Sanger's beliefs, however inhumane they may
seem in the current age of medical enlightenment when human suffering is much
less visible in our daily lives, actually came from her direct experience with
the poor and oppressed. An illustration can be found in a 1932 letter written to
Sanger by a woman requesting birth control advice:</p>

<blockquote>
<p>"I will be thirty-six years old on December 16, 1932. and I shall have
been married fifteen years on December 13, 1932. During this time I have
given birth to eleven children, of whom four are now living&ndash;a boy of 13 1/2
years&ndash;a girl of 12 years and twin boys two years old. Three of these eleven
children were born badly deformed&ndash;one with a hare lip and split palate and
two with excessive water and a frog-like form. The last birth (one of the
deformed ones) was in August 1931 and had to be accomplished with
instruments and the Doctor . . . feared for my life and warned us against
further pregnancy." (Client to MS, July 5, 1932 [<em>MSM</em> S7:218].)</p>

</blockquote>
<p>Such dilemmas led Sanger to the strongly held belief that the best way to
reduce human suffering was to first provide greater access to birth control. It
was also necessary, she argued, to somehow regulate the procreation of those
individuals likely to pass on physical or mental disease and disability who were
incapable of using or denied access to contraception. But her writings on
eugenics, including her 1922 book <em>Pivot of Civilization</em>, argued that
eugenic measures in and of themselves were not practicable. Instead, she
concluded that women's empowerment through birth control offered the only
viable means of improving the human condition.</p>
<p>While "My Way to Peace" is brutally frank and among the most extreme of
any of Sanger's eugenic writings, it does not condone race-based eugenics.
Sanger never accepted the racial hierarchies that led to the deadly racist
policies of the Nazis. Rather, she vehemently rejected any definition of the "unfit"
when it referred "to race or religions." (MS to Sidney Lasell, Jr., Feb. 13,
1934 [<em>MSM</em> S8:541].) This was not true of the broader eugenics movement,
both in Europe and the United States, which blurred the distinction between good
science and racial prejudice, and generally failed to protest the perversion of
its ideals under the Nazis. A number of American eugenicists excused or even
commended reprehensible Nazi race policies camouflaged, however poorly, under
the veneer of science.</p>
<p>Sanger did write to and share organizational memberships and conference
programs with any number of eugenicists, including such champions of scientific
racism as Charles Davenport and Harry Laughlin, who ran the genetics laboratory
in Cold Spring Harbor, New York; and Leon Whitney, secretary of the American
Eugenics Society. All of them conflated physical and mental deficiencies with
racial ones. While Sanger publicly criticized these most notable eugenicists for
their opposition or indifference to birth control, she never publicly condemned
their racial views. Her silence is damning in retrospect, but it does not make
her a Nazi.</p>
<p>Those who insist on labeling Sanger a Nazi claim time and again that she
inspired the men who unleashed the barbarism lurking in eugenics, yet many of
the men she supposedly roused to action had, in the main, only a grudging
respect tinged with contempt for the woman they saw as a major deterrent to
their quest to breed more of the "best." And though Sanger sought their
support for birth control, in most cases she failed to win their endorsement.
With few exceptions, American eugenicists advocated increased breeding among the
"fit," defined by them as white Anglo-Saxon Protestants with middle or upper
class values, and viewed birth control as the major impediment to the
proliferation of these "better stocks."</p>
<p>Even more than her links with American eugenicists, Sanger's so-called
association with Ernst Rudin, the director of the Kaiser Wilhelm Institute for
Psychiatry in Munich, who helped align prevalent eugenic theories with Nazi race
policy, has been featured in nearly every right-wing assault on Sanger's
legacy. The grounds for charges that she knew, corresponded with, or influenced
Rudin stem from the April 1933 <em>Birth Control Review (BCR), </em>a special
"sterilization number." Rudin did contribute an article to this issue,
as did Harry Laughlin and Leon Whitney and other eugenicists. The issue also
included excerpts from the works of Havelock Ellis and influential gynecologist
Robert Dickinson. Taken as a whole, the issue presents a clear, if not always
comfortable, debate on compulsory sterilization, with forceful arguments for and
against, and calls for further research on sterilization as a eugenic measure.
But Sanger had resigned as editor of the <em>BCR</em> in 1929 and no longer had
any affiliation with the<em> </em>publication. Nevertheless the <em>BCR</em> issue
has been held out like a smoking gun in the campaign to brand Sanger a
sterilization missionary and Nazi sympathizer. What is never noted is that the
one voice absent in the issue is Margaret Sanger's.</p>
<p>Historians must grapple with the phenomenal amount of material that is being
dumped on the Internet. This flood of historical "evidence" is at once
liberating and dangerous, for it includes information and disinformation, and
there are no help menus to tell the difference. This has become an immense
challenge to historical editors who seek to deliver accurate texts in historical
context. Some of the incredible attacks on Sanger have existed in book and
pamphlet form for several decades now, but in the past only the most zealous
would pay for them or go to the trouble to track them down. Now search engines
bring them in an instant to our desktops. With sensational headlines, comical
juxtapositions, bold assertions and a kind of <em>Twilight Zone</em> aura about
them, these anti-Sanger web sites appear to have a sizeable and
growing audience. And therein lies the problem; the proliferation of extremist
material makes it all seem less extreme, more acceptable to students,
journalists and others looking for a quick take on a controversial and
complicated figure. History is never that easy.</p>
<table width="543" height="94" border="1">
    <tr>
    <td> <p><strong>From Sanger's &quot;Dream Journal&quot;<a name="dream" id="dream"></a></strong></p>
    <p align="right">[<em>Tucson, Ariz</em>.]<br />
    Feb 3rd 1942.</p>
    <p align="left"><br />
    Last night I dreamed of Hitler&ndash;- Saw him in a room so close that I could see his eyes wink. Dream not very clear at 3 Am. just awoke&ndash;- But house I was in with others raided by Nazis. I hid under a table with others but one womans leg was discovered then we all were brought forth. Hitler came in to execute war plans &amp; operations using this house as his base. A bird flew into the room from the window &amp; lighted near me-&ndash; It was white &amp; a dove-&ndash; Hitler caught it held it up high over my head &amp; told me to pick out a feather&ndash;-I did so &amp; <u>awakened</u>. </p>
    <p>AD MSP, MN-SSC (<u>MSM</u> S70:513-14).</p></td>
    </tr>
</table>
<p>&nbsp;</p>
<p>
<em>
(Sanger's letters on the war and on Hitler, the controversial writings quoted
in this newsletter, and more of Sanger's eugenical views appear in Volume
III of </em>The Selected Papers of Margaret Sanger, The Politics of Planned
Parenthood<em>. )</em></p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
