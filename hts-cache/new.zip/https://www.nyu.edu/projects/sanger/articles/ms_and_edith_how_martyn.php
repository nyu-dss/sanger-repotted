
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #5 (Spring 1993)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #5 (Spring 1993)</h1>
<div class="maintext">
<h1>"Margaret Sanger and Edith How-Martyn: An Intimate Correspondence"</h1>

<p>   If Margaret Sanger had a British counterpart in her commitment to internationalizing the birth control
movement it was undoubtedly Edith How-Martyn (1875-1954), who for two decades worked closely with Sanger
in creating a global movement.  Last October, the Margaret Sanger Papers Project acquired copies of a large
collection of unpublished letters written by Sanger to How-Martyn which had been privately held by Eileen
Palmer, How-Martyn's secretary for more than 30 years.   The MSPP also acquired How-Martyn's personal
scrapbooks from the 1935-36 World Tour for Birth Control.  Together, the letters and the scrapbooks provide
details about Sanger's travels and activities between 1915-1936 and illuminate the special friendship that
developed between the two women.</p>

<p>    Born in Cheltenham England in 1875, Edith How married Herbert Martyn in 1899; she shortly after she began
acting on her commitment to women's issues by devoting herself to the British suffragette movement.
How-Martyn met Sanger in 1915 and by the early 1920s began to direct her considerable energies toward birth control.
How-Martyn worked with Sanger on organizing the 1927 World Population Conference in Geneva; and in 1930
the pair established the Birth Control International Information Centre (BCIIC) in London with Sanger as
president and How-Martyn as director. How-Martyn traveled extensively in Europe and Asia serving as Sanger's
link to the international community of birth control supporters.  The two developed an unusually effective working
relationship.  As Sanger told How-Martyn, "You   
have a way of winning hearts and its really dangerous!...I love the notes you send & the interesting report &
everything you do just like  I like it done.  We must have ruled a world together once Edith."
(July 4, 1926). 
Between November 1934 and March 1935, How-Martyn traveled through India building support for birth control;
the next year she accompanied Sanger on a historic visit to Asia which included Sanger's widely publicized
meeting with Mahatma Gandhi.  Over the next three years How-Martyn returned to India to continue building an
extensive network of birth control providers and activists.  </p>

<p>    Both Sanger and How-Martyn's international work was
interrupted as war spread through Europe. Plagued by lack of funds and staffing problems, the London centre shut
down in 1937.  When the war spread to England, the How-Martyns fled to Australia.  Eileen Palmer, How-Martyn's secretary, rescued her employer's correspondence when the How-Martyn house was bombed.  After the
war, Edith How-Martyn's recurring health problems prevented her from returning to Britain.  She died in a
Sydney nursing home on February 4, 1954. </p>

<p>     From the earliest surviving examples of the Sanger/How-Martyn
correspondence, it is clear that Sanger relied on How-Martyn's advice
and opinions, but she also used her friend as a sounding board for her
own thoughts and ideas.  "I think of you so often, " Sanger wrote, "that I
write letters to you in my head & have a hard time realizing you might
not be able to reply to them." (October 27,1928) </p>

<p>   Because of their close friendship and their commitment to the birth
control movement, Sanger's letters to How-Martyn were unusually frank
and detailed in their assessment of the movement and her role in it.  In
one of the earliest letters uncovered, Sanger described her 1916 cross-country tour noting the many women who were drawn to her hotel room.
"Oh dear lady if you could hear the tragic stories & hear the heartrending
appeal for relief, no one would ask me ever again to respect a piece of
paper called a law which kept these women in bondage" (July 18, 1916). 
After the 1927 World Population Conference, Sanger took a trip to
Germany where she received a mixed reception when she spoke for birth
control.  "The Socialist Women were for b.c.," she wrote How-Martyn,
"but the Pres. of the Midwives Assn was the limit.  She weighed at least
250 lbs. - a giant of a female - decked out in blue nurses garb, large cross
hanging from her neck.  She arose & attacked me.  It was great!" (December 11,
1927).</p>

<p>   Because of the international focus of their work together, birth control
could not be separated from politics.   "You should see the adorable pessaries
sent me from Japan, blue, red, orange, yellow, all colors, delicately blended
& aesthetically made.  Its worth considering, but Manchuria!  This latest
butchering of China makes us all hesitate to buy even good pessaries from
Japan." (January 10, 1932).  Sharing her plans for a conference in the Soviet
Union with How-Martyn, Sanger explained her decision to postpone the event
fearing the effect it might have on her drive to legalize birth control in the
U.S.  In proposing instead to hold the conference in Germany, she argued, "If
this went over we could then plan for Russia for 1935 for if the laws in the
U.S.A. are not changed by that time I'll be ready to live in Europe
somewhere & let the U.S.A. go to the dogs in her Puritanical ways." (July 31,
1932).  Sanger's letters to How-Martyn also include lively sketches of
her meetings with influential supporters.  In a February 1, 1928 letter, Sanger
describes a London  fundraising meeting with Lady Astor: "I went and found
her with cold cream all over her face&ndash;her windows wide open in a most
unAmerican fashion & we started right in to laugh together as if our spirits
were old friends."  </p>

<p>   The friends also shared details of their private lives and exchanged
discussions of various physical ailments.  When Sanger's ill health in the
summer of 1928 forced her to take rest cures in Geneva, St. Moritz, and Berlin, she wrote to How-Martyn on a
biweekly basis, confiding details of the cures she sought and the annoyance that inactivity forced upon her. </p>

<p>   One of the most unique aspects of the Sanger-How-Martyn correspondence
is the ubiquitous presence of Eileen Palmer, who held on tightly to the
collection until shortly before her death in 1992.  Until she began
arrangements to deposit the How-Martyn papers, (along with a collection of
Olive M. Johnson papers) in a British repository, Palmer took her role as
custodian of the papers very seriously.  In fact,  portions of a number of
Sanger's handwritten letters to Edith How-Martyn were deleted outright by
Palmer, who either blacked out key portions or sliced them out with a pair of
scissors.  Palmer's motive was to preserve the reputations of Sanger and How-Martyn and the passages she excised were those in which Sanger
criticized staff members, physicians, or others involved in the birth control
movement.  Palmer's editorial work obviously leaves much detective work for
the MSPP and other historians who must piece together paragraphs and
sentences from contextual clues, and from How-Martyn's letters to Sanger
which are preserved intact among the Sanger correspondence in the Sophia
Smith Collection.  Nevertheless, Palmer's recognition of the importance of
preserving these documents has provided us with yet another significant
glimpse into Sanger' life and work.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
