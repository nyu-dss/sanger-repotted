
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #10 (Fall 1995)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #10 (Fall 1995)</h1>
<div class="maintext">
<h1>"Sanger and World War II"</h1>

<p>     As we mark the fiftieth anniversary of the end of
World
War II, we thought it was an appropriate time to look
at Margaret Sanger's impressions of the war, in her
own public and private words. </p>

<p>     Not surprisingly, Margaret Sanger's views on war
were tightly connected to her belief in the importance
of birth control.  She began forecasting another world
war shortly after the first had ended. In speeches and
articles she offered the well-worn argument that
over-population begets aggressive expansionism. For
Sanger, the only effective preventative measure was to
limit population growth through birth control.</p>

<p>    Though somewhat naive and often over-simplistic in
her analysis of international affairs, Sanger's tours of
Europe and Asia during the 1920's and 1930's, her
work as president of the London-based Birth Control
International Information Centre, as well as her
extensive network of friends and colleagues, afforded
her a bird's eye view of the conflicts and personalities
that drove the war machines.  Sanger found culpability
on all sides in the global arena, but was especially
distrustful of British leadership.  </p>

<p>     For most of the 1930s, Sanger's frustration with
the deteriorating situation in Europe and the Far East,
and her long-held pacifistic ideals, led her to adopt a
rigidly isolationist stance from which she would not
budge until America was solidly entrenched in the
war. However, although she agreed with much of what
Charles Lindbergh and other America First
campaigners were publicly proclaiming about the
importance of U.S. neutrality, Sanger was unequivocal
about the evils of fascism and the Nazi regime.  </p>

<p>     Nor did her isolationism prevent her from
participating in projects to help those most affected by
war.  During the 1930's she worked to help bring
European refugees to America, (see "Margaret Sanger and the Refugee
Department, Margaret Sanger Papers Project
Newsletter, Spring 1993).  After 1940 she began
sending food and clothes to British friends and later to
friends in Germany as well.  And after Pearl Harbor
she reminded wartime Americans of the even more
critical need for birth control.</p>

<p>    As the mother of two sons, Sanger like most other
Americans dreaded the reality of war.  When her two
sons, Grant and Stuart, were sent overseas late in
1943, Sanger withdrew to her Tucson home, and
anxiously awaited news.  Happily, both men returned
home safely in 1945 and shortly thereafter continued to
pursue their medical careers. </p>

<p>     When the war finally ended in 1945, Sanger was
relieved, but also horrified by the devastation the
conflict had left in Japan, Germany and many other
parts of Europe. And she remained even more
convinced that the key to peace was population
control.  What follows are extracts from Sanger's
letters, journals, and speeches.</p>

<p>December 8, 1920<br />
We are breeding, breeding, breeding excess
numbers for what?  For another condition like
that of Europe in 1914 with its dingy,
crowded communities that sought in
bloodshed an outlet and a relief from the
tragedy of existence?  Unless we apply
fundamental remedies to these conditions we
will just approach the
same congested and confused state which may
and is

likely to produce an outburst of the same
nature as the European struggle of the past 5
years. ("Return from Europe" Speech, <em>MSM </em>70:870)
</p>


<p>
September 3, 1933<br />
Japan is breaking her own record for
population increase.  The whole crisis in the
Far East &ndash; so menacing for the peace of the
world at large - - grows out of this
"full-speed-ahead" cradle competition
between Asiatic races.... the sowing of the
seeds of another World War!  ("Woman of the
Future" Speech, <em>MSM</em> S71:510)
</p>

<p> 
October 4, 1939 <br />
I am one of those who believe that Americans
have no influence politically in Europe.  That
our ideals are merely "eye wash" to the
diplomats and unless we can present a broad
& just peace as a working basis for Russia,
Germany and the trouble making countries we
should keep out of it.  (MS to Edith How-Martyn, <em>MSM C</em>)
</p>

<p> 1939?<br />
I do not believe that the statesmen of England
or France are any more righteous, noble,
honest, truthful or wise than the same
gamesters in Germany, Italy or Russia.  They
are all playing a game with Nations as their
pawns. ("Hitler and War" Speech, <em>MSM</em> S72:125)
</p>

<p>  August 1940<br />
War in Europe &ndash; with Germany conquering
France, Holland, Belgium & threatening
England has upset the world.  To keep USA
out of Europes war is the desire of all of us &ndash;
but G. B. influence here is tremendous &ndash;
(Journal Entry, <em>MSM</em> S70:531)
</p>

<p>   September 20, 1940<br />
The British Propaganda is Effective &ndash; all the
papers & columnists are hard at it.  Only Col
Lindbergh is sane & the Lone Eagle trying to
keep USA out of European entanglements.
(Journal Entry, <em>MSM</em> S70:538-539)
</p>


<p>  June 9, 1941<br />
I certainly want to see a better world.  We
have fought for that you & I.  All that we
have believed in & worked for has been
crushed in Germany but I am glad to say a
little light still burns in England, just a flicker
but it burns....No dearest I do not think it
wrong to condemn us or keep
our freedom or are we
not opening the
floodgates to all the
things we hate in
Germany & Russia?
(MS to Juliet Rublee, <em>MSM</em>)
</p>

<p>  December 7, 1941<br />
Today news over the
Radio that Japan
declared war on USA. 
Bombed Pearl Harbor
in Hawaii... Nation
after Nation will now
join in this madness &
God only can keep
hearts true & heads
cool. (Journal Entry, <em>MSM</em> S70:568)
</p>

<p>

February 3, 1942<br />
Last night I dreamed
of Hitler &ndash; Saw him in
a room so close that I
could see his eyes
wink ... house I was in
with others raided by
Nazis.  I hid under a
table with others
but one womans
leg was
discovered then
we all were
brought forth. 
Hitler came in to
execute war plans
& operations
using this house as
his base.  A bird
flew into the room
from the window
& lighted near me
&ndash; It was white &
a dove &ndash; Hitler
caught it, held it
up high over my
head & told me to
pick out  a
feather &ndash;
I did
so &
awakened.
(Journal
Entry, <em>MSM</em> S70:513-514)
</p>

<p>

May 1942<br />
Grant in Navy! ...
expects to be called
Somewhere any day. 
God forbid&ndash; (Journal
Entry, <em>MSM</em> S70:570)
</p>

<p>

January 26, 1943<br />
Millions of Women in
Industry, Defense &
other National
Activities are needed
unencumbered &
unhampered for the
duration as much as
their husbands or
brothers are
needed as free
men on the battle
fronts. (MS to
Kenneth Rose, <em>MSM</em> S22:108-109)
</p>

<p>March 22, 1943<br />
I do not know whether
or not you listened to
Churchill's speech
yesterday, but I was
never more
disappointed in his
views, expressing, as
they did, the whole
Tory clique of the City
of London.  It was
what I call a
nationalistic, jingoistic
brain storm! (MS to
Margaret Valiant, <em>MSM</em> S22:373)
</p>

<p>

August 12, 1943<br />
Stuart may have to go
Overseas &ndash; God
knows I'll be crushed
over that.  It will be
the end for me! (MS to
Florence Rose, <em>MSM</em> S23:0062)
</p>

<p>

March 10, 1944<br />
Planned Parenthood
must be an important
plank in the post war
platform if enduring
peace is to prevail. 
Global war demands
global peace, and the
gains which we are
struggling to achieve
in this country must be
extended throughout
the world if they are to
be effective for us.  In
the United States we
have achieved a
favorable balance
between population
and resources which
has contributed greatly
to the raising of our
national standard of
living.  But it will
avail us little in the
long run if European
and Asiatic countries
continue to overrun
their boundaries, and
to breed themselves
into greater poverty,
famine and ultimately
into war. 
Therefore the
fight for planned
parenthood must
encompass the
world. ("Children
of Tomorrow"
speech, <em>MSM</em> S72:380)
</p>

<p>

May 10, 1944 <br />
What an amazing
experience for you, as
you say, to have two
human beings fall
through the air from
that height &ndash; it is all
too ghastly and
horrible.  I keep
wondering what is
going to happen after
the war to men who
live through
experiences of that
kind. (MS to Stuart
Sanger, <em>MSM</em> S23:954)
</p>

<p>

September 19, 1944<br />
Stuart is in France
having left England
with the others without
a days vacation.  I
think the American
Army is treating the
American boys as if
they were children,
not letting them get
away in case they get
into trouble when not
with his Uncle Sam.
(MS to H. G. Wells, <em>MSM</em> S24:323)
</p>

<p>

October 27, 1944<br />
Grant is out in that
Philippine battle in a
carrier ... its too
horrible being at the
end of a phone
waiting. (MS to
Margaret Valiant and
Florence Rose, <em>MSM</em> S24:395)
</p>

<p>

August 10, 1945<br />
Atomic Bomb over
Japan startled the
World. (Calendar
Entry, <em>MSM</em> S80:647)
</p>

<p>

August 30, 1945<br />
Stuart has come back
from France but is not
out of the Army. 
Grant was still in
Okinawa the last we
heard, we only hope
he will not be sent in
Japan.  We as
everyone else are
terribly thankful that
the war is over. (MS to
Marion Willis Brock, <em>MSM</em> S24:1148)
</p>

<p>

October 25, 1945<br />
Isn't it true, General,
that until America,
with her present
power, stands for the
rights of parents
everywhere in the
world to voluntary and
healthful reproduction,
neither a large
standing army or the
atomic bomb can save
us from another war?
(MS to General
Douglas MacArthur, <em>MSM</em> S25:213)
</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
