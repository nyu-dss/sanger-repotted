
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #55 (Fall 2010)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #55 (Fall 2010)</h1>
<div class="maintext">
<h1>"John Rock's Catholic Faith: Sanger's Hard Pill to Swallow"</h1>

 <p>The just-published <em>Selected Papers of Margaret Sanger, Volume 3: The Politics of Planned Parenthood, 1939-1966</em>, features the four driving forces behind the development of the birth control pill: Margaret Sanger, Katharine McCormick, Gregory Pincus and John Rock. Much has been written about how these fascinating and contrasting personalities were able to come together for a common goal that few others thought possible. Their individual stories fill a number of biographies and their unlikely collaboration has been highlighted in several books on the pill. <em>Volume 3 </em>looks at this extraordinary chapter in the history of birth control through Margaret Sanger&rsquo;s eyes. </p>
 <p>At least one author has commented that these four strong-willed characters were ready-made for dramatization: Sanger, the aging radical; McCormick, the eccentric philanthropist; Pincus, the maverick scientist; and Rock, the upstanding physician and traditional family man. Their relationships were complicated, many years in the making, and evolved during the work on the pill. Perhaps the most unlikely association&ndash;and the one that has received the least attention&ndash;was between the lapsed Catholic and anti-cleric, Sanger, and John Rock (1890-1984), a devout Catholic who attended daily Mass and kept a crucifix above his desk. Sanger&rsquo;s inability to square Rock&rsquo;s faith with his advocacy of birth control initially added another layer of tension to the pill project and another obstacle to overcome. (Margaret Marsh and Wanda Ronner, <em>The Fertility Doctor: John Rock and the Reproductive Revolution </em>[Baltimore, 2008], 151; Lara V. Marks, <em>Sexual Chemistry: A History of the Contraceptive Pill </em>[New Haven, 2001], 220.) </p>
 <p>Rock and Sanger probably met in 1948 at the International Congress on Population and World Resources in Cheltenham, England, the first postwar birth control conference. At age 58, John Rock was one of the world&rsquo;s leading experts on fertility. Since 1926 he had been directing an infertility clinic at the Free Hospital for Women in Boston. He also held the position of Clinical Professor of Gynecology at Harvard and carried on a private practice. Earlier in 1948 he had captured world-wide attention by announcing that he and collaborator Miriam Menkin had achieved the first successful in vitro fertilization of a human ovum. </p>
 <p>The tall and handsome Rock had an air of celebrity about him in Cheltenham, but he seemed out of step with the other attendees. He prefaced his talk by telling the audience, &ldquo;Perhaps we sometimes get off on the wrong foot.&rdquo; Then he proceeded to discuss the &ldquo;building up of the family&rdquo; and referenced Christ&rsquo;s teachings about individual sacrifice. He tempered the conference&rsquo;s enthusiasm over birth control initiatives with a plea for putting greater value on children. &ldquo;I am in favor of family planning,&rdquo; he said, &ldquo;but I am very much against teaching young people the disadvantage of having babies.&rdquo; For Rock, the future success of birth control was dependant on both &ldquo;teaching children and adolescents the value of offspring&rdquo; and increasing scientific understanding of fertility. He hinted at the potential for hormonal control of fertility when he shared one of his research findings. &ldquo;If we give a patient who is regularly ovulating about 5 mg. of diethyl boestrol [a synthetic estrogen] each day,&rdquo; he said, &ldquo;we can disrupt the endocrine system and stop ovulation. This can be done for months at a time.&rdquo; He added, &ldquo;I am not suggesting this is a contraceptive, but merely calling attention to the fact that insight into the physiology of ovulation has already thrown one tiny little gleam on another way of interfering with conception.&rdquo; (Sanger to Rock, June 14, 1952 [<em>MSM </em>S37:966]; James Reed,<em> The Birth Control Movement in American Society: From Private Vice to Public Virtue </em>[Princeton, 1983], 351-55; Beryl Suitters, <em>Be Brave and Angry </em>[London, 1973], 32; <em>Proceedings of the International Congress on Population and World Resources in Relation to the Family </em>[London, 1948], 188-93 [quotations].) </p>
 <p>Sanger had little patience for anyone who encouraged fertility. She had, for example, been cross with Abraham Stone, the medical director of the Margaret Sanger Research Bureau, for wanting to expand fertility services at the clinic. Nevertheless, she held her tongue in Cheltenham, aware of the fragile state of the postwar movement and Europe&rsquo;s interest in rebuilding its population. There is no record of what Sanger thought about Rock at this time. She likely dismissed his conference statements as those of a Catholic still grappling with conflicts between his faith and science. Nearly 70 years old and having battled the church for three decades, Sanger was resigned to a tired anti-Catholic bigotry. &ldquo;The d&mdash; Roman Catholics make life &amp; work difficult,&rdquo; she told her niece in one of her a typical statements of exasperation on this subject. (Sanger to Olive Byrne Richard, Oct. 31, 1951 [<em>MSM</em> C9:220].) </p>
 <p>However, Sanger had little experience with practicing Catholics within the birth control movement. And she had never come upon a man like John Rock, who battled with the church and publicly confronted the moral predicament of being a Catholic doctor who advocated family planning. Just months before Cheltenham, Rock explained that his faith was not intended to encroach on another person&rsquo;s thinking or sense of right and wrong. &ldquo;I don&rsquo;t think that Roman Catholicism forces a man to interfere with other people&rsquo;s freedom of conscience and action within their own moral principles.&rdquo; (&ldquo;Planned Fertility,&rdquo; <em>Time Magazine</em>, Feb. 9, 1948.) </p>
 <p>As early as 1931 Rock had defied his church and signed a petition to repeal Massachusetts&rsquo; stringent prohibitions on contraceptive information, the only Catholic of the fifteen prominent physicians who signed. Like Sanger, Rock had been affected by his early medical work with indigent women and had decided that contraception should be made available through clinics and doctors. The irreverent act of signing the petition was the first of his many clashes with the church over contraception. Yet Rock found the birth control movement too radical and too feminist. In the 1930s, Rock would only accept the use of contraception for valid health and medical reasons, and not as a tool of women&rsquo;s autonomy. &ldquo;Nature intended motherhood to be woman&rsquo;s career,&rdquo; he said in 1936, and &ldquo;Anything which diverts from her prime purpose is socially wrong.&rdquo; He believed sex could not &ldquo;be made an end in itself without dire consequences.&rdquo; He did not offer any insight into his own marriage: five children in the first eight years and then no more. Through the 1930s and into the 1940s, Rock sought to assert a pro-family rationale for family planning, where helping couples have more children was as important as prescribing contraception for health reasons. (Marsh and Ronner, <em>The Fertility</em>, 127-28; Rock, speaking at a Committee on Maternal Health Round Table Discussion, Dec. 4, 1936, quoted in Reed,<em> Birth Control Movement</em>,188.) </p>
 <p>In conducting research on infertility Rock became interested in finding a means of fertility control that was acceptable to Catholics, who were forbidden from using so-called &ldquo;unnatural&rdquo; contraception&ndash;condoms, diaphragms, suppositories. To that end he had opened a rhythm clinic at the Free Hospital in 1936 and became one of the leading experts on this one church-sanctioned method. </p>
 <p>Sanger never accepted rhythm as a legitimate form of birth control because of its high failure rate and because it dictated when a couple could or could not have sex. &ldquo;I disagree with it violently,&rdquo; she told a friend in 1953. Yet when preparing the program for the Third International Conference on Planned Parenthood in Bombay in 1952, Sanger invited Rock to give a paper on rhythm to placate public health leaders in India. She might have sought Rock&rsquo;s insights into the topic because he had just published a paper that concluded the rhythm method offered a &ldquo;satisfactory degree of protection&rdquo; only to &ldquo;rigorously selected and carefully instructed wives.&rdquo; For all others, Rock and his co-authors wrote, &ldquo;the effectiveness of the method in preventing conception is not considered adequate.&rdquo; Whether or not Rock was aware of Sanger&rsquo;s strong views on rhythm, he declined the invitation because he was &ldquo;pressed for time.&rdquo; He added that &ldquo;I thoroughly believe in the work you are doing,&rdquo; an acknowledgment, perhaps, that he had expanded his advocacy of birth control beyond its use for medical reasons. (Sanger to Edward Steele, Mar. 31, 1953 [quote 1]; Sanger to Rock, June 14, 1952; Rock to Sanger, Aug. 28, 1952 [quotes 5 and 6] [<em>MSM </em>S37:966, S39:409, S41: 197]; Christopher Tietze, Samuel R. Poliakoff and John Rock, &ldquo;The Clinical Effectiveness of the Rhythm Method of Contraception,&rdquo;<em> Obstetrical &amp; Gynecological Survey </em>7:2 [April 1952]: 299-302 [quotes 2-4] .) </p>
 <p>Indeed, Rock&rsquo;s views on contraception had begun to change. In 1949 he co-wrote with PPFA publicist David Loth, <em>Voluntary Parenthood</em>, a guide that incorporated up-to-date birth control information with advice on marriage and child rearing and tips for childless couples. Concluding that overpopulation threatened world peace and stability, Rock became an advocate of population control and backed away from his earlier defense of the large family. And he increasingly came to regard sexual expression within marriage as essential to health and happiness. Birth control, therefore, played an important role in allowing couples to experience sexual union when they were either trying to space children or had completed their family. (Reed,<em> Birth Control Movement</em>, 353-54; David Loth and Rock, <em>Voluntary Parenthood </em>[New York, 1949].) </p>
 <p>When in 1953 Gregory Pincus approached Rock about collaborating on a study of the contraceptive effects of progesterone, Rock unhesitatingly signed on. The two scientists had known each other since the 1930s and closely followed each other&rsquo;s work. Rock&rsquo;s finding, in the course of his research on infertility treatments, that small amounts of female hormones inhibited ovulation, helped validate Pincus&rsquo;s similar results in animal trials. Pincus needed someone with Rock&rsquo;s clinical experience to extend research trials to human subjects. And it helped in terms of fund-raising and public relations that Rock had an unimpeachable reputation as physician and medical researcher. Their cooperative work was made possible by an influx of funds from Katharine Dexter McCormick, whom Sanger had convinced to support Pincus&rsquo;s promising research. </p>
 <p>Starting in the summer of 1953, McCormick began to immerse herself in the project and sent regular progress reports to Sanger mentioning Rock&rsquo;s involvement. In November 1953 McCormick informed Sanger that Rock and Pincus had begun the first human trials in the study. But Sanger, who was preoccupied with setting up the International Planned Parenthood Federation (IPPF), did not appear to be aware of the extent of Rock&rsquo;s participation. Nor did she feel completely comfortable with his involvement. </p>
 <p>In February 1954 Sanger learned that the PPFA president William Vogt had appointed Rock to chair the Scientific Council of the Dickinson Research Memorial, the research arm of the PPFA, which had been helping to fund and guide the pill research. Sanger had trouble containing her anger. She asked if Vogt had &ldquo;lost his mind&rdquo; in naming an &ldquo;ardent Roman Catholic&rdquo; to an influential research position. &ldquo;Things are getting very confusing to me.&rdquo; To McCormick, she wrote, &ldquo;You will recall what a very charming person John Rock is, but that does not mean that his interest in contraception is sufficient for him to become a Chairman of a Research Committee, whose object should be the discovery or the development of a simple contraceptive.&rdquo; She held back on questioning Rock&rsquo;s commitment to the progesterone studies. (McCormick to Sanger, Nov. 13, 1953 [LCM 9:342-53; <em>Vol. 3</em>]; Sanger to Marion Ingersoll, Feb. 18, 1954 [quotes]; Sanger to McCormick, Feb. 23, 1954 [quote] [<em>MSM</em> S42: 981, 1024].) </p>
 <p>McCormick quickly put out this fire, telling Sanger that Rock had left the Catholic Church. This turned out to be untrue, but it calmed Sanger, who said nothing more in the short term about Rock&rsquo;s faith. In July 1954, McCormick learned of her error, telling Sanger, &ldquo;I find that I have mis-informed you concerning Dr. Rock&rsquo;s religion. Dr. Pincus called him a &lsquo;reformed Catholic&rsquo; which I thought meant that he had left the Catholic Church. I was mistaken and learned recently that he does belong to the Catholic Church.&rdquo; She added, &ldquo;How they manage to put up with him I do not know! It seems that his position is that religion has nothing to do with medicine or the practice of it and that if the church does not interfere with him he will not interfere with it&ndash;whatever that may mean!&rdquo; (McCormick to Sanger, July 21, 1954 [<em>MSM</em> S44:145].) </p>
 <p>By then, Sanger had learned more about Rock and the depth of his dedication to birth control, even if he remained a practicing Catholic. She was especially impressed with his address at PPFA&rsquo;s annual luncheon in May 1954. In a speech entitled, &ldquo;Physiology and Fertility Control,&rdquo; Rock called for massive increases in funding for research on human reproduction and to discover new contraceptives to stem population growth. He said that if just one-tenth of the amount of money committed to the development of nuclear weapons could be used for research on furthering the science of reproduction and on birth control, &ldquo;we could assuredly obtain the greatest aid ever discovered to the happiness and security of individual families&ndash;indeed of mankind. This would,&rdquo; he concluded, &ldquo;avert Man&rsquo;s self-destruction by starvation and war. If it can be discovered soon, the H-bomb need never fall.&rdquo; Sanger told Rock that she was &ldquo;thrilled and delighted to read the magnificent address,&rdquo; and that it &ldquo;should be distributed by the millions.&rdquo; (John Rock, &ldquo;Physiology and Fertility Control,&rdquo; PPFA Annual Luncheon, May 6, 1954 [MS Unfilmed]; Sanger to Rock, June 26, 1954 [<em>MSM</em> S43:1051].) </p>
 <p>Over the next few years Sanger came to deeply respect Rock for his cautious approach and conscientious manner. He was a welcome contrast to the impetuous Pincus, who began telling people as early as 1955, based on one very small clinical trial, that his team had achieved an oral contraceptive. Rock insisted on more extensive testing before going public. After <em>Science </em>magazine published preliminary results of their research in November 1956, Sanger wrote to McCormick that Rock &ldquo;really is one of the best and most highly respected in his field. . . . We can really be proud that even with his religious background he has the courage to undertake this study and come out in the open with his results.&rdquo; Not only did Rock, as a Catholic, publicly stand behind the pill, over the next decade he took on the church in the press, at conferences and in his popular 1963 book, <em>The Time Has Come. </em>He argued that the Vatican should accept the oral contraceptive because it duplicates a woman&rsquo;s natural hormones and is, in effect, a scientifically controlled version of the rhythm method. His advocacy convinced many Catholics to reject church teaching on this issue. (John Rock, Gregory Pincus, and Celso Ramon Garcia, &ldquo;Effects of Certain 19-Nor Steroids on the Normal Human Menstrual Cycle,&rdquo; <em>Science </em>124:3227 [Nov. 2, 1956]: 891-93; Sanger to McCormick, Dec. 12, 1956 [quote] [<em>MSM</em> S51:62]; Marks, <em>Sexual Chemistry</em>, 221-23.)</p>
 <p><strong> &nbsp;</strong>Rock and Sanger found each other to be persuasive and alluring figures. In 1957, after Rock had declined an invitation from the IPPF to join the program committee for the Sixth International Conference on Planned Parenthood, Sanger sent him a personal appeal. He wrote back, &ldquo;How I wish I had your amiable persistence and an inoffensive pachyderm like yours. After I have refused to serve on the committee . . . I now find myself capitulating completely, to your irresistible command. God bless you and &ndash; more power to you!&rdquo; By 1960, after having observed from afar Rock&rsquo;s skillful negotiations with drug companies, his influence within the medical profession, and his steadfast determination to change the official Catholic position on birth control, Sanger now viewed Rock&rsquo;s faith as an asset. &ldquo;Being a good R. C.,&rdquo; Sanger wrote in a letter to Martha Baird Rockefeller, &ldquo;and as handsome as a god he can just get away with anything.&rdquo; (Rock to Sanger, Apr. 15, 1957; Sanger to Martha Baird Rockefeller, Feb. 19, 1960 [<em>MSM</em> S51:952, S56:692].) </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
