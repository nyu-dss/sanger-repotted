
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #44 (Winter 2006/2007)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #44 (Winter 2006/2007)</h1>
<div class="maintext">
<h1>"Depopulation!"</h1>

<p>Sometime on or about October 16, 2006, ninety years almost to the day since Margaret Sanger opened the first birth control clinic in the United States, the country&rsquo;s population reached the 300 million mark. As a reporter for the <em>Washington Post</em> remarked, the U. S. is &ldquo;230 years old . . . and still in a growth spurt.&rdquo; As this is not an election issue, there was little fanfare over the announcement and only a limited dose of Malthusian angst. Yes urban congestion is a problem, not to mention environmental degradation. And the fact that immigration accounted for roughly forty percent of the population increase caught the attention of a number of border-state politicians. But there appears to be a general acceptance that America will continue to grow at a brisk, predictable pace, and that this growth is good for the economy (more iPods and IHOPs and IOUs), necessary for the care and social security support of aging baby boomers, and a boon to future security needs. (Blaine Harden, &ldquo;America&rsquo;s Population Set to Top 300 Million,&rdquo; <em>Washington Post</em>, Oct. 12, 2006.)</p>

<p>Margaret Sanger spent much of her career working against the grain of American manifest destiny &ndash; the country&rsquo;s inalienable right to fill its vast spaces. Just after she launched her campaign to legalize birth control in 1914 the country counted up to 100 million, and she died a year before the 200 million mark in 1967. Both milestones were met with nationalistic glee. Sanger was always more concerned with the quality of the population than mere numbers, but numbers are measurable while quality, as we have learned the hard way in American history, is not. That is why a panic broke out in the late 1930s when the numbers indicated a downward trend in the population growth rate that had some demographers predicting catastrophic depopulation and placing the blame squarely on Margaret Sanger. </p>
<p>The gradual demographic transition in the U.S. from larger to smaller families, which had for decades been viewed by most social scientists as a healthy trend, raised concerns among those eugenicists who believed the wrong families &mdash; middle and upper class &mdash; were getting smaller. The rapid population gains produced by immigration meant that America did not suffer from the concerns over anemic growth rates that bedeviled the leaders of Western Europe. But the reduction in the overall population growth rate in the 1930s caused by immigration quota laws and the Depression-era drop in the birth rate led some population experts to warn of prolonged economic stagnation and a weakened future military if the downward trend continued. The issue made national headlines in 1937 when it was reported that the 1936 U. S. birth rate was the lowest on record. </p>
<p>It did not help matters that by 1937 a number of European countries scrambled to reverse population rate declines and join in a belligerent &ldquo;cradle competition,&rdquo; to use Sanger&rsquo;s phrase. A depopulation panic hit England in the mid-1930s following several demographic studies that demonstrated both a sharp drop in the birth rate and an alarming differential fertility trend &ndash; the lower classes were far out-reproducing everybody else. Eugenics groups advocated birth promotion programs, including marriage loans, bachelor taxes and baby bonuses to arouse fertile procrastinators. Parliament discussed incentives for couples and even broached the idea of making birth control illegal. Members lamented the population decline and scolded fellow countrymen for selfish considerations when it came to family size. The only problem was that several of the M. P.&rsquo;s expressing the most concern about the differential birth rate were bachelors. &ldquo;I learned with amazement and horror,&rdquo; a Member told the House of Commons shortly after one of the first discussions on population policy, &ldquo;that even in this House, where the age limit is, I think, fairly high, and which should set an example to the rest of the country, there are nearly 200 bachelors &ndash; a situation which honorable Members should take immediate steps to remedy.&rdquo; (&ldquo;Bachelor M. P.s Discuss Population Problem in Parliament,&rdquo; <em>The Birth Control News</em> 15:10 [Mar. 1937]121-122.)</p>
<p>In Germany and Italy, where the birth rates had been on the decline for years, the fascist governments instituted state campaigns in the mid-1930s to raise birth rates among racially &ldquo;correct&rdquo; groups using a combination of inducements to young couples such as &ldquo;nuptial prizes,&rdquo; financial penalties for bachelors, and tighter restrictions on divorce, contraception and abortion. It didn&rsquo;t work in either country. Italy&rsquo;s birth rate continued to fall in the late 1930s even after more than ten years of government inducements, and the German birth rate, though it increased for several years following Hitler&rsquo;s ascension to power, dropped off again after 1936. Everybody wanted more babies but only the Soviet Union, its population already increasing by more than three million a year, devised a successful campaign that raised the birth rates even higher, mainly by outlawing abortion and paying cash premiums for large families. (<em>New York Times</em>, Aug. 30, 1936, Mar. 28, 1937.)</p>
<p>With conflict looming in Europe, some American social scientists viewed the lower birth rate as a future security issue. A group of demographers predicted sharp population declines by the end of the century that would reduce the U.S. to a second-rate power. Dr. Louis Dublin, a statistician for Metropolitan Life Insurance and a leading expert on American population trends, predicted that the population would reach a peak of about 140 million in 1950, after which deaths would outnumber births, resulting in a population of only 75 million by the year 2000. By then it would be a nation &ldquo;composed largely of middle-aged and elderly people&rdquo; and &ldquo;unduly weighted with elderly women,&rdquo; hardly a demographic vision to instill fear in one&rsquo;s enemies. (<em>New York Times</em>, Mar. 28, 1937.) </p>
<p>If the decline in quantity was the catalyst for an unprecedented analysis of population trends and burst of demographic foresight in the 1930s, the perceived decline in quality provoked some extreme proposals and challenged the fundamental aim of birth control. It had been well established in one study after another during the Depression years that unskilled, under-educated and poor Americans had more children than skilled, educated middle- and upperclass Americans. &ldquo;Unless this decline can be reversed,&rdquo; eugenics proponent Frederick Osborn told the annual meeting of the American Eugenics Society in May 1938, &ldquo;the biological stock and cultural inheritance of the American people will suffer.&rdquo; There was a strong consensus among eugenicists and population experts that the main culprit in the trend toward differential fertility was birth control. (<em>New York Times</em>, May 6, 1938.)</p>
<p>Writing in the <em>Birth Control Review</em> in 1938, Henry Pratt Fairchild, one of the most popular authors on population and immigration issues, determined that &ldquo;Birth control must accept a large part of the responsibility for the situation in which we now find ourselves . . . It is now . . . both possible and desirable for the birth control movement to divert its attention in the countries of Western civilization from purely quantitative matters, and to concentrate on cooperating with other agencies to promote the eugenic objectives of society.&rdquo; Louis Dublin was more emphatic, claiming in 1937 that birth control had caused &ldquo;inestimable damage&rdquo; to the country and, specifically, that Margaret Sanger&rsquo;s actions had been governed by &ldquo;a misguided and short-sighted fervor.&rdquo; &ldquo;Mrs. Sanger,&rdquo; he told a reporter, &ldquo;was overwrought by the misery she witnessed as a nurse, in families she visited. She did not realize that bad as these conditions were, they actually affected only a small proportion of the country&rsquo;s population.&rdquo; In other words, she should not have so freely extended birth control to those of good health and home who were merely seeking to evade &ldquo;family responsibility.&rdquo; He said she must balance &ldquo;her destructive program with constructive advice to those economically able to have children.&rdquo; (Henry Pratt Fairchild, &ldquo;Contemporary Population Changes in Relation to Birth Control,&rdquo; <em>Birth Control Review</em> 22:7 [Apr. 1938], 74-75; <em>New York Times</em>, Mar. 28, 1937.)</p>
<p>Sanger offered an immediate rebuttal, telling the <em>Times</em> that &ldquo;Dr. Dublin says there has been an evasion of responsibility. Quite the contrary. Statistics and our social workers testify that the parents who have few children are those most responsible toward their children. It is the large family groups that evade family responsibility, and have to plead with agencies and government to keep them going. Dr. Dublin&rsquo;s is the voice of 100 years ago &ndash; not the voice of the future.&rdquo; She refused to see a downward shift in population as anything but a progressive, civilized trend, noting that &ldquo;the death rate has also dropped, and that more lives have been saved through birth control, not only of mothers but of children.&rdquo; (<em>New York Times</em>, Mar. 28, 1937.)</p>
<p>Even as Sanger was celebrating a succession of major victories in the late 1930s, in eugenics circles her name continued to be linked with the prospect of depopulation. Following the publication of an influential 1938 government report on population changes, Sanger briefly caved in to the pressure, issuing a statement of concern over the low birth rate among &ldquo;healthy and intelligent couples.&rdquo; Uncharacteristically, she called for subsidies to go to healthy couples who could not afford to raise a family, declaring it was a matter of &ldquo;promoting the national welfare.&rdquo; She quickly backed away from this sentiment and scolded the new Birth Control Federation&rsquo;s national director a year later after the Federation had proposed &ldquo;to encourage the increase of the birth rate where health, intelligence and favorable circumstances tend to promote desirable population growth.&rdquo; She told him, &ldquo;I strongly object to our straddling this issue and trying to satisfy the large population groups . . . Let the Federation begin with its own Board and see how far your efforts, or the most brilliant oratory, will go in getting them to increase their reproductive rates.&rdquo; (<em>New York Times</em>, Nov. 13, 1938; BCFA, &ldquo;Objectives,&rdquo; Feb. 1939 [<em>MSM</em> S62:36]; MS to D. Kenneth Rose, Dec. 27, 1939 <em>[MSM</em> S17:661.)</p>
<p>As aggressions intensified in Europe in the winter of 1939&ndash;Sanger blamed the warmongering on the pressures of over-population&ndash;she distanced herself still further from the demographers and eugenicists who thought birth control should be better managed: subsidized for the poor and packaged with constructive, race-saving advice and encouragement for the better-born. Speaking at the eighteenth annual meeting of the American Birth Control League in January 1939, Sanger reviewed the dire depopulation predictions that had put the movement on the defensive. &ldquo;The picture is presented&rdquo; she told a faithful audience, &ldquo;that there will be a nation of old men and women over 65 years of age, using spectacles, ear trumpets, crutches, and wheel chairs and these people will dominate our health resorts and increase the call upon the services not of obstetricians but of neurologists. . . To some this may seem a sad prediction, but I agree with Havelock Ellis, who says that perhaps a million more old people may make for more peaceful and happy conditions. That it is the countries dominated by the racketeering young, with their black-jacks, their machine guns, their military drills, uniforms and the adventurous and exciting activities of arrogant youth, that have made for chaos in the world today.&rdquo; (MS, &ldquo;Doors to a New World,&rdquo; Jan. 19, 1939 [<em>MSM</em> S72:47].)</p>
<p>In the summer of 1939 the Census Bureau announced that the birth rate had risen two years in a row. The 1937 predictions of future depopulation looked foolishly premature. War, however, soon united the country on the need to increase the birth rate. Margaret Sanger was one of the few voices who continued to caution the public on the dangers of too many people.</p>
<p>In all of their figuring, the statisticians and demographers and newly minted professors of population studies did not forecast the size and length of the postwar American baby boom that silenced any lingering talk of depopulation in the U. S. As the country sped toward the 200 million mark and populations rose dramatically in many developing nations, Sanger&rsquo;s arguments again gained currency. Today, depopulation is once more an issue of concern in Europe, but America, the perpetually young superpower, just can&rsquo;t kick its growth spurt. </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
