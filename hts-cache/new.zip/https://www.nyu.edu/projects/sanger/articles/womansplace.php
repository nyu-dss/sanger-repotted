
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #51 (Spring 2009)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #51 (Spring 2009)</h1>			

<div class="maintext">		
<h1>"A Woman's Place"</h1>

<p>In May of 1950 Sanger received a letter from Violet Alva, an Indian lawyer and feminist, and P. N. Nariman, the secretary of the Bombay (Mumbai) birth control clinic, who had met Sanger in India in 1936. The two were writing a book on the social status of women throughout the world and planned to include a chapter &ldquo;on the views of eminent women of our time on problems affecting womenhood.&rdquo; They asked Sanger to complete a questionnaire so that they could incorporate her views into the book. </p>
<p>Sanger took her time in carefully formulating her answers, and did not respond until late August, 1950. Her letter to Alva and her responses to the questionnaire mark one of the few times since very early in her career that Sanger discussed issues related to women&rsquo;s position in society without focusing solely on birth control. </p>
<p>She did devote much of her cover letter to asserting the importance of her cause to any study of women&rsquo;s status. She wrote:</p>
<blockquote>
<p>
&ldquo;There is one aspect of woman&rsquo;s freedom and development seldom mentioned. That is the struggle for her biological freedom&ndash; Motherhood, its spacing, its preventions, and its maturity. A woman cannot evolve to her highest development if she must be under the shadow of pregnancy year after year through her child-bearing period. This is to me an enslaved condition, and without birth control knowledge she cannot determine her destiny. Neither political nor economic nor social freedom adds to woman&rsquo;s dignity as much as biological freedom does. Why not stress the importance of this in your book? Men cannot feel its need as women do and should. Consequently, we as women should shout from the housetops whenever we can. In this way, we may help other women in less fortunate circumstances control or limit their pregnancies.&rdquo; </p>
</blockquote>

<p>She then proceeded to offer her responses. The completed questionnaire follows.</p>

<p><strong>QUESTIONNAIRE</strong></p>
<p><strong>1. IS HOME THE ONLY PLACE FOR WOMEN?</strong><br /> No. The world and its activities, needs, and occupations is for women as well as for men. Home is not the only place for women.</p>
<p><strong>2. DOES HOME LIFE GIVE COMPLETE HAPPINESS TO WOMEN?</strong><br /> There are some women for whom a good comfortable home gives complete happiness; there are others who find its duties dull and boring. The home does not give complete happiness to all women.</p>
<p><strong>3. SHOULD WOMEN SACRIFICE ALL OTHER INTERESTS IN FAVOUR OF HER CHILDREN UNTIL THEY ARE ADULTS?</strong><br /> Women should not sacrifice all other interests in favor of her children until they are adults. That is by far the most harmful thing she can do, not only to herself but to her husband and growing children. The woman who has outside cultural or civic interests brings into the home these interests and often is the inspiration of her children&rsquo;s higher learning, creating a larger horizon in their own growing world. Any woman is of greater interest to her family when her mind is developing and her own spiritual being is growing with and through efforts of cultural import.</p>
<p><strong>4. DOES MARRIAGE ENSLAVE OR PROTECT WOMEN?</strong><br /> Marriage can enslave some women; it can also protect some women. It depends greatly upon the one who enslaves or protects her. Sometimes protection is enslavement. </p>
<p><strong>5. WHICH IS MORE RATIONAL, MATRIARCHAL OR PATRIARCHAL SYSTEM?</strong><br /> To me, neither Matriarchal or Patriarchal systems are rational. Why should they be either?</p>
<p><strong>6. FROM YOUR OBSERVATIONS AND STUDY, COULD YOU TELL US WHETHER MEN GENERALLY PREFER THE HOMELY TYPE OR THE CAREER TYPE OF WOMEN?</strong><br /> Most men like a good home and its comforts. It does not make much difference to men how their comforts are made. They can be directed by a career wife and accomplished by servants or done by the woman herself. The career type of woman is often an office wife to a business man far more attractive and helpful than the slavey home wife. Most men like women with charm, wit, ability in any position of home or office.</p>
<p><strong>7. SHOULD WOMEN QUIETLY AGREE TO DOUBLE STANDARD OF MORALITY AS MEN ARE POLYGAMOUS BY NATURE, OR DEMAND EQUAL MORAL STANDARDS?</strong><br /> As standards of morality differ in various countries, it is difficult to call one country&rsquo;s &ldquo;double or single standards&rdquo; what other countries accept as moral. In English speaking countries, intelligent men and women hold a single moral standard for man and woman, especially after marriage. Before marriage, however, opinions differ as to man&rsquo;s code of morals. As for woman, there is almost a universal agreement that her moral code must be virginal until marriage.</p>
<p><strong>8. DO YOU ENVISAGE A TIME WHEN SOCIETY WOULD DISCARD THE INSTITUTION OF MARRIAGE FOR FREE LOVE?</strong><br /> There is no such institution as &ldquo;free love.&rdquo; I can envisage no period when Society will discard marriage for promiscuity.</p>
<p><strong>9. WOULD IT BE ADVISABLE TO LEGALIZE UNMARRIED MOTHERHOOD?</strong><br /> Yes, it would be wise and humane to legalize children born out of wedlock and remove the stigma from an innocent victim. As to legalizing the unmarried mother, much would depend on the circumstances of her case&ndash;how many illegitimate children has she born, how many will she continue to bring into the world? Our institutions can testify to the custom. </p>
<p><strong>10. WITH INCREASED INTEREST IN WORLD AFFAIRS, COULD WOMEN CHANGE THE SOCIAL, POLITICAL, AND ECONOMIC STRUCTURE OF SOCIETY?</strong><br /> Women have not so far with their hard-won political freedom changed even a small fraction of the structure of Society. They have not changed the status of women through their positions in the halls of Parliament or U.S. Senate. Not a woman&rsquo;s voice in any country has been raised in their official position on behalf of the right of the poor, over-burdened women to have knowledge of birth control. This to their shame, for none of the women in the political arena, none in earning positions have large families and certainly would not attain the freedom they have without some knowledge or method to prevent the conception of unwanted children. Woman in world affairs is not a force&ndash;only a partial copycat of man&rsquo;s influence and leadership, alas.</p>
<p>[Both Sanger&rsquo;s letter and the questionnaire have been included in <em>The Selected Papers of Margaret Sanger, Vol. 4: Round the World for Birth Control, 1920-1959</em>.] 
(Alva and Nariman to MS, May 26, 1950; MS to Alva, Aug. 28, 1950 [LCM 7:787, 791].)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
