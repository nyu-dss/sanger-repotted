
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #9 (Winter 1994/1995)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #9 (Winter 1994/1995)</h1>
<div class="maintext">
<h1>"Margaret Sanger: The Arizona Years"</h1>

<p>1994 marks the 60th anniversary of Planned Parenthood of Southern Arizona in
Tucson, an organization which was especially dear to the heart of Margaret
Sanger, who made her home in Tucson for some thirty years. Sanger made her first
visit to Tucson in October of 1934 with her son Stuart, who sought the dry
desert heat to recuperate from respiratory ailments. Though she grew to love her
still sparsely populated city, Sanger was initially less than enthralled with
Tucson. "Its sizzling hot &ndash; I drip. Sleep under the stars at night but
with bats flying overhead &amp; rattle snakes underneath &amp; spiders watching
for their midnight meal. Im under the covers and cant tell what the sky is
like...." (Sanger to F. Rose, October 8, 1934, <em>MSM</em> S9:97).</p>

<p>In another letter to Florence Rose, Sanger noted, "There is prospect of
a new clinic here before I go away...So I grabbed the straw and got them
going...." (November ??, 1934, <em>MSM</em> S9:366). As she did in so many of the
cities she visited, Sanger met with "60 of the best women," including
Molly B. Smith and Barbara Dittmann, and helped them found the Tucson Mother's
Health Clinic. (Sanger to J. N. Slee, November ??, 1934, <em>MSM</em> S9:377) The clinic
thrived and eventually became Planned Parenthood of Southern Arizona. </p>

<p>     Margaret Sanger was still a visitor to Arizona in 1934, but in the fall
of 1937 she moved to Tucson with her ailing second husband, J. Noah Slee. Sanger
had by then devoted herself non-stop to birth control for over twenty years and
at the age of 58 wanted to cut back on her public activities. Her first year in
Tucson changed her feelings about Southern Arizona's stark beauty. "The
mountains, not distant or aloof or towering over all, reached into the sky, but
they were also somehow intimate, cupping the town gently on all four
sides," she wrote, "The first thing when you opened your eyes, before
actual dawn, you beheld the gold and purple and then the entire sky break into
color. In the evening the sunsets were reflected on the mountains in
pink-lavender shades...Sunset vanished as quickly as sunrise, never lingering
long." (<em>Margaret Sanger: An Autobiography</em>, 1938, p. 492) The color
and light of the desert proved so compelling that she took up painting,
specializing in watercolor renderings of the Arizona landscape. She joined the
Tucson Watercolor Guild and took lessons with local artist Gerry Peirce.</p>

<p>     While initially only winter residents, the Slees were soon
spending much of the year in Tucson.  After Noah Slee's death in
1943, Sanger decided to sell Willowlake, her country estate in
Fishkill, NY, and build a new house in Tucson's Catalina foothills. 
She had asked her friend, Frank Lloyd Wright, to design the
house, but when he discovered the building lot was only 110' by 150' he abruptly declined the commission.  Not
easily discouraged, Sanger took matters into her own hands and worked closely with Tucson architect Arthur T.
Brown to design a singular house, known for its original fan-like structure.  Sanger's close friend and biographer
Lawrence Lader described the effect:</p>

<blockquote><p>
     "The living room was the main spoke of the fan &ndash; spreading
  dramatically from a width of about thirteen feet at the entrance to over forty
  feet at the far end, with floor to ceiling windows that looked up into the
  mountains. A large steel fireplace stood in the center of one side wall. In
  front of it was a gracefully curving pool of water on whose surface in the
  wintertime the reflections of the flames made a riotous dance." (<em>The
  Margaret Sanger Story</em>, 1955, p.331)</p>
</blockquote>

<p>     The house on Sierra Vista Drive was especially dear to Sanger because it put her
next door to her son Stuart and his family.  Her two granddaughters and many of the
neighborhood children spent a great deal of time at the house. Sanger also did a
great deal of entertaining and cooking there, often hosting dinner parties on a
specific theme complete with appropriate foods and costumes for the guests.   </p>

<p>   At her home,
Sanger often
entertained the
notables she met
through her work. 
Her granddaughters
remembered
meeting Lakshmi
Pandit, Jawaharlal
Nehru's sister, John
D. Rockefeller, Jr.
and his wife,
Martha, and Sumiko
Kato, the daughter of
Japanese birth
control leader,
Shidzue Kato. 
Other guests
included Frank Lloyd Wright, Mary Ritter Beard, Lady Dhanvanthi Rama Rau, and Eleanor Roosevelt.   On one
occasion 125 geologists from across the country gathered in Tucson under the auspices of the University of
Arizona and Sanger hosted a cocktail party for them.  Margaret Sanger Marston described her grandmother's
role:  "This little lady sat on the couch to greet them in a long Hawaiian dress and she told stories and the 125
men were absolutely spellbound. They thought she was the greatest woman they had ever seen." (Oral Interview,
Recorded by J. Van Voris, May 29, 1977, Margaret Sanger Papers, Sophia Smith Collection). </p>

<p>     However, Sanger's enjoyment of Tucson's pleasures were rarely full-time.  While building her Tucson home,
she was also re-entering public life, devoting herself particularly to the rapidly expanding international birth
control movement.  From 1952-1959 Sanger served as the first president of the International Planned Parenthood
Federation.   In her seventies, frail and in failing health, Sanger undertook much of the grueling organizational
work from her Tucson home where granddaughter Nancy recalled, "seeing her sitting there with a secretary at
one end of the room and she'd be at this great dining room table where she worked, writing.  She'd work very
hard at whatever she was doing at that time, writing, keeping up her correspondence with people" (Nancy Sanger
Ivins, Oral Interview, Recorded by J. Van Voris, May 29, 1977, Margaret Sanger Papers, Sophia Smith
Collection).  </p>

<p>     During the 1950's Sanger also made frequent trips to New York City and
attended conferences in England, Sweden, India and Japan. But in the end, she
always returned to Arizona. In March 1965, a year before her death, the Tucson
Planned Parenthood Center held a dinner honoring Margaret Sanger as the
"Woman of the Century." (<em>Tucson Daily Citizen</em>, March 23, 1965)
In 1992, Margaret Sanger was honored by her adopted state with her induction
into the Arizona Women's Hall of Fame.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
