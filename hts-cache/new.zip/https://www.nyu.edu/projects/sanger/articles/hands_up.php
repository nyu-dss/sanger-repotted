
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #35 (Winter 2003/2004)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #35 (Winter 2003/2004)</h1>
<div class="maintext">
<h1>"Hands Up!"</h1>

<p><img border="2" src="http://www.nyu.edu/projects/sanger/images/hand1.jpg" align="left" width="250" height="353">
In 1933, Nellie Simmons Meier,
a well-known palm reader from Indianapolis, wrote to Sanger to see if she could
make an appointment to read the hands of the noted birth control reformer for an
upcoming book on the hands of outstanding men and women in various fields. "This
book," she wrote Sanger "goes down to posterity to show the famous hands who
put into execution, the commands of their owners." (Nellie Simmons Meier to
MS, Dec. 2, 1933 [LCM 9:550].) Meier called herself "a professional reader of
character through scientific palmistry," and claimed to have read roughly
20,000 pairs of hands over 35 years. Indiana writer and American diplomat
Meredith Nicholson wrote in the introduction to Meier's book of collected palm
readings, <em>Lions' Paws: The Story of Famous Hands</em> [New York, 1937]: "She
has made of palmistry something more than a fad, and I venture to say that no
one has ever carried the study of it further or to a higher plane." Sanger,
who periodically tested her faith in astrological readings and handwriting
analysis, welcomed the opportunity to have Meier examine and take an impression
of her hands. (<em>Lions Paws</em>, 18, 20)</p>
<p>Meier read Sanger's hands in January 1934. According to her book, she
averaged twenty minutes with each subject, analyzing their handshake and palms
and fingers before taking an ink impression. She wrote Sanger after their
meeting, calling Sanger's small hands "wonderful exponents of that busy,
active brain of yours." (Nellie Simmons Meier to MS, Jan. 11, 1934 [LCM 9:554]
.)</p>
<p><em>
Lions Paws</em>, published in 1937, incorporated a little over 100 hand
readings of reformers, politicians, artists, musicians, actors, writers,
scientists and business leaders, including: Walt Disney ("his thumbs are
double jointed, disclosing his liking for dramatic episodes and the ability to
create them in life."); financier Otto Kahn ("square palm, the palm of a man
of order and of method who recognizes authority and the need for discipline.");
Susan B. Anthony ("...her heart line, forked at one end and running to the
space between the first and second fingers showed idealism."); Booker T.
Washington ("His head line indicated that his mentality was used in furthering
one particular line of work, rather than diversified interests &ndash; a one-track
mind."); George Gershwin ("His originality is shown in the rather spatulate
development of the tip of his third finger, Apollo."); Amelia Earhart ("The
length and breadth of her palm indicate her love of physical activity, and her
long fingers show her carefulness in detail ensuring perfection as far as
possible."); and Helen Hayes ("Her palms slope toward the wrist, the skin is
satiny, of exceedingly fine texture, and these together with her nicely placed
but rather short fingers, show quick, inspirational, mental grasp, such as she
applies to her character delineations.") (<em>Lions Paws</em>, 155, 147, 150,
142, 101, 75, 35.)</p>
<p>Her analysis of Sanger's hands was one of the lengthiest in the book:</p>
<p>"As I looked at her palms I understood why she, of many women who had gone
through a similar experience, had begun her work. If you will look closely at
her hands you can see the circle of intuition in both, that is, the curve which
leads from under the mount of Mercury, the fourth finger, and extends to the
percussion of the hand on the mount of the Moon. The whorl of the capillaries
form what <img border="2" src="http://www.nyu.edu/projects/sanger/images/hand2.jpg" align="left" width="250" height="307"> I call ‘thumb' of ‘finger' impressions of Luna, as if fingers
had just rested upon the spots. These are found not only upon the mount of the
Moon, but between the second and third fingers and the third and fourth fingers.
These are all signs of intuitive gifts. Margaret Sanger does little conscious
planning. She receives impressions and makes plans without knowing that she does
anything. Suddenly a course of action lies open before her. It is plain and
direct; the only course she can possibly follow.</p>
<p>As she shook hands with me I felt in that sincere firm grasp, an immediate
reaction to my personality. The resiliency of her palm is remarkable, she
literally feels a person's mood and opinion, as she touches the hand.</p>
<p>The development of the mount of Venus coupled with the drooping of her head
line in the left hand to the mount of the Moon shows her sympathy with the
problems of others together with an imagination that at times interferes with
her clarity of judgment. She has suffered periods of great depression because of
lack of progress in her work. The straight head line in her right hand shows
that she gained confidence as she went on. The development of the mount at the
base of the first finger, Jupiter, shows that she had some love of approbation,
but not enough to be a motivating force. Her motivation comes from impulse,
sympathy with others, and her rare intuitive qualities. There is no
self&ndash;interest in it. Her driving power again is impulse, backed by intuition.
She is a true reformer in that she is not a self seeker, but she is a reformer
of a rare type, and her success must be explained by her intuitive qualities.
Hard as her struggle has been, she seized upon the propitious time to launch her
cause." (<em>Lions Paws</em>, 149-150.)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
