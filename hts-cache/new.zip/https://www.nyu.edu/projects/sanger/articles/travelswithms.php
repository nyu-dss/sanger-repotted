
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #63 (Spring 2013)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #63 (Spring 2013)</h1>
<div class="maintext">	  
<h1>"Travels With Margaret Sanger: Dorothy Brush's Portrait of Margaret Sanger"</h1>

<p>Dorothy Hamilton Brush is best known for knowing others. From her undergraduate days at Smith College and her early years as a Cleveland socialite, to her regular visits to the New York Cosmopolitan Club and many years service in the birth control movement, Brush came in contact with some of the most charismatic, ambitious and powerful women of her time. Self-effacing and at times outwardly insecure, she ducked out of the shadow cast by her younger sister, actress Margaret Hamilton (the Wicked Witch of the West in the Wizard of Oz) only to, decades later, fall under the spell of Margaret Sanger. </p>
<p>From the early 1930s until Sanger's death in 1966, there may have been no other friend of Sanger's who spent as much time with her as Dorothy Brush. “Of course she pulled me into the work,” Brush later wrote, “Yet quite apart from the cause, our private friendship grew like Topsy without cultivation.” A member of the board of Cleveland's Brush Foundation, Dorothy Brush accompanied Sanger on several major trips abroad, including to Asia in 1937, to Sweden in 1946, and to Japan and India in 1952. She also spent part of several summers living with Sanger in Tucson and one in Haiti, and often hosted Sanger at her house in Bridgehampton, N.Y. She served as an officer on Sanger's National Committee on Federal Legislation for Birth Control (NCFLBC) in the 1930s and worked side-by-side with her in the 1950s in building the International Planned Parenthood Federation (IPPF). Their correspondence is among the largest and most insightful in the voluminous collection of Sanger's papers. (Dorothy Brush, “I Just Love Margaret,” in “Our Margaret Sanger” [ <em>MSM </em> S77:720].) </p>
<p>For three decades Brush also jotted down anecdotes about her time with Sanger, saved excerpts from letters, compiled biographical notes, and penned short essays, speeches, and articles about Sanger's achievements as well as “her infinitely varied personality”--the different sides of a public woman revealed in private moments. Brush planned to one day write a biography, but a book never materialized. Nevertheless, her files of typed and handwritten notes and fragments, as well as a few published and unpublished manuscripts, offer a unique portrait of Sanger's later career and life. (Brush, writing fragment, n.d [Brush Papers, Sophia Smith Collection].) </p>
<p>Dorothy Adams Hamilton was born in Cleveland in 1894. She graduated from Smith College in 1917 and that same year married Charles Francis Brush, Jr., the son of the world-famous inventor of the arc light, Charles F. Brush, Sr. After an overseas military stint, the couple settled in Cleveland where, starting in 1920, Dorothy Brush and fellow Junior League member Hortense Shepard, began to provide birth control information to women at a prenatal clinic of a maternity hospital, where they volunteered. Brush had been “deeply influenced” by Sanger's 1920 book, <em>Woman and the New Race </em>, and began to follow Sanger's activism. In November 1921, Brush's cousin, Juliet Barrett Rublee, a rising figure in the New York birth control movement and a close friend of Sanger's, invited Brush and Shepard to attend the First American Birth Control Conference in New York. They took their mothers along to share the opportunity to hear Sanger speak. Brush was in the crowd that followed Sanger when police escorted her to a local precinct following her arrest at the concluding session of the conference. The experience energized the twenty-seven year old Brush, who returned to Cleveland to help lead the clinical birth control movement in that city, culminating in the founding of the Maternal Health Association of Cleveland in 1928. (Brush, writing fragments, nd [Brush Papers]; Jimmy Elaine Wilkinson Meyer, <em>Any Friend of the Movement: Networking for Birth Control, 1920-1940 </em>[Columbus, 2004], 28-31.) </p>
<p>Tragedy hit Brush in 1927. She lost her six-year-old daughter, Jane, to pneumonia, and a week later her husband Charles died from complications related to his donation of blood for his dying daughter. In memory of Charles Brush, and at Dorothy Brush's behest, her father-in-law created the Brush Foundation to support research in population control. The Foundation, which continues to this day and has supported the MSPP, played a significant role in the formation of the IPPF in the 1950s. In 1928, Brush relocated with her young son to New York to escape her grief in Cleveland and begin anew. Not long after settling in the city, she met Sanger first at a meeting and then one-on-one over lunch. Although neither woman mentioned it in later writings, they undoubtedly shared their mutual grief over losing six-year-old daughters to pneumonia--Sanger's little girl, Peggy, having died in 1915. (Biographical Note, Dorothy Hamilton Brush Papers, 1840-1969, Sophia Smith Collection, Smith College.) </p>

<p>By this point in her life, Brush had published some children's plays and travel articles, and fashioned herself a writer. She approached Sanger with a proposition. “In my brash youth,” she later wrote, “I actually had the nerve to invite her to lunch and propose to write her life, no less! Instead of laughing at me as I certainly deserved, she listened throughout with perfect gravity and only at the end suggested that perhaps we should know each other better first.” Sanger considered Brush's proposal but sought to control her own story and use it to publicize the movement; she would begin work on her first autobiography, <em>My Fight for Birth Control, </em>a year later. But she did not forget Brush's enthusiasm or ambition, and asked her to ghostwrite a short piece about her in a collection of biographical essays titled, <em>Adventurous Americans </em>, published in 1932. (Brush, “Our MS.”) </p>

<p>Their friendship blossomed following that first get-together. Sanger recognized Brush's communication skills and welcomed her influential and moneyed contacts, including her new husband in 1929, attorney Alexander C. Dick. Brush joined the NCFLBC, becoming its secretary in 1931. After the war, Brush helped Sanger organize a new international birth control organization, the IPPF. Brush designed and edited the IPPF's chief publication, <em>Around the World News of Population and Birth Control, </em>running the monthly largely on her own until 1956. She stepped in for an ailing Sanger on several occasions to give speeches or represent the IPPF, such as in Rome in 1954 for the World Population Conference. When she was not working for one of Sanger's organizations, she was often overseeing multiple projects to secure Sanger's legacy. Brush pulled the strings to get Smith College to award Sanger an honorary doctorate and to house a substantial portion of Sanger's papers in the Sophia Smith Collection. She also led the effort to try and win Sanger a Nobel Peace Prize, a multi-year endeavor that fell short. </p>

<p>Always insecure, Brush felt snubbed whenever Sanger chose another friend to accompany her or when Sanger overlooked one of Brush's many contributions to the movement. Brush had long before shaped and sculpted Sanger into a saintly and nearly superhuman figure with few failings. But their last years together were fraught with petty disagreements and marked by spiteful acts, as neither woman could adjust to changes in their friendship created by Sanger's mercurial personality, a consequence of her poor health. In Sanger's difficult last years, when her all too human frailties became sometimes overbearing and often burdensome to others, Brush struggled to stay close. While she was not alone and could share her frustration and disillusionment with some of Sanger's other friends and family members, she was forced to construct emotional barriers and learn to cease being, in her words, “subservient” to Sanger. Yet she was there at the end, caring for Sanger in Tucson and coordinating Sanger's household needs and personal finances before Sanger entered a nursing home in 1963. “Goethe said, ‘Blessed is he who draws near to the great of the world,'” Brush wrote in a biographical fragment, “And indeed, I have been so blessed in drawing near to Margaret. Not only has she constantly inspired me, but she brought more sparkle, more adventure into my life than anyone else.” Brush died in 1968, less than two years after Sanger, working right up to the end on continuing to collect Sanger's papers for Smith College. (Brush, transcribed letter, Oct. 29, 1952 [Sanger Unfilmed, Sophia Smith Collection]; Brush, “My Friend, Margaret Sanger” [Brush Papers].) </p>

<p>What follows is a small selection of Brush's remembrances and firsthand accounts of her time with Sanger. Brush later edited many of these short pieces into a tribute to Sanger that she included in “Our Margaret Sanger,” a collection of tributes from friends and co-workers presented to Sanger in 1959. It is included in the <em>Margaret Sanger Microfilm Edition, Smith College Collections </em>. All other excerpts come from the Dorothy Brush Papers or the unfilmed portion of the Margaret Sanger Papers, in the Sophia Smith Collection, Smith College. </p>

<p><strong>On their first meeting: </strong></p>

<p><em>I invited Margaret Sanger to lunch with me at the NY Junior League club, the first time we had met except in a public meeting. How strange it is that it never entered my mind that she might not accept, a woman already famous, so busy that she was like a locomotive running at top speed on a single track! I can see her now as she sat opposite me at a table for two, smiling under a wide becoming hat, dressed in a gray-blue silk which matched her eyes, those eyes set so far apart which twinkled at me as if we had a secret known only to the two of us. And so we were to have during our more than thirty years of close friendship. Now she began chatting with me as if we'd known each other always. Not until after she left, did I realize with a sense of shame, that the conversation was all about me. Many times to come, I was to see her in the role of the great listener, drawing strangers out, making them instantly at ease. </em>(Brush, writing fragment, n.d., [Brush Papers].) </p>

<p><strong>On the secret to Sanger's success: </strong></p>

<p><em>Margaret's friends have made much of her Irish luck, intuition, and what sometimes seems like second sight. They should never discount her foresight and native shrewdness and a perfect sense of timing. </em>(Brush, writing fragment, n.d, [Brush Papers].) </p>

<p><strong>Brush served as an officer of the National Committee for Federal Legislation on Birth Control in the 1930s and found working for Sanger to be an unconventional experience: </strong></p>

<p><em>There was neither formality or regularity. Board meetings were few, far between and were fun. Unlike other boards I'd been on, there were never any cut and dried questions prepared to which we were expected to assent like so many rubber stamps. For the most part we worked individually and seldom saw each other. Were she not so gentle except when frustrated, Margaret was rather like a lion tamer. She kept us each on our boxes until she needed us–then we jumped and jumped fast. My husband used to call me Margaret's fire-horse. Weeks might go by without word from her. Then perhaps a telephone call and I had to be down at 17 West 16th Street [Sanger's clinic] in an hour . . . . or perhaps take off for Washington. One classic morning I read in the New York Times that I was to take part–actually speak–in a Senate hearing, in only two days. Aghast I called the office. It was true. I just happened not to have been notified! </em>(Brush, writing fragment, n.d, [Brush Papers].) </p>

<p><strong>On Sanger's trouble with organizations: </strong></p>

<p><em>Margaret has never been good at red-tape and even the big scissors with which she perpetually hacks away at it is a nuisance to her. She is no objective executive. She is a prima donna. When she did work with a “regular” birth control organization she nearly drove her Board crazy. Things were always happening of which they knew nothing and she was as indifferent to money problems as to the whole terrific weight of opposition to the Cause. She would hire a hall; she would forget to mention it; her Board would find it out. </em></p>

<p><em>“Where do you think we shall get that awful price? We'll have to dip into our own pockets.” </em></p>

<p><em>“No you won't,” Margaret would say soothingly, “It will come.” </em></p>

<p><em>“Where from? Have you got it now?” </em></p>

<p><em>“No, but I'll raise it at the meeting.” </em></p>

<p><em>What really exasperated them most, I think, was that she always did raise it. But Boards rely on accounts and budgets. How to do business with a woman who explained when she needed money, “I simply cast myself on the universe and the money always comes.” </em>(Brush, writing fragment, n.d, [Brush Papers].) </p>

<p><strong>Brush, like many other observers, frequently commented on Sanger's deceptive appearance: </strong></p>

<p><em>No one ever picks out Margaret Sanger as the Margaret Sanger. People expect a warhorse–and see a little Shetland pony. Or the other way around–as if you saw a candy box–and then found it full of dynamite. </em>(Dorothy Brush, speech draft, 1954 [Brush Papers].) </p>

<p><strong>On Sanger's appearance at age 57: </strong></p>

<p><em>She is a timeless looking person. I don't think one would ever connect her in mind with time at all. She is so alert mentally, that she looks almost girlish at times; at others she looks, not old exactly, but very tired. Her skin is very white with an opaque whiteness; the lines in her skin look like shadow markings against the white; I don't think she ever uses make-up, or very little. She has lovely eyes, blue-gray and set very wide apart. Her mouth is sweet but determined; the lower lip full and protruding a little. Her chin has dropped into the deep fold of flesh just beneath it, which is circled by the scar of an operation. Her hair, which she has marcelled rather than finger-waved, because she cannot stand the heat of a dryer, stands up, a paling red, threaded with white. It looks as alive as if it had a separate life of its own and too much vitality (like herself) ever to lie down. </em>(Brush, Diary, Aug. 29-31, 1936 [Brush Papers].) </p>

<p><strong>On Sanger's speaking ability: </strong></p>

<p><em>What is unbelievable is the way she completely lost all trace of self-consciousness the moment she was on her feet facing an audience. She could play on people's emotions. She could rouse them, and hold them spell-bound as if she were a Heifitz and they were all Stradivarious violins. To me, perhaps the most astounding example of this was the first night of the Cheltenham, England, Conference. The audience was made up chiefly of prominent Englishmen, notable for their reticence. Perhaps there were fifty or seventy-five crowded into a rather small room. At the end of her talk these gentleman not only applauded but shouted “Bravo, bravo,” and some of them actually stood up on their seats. </em>(Dorothy Brush, fragment, n.d. [Brush Papers].) </p>

<p><strong>Sanger gives relationship advice: </strong></p>

<p><em>People stream to her all day long and for all sorts of reasons–friendship, interviews, jobs, help, advice. Nothing is ever too much trouble or ever ‘impossible'; her door is never closed to anyone. One young girl wasn't sure that she really loved her fiancé; she should, she couldn't think of one thing against him. Margaret listened quietly and then asked, ‘But do you like the way he smells? It is essential that you like his smell–you will have to live so intimately with him.' </em>(Brush, “Our MS.”) </p>
<p><strong>On Sanger's age: </strong></p>

<p><em>At her death, September 6th 1966, nine days before her next birthday, the press notices gave various ages–82, 83, 84. You can be sure they never got her true age from Margaret. Margaret never believed in age and wouldn't have the hateful subject mentioned. I never knew her age and if I had I wouldn't have dared mention it to a soul. I have reason to believe she was at least 12 or 14 years older than myself but on my own sixtieth birthday, Margaret's picture appeared in the New York Times with the caption, “Margaret Sanger. Aged sixty.” She and I had a good laugh about that but not one word from her to suggest what that age should have been. An even better example of her attitude occurred when, in 1946, we were entering Sweden together. A gruff-looking customs official examined her passport and then suddenly barked, “How old are you?” Taken by surprise, Margaret mumbled an age. He took another look at the passport. “That's not what it says here.” “Oh isn't it?” asked Margaret sweetly. “I'm sorry–but then, you know, it never is.” </em></p>

<p><em>As her years piled up, Margaret's age, when she had to give one, became younger and younger until her oldest son, Stuart, protested that people looking at him would decide Margaret must have been a child bride. </em>(Brush “My Friend, Margaret Sanger” n.d. [Brush Papers].) </p>

<p><strong>On Sanger's healing abilities: </strong></p>

<p><em>I had gone with her to my own college, Smith, where she received her first honorary degree [. . .] I have never seen her so happy as, in cap and gown, she sat on the platform among all those dignitaries, trying to look solemn (Actually with her mortar-board askew and her shining countenance, she looked like a cockeyed angel.) </em></p>

<p><em>As we were leaving for New York, something dreadful happened. I slammed the door on her fingers! She slumped with a cry. Terrified, I jumped in to drive straight to a doctor. She wouldn't hear of it. “Just keep still and I can work this out myself.” I couldn't keep still. “No, my hand isn't broken–if you only wouldn't talk–DRIVE ON!” I did drive on–my children say that Margaret is the sole person who can dominate me. Presently she smiles, “Now the pain is gone.” I stopped and gently opened her hand. Across the palm were five big blood blisters. Again I begged for a doctor. “No, soon the blisters will be gone also.” In my worry, I was sarcastic: “I know you're a miracle worker but you can't think those blisters away!” Well–she did. By the time we reached New York, they were so nearly invisible that her son Grant could scarcely believe the story. </em></p>

<p><em>Later, I asked her how this was possible–her faith might overcome the pain, but how those blisters! She said she thought it was because the degree had filled her with “a great white light of burning joy.” Whenever possessed by that, she had found she could do anything. </em>(Brush, “Our MS.”) </p>

<p><strong>A summer with Sanger in Tucson: </strong></p>

<p><em>There was one party I wouldn't miss. Every Thursday night, the Sanger family came for dinner. Each meal was “foreign” and when Chinese or Japanese, complete with chopsticks. Beforehand, we five “women” [Brush, Sanger, Sanger's daughter-in-law, and two granddaughters] would gaily raid her costume box [. . . .] Margaret had collected costumes and recipes from all over the world. And how she can cook! She told me she was so bored with the food at home as a child–“prunes, prunes, prunes”–that at fourteen, she won a prize in Atlantic City for inventing prune-whip. She always “invents” her wonderful salads and anything on the table may go into them–remains of the wine, celery, olives, nuts, even leaves from the centerpiece. Sometimes I've thought she looked speculatively at the china. </em>(Brush, “Our MS.”)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
