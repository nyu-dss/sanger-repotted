
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #34 (Fall 2003)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #34 (Fall 2003)</h1>
<div class="maintext">
<h1>"Hail to the Male!"</h1>

<p>In the fall of 1933 all of Japan anxiously awaited the "gokeiji,"
the auspicious event &ndash; the birth of a baby to the Emperor Hirohito and his
consort Nagako. Four times previously the couple had failed to deliver an heir,
three surviving daughters being their only consolation. The disappointment had
been palpable. The birth of a male heir in Japan marked approval from heaven and
good fortune for the country. As the physicians to the Imperial Court announced
that the birth would probably occur before the new year, the pressure mounted,
the people prayed, the prospective parents journeyed from shrine to shrine in
hopes of pleasing the powers above. This time, however, their luck was destined
to change; not because of divine intervention but something more irresistible,
the advice of Margaret Sanger.</p>
<p>According to a Universal Service news story published in December 1933,
Sanger was never consulted directly by the imperial household, but had explained
to members of the Japanese parliament and to Baron Kato, husband of Baroness
Shidzue Kato, Sanger’s counterpart in Japan, that a special diet was thought
to increase the chances of producing a male. As the newspaper report described
it: "A diet of carbohydrates for six weeks before and six weeks after
conception, with lots of alkalis, no acids, no cigarettes and no alcohols, is
the basis of the formula prescribed for women desiring male babies." Sanger
later said the newspaper article "gave exactly the wrong thing," as a
high carbohydrate diet should be followed if seeking a girl. It was called the
"beehive recipe" &ndash; because it was said the queen bee would lay
identical eggs, but deposit them "in cells having different food
values." "I gave them all the facts at my command," Sanger later
said, and the information made its way to the Emperor. Sanger shared the diet
with Japanese dignitaries after they told her that "birth control will be
acceptable in Japan when science can guarantee sons to Japanese mothers when
they want them." Sanger credited a Viennese doctor with this particular
theory. He had prescribed it for the Russian czarina prior to her giving birth
to a male heir; her previous children had been girls.</p>
<p>On Dec. 23, 1933 Tokyo was awakened by a piercing siren. The 5,000,000
residents within earshot shot up off their sleeping mats to await another blast
of noise. A second siren filled the air signifying that Empress Nagako had given
birth to a Prince! The birth of Prince Akihito, destined to be Emperor, began a
new era for Japan. The imperialist Japanese General Sadao Araki told friends and
foe that "the foundations of our empire are now based more firmly than
ever."</p>
<p>Was Sanger responsible for preserving the unbroken lineage of the Imperial
House, the link between God and the people of Japan?</p>
<p>Japanese leaders explained that the momentous event was brought about because
Japan grew firm, revived Samurai discipline and launched "an era of
iron," prompting Heaven to send a male heir in an act of approbation.</p>
<p>All Sanger said was that she "really could not claim any direct
influence." And she later told one of the many women who wrote to her to
confirm the advice, "I do not want you to depend absolutely upon any
suggested diet which might determine the sex of a child . . . do not set your
heart on this being a success." But she never dismissed the notion that she
may have had a part to play in one of the most important events in the modern
history of Japan. ("Birth of Japan Heir Credited to Sanger Diet," <em>Seattle
Post Intelligencer</em>, Dec. 31, 1933; "Japan Hails a Prince and a New
Era," <em>New York Times</em>, Dec. 31, 1933; Herbert P. Bix, <em>Hirohito and
the Making of Modern Japan</em> [New York, 2000], 270-71; MS to Hazel Shaw, April
13, 1934 [<em>MSM</em> S8:650].)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
