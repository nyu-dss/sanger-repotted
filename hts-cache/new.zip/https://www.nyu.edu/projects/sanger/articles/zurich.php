
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #56 (Winter 2010/2011)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #56 (Winter 2010/2011)</h1>			

<div class="maintext">
<h1>"The Quest for Contraceptive Knowledge: Marking the 80th Anniversary of the Zurich Conference"</h1>			

<p>This year marks the eightieth anniversary of the Seventh International Birth Control Conference, conceived and organized by Margaret Sanger and held in Zurich from September 1-5, 1930. Though it received little attention at the time, the conference marked a major milestone in the history of contraception. </p>
<p>The next in line of the Neo-Malthusian conferences that began in 1900, the Zurich conference was the first international birth control symposium to shift emphasis from social aspects and propaganda concerns to practical medical and scientific considerations. Sanger removed the reference to neo-Malthusianism in the conference series name, indicating her intention to focus solely on contraception and clinical research. This was not the only immediately apparent difference between this conference and its predecessors, the last having taken place in New York in 1925. For the first time in an international gathering, Sanger gave women doctors and clinicians nearly equal time at the podium. </p>
<p>The Zurich conference featured forward-looking papers and discussions on new contraceptive technologies and investigations, including an early breakthrough in using hormones to suppress ovulation in mice, the concept that evolved into the birth control pill three decades later. Sessions on various categories of contraceptive methods, on sterilization and on abortion, highlighted new research that led to immediate advancements in the field, such as the independent findings of Dr. Hermann Knaus of Austria and Kyusaku Ogino of Japan that confirmed predictable days of sterility in a woman&rsquo;s cycle and opened the floodgates to rhythm calendars. Other contraceptive technologies that had shown promise, including a new form of an intrauterine device (IUD) and X-Ray sterilization, met with fierce criticism at the conference that slowed the clinical acceptance of these methods. Recommendations of diaphragms and several reports on recent tests of chemical methods provided a much needed quality control service for the many clinic directors in attendance. In addition, papers by statisticians and demographers led to reappraisals of the links between class and family size. Sanger and her coordinating staff also provided a comprehensive exhibit of contraceptive devices and clinic forms and charts, as well as statistical information gleaned from questionnaires sent out by Sanger to clinics in Europe, Asia and the United States. </p>
<p>The Zurich conference never garnered the press attention of the first World Population Conference, also organized by Sanger and held in Geneva in 1927, or the two conferences mounted by the World League for Sexual Reform (1929 in London and 1930 in Vienna) that sandwiched the Zurich gathering. Sanger had planned it that way, organizing a quiet and serious meeting of about one hundred and thirty physicians, clinicians and researchers in Zurich, &ldquo;without fanfare and without the blow of trumpets.&rdquo; As Sanger stated in her opening address, &ldquo;This is in essence to be a fact-finding conference, and we shall not be concerned with nor attempt to express our opinions on birth control in conjunction with politics, religion or morals.&rdquo; (Hannah M. Stone, &ldquo;The 7 th International Conference,&rdquo; <em>Birth Control Review </em>14:11 [quote 1] [Nov. 1930]: 317; Sanger, &ldquo;President&rsquo;s Opening Address,&rdquo; Aug. 31, 1930 [quote 2] [LCM 130:572].) </p>
<p>Though Sanger and others hoped that the conference would lead to regular gatherings of clinicians and researchers, this was the last international birth control conference before World War II decimated the international movement. Eighteen years would pass before many of the conferees would come together again. The Zurich conference did help launch the first truly international birth control group, the Birth Control International Information Centre, based in London, with Sanger as president. The Centre served as a clearinghouse for contraceptive information from 1930 to 1938. </p>
<p>What follows are excerpts from the surrounding documentation on the conference and from the conference proceedings, including both formal papers and discussions. </p>
<p>Sanger ran into difficulties in convincing funders to support yet another conference, following several regional and international conferences in the late 1920s. Some, like the wealthy English businessman Clinton Chance, who backed many of Sanger&rsquo;s projects and oversaw the finances of the fledgling international movement, argued that there had not been sufficient advancement in contraceptive research and technique to warrant a conference focused on methods. Sanger replied: </p>
<p>&ldquo;. . . this is why we need a Birth Control Conference of entirely clinicians. There is such a difference in the training of physicians who are in the clinics&ndash;not only in this country but in England and in Germany. From my experience they are all going higgledy-piggledy. They have not standardized their technique; they do not instruct intelligently&ndash;even from the medical standpoint. You may not be aware that it is generally known that the physicians in the Clinics of England, especially in London, do not use a speculum, which horrifies our big gynecologists and obstetricians. . . . I have come to the conclusion that it is not the patient that needs so much direction as the doctor . . . .&rdquo; (MS to Clinton Chance, May 9, 1930 [LCM 124:77].) </p>
<p>One reason Sanger had organized this conference was to inspire scientists to advance contraceptives beyond the methods perfected in the mid-nineteenth century. Hannah Stone, the director of Sanger&rsquo;s Birth Control Clinical Research Bureau in New York, began the conference noting: </p>
<blockquote>
<p>&ldquo;I feel that for the present the pessary plus the jelly is the most satisfactory contraceptive available. Further research will undoubtedly bring forth contraceptives greatly superior to those now employed. Until then, however, we must depend upon the vaginal occlusive pessary as the method of choice in contraception.&rdquo; (Sanger and Stone, <em>Practice of Contraception</em>, 15.) </p>
</blockquote>
<p>Dr. Rachelle S. Yarros, the pioneering Chicago birth control advocate, reported a high success rate among the mostly poor clientele for whom she prescribed the diaphragm paired with a douche. Her findings countered the largely anecdotal evidence that the poor and uneducated struggled to successfully use the diaphragm. </p>
<blockquote>
<p>&ldquo;In my own private work, I have been giving contraceptive information for nearly thirty years. From the very beginning to within the last two or three years, I used nothing but a cervical French Pessary, dipped in glycerine and followed by a bichloride douche . . . . The results were excellent, and I cannot remember when the percentage of failure was higher than 2 percent. My practice was largely among poor and ignorant people.&rdquo; (Sanger and Stone, <em>Practice of Contraception</em>, 17.) </p>
</blockquote>
<p>From the start, Sanger planned for a conference in which women doctors and clinicians would have equal time with their male counterparts. In part, she wanted the Zurich conference to be a corrective to the 1927 World Population Conference where women had no voice and neither Sanger, who organized the event, or her staff of women assistants received any official recognition in the program. Sanger wrote in early 1929 that she wanted the next conference to be &ldquo;by men &amp; women, but to have the subjects discussed by women &amp; about women more than about general things. It will be better not to make it strictly a womans conference (as at first suggested) but to have it as Scientific as Sociology lends itself to be with women much in the lead.&rdquo; In the end, women made up slightly less than half the speakers and discussion panelists. Frankfurt clinician Elsa Bauer was one of several women in Zurich who took the opportunity to speak out about women&rsquo;s concerns. (MS to How-Martyn, Feb. 15, 1929 [<em>MSM</em> C4:900].) </p>
<blockquote>
<p>&ldquo;I am firmly convinced that when birth control is necessary it should not be the woman alone who takes the responsibility. I think that at a serious assembly such as the present Conference the question as to the extent to which the husband may take his share of the responsibility should be brought up for discussion. Referring to the use of the condom the remark is so often made that the thing itself is good but that it interferes with the man&rsquo;s enjoyment. I do not think that we can or ought to take this attitude . . . when birth control is necessary we should encourage the husband to face a little discomfort and unpleasantness.&rdquo; (Sanger and Stone, <em>Practice of Contraception</em>, 129.) </p>
</blockquote>
<p>One of the highlights of the Zurich conference was the much awaited paper read by Ernst Gr&auml;fenberg on &ldquo;An Interauterine Contraceptive Method.&rdquo; The German gynecologist, better known today for his work on female sexual response that led to the designation of the Gr&auml;fenberg or &quot;G&quot; spot, Gr&auml;fenberg had presented his invention of a spiral ring IUD at a physician&rsquo;s meeting in Berlin in 1928. After other gynecologists criticized the method as untested and harmful, Gr&auml;fenberg came to Zurich and presented an updated spiral IUD made of silver, which he believed to be safer than his previous version, made of silk-worm gut. In an attempt to get his audience to consider the IUD in a more favorable light, Gr&auml;fenberg spoke of the potential of his device to radically alter contraceptive practice for at least a segment of the population. In a rather blunt address, he focused on the fact that the IUD did not interfere with sexual pleasure. </p>
<blockquote>
<p>&ldquo;Every method that affects the man is doomed to failure, for the man must not be balked in his pleasure, whereas the woman is always the one to suffer. We must also remember, however, that many women are lazy and stupid, and take no interest in protecting themselves. All these points must be taken into consideration. Then there are also the women who are indifferent, who are not in a position to make the necessary preparations, and do not want to go to a physician. There are women who become psycho-neurotic if they have no method available that makes them independent of the doctor. By freeing the woman from the need of making troublesome preparations, we favorably influence her sexual reactions.&rdquo; (Sanger and Stone, <em>Practice of Contraception</em>, 46.) </p>
</blockquote>
<p>Despite Gr&auml;fenberg&rsquo;s appeals to his fellow gynecologists to carefully consider the IUD for certain patients, several of the participants in his session continued to reject the device, citing repeated instances of irritation and inflamation, reporting low effectiveness rates, and suggesting that the method amounted to a form of abortion. Among the most outspoken opponents of the IUD was the Danish physician J. H. Leunbach, who conducted his own clinical trial on the Gr&auml;fenberg ring, finding bleeding, pain and irregular menstruation, many instances where the ring came out, and a very low satisfaction rate. His frank conclusion: </p>
<blockquote>
<p>&ldquo;I think that the following should be demanded of a preventive: (1) Very great reliability (2) Absolute harmlessness. The intrauterine silver ring has failed decidedly in both respects.&rdquo; (Sanger and Stone, <em>Practice of Contraception</em>, 58.) </p>
</blockquote>
<p>Attendees expressed even more caution, as well as curiosity, over biological methods of birth control, including sperm immunization or spermatoxins. As discussed in a recent <em>MSPP Newsletter </em>article (# 52, Fall 2009), researchers in several countries had discovered that subcutaneous injections of animal spermatozoa into the female brought about a temporarily state of infertility. Leading up to the conference, Russian scientists had claimed success with spermatoxins in both animal and human studies, but other researchers had trouble replicating these experiments. The buzz created over spermatoxins, which had received little attention until Zurich, overshadowed the equally unorthodox research on the hormonal suppression of ovulation, presented by the Animal Breeding Research Department at the University of Edinburgh. As reported by Dr. H. Taylor, the research team discovered that they could prevent pregnancy in mice by injecting ovarian hormones into the female. They did not yet understand how these hormones acted on the reproductive system but observed changes in the pituitary gland. In fact, scientists had still not solved the mysteries of human reproduction, and there was much guesswork involved in these experiments. Clearly the Edinburgh researchers were on the cusp of an important discovery. Yet they proceeded carefully and with the understanding that they might be treading on dangerous ground. </p>
<blockquote>
<p>&ldquo;The mechanisms which secure fertilization and reproduction in general are extremely delicate. It is certainly not very difficult to disturb them, but it is just as certainly very dangerous to do so. The injection of ovarian hormone interferes with the function of the pituitary. We do not know yet what the injection of the pituitary does to the other glands, and in particular the gland from which they originate. But whatever the possibilities of experimentation in this line are, we are very far from any practical application; and it is doubtful whether we shall ever wish to obtain a point where these dangerous weapons will be at the disposal of man.&rdquo; (Sanger and Stone, <em>Practice of Contraception</em>, 104.) </p>
</blockquote>
<p>You can almost feel the cringe of discomfort in Dr. Hertha Riese&rsquo;s comments following the paper on the hormonal control of fertility. Riese, the director of a Frankfurt birth control clinic, referred to the process as &ldquo;hormonizing&rdquo; and expressed concern that it might alter one&rsquo;s personality. </p>
<blockquote>
<p>&ldquo;I have always been opposed to hormonising on principle. I do not know whether we can introduce hormones into another body without affecting the personality. I would hesitate to have myself hormonised. I want to be myself, to remain what I am.&rdquo; (Sanger and Stone, <em>Practice of Contraception</em>, 113.) </p>
</blockquote>
<p>The conference devoted a session to abortion despite the protests of some delegates. Sanger&rsquo;s intention had been to discuss ways to avoid abortion through the use of better birth control, but instead the session focused on new abortion techniques, such as X-Ray induced abortion and the injection of an antiseptic paste into the uterus. Dr. Theodore H. Van de Velde, the Dutch physician well known for his popular marriage guides, expressed his disappointment with the session. </p>
<blockquote>
<p>&ldquo;I regret that the question of the technique of induced abortion should have been brought up for discussion at this conference, for I consider it out of place. . . . However important the question may be in itself, because we are not too seldom obliged to consider it in connection with patients needing our help in cases where the indication is an absolute one, we should not, when setting out to discuss the problem of prevention of abortion, mix it up with the question of technique. The reproach will at once be hurled at us that we, who say we are working for the control of conception, are in reality for abortions.&rdquo; (<em>Practice of Contraception</em>, 196.) </p>
</blockquote>
<p>On the second night of the conference, Sanger invited delegates to watch a German anti-abortion film, &ldquo;Frauennot-Frauengl&uuml;ck,&rdquo; that she had previously viewed. Its message, in Sanger&rsquo;s words, was that &ldquo;legal abortion is better than illegal abortion but the cure for abortion is birth control.&rdquo; The film contained graphic scenes, including footage of a Caesarian section. Sanger wrote to Penelope Huse, one of her administrative workers, describing the film and the reaction of Bob Huse, Penelope&rsquo;s adult son, who attended the conference as an observer. </p>
<blockquote>
<p>&ldquo;I thought Bob was going to faint one evening. He sat directly in front of me in the theatre where members of the conference had the priviledge of seeing a famous film against abortion. . . . When the Caesarian Section was being performed I saw a nice head in front of me go &ldquo;wabble wabble.&rdquo; Before I could offer aid, the woman on my left keeled over into my lap &amp; I had to put all my attention on her. Smelling salts revived Bob tho he describes himself as being but &ldquo;one lap behind&rdquo; Mrs. How-Martyn who had fainted clean away. He did not faint, &amp; to hear him describe holding on to consciousness was a scream. It was an extraordinary film &amp; only the Germans could produce it.&rdquo; (MS to Penelope B. P. Huse, Sept. 16, 1930 [<em>MSM</em> S5:889].) </p>
</blockquote>
<p>Sanger heralded the conference as one of her most significant achievements despite its low profile. Writing in the introduction to the proceedings, she expressed pride in the civility and scientific spirit that united conference delegates from many different countries and political persuasions. </p>
<blockquote>
<p>&ldquo;Here indeed, the impartial observer might have discovered the true spirit of internationalism, the fundamental brotherhood of man, rather than the bickerings and disagreements of the League of Nations at Geneva, or the truce in the warfare of governmental finances. For these reasons, the records of the Zurich Conference demand permanent place in the annals of human progress.&rdquo; (<em>Practice of Contraception</em>, xviii.) </p>
</blockquote>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
