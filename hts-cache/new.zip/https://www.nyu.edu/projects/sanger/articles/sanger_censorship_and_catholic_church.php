
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #6 (Winter 1993/1994)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #6 (Winter 1993/1994)</h1>
<div class="maintext">
<h1>"Sanger, Censorship, and the Catholic Church &ndash; The Latest Battle in a Long War"</h1>

<p>     More than twenty-five years after her death in 1966,
Margaret Sanger's battle with the Catholic Church continues. 
The most recent incident occurred this October when a Roman
Catholic bishop attempted to have a poster of Sanger
removed from the University of St. Thomas library in St.
Paul.  Part of an American Library Association series
entitled Great Minds Meet at the Library, the poster
depicts Sanger in a photo taken just after her 1917 conviction
for opening the nation's first birth control clinic in
Brownsville, Brooklyn.  Beneath the photo is a quote from
Sanger's 1931 autobiography, <em>My Fight For Birth Control</em>:</p>

<blockquote>
<p>       "Life has taught me one supreme lesson. 
This is that we must &ndash; if we are to really
live at all, if we are to enjoy the life more
abundant promised by the Sages of Wisdom
&ndash; we must put our convictions into action. 
My renumeration has been that I have been
privileged to act out my faith."
</p>
</blockquote>

<p>   A graduate of St. Thomas, evidently offended by the fact
that the poster celebrated the nation's most prominent birth
control advocate, contacted Bishop Robert Carlson who
asked the university's president, Rev. Dennis Dease, to have
the poster taken down.  Bishop Carlson justified his request
not just on Sanger's advocacy of contraception, a practice
which the Pope recently included in a list of practices he
defined as "intrinsically evil" but on the grounds that Sanger
was a "strong racist." (<em>St. Paul Pioneer Press</em>, October 7,
1993)  This was not the first time that the Church officially
tried to censor Sanger, nor was it the first time her opponents
sought to sustain an anti-birth control position by assailing
Sanger's character.  She was regularly vilified on political as
well as moral grounds.  In 1935, Patrick Cardinal Hayes of
New York, for example, not only referred to birth control as
"diabolic," but vilified its advocates as "prophets of
decadence" (<em>New York Times</em>, 12/9/1935).  Others linked
Sanger's early radicalism to a communist conspiracy, referring
to her as an "enemy and traitor," (Shipler, "Catholics and
Birth Control," <em>The Churchman</em>, August 15, 1941).</p>

<p>   Sanger's struggle to promote birth control was often met
with both overt and covert opposition by the Catholic Church. 
For example, days before Sanger was scheduled to speak at St.
Louis' Victoria Theatre in 1916, the theater manager was
pressured by prominent Catholics to cancel the event. 
According to local Catholic lawyer and morals crusader,
Edward Schneiderhahan, "I simply told the management that if
they opened the doors to her they need not expect us to enter
those doors again." (<em>St Louis Republic</em>, May 20, 1916)  The
manager gave in to the threat and notified Sanger that the
event was cancelled.  As always, Sanger made the most of
such efforts to censor her.  Though she had already
rescheduled her lecture for the Hippodrome Theatre, Sanger
went to
the
Victoria
Theatre
at the
originally
scheduled time,
and
playing
to the
gathered
crowd
of 1,400
people
loudly
protested the
locked
doors.  </p>

<p>   When
faced by
Catholic
efforts
to stop
public
discussion of
birth control, Sanger often effectively invoked the First
Amendment, and in the process exposed the Church's
willingness to ignore constitutional church/state separation.  In
the 1920s,  Sanger's refusal to yield led some more militant
Catholic groups to step up efforts to silence her.  At the
founding conference for the American Birth Control League in
1921, Monsignor Patrick J. Ryan pressured the New York
City Police to stop a lecture on the morality of birth control
being given at Town Hall on November 13.   When Sanger
and others resisted, they were arrested.  Though the charges
were dropped the next morning, the resulting press coverage
again worked in her favor &ndash; the meeting was held November
18 at the Park Theater in front of an overflowing crowd.  As
Sanger later remarked in <em>My Fight for Birth Control</em>, "instead
of cutting off discussion of birth control, the episode made the
whole country talk about it" (p. 220).</p>

<p>    The Catholic Church's battle with Sanger continued in the
1930s when she instigated a campaign to lobby Congress to
legalize birth control.  Increasingly well-organized and
national in scope, the Church had begun to alter its strategy,
focusing now on using its considerable political clout to block
birth control legislation.  Sanger's bills were killed time and
time again in congressional committee, at least in part the
result of the increasingly powerful Catholic lobby, which no
politician was willing to alienate. </p>

<p>    Sanger succeeded
in keeping birth
control in the center
of public debate
despite her
legislative failures
and the persistent 
efforts of her
opponents to
demonize her
through red-baiting
and charges that she
was a racist.  The
publicity value of
such confrontations
was enormous as
Sanger herself noted
in 1929, when she
joined Theodore Dreiser, Clarence Darrow, and others
at Boston's Ford
Hall for a forum on
Free Speech.  It was
no accident that Sanger chose Boston, a city with a strong and
vocal Catholic population, to mock bans on public discussion
of birth control.  Appearing on the stage wearing a gag,
Sanger had her remarks written on a board:</p>

<p>     


"To inflict silence upon a woman is indeed a
drastic punishment.  But there are certain
advantages to be derived from it
nevertheless....You all know that I have been
gagged.  I have been suppressed.  I have
been arrested numerous times.  I have been
hauled off to jail.  Yet every time, more
people have listened to me, more have
protested, more have lifted up their own
voices.  As a pioneer fighting for a cause, I
believe in free speech.  As a propagandist I
see immense advantages in being gagged. It
silences me, but it makes millions of others
talk and think the cause in which I live."
("The Importance of Being Suppressed, April
16, 1929, Margaret Sanger Papers, Library
of Congress)</p>


<p>    The most recent attempt by the Church to quiet Sanger's
voice was no more successful than earlier ones.  The President
of St. Thomas University supported Library Director Jean
Haley's decision to leave the poster of Sanger in its place. 
Haley commented, "The poster is part of the Library's
collection and is protected by the Library Bill of Rights...It
deserves the same protection as the rest of the collection." (<em>St.
Paul Pioneer Press</em>, October 7, 1993)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
