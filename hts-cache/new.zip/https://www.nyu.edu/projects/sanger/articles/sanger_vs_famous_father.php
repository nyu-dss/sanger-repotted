
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #29 (Winter 2001/2002)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #29 (Winter 2001/2002)</h1>
<div class="maintext">
<h1>"Sanger v. Famous Father of 18!"</h1>

<p>For someone who claimed she hated to speak in public, Margaret Sanger
rose to the occasion dozens of times each year, addressing large audiences
in auditoriums, with protestors outside and police in waiting; small gatherings
in living rooms for tea; and everything in between.  She spoke to
university students, women's societies, civic and religious organizations,
medical professionals, young parents &ndash; just about any group but school
children.  When asked to participate in a debate, however, she usually
declined.  Though feisty and quick on her feet, Sanger generally avoided
organized public encounters when she was not assured of control.  
When she did accept a debate, it was usually against someone predictable
and therefore vulnerable, always against men, and she dictated the rules.
</p>

<p> A good example is Sanger's 1920 debate with John Winter Russell. 
A New York lawyer and recent convert to Catholicism, Winter Russell was
still new to the issue of birth control and the teachings of the Catholic
Church.  In his remarks he fumbled along, equating birth control with
abortion and recounting from personal experience the short, unhappy lives
of couples who chose to have small families. Periodically he exclaimed
that one cannot have pleasure without pain.  Sanger began her rebuttal. 
"Now, Mr. Russell has said some things that are very interesting to me. 
He tells us that we cannot have pleasure without pain.  It is a man
who is speaking. It is very peculiar that Nature only works on the one
side of the human family when it comes to that law.  She applies all
the pain to the woman.  It is absurd &ndash; a perfectly absurd argument
in the face of rational intelligence to talk about marriage being for one
purpose."  After several more retorts and a clear, passionate defense
of small families, Sanger had disarmed her opponent and left him sounding
unsure of his own arguments. He closed the debate awkwardly with the notion
that birth control kept the unborn from heaven.  (Dec. 12, 1920, [<em>MSM</em>
S76:923-943.)
</p>

<p> Sanger did debate some worthy opponents over the years who presented
reasoned arguments against birth control, but she clearly preferred predictable
opponents: the rock-solid religious conservative who would fall back on
Scripture, exhibit male chauvinism and serve up a stew of medical misinformation.
</p>

<p> So it was somewhat surprising that Sanger agreed to a May 14,
1931 debate with Chief Justice Richard B. Russell of Georgia's state supreme
court.  Justice Russell was the father of then Governor-elect Richard
Russell, Jr. and 17 other children.  Russell (no relation to the 1920
debater, Winter Russell) was an extremely popular public figure in Georgia,
noted for the legal and literary scholarship of his judicial opinions.
Sanger was also informed (by one of her organizers sent down to Atlanta
to dig up some background material on Russell) that the judge was quite
famous for ridiculing his opponent and planned to secretly run up to Washington
to hear Sanger speak prior to their meeting.  Sanger may have been
encouraged to hear him described as "an old fashioned type of man," and
surely reinforced her preconceived notions of him on the news that he "chews
tobacco and keeps a cuspidor on the stage.  (Constance Heck to Sanger,
May 6, 1931 [LCM 89:666].) But Russell presented a greater challenge than
Sanger usually sought, especially as he had the home field advantage; the
debate would take place in Atlanta among many Russell friends and family
members, making it difficult for Sanger to remind the audience that five
of Russell's children, over two marriages, died in infancy. Partly for
these reasons and her need to always control the terms of the debate, Sanger
insisted that she both open and close the contest.
</p>

<p>  Financial considerations may have been the deciding factor for
Sanger in going forward  with the debate, even though she received
only $250, much less than her usual debate fee of between $500 and $1000. 
The Depression had suddenly hit Sanger quite hard.  She struggled
to meet salaries for staffs at both her Washington lobby group, the National
Committee on Federal Legislation for Birth Control, and the Birth Control
Clinical Research Bureau in New York.  And she could no longer rely
on her husband to make up budget shortfalls;  J. Noah Slee had accumulated
significant loses on Wall Street and was in danger of losing his seat on
the New York Stock Exchange.  The Sangers still lived relatively well,
but cash was scarce.
</p>

<p> Russell, with his three youngest children in college, apparently
needed the money too, as he agreed to the debate over the objections of
at least one of his offspring, the Governor-elect, who reportedly said
he would have given his father the money rather than have him "exploit"
the family. (Heck to Sanger, May 6, 1931 [LCM 89:666].)  According

to Russell's wife Ina, the Judge was in it for more than money; he wanted
to use the debate to educate and persuade others to oppose Sanger-backed
legislation to open the mails for contraceptives and contraceptive information
to be sent by doctors.  Ina Russell wrote to her daughter Pat on May
6, ". . . Yes, dad does get some money &ndash; $250.  That's the why of
it &ndash; but you know he would not mind debating that subject . . . I do hope
dad will impress the young people of our Beautiful America how terrible
it would be if the bill was passed in Congress to send the vile, dangerous
doings broadcast over our land."  Yet, according to Russell's granddaughter,
Sally Russell, who edited her grandmother's letters, it was Ina Russell,
one of thirteen children herself, who was the one who opposed birth control
in their marriage, refusing to consider using a contraceptive the Judge
brought home one day not long after the birth of one of their sons. 
She wanted him to bury it in the backyard. (Sally Russell, ed. <em>Roots
and Ever Green: The Selected Letters of Ina Dillard Russell</em> [Athens,
GA, 1999], 289, 40.)
</p>

<p> All of the pre-debate publicity emphasized the size of Russell's
family.  The photo reproduced here of Russell with his 13 surviving
children appeared in many newspapers at the time with captions such as:
"Can you guess which side Richard B. Russell . . . is going to take." (<em>Griffin
Daily News</em>, May 8, 1931.)  Called a "leading opponent" of birth
control, though he had no public record on the issue, the press portrayed
Russell as a favorite son, "one of Georgia's clearest and deepest thinkers."
(<em>Weekly Jackson Herald</em>, May 7, 1931.) Newspapers referred to Sanger
simply as the leader of the birth control movement in the U.S., reminding
readers of her frequent arrests and various books on the subject.
</p>

<p> By all accounts the debate thoroughly entertained the audience
at the Erlanger Theatre in Atlanta. Unfortunately no transcripts of the
debate survive.  The most extensive coverage ran in the Atlanta Constitution,
where B. R. Crisler, no doubt longing to leave journalism for dramaturgy,
gave the ringside call:</p>

<blockquote>
<p>Mrs. Sanger was first in the field, trotting out her light
cavalry of statistics, her portable and compact artillery of logic and
of modern ideas.  And like a good strategist, she had not failed to
provide her forces with an inexhaustible commissary of information. 
The old Roman [Russell], whose eloquence played no small part in winning
him the place of honor on Georgia's supreme court bench, must have realized
that here was a different and somewhat disconcerting antagonist to deal
with.</p>

<p>But the Lady's opening speech was merely a ruse; merely a skilled
maneuver to draw the enemy out; for she is the sort of fighter who must
have something definite to strike at; and there was a very clever little
ambush prepared!</p>

<p>The enemy marched into it, too, with trumpets blowing and flags
whipping spectacularly in the breeze.  It was the Roman phalanx going
grandly and unsuspectedly into a nest of machine guns.  Taking his
text from the Scriptures, Chief Justice Russell reminded his opponent of
the Biblical injunction to Noah, "increase and multiply.</p>

<p>"Rat, tat, tat", the machine guns in rebuttal, spat like so many snakes. 
"And it might be opportune to remind my opponent," Mrs. Sanger parried,
"that when God laid this command upon Noah, there were only five people
on earth.  My opponent must admit that the situation has altered a
little since then."</p>

<p>But people, the phalanx contended, are motivated by pure selfishness
when they refuse to have children.  In glowing words he painted a
picture of a happy family group &ndash; the more numerous the better &ndash; with
the mother and father actuated by feelings of self-sacrifice, willing to
bear the pains and economic tribulations of life as well as its merely
sensual pleasures.</p>

<p>Once more the machine guns spat.  "I love," Mrs. Sanger
remarked, laconically, "to hear men talk about the pain and sacrifice entailed
by childbirth!  They have so much first-hand knowledge."</p>

</blockquote>

<p>Crisler called the debate "pretty decisively in favor of the lady." 
Apart from handily refuting her opponent, it appears Sanger was able to
inject highlights from her recent speeches and Congressional testimony
on a birth control bill,  including persuasive arguments on the economic
and health benefits of birth control.  It does not appear she made
any reference to the size of Russell's family, nor felt she needed to take
the debate to a personal level. "It is for us to choose," the Constitution
quoted her in conclusion, "a decreased birth rate or an increased death
rate."  Russell,  Crisler noted, went down "like the noble old
Roman he is&ndash;with the standards of the legion intact." ("Margaret Sanger
Given Verdict at Debate Over Birth Control," <em>Atlanta Constitution</em>,
May 15, 1931.)
</p>

<p> In recapping the debate, Ina Russell told daughter Pat on May
23 that the "small" crowd (no other estimates of crowd size were given)
favored Sanger: "Of course, every body, almost, was for Mrs. Sanger ‘cause
every body who is up-to-date, practices and believes in birth control."
She commended her husband for making "some good points," but complained
that "Some women sitting behind me called him ‘old fool' and they said,
‘he just doesn't know what he is talking about.'" ( Russell, <em>Roots and
Ever Green</em>, 290.)
</p>

<p>  Sanger had once again chosen the perfect set-up man as debate
opponent, catering to her assertive style and ability to posture birth
control as a leading economic and scientific issue. She told a supporter
a couple of weeks later that "I think dear old Judge Russell was thinking
in times of Noah's Ark.  He had no facts and had just read all the
old Catholic arguments and kept clinging to these as if he were an advocate
of the pope." (MS to Landon Thomas, May 29, 1931 [LCM 89:736].)
</p>

<p> The lively debate was one of the few victories for Sanger in the
early 1930s as her efforts on Capital Hill bore little fruit.  Her
confident manner and polished debate tactics during congressional testimony
on a series of birth control bills played well to adherents to the cause,
but may have increased congressional resistance.  Many of the congressmen
she confronted &ndash; traditionalists espousing predictable arguments against
birth control &ndash; must have met  her criteria for easy debate prey,
but in the complex power-structure of Congress, at the mercy of political
maneuvering, Sanger could not always recognize the opposition or control
the terms of the debate.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
