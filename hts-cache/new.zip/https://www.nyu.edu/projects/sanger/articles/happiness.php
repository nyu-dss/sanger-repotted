
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #46 (Fall 2007)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #46 (Fall 2007)</h1>
<div class="maintext">
<h1>"Happiness (?) In Marriage"</h1>

<p>Seeking marital advice from Margaret Sanger was a bit like asking Bertrand Russell the way to Christian salvation. She may have understood sexuality and family planning better than any other advice maven of the first half of the twentieth century, but she rejected much of what the institution of marriage represented and failed to conform, in her own life, to the moral limits imposed by the marriage bond. Yet only a few years after she established the birth control movement, and without a clear intention beyond advocating her cause, Sanger became a trusted and sought after source on how to improve and sustain a marriage.</p>

<p>While Sanger declared in her earliest writings that marriage, as defined and bound by canons and laws, had proven a failure, only a few years later she was giving regular talks for young people on marriage preparation. In the 1920s she wrote an entire marriage guide, one of the first of its kind. By the 1940s her clinic offered marriage counseling, first informally and then through a separate marriage counseling service. During World War II she advised war brides over the radio and in magazine articles on how to keep their marriages intact. All the while she responded to countless women who wrote to her not only for birth control information but for specific advice on love, sex and marriage. </p>
<p>Sanger drew on the work of the sex psychologist Havelock Ellis, the feminist writer Ellen Key and the ideas and practices of a number of Greenwich Village radicals to advise couples on how to make marriage into something the church never intended and the state, by legislating morality, tried to prevent: an intimate and thrilling sexual adventure culminating in the union of body and spirit. Surprisingly, she did not advocate changes in gender roles or challenge basic assumptions about the traditional marital arrangement, only the treatment of women within that arrangement. All the while in her own marriage Sanger asserted individual choice and sexual liberation, disregarded fidelity and refused to adhere to the male-provider, female-homemaker marriage standard. </p>
<p>Sanger married twice: first for love, the second time for money. Both unions were at odds with her free-thinking individualism and rejection of church- and state-imposed morality. Neither union came close to satisfying her needs, nor did she succeed in reaching a state of marital happiness for more than brief periods. </p>
<p>In 1902, while in nursing school, the lovestruck twenty-two-year-old Margaret Higgins was pressured into an elopement by the impetuous and handsome young artist and draftsman, William Sanger. Early on, their marriage conformed to convention: she stayed at home each day in suburban Westchester to raise the children, and he commuted into the city to work in the drafting trade. But less than ten years into their marriage, the radical winds that drew the young couple from the suburbs into Greenwich Village bohemia stirred a restlessness in Margaret Sanger. Lively discourse on feminism, working women, female sexual expression and free love challenged the precepts of marriage and encouraged freedom from marital and family obligations. </p>
<p>Before long, Margaret Sanger could no longer square her feminist awakening and anarchistic inclinations with the constraints of a traditional marriage. She sought both sexual and intellectual freedom in the radical haunts of New York, and for the first time began to express her views on marriage in writing. In her 1912 series of hygiene and health articles for girls, <em>What Every Girl Should Know</em>, published in the New York Call, Sanger envisions a time when women would actively choose a mate &ndash; not marriage necessarily &ndash; based on the man&rsquo;s potential to produce a robust progeny. </p>
<p>&ldquo;All over the civilized world today girls are being given and taken in marriage with but one purpose in view; to be well-supported by the man who takes her. She does not concern herself with the man&rsquo;s physical condition: his hereditary taints, the cleanliness of his mind or past life, nor with the future race. . . When women gain their economic freedom they will cease being playthings and utilities for men, but will assert themselves and choose the father of their offspring.&rdquo; (&ldquo;<em>What Every Girl Should Know</em> &ndash; Sexual Impulses, Part II,&rdquo; <em>Vol. 1</em>, 43.)</p>
<p>Many marriages among the World War I-era American radicals were transformed into working partnerships or open marriages, or simply came apart as the moral boundaries faded away. Love affairs were rampant, and in the case of the Sangers, such an affair accelerated the demise of their marriage. Margaret Sanger&rsquo;s fling with the Greek anarchist John Rompapas may have been the motivating factor in the Sangers&rsquo; decision to move to Paris in 1913 &ndash; a last ditch effort to save a compromised marriage. It didn&rsquo;t work, and Margaret Sanger returned with the children to New York, Rompapas and her circle of anarchist friends, leaving Bill Sanger in Paris to paint. They were never to live together again.</p>
<p>That winter of 1914 she began editing and publishing the Woman Rebel, in which marriage featured prominently among the many targets of her anti-establishment outbursts. Sanger declared in the first issue a woman&rsquo;s &ldquo; right to be an unmarried mother,&rdquo; an identity she had herself assumed, though she would not be legally divorced for another eight years. (&ldquo;On Picket Duty,&rdquo; <em>Woman Rebel</em>, March 1914, 3.) In an article in the next issue titled &ldquo;Marriage,&rdquo; she deemed it a failed institution that enslaved women. </p>
<p>&ldquo;Marriage, which should be the personal agreement between a man and a woman, should be no concern of the State or of the Church. Never have either of these institutions interested themselves in the happiness or health of the individual. . . Marriage laws abrogate the freedom of woman by enforcing upon her a continuous sexual slavery and a compulsory motherhood. . . . A man and woman who under a natural condition avow their love for each other should be immediately qualified by this to give expression to their love or to perpetuate the race without the necessity of a public declaration. . . .The marriage institution viewed from the light of human experience and the demands of the individual has proven a failure.&rdquo; (&ldquo;Marriage,&rdquo; <em>Woman Rebel</em>, April 1914, 8.)</p>
<p>A few years later in her first major book, Woman and the New Race, in a slightly more restrained but no less angry fashion, Sanger continued to rail against organized religion and the state for using marriage to keep women submissive and ignorant about their own sexuality - a &ldquo;pure&rdquo; and controllable &ldquo;asset to the church, the state, and the man.&rdquo;</p>
<p>Despite these blistering attacks on marriage, Sanger was something of a romantic at heart and spoke in nearly spiritual terms of unions built of a natural, unadulterated love. As she carved out her intellectual rationale for birth control, drawing mainly on the work of the new European sexologists, she emphasized the creative force of the sexual bond which should be celebrated. To Sanger, it was a profound physical and spiritual love that ultimately secured and advanced a relationship; the marriage institution itself had little to do with it. She told an audience in 1921:</p>
<p>&ldquo;I contend that it is just as sacred and just as beautiful for two people to express their love when they have no intention whatsoever of becoming parents. And I contend that they can go into that relationship with the same beauty and the same holiness with which they go into music or to prayer.&rdquo; (&ldquo;Closing Remarks, First American Birth Control Conference,&rdquo; Nov. 18, 1921, <em>Vol. 1</em>, 328-9.)</p>
<p>Sanger spoke these words at the conclusion of the First American Birth Control Conference, as J. Noah Slee, self-made millionaire and president of the Three-in-One Oil Company, stood in the wings ready to escort her home. He had been hot in pursuit of Sanger since that spring and had made his intentions clear. Sanger&rsquo;s close friend Juliet Rublee wondered if marriage was around the corner. Sanger retorted that Slee &ldquo;has not the money enough to pay the price &ndash; He could not inspire me to love . . . it would be for love or money enough to put the b. c. movement on the map. He has not the means to do either.&rdquo; She obviously was not yet aware of his net worth. &ldquo;But besides that and all joking aside dearest,&rdquo; she told Rublee, &ldquo;I am not inclined to marriage. Freedom is too lovely &amp; I want to enjoy it for a time.&rdquo; (MS to Rublee, June 22, 1921, <em>Vol. 1</em>, 299-300.)</p>
<p>Sanger continued to brush off the marriage question, with Slee accompanying her everywhere, telling her occasional lover, the English novelist and cricket chronicler, Hugh de Selincourt &ldquo;I don&rsquo;t believe in that institution particularly &ndash; do we?&rdquo; She joked to him that &ldquo;I shall marry for wealth some day soon &amp; come &amp; live near you &ndash; yes?&rdquo; (MS to de Selincourt, Jan. 27, 1922 and July 15, 1922, <em>Vol. 1</em>, 339, 345.)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
