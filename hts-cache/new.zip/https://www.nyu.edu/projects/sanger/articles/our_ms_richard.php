
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #14 (Winter 1996/1997)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #14 (Winter 1996/1997)</h1>
<div class="maintext">
<h1>"Our Margaret Sanger &ndash; Olive Byrne Richard"</h1>

<p> <em>In 1959, Ellen Watumull prepared a two-volume tribute to her friend, Margaret Sanger and
presented it to her at the Sixth International Conference on Planned Parenthood in New Delhi. 
Excerpted below is the entry contributed by Sanger's niece, Olive Byrne Richard. The entire two-volume tribute has been filmed as part of the
MSM S77:720-1130.</em></p>

<p align=center><STRONG>MY AUNT MARGARET</STRONG></p>
 <p>    So long as I can remember, my Aunt Margaret always did Christmas things for me and
my family. . . . More than any of the material things she gave me, was a feeling of "belonging"
to someone.  It happened in a single incident and came about this way: I was twelve years old
and a student in a convent school, sent there because there was nobody left in my father's family
to make a home for my brother and me.  I knew my mother's large family mostly through gifts
at Christmas and birthdays but seldom saw any of them.  So I was completely surprised one day
when the headmistress of the school sent for me and said: "There is a woman here who says she
is your aunt and she wants to see you."  She added, "You don't have to see her, you know." 
Having no reason to suspect the latter remark, I said, "Oh, I don't mind."</p>
<p>     Forthwith I was ushered into a room where two priests, a bishop, a battery of nuns and
my Aunt Margaret awaited me.  I was a dumpy kind of child with a freckled face and wearing
a most unbecoming school uniform, but that beautiful woman came to me, swept me up into her
arms and said, "Oh, you lovely darling."</p>
<p>     As no one had ever made such an extravagant gesture of love to me before, I was
overcome with shyness and could not speak.  But a wonderful glow filled me so I thought I
would cry, and I was afraid they might send her away if I did.  </p>
<p>     I don't remember the details of the short visit, not at the time did I wonder about the
presence of the high church dignitaries.  I only knew that now I really belonged to a family and
was pretty and a darling.</p>
<p>     That visit to her sister's daughter cost Margaret Sanger three days of determined effort
against all the local strength of the Catholic Church.  She made her initial request to see me to
the headmistress of the school and it was passed on to higher authorities until the matter arrived
in the bishop's office.  His "Certainly not!" was just a red flag to a woman who had engaged
in larger battles than this.  She secured legal advice and threatened to charge the school with
abduction if they continued in their refusal to let her see me; thus the roomful of clerical
guardians when I met and fell in love with Aunt Margaret.</p>
<p>     Now it seems ridiculous that they could have thought she might instruct me, a child of
twelve, in the rites of birth control.  But those were the days when birth control was a dirty
word and she who propounded it, a scarlet woman.
(Volume II, pp. 236-237).</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
