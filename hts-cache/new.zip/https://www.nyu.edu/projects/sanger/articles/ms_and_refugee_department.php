
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #5 (Spring 1993)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #5 (Spring 1993)</h1>
<div class="maintext">
<h1>"Margaret Sanger and the Refugee Department"</h1>

 <p> "You surely do not remember me, but I remember You not
only by your work but by your visit to our home in Berlin,"
wrote Anna Ludwig to Margaret Sanger (August 1, 1940).  Written
by the wife of Dr. Carl Hamburg, a Jewish physician, the
letter was just one of many Sanger received in the late 1930s
and early 1940s from those seeking to escape war-torn Europe. 
In addition to the millions who were persecuted by the racial
and political purification programs of the Nazis, many
physicians, nurses, social workers and others were victimized
as the Germans began closing birth control clinics.  Many fled
their homelands and desperately sought entry into the United
States.</p>

<p>   Sanger was horrified by the news from Europe.  In 1933,
she wrote to Edith How-Martyn, "All the news from Germany
is sad & horrible & to be more dangerous than any other war
going on anywhere because it has so many good people who
applaud its atrocities & claim it's right.  The sudden
antagonism in Germany against the Jews & the vitriolic hatred
of them is spreading underground here & is far more
dangerous than the aggressive policy of the Japanese in
Manchuria." (May 21, 1933, Palmer Collection, MSPP)  But like
many Americans in the 1930s, Sanger was opposed to
U.S. involvement in the European conflict.  In a letter to close
friend Juliet Rublee, Sanger insisted that she would sacrifice
personal possessions to assist England, "first rather than to ask
mothers to give up the lives of their sons, their only
possessions, for any country except America" (Rublee Papers,
Dartmouth College, June 9, 1941).  As a mother of two draft-age sons, Sanger resisted any level of U.S. involvement that
would jeopardize American lives, yet she could not long avoid
confronting the brutality and danger 
faced by the victims of the Nazis selective pro-natalist policies. </p>


<p>   Many of
those who
wrote to
Sanger
knew her
through her
efforts to
promote
birth
control
throughout
Europe;
several had
met her at
international
conferences
in the
1920s. 
They
believed
that
Sanger's international stature could facilitate their attempts to
negotiate the strict and complex American immigration laws. 
"I wish to come the U.S.A. for ever or only for a shorter
time, wrote Dr. Hedwig Prager (June 15, 1940), "but that is now
very difficult because the Quota is full."   </p>

<p>   The quotas on immigration set by the 1924  National Origins
Act remained in effect during the inter-war years despite
increasing pressure from some groups to relax the restrictions
to admit more refugees.  U.S immigration policy required
refugees to secure affidavits from American citizens that
demonstrated the financial means necessary to sponsor an
immigrant and insure that he or she would not become a public
burden.  Although Sanger was relatively well-off, her second
husband J. Noah Slee was fighting charges of tax evasion and
refused to provide any bank account balances or statements of
the couple's personal worth.  Nevertheless, Sanger decided to
help.  "I've always felt that those giving unselflessly to BC"
she wrote, "would never be left in the lurch" (MS to Florence
Rose, n.d.) and used her ownership of the couple's home in
Fishkill as evidence of her financial commitment.  She also
relied upon such wealthy associates as Clarence Gamble to
provide funding for several refugees, sometimes in the form of
a loan to pay for their passage, other times by providing them
with a medical research grant which would take care of the
financial requirements for immigration.</p>

<p>   Sanger's efforts,
unofficially known as
the "Refugee
Department" in
internal memos, was
headed by her
longtime secretary,
Florence Rose. 
Sanger and Rose soon
learned how to
maneuver through the
bureaucratic maze of
procedures established
by immigration
authorities.  Often the
process took over two
years to complete,
during which time
Sanger had to dance
carefully between
appearing to promise
financial security for
the refugees to the
U.S. Government, and
making clear to the refugees themselves that she could not
actually support them.  "I am writing to advise you that I have
invited Dr. H. Rubinraut of Warsaw to come to America" she
wrote to the American Consulate in Warsaw, "to assist us in a
research program in which we are developing at present in this
country" (November 13, 1938).  Sanger then explained privately to Rubinraut, "We cannot offer any compensation for your
services, but we, of course, will be glad to take care of your
expenses involved in experimental work, etc." (November 19, 1938).</p>

<p>   She was able to help find jobs for some of those she helped
sponsor, either at the Margaret Sanger Research Bureau
(MSRB), or through her friends and associates, while most of
those she hired received minimal pay ($5.00 per week in some
cases), her efforts did not go unchallenged.  In 1939, Sanger
dismissed concerns about alienating the MSRB Board of
Managers, but by 1941 the Board expressly forbade her to use
promises of employment at the clinic as a surety for refugees. 
Sanger also found her efforts questioned in another light.  On
signing an affidavit for yet another refugee, she asked Rose to
keep it quiet, for "you know how things get started.  They'll
claim I'm Jewish next..." (n.d.).  Yet Sanger persisted in her
efforts to bring these desperate people to the United States
because she believed, "we can scarcely stand by & have the
opportunity to save a life from torture and not do it" (MS to
Rose, n.d.). </p>   

<p>   As the situation in Europe worsened, Sanger stepped up her
efforts.  She used her contacts in Washington to speed up cases
that seemed to drag on without end.  Congresswoman
Jeannette Rankin was able to expedite paperwork in the case of
two Yugoslavian women whose papers were being held up at
the U.S. Embassy in Geneva.  In another case, Sanger used
her relationship with Elinor Morganthau, wife of Treasury
Secretary Henry Morganthau to try to win a visa for a German
doctor.  Always impatient with bureaucracy, Sanger felt
increasingly frustrated at the amount of red tape she
encountered.  Unable to move the paperwork for a desperate
couple out of a U.S. Embassy, she told Florence Rose, "It
makes me heartsick, to have those two dear souls kept there
because of some puppy who is temporarily important." (January 3,1941).  When she lost contact with Dr. Rubinraut she
contacted the Red Cross.  "About six months ago, our mail to
Dr. Rubinraut was returned.... We are, of course, anxious to
know whether Dr. Rubinraut is still alive and if anything can
be done to assist him in any way." (August 2, 1940).</p>

<p>   Despite the delays, Sanger's record in bringing refugees to
America was largely successful.  From letters at the Sophia
Smith Collection, we have identified at least twenty people for
whom Sanger signed affidavits (or had friends and co-workers
sign) and of those, only five (unfortunately including Dr.
Rubinraut) appear not to have made it to America, and none &ndash;
despite their worst fears &ndash; appear to have perished in the war. 
Most, though not all of the refugees were doctors, including
Ludwig and F. Sidonie F&uuml;rst Chiavacci (Italy) who were able
to continue practicing medicine in the U.S. after taking
licensing exams; Ernst Gr&auml;fenberg, Norbert Neufeld, and
Hertha and Walter Riese (Germany); and Tilde Winternitz
(Czechoslovakia).  Others were acquaintances of Sanger's
associates, such as Anna Kreupl, a housekeeper who wanted to
emigrate with her employer, actress Lilia Skala, and Ludmilla
Protitch, who later worked as an interpreter in the U.S.</p>
 
<p>   The number of people who finally reached the United States
and other safe havens pales beside those who did not. As the
nation commemorates the opening of the United States
Holocaust Memorial Museum in Washington on April 26, we
were reminded of the war's impact on those Americans who
before 1941 thought they could avoid getting involved and
those like Sanger who did not turn their back when finally
called. </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
