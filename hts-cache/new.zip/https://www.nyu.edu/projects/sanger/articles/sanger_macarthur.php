
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #7 (Summer 1994)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #7 (Summer 1994)</h1>
<div class="maintext">
<h1>"Sanger, MacArthur and Birth Control in Japan"</h1>

<p>     Welcomed as an educator, nurse, and benevolent sage,
Margaret Sanger was warmly embraced by the Japanese
people on each of her seven trips to Japan, and she, in turn,
grew very fond of Japan, its people, and its customs. 
Although the Japanese Government attempted to deny her
entry in 1922 citing her dangerous views on birth control,
Sanger was able to talk her way into the country by promising
to refrain from publicly discussing the issue.  But her attempt
to return to Japan in 1949 were foiled by a far more unyielding
government &ndash; her own.  General Douglas MacArthur,
Supreme Commander of the Allied Occupation Forces refused
Sanger permission to enter the country, despite the fact that
Sanger had been asked to visit postwar Japan by that nation's
most prominent birth control advocate, Baroness Shidzue
Ishimoto (Kato).  </p>

<p>     Sanger's advocacy of birth control was well-known in
Japan.  In the 1920s and early 1930s, as the country's
burgeoning population, combined with an accelerating
industrial revolution and an unusually high literacy rate,
interest had deepened in Sanger and her efforts to disseminate
contraceptive information.  As early as 1925 Professor Iso Abe
wrote:  "It is not [an] exaggeration at all if I say that
[Sanger's] name is better known in Japan than that of any
American or English woman." (<em>Birth Control Review</em>, August
1925, p. 102).  Her biographer, Ellen Chesler, suggests that 
Sanger's association with birth control in Japan may have been
strengthened by the coincidence that her name, transliterated in
Japanese as "Sangai-san," means "destructive of production"
(<em>Woman of Valor</em>).  It was even reported that a diaphragm-and-jelly kit was sold under that label in Japanese pharmacies. </p>

<p>     As right-wing extremists took control of the government of
Japan in the 1930s, the liberal social policies of the prior
decade, including tolerance of contraception, were turned
back.   Birth control activity remained suppressed until after
World War II.  In the postwar years, however, Japan began
experiencing a baby boom similar in proportion to that of the
U.S. and Europe.  Not only was Japan's deepening population
density becoming burdensome to its social and economic
recovery, but Japan's women were increasingly reluctant to
sacrifice the expanding economic and political opportunities
available to them in order to raise large families.  With little
access to reliable contraceptives, Japanese women increasingly
resorted to abortion.  It was this high abortion rate that so
alarmed Sanger's friend, the Baroness Ishimoto (Kato), and
led her to press for Sanger's visit to Japan to promote the use
of reliable contraceptives.  </p>

<p>     Japan, however, was still under allied military control in
1949.  On August 30, Sanger was informed by the U.S. High
Command that she would not be granted military clearance to
enter occupied Japan.  Unlike Germany, occupied Japan was
not divided into zones and the Supreme Commander ran that
nation.  The U.S. government was anxious to revitalize a
strong anti-Communist Japan by discouraging the rise of
radical or even reformist notions. MacArthur, who viewed
Sanger as a radical rabble-rouser who would foster social and
political disorder, justified his action on the grounds that he
did not want to give the impression that the Americans were
actively promoting Japanese population control. Instead, he
piously claimed he would not take sides in what he claimed
was an internal debate:</p>

<blockquote>
<p>  I have yielded to pressure from neither the group in
advocacy nor that in opposition to birth control, but
have consistently and publicly taken the position that
the subject matter is a social problem for solution by
the Japanese people themselves without interference,
directly or indirectly, by the Allied Powers.  In
support of this position, I have refused to authorize
the protagonists of either viewpoint to make of Japan
a battleground upon which to inject  and then to fight
an issue as to which Americans themselves have by
no means found uniformity of opinion." (Douglas
MacArthur to Wilford I. King, Feb. 23, 1950, King Papers University of Oregon).
</p>
</blockquote>

<p>
Colonel Herbert Wheeler, one of MacArthur's personal
advisors, further explained that the "approval of [Sanger's]
application...would necessarily carry the connotation that she
was here to serve an Occupation objective, [and] the General
could thereafter scarcely take the neutral position on the issue
of birth control, which he has taken heretofore." (William R.
Mathews to Florence Mahoney, 1/13/1950, Mahoney Papers,
National Library of
Medicine).</p>

<p>      Sanger's supporters
claimed that MacArthur
was ignoring the fact
that she had been invited
to discuss the issue by
the Japanese themselves. 
MacArthur denied this
asserting:  "Contrary to
what has been publicly
intimated, no agency of
the Japanese
Government has
requested Mrs. Sanger to come to Japan for consultation.  As
far as I know the only question of her admissibility is based
upon the application by an editor of a Tokyo newspaper last
July to be permitted as a publicity move to bring her to Japan
for a lecture tour."  Resisting claims that Sanger's large
Japanese following and charismatic impact posed a threat to
his authority, MacArthur remarked "There is no question of
personality involved as none will fail to recognize the
distinguished ability of Mrs. Sanger to counsel, support, and
defend the cause she has so long espoused." (MacArthur to
Charles E. Scribner, Feb. 24, 1950, Marie Stopes Papers, The
British Library)</p>

<p>     While it remains unclear whether he was being guided as
much by concerns over U.S.-Japan relations as by his own
political ambitions (specifically his desire not to antagonize
Catholic constituencies in the U.S.), MacArthur held firm.
Sanger, for her part, bided her time.  She told a friend, "while
I would have welcomed the right to go to Japan I am
not going to try to buck the occupation authorities, inasmuch
as the Japanese people are doing a splendid job on their own."
(MS to Rosika Schwimmer, 04/15/1949, Schwimmer-Lloyd
Papers, NY Public Library).  But she did not remain idle. 
Instead, she began raising funds to be sent to Japan to help
open more birth control clinics there.  When American
occupation forces left Japan in 1951, Sanger again applied for
entry.  After enduring yet another extensive U.S. security
check, she was granted a visa, and in 1952 some 30 years after
her first controversial visit there returned to Japan.  Sanger's
trip was a great success and her popularity in Japan grew.  By
1954, Douglas MacArthur, fired by President Truman three
years earlier, was out of the military, while Margaret Sanger
once again traveled to Japan, this time as the first foreigner
ever invited to address the Japanese Diet (parliament). </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
