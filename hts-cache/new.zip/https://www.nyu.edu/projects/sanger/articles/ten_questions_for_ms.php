
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #20 (Winter 1998/1999)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #20 (Winter 1998/1999)</h1>
<div class="maintext">
<h1>"Ten Questions for Margaret Sanger on the Subject of Women"</h1>				

<p><em>For a book on the social status of women throughout the world, Violet Alva, an Indian writer/editor, questioned Sanger in 1950 on the role of women in society.  Sanger's answers sound almost traditional from our vantage point in 1998, but would have been viewed as very progressive in 1950, when Sanger was 71 years old. As in 1950, the status of women in society continues to be a popular subject of discussion.  Would Sanger's answer to question number 10 be any different today?  As always, the text is reprinted here without corrections or changes of any kind. (Written response to questions by Violet Alva, August 1950, MSP-LCM 007:797.)</em></p>

<p><strong>1. Is home the only place for women?</strong></p>

<p>No.  The world and its activities, needs, and occupations 
is for women as well as for men.  Home is not the only place for women.</p>

<p><strong>2. Does home life give complete happiness to women?</strong></p>

<p>There are some women for whom a good comfortable home gives complete happiness; there are others who find its duties dull and boring.  The home does not give complete happiness to all women.</p>

<p><strong>3. Should women sacrifice all other interests in favor of her children until they are adults?</strong></p>

<p>Women should not sacrifice all other interests in favor of her children until they are adults.  That is by far the most harmful thing she could do, not only to herself but to her husband and growing children.  The woman who has outside cultural or civic interests brings into the home these interests and often is the inspiration of her children's higher learning, creating a larger horizon in their own growing world.  Any woman is of greater interest to her family when her mind is developing and her own spiritual being is growing with and through efforts of cultural import.</p>

<p><strong>4. Does marriage enslave or protect women?</strong></p>

<p>Marriage can enslave some women; it can also protect some women.  It depends greatly upon the one who enslaves or protects her.  Sometimes protection is enslavement.</p>


<strong><p>5. Which is more rational, matriarchal or patriarchal system?</p></strong>

<p>To me, neither Matriarchal or Patriarchal systems are rational.  Why should they be either?</p>

<p><strong>6. From your observations and study, could you tell us whether men generally prefer the homely type or the career type of women?</strong></p> 

<p>Most men like a good home and its comforts.  It does not make much difference to men how their comforts are made.  They can be directed by a career wife and accomplished by servants or done by the woman herself.  The career type of woman is often an office wife to a business man far more attractive and helpful than the slavey home wife.  Most men like women with charm, wit, ability in any position of home or office.</p>


<p><strong>7. Should women quietly agree to double standard of morality as men are polygamous by nature, or demand equal moral standard?</strong></p>

<p>As standards of morality differ in various countries, it is difficult to call one country's "double or single standards" what other countries accept as moral.  In English speaking countries, intelligent men and women hold a single moral standard for man and woman, especially after marriage.  Before marriage, however, opinions differ as to man's code or morals.  As for woman, there is almost a universal agreement that her moral code must be virginal until marriage.</p>


<p><strong>8. Do you envisage a time when society would discard the institution of marriage for free love? </strong> </p>

<p>There is no such institution as "free love."  I can envisage no period when Society will discard marriage for promiscuity.</p>


<p><strong>9. Would it be advisable to legalize unmarried motherhood?</strong></p>

<p>Yes, it would be wise and humane to legalize children born out of wedlock and remove the stigma from an innocent victim.  As to legalizing the unmarried mother, much would depend on the circumstances of her case &ndash; how many illegitimate children has she born, how many will she continue to bring into the world?  Our institutions can testify to the custom.</p>

<p><strong>10. With increased interest in world affairs, could women change the social, political, and economic structure of society?</strong></p>

<p>Women have not so far with their hard-one political freedom changed even a small fraction of the structure of  Society.  They have not changed the status of women through their positions in the halls of Parliament or U.S. Senate.  Not a woman's voice in any country has been raised in their official position on behalf of the right of the poor, overburdened women to have knowledge of birth control.  This to their shame, for none of the women in the political arena, none in earning positions have large families and certainly would not attain the freedom they have without some knowledge or method to prevent the conception of unwanted children.  Woman in world affairs is not a force &ndash; only a partial copycat of man's influence and leadership, alas.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
