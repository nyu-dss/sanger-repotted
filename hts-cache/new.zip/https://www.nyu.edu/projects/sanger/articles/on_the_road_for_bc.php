
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #21 (Spring 1999)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #21 (Spring 1999)</h1>
<div class="maintext">
<h1>"On the Road with Birth Control"</h1>

<p>"Never mind if you don't like speaking, Margaret," wrote Elizabeth Gurley Flynn in an
August, 1915 letter imploring Sanger to organize a cross-country speaking tour, "one talk on the general
purposes of your work would be sufficient"  (Elizabeth Gurley Flynn to MS, August 1915,
LCM 8:679).  Other radical friends including Emma Goldman and her inner circle, Caroline Nelson,
Alexander Berkman and Ben Reitman, prodded Sanger to confront her enemies and give voice to her
self-replicating pamphlet, Family Limitation, that was pulling people to labor halls and down-town
auditoriums to discuss publicly what was so rarely mentioned even in private. As Ben Reitman wrote at
the end of  his own propaganda tour:
<blockquote>
<p>
    O brave Margaret Sanger! You can be glad even if they hang you or
     send you to the penitentiary for life,      your pamphlet has found its way
     into nearly every hamlet or village      in America, and dozens of other
     men or women have republished      your pamphlet or similar ones and
     scattered them broadcast      throughout the land and Anthony
     Comstock, though aided by all the      powers of government or hell,
     cannot stop this stupendous      movement (Ben L. Reitman, "The
     Tour," in <em>Mother Earth</em>,      September, 1915). </p>
</blockquote>
<p>    Following her year-long exile in Europe in
the fall of 1915, Sanger considered a national
speaking tour to bolster a defense fund for her
pending <em>Woman Rebel</em> trial (she had been arrested on
obscenity charges a year earlier, prompting her flight
overseas) and build on publicity generated by the
arrest and imprisonment of her husband, William, for
giving a copy of Family Limitation to one of vice-crusader Anthony Comstock's henchmen. But the
sudden death of five-year old Peggy Sanger in
November altered the timing and likely the outcome
of her trial.  After many postponements, the state
dismissed its case against Sanger in February of 1916,
leaving her, for the time being, less martyred than
manipulated, but nevertheless poised for further
publicity.  She announced at a February "victory"
celebration at the Bandbox theater in New York that
she would commence a coast-to-coast lecture tour in
April. She wrote to friends and supporters in March
asking them to write to her at once and "tell me the
capacity of the largest lecture hall" in their vicinity.
(MS to Friends, March 13, 1916, <em>MSM</em> C1:124.)</p>

<p>     Sanger organized her tour so that she would
appear in cities where there already existed an
organization or, at the very least, a working group
dedicated to free-speech
issues or the "small family"
question, that could be
energized to form a birth
control league and eventually
clinics.  In 1915 Emma
Goldman had bulldozed
through many of the cities
Sanger would
visit, speaking on a host of
subjects, including the war,
homosexuality and birth
control; thus both birth
control supporters, including
many labor leaders and
socialist organizations, and
the guardians of public
morality &ndash; from mayors to
church leaders to constabulary
&ndash; were agitated well before
Sanger packed her bags. </p>

<p>     After drafting her stump speech &ndash; a
composite of writings completed in Europe and trial
preparation materials &ndash; Sanger confronted one last
problem.  Elizabeth Flynn referred to it earlier:
Sanger despised public speaking.  By this time she
had given several major speeches, including a well-attended appearance in Fabian Hall in London the
previous year.  But never had she confronted the kind
of overflowing auditoriums and packed meeting halls
she knew awaited her night after night.</p>

<blockquote>
<p>      
     . . . the anxiety that went into the
     composition of the speech was as
     nothing compared to the agonies
     with which I contemplated its
     utterance.  My mother used to say a
     decent woman only had her name in
     the papers three times during her
     life &ndash; when she was born, when she
     married, and when she died.
     Although I never shrank from
     publicity . . . I was frightened to death.  Hoping that
     practice would give me greater confidence, I used to
     climb to the roof of the Lexington Avenue hotel
     where I was staying and recite, my voice going out
     over the house tops and echoing timidly among the
     chimney pots (<em>Autobiography</em>, 192-3).</p>
</blockquote>

<p>     Sanger claims she never, over her long
career, felt comfortable speaking in public, and often
turned ill just before an event, but was propelled by
her cause, the outpouring of affection, and anger
aroused over attempts to silence her.  Not far into the
1916 tour it became clear that Sanger performed
exceedingly well in public, appearing as a gentle
society woman emboldened by a new gospel.  As one
attendee at
Sanger's
Portland,
Oregon
lecture
in June
later
wrote:
"I was
impressed with her modest demeanor and her low, soft
voice.  I had thought of her wielding a hatchet, with a
strident voice, daring anyone to knock a chip off her
shoulder.  On the contrary, she seemed to be a perfect
lady who would qualify for membership in the
Colony Club" (William Fielding Ogburn,
"Recollections" in "Our Margaret Sanger" <em>MSM</em>
S77:1000).  A newspaper described Sanger as
"essentially feminine in appearance," noting that "in
her countenance is apparent none of the boldness of
the professional propagandist" (<em>The Morning
Oregonian</em>, July 1, 1916).  Her surprisingly
approachable manner and diminutive size proved far
less intimidating than Goldman or Flynn &ndash; both fiery
speakers and imposing presences &ndash; and may have
enabled Sanger to better connect with many
apprehensive members of her
audience.</p>

<p>Following a trial lecture in New
Rochelle, New York on April 16th,
Sanger embarked on a three-month,
eighteen-city tour that would land
her name in the pages of the
nation's major newspapers.</p>

<blockquote>
<p> 
     I spoke in Washington, Pittsburgh,
     Cleveland, Chicago, Detroit,
     Racine, Milwaukee, Wisconsin, St.
     Paul and Minneapolis.  Then I
     turned back a little and went down
     to Indianapolis to speak at the
     National Convention of Charities . .
     . The next stop was in St. Louis,
     then Denver, Los Angeles and San
     Francisco.  After two weeks in that
     glorious State, I went up to
     Portland, (Oregon), by boat; spoke
     also in Seattle and Spokane
     (Washington), and thus ended my
     first and maiden tour in U.S.A. (MS
     to Charles and Bessie Drysdale,
     August 9, 1916, <em>MSM</em> S1:638-640).
</p>
</blockquote>

 <p>    In a note scrawled on a draft of her tour
speech Sanger wrote that she gave it 119 times. Notes
and variations suggest she altered it as she went,
adding more references to birth control and tightening
longer sections.  She gave ample background on her
work, put forth a strong economic argument for
family planning, and logically established birth
control as something scientific and moral. 
Unfortunately it is not one of her stronger speeches; it
meanders and has little momentum until an
autobiographical section near the end.  Packed
audiences of largely working-class folk with crying
infants in makeshift meeting halls on hot summer
nights most likely grew restless waiting for the prize &ndash; a description of actual contraceptive methods
(which Sanger generally avoided due to the threat of
arrest) and a copy of <em>Family Limitation</em>. </p>

 <p>    Newspaper articles announcing Sanger's
appearance and sometimes following-up on the
results of her visit proved more effective in reaching
large numbers of people, something of which Sanger
was clearly aware, judging by her well-spun remarks
to reporters and intuitive sense of how to make news. Sanger's statements to
the press were terse and efficient. She told one paper:
"Birth Control does not necessarily make for either
larger or smaller families; it simply insures, through
the mother's knowledge, a square deal and a fair
chance for whatever children are born" (1916
Scrapbook, Sanger Papers, Library of Congress, not
filmed).   In print Sanger less often reverted to
radical-speak or wrapped her subject in the language
of utopianism as she was apt to do on the podium.
She made every effort to pull the image of birth
control out of the gutter and even, at times, away
from its identification with militant radicalism. She
clarified that the movement was not about abortion
("we do not advocate illegal operations").  And she
demonstrated her strong European ties and intention
of following the example of Holland's public health
success with contraceptive clinics.  Sanger gave the
impression in her newspaper interviews that the birth
control movement was not built from the ground up
but from the pinnacle of society and academia down,
with support from some of the greatest minds of the
era (she never failed to mention Havelock Ellis and
H. G. Wells).  "Our work," she told one paper, "is
conducted on a high plane" (<em>St. Paul Pioneer Press</em>,
May 8, 1916).</p>

   <p>  Controversy on the tour, as throughout
Sanger's career, greatly increased press coverage and
aided the cause immeasurably.  In St. Louis, a
threatened boycott by local Catholic hierarchy forced
the manager of the Victoria Theater to lock the doors
of the building just prior to Sanger's scheduled
appearance.  After shouting to reporters that she
planned to sue the theater for $5000, Sanger stood on
top of a car and briefly addressed the estimated 2000
people who filled the streets.  She then led them down
to another theater but found its doors locked as well. 
She began to give her speech from atop the car until
police broke up the scene and cleared the street for
traffic. (<em>St. Louis Globe-Democrat</em>, May 25, 1916.)
"The effort to suppress Sanger," wrote the St. Louis
Post-Dispatch, "has advertised her propaganda,
piqued public curiosity, aroused popular interest, and
gained public support from many who otherwise
might be indifferent" (quoted in <em>My Fight for Birth
Control</em>, p. 147).</p>

   <p>  In Portland, Oregon three men were arrested
for selling Family Limitation at one of Sanger's
meetings.  Sanger left to deliver lectures in
Washington State but returned to Portland to attend
the men's trial.  During her short absence the mayor
and city council passed an ordinance banning Family
Limitation.  At a meeting to protest the ordinance,
Sanger and several women passed out revised copies
of the pamphlet.  Four of them, including Sanger,
were arrested and jailed for a night.  All were found
guilty; the men fined ten dollars a piece and the
women simply released, the court opting to continue
the matter indefinitely.  An incensed Sanger told
reporters: "I consider it a cowardly decision . . . It's
practically the same old story, that knowledge, if it's
hidden away on the musty bookshelves or in the
narrow confines of the medical profession, is moral;
but as soon as it is distributed among the working
people the same book becomes obscene" (<em>The
Morning Oregonian</em>, July 8, 1916). The trial
prompted newspapers to hash out the issue in
editorials and letters sections and sprung forth a flurry
of requests to Sanger and the birth control league in
Portland for copies of <em>Family Limitation</em>.</p>

<p>    Opposition groups effectively silenced
Sanger in Akron, and authorities demanded a preview
synopsis of Sanger's speech in Milwaukee, but
overall, Catholic and conservative attempts to muzzle
or mollify Sanger only catapulted her cause farther to
the front of the local papers. By the end of the tour
Sanger felt victorious. "In another year," she wrote
British suffragette and birth controller, Edith How-Martyn, "[birth control] will become a vital fact here. 
Its already bigger than the laws against it" (MS to How-Martyn, July 18, 1916, <em>MSM</em>
C1:144).</p>

  <p>   Sanger conducted similar cross-country
tours several more times in the 1920s and 1930s, but
they never generated the kind of attention or results of
her maiden tour.  The 1916 trip launched a number of
city and state birth control organizations that still
exist today as affiliates of Planned Parenthood of
America.  Leagues formed almost immediately upon
Sanger's departure in Washington, D.C., Cleveland,
Spokane, Detroit, St. Paul, Minneapolis, and
Indianapolis.  Organizations in some of the larger
cities like Los Angeles, San Francisco and Chicago
formed in 1915 and early 1916, but had little
direction and relatively small  memberships prior to
Sanger's visits. </p>

<p>     Still apt to display modesty in 1916, Sanger
told How-Martyn she deserved little credit for
arousing "this country out of its Rip Van Winkle
slumber of Puritanism" (MS to How-Martyn, July 18,
1916, <em>MSM</em> C1:138).  But she refused then and
later to properly acknowledge the likes of Flynn,
Reitman and Goldman who primed the podium for
Sanger and in many ways had the more difficult task
of being first to publicly utter the term Sanger coined.
In full vainglorious mode, Sanger wrote about the
tour fifteen years later:</p>
<blockquote>
<p> 
  I had created a national public
     opinion in favor of birth control,
     had won the press to
     discuss the subject, had
     inspired the organization
     of leagues to carry on the
     work throughout the
     country, and had aroused
     the nation to a realization
     of its great moral duty
     toward woman-hood"  (<em>My
     Fight for Birth Control</em>, p.
     149).</p>
</blockquote>

<p>     A more magnanimous Emma Goldman
emphasized Sanger's most impressive feat during this
time. In reference to <em>Family Limitation</em> and its
contraceptive recipes, Goldman wrote that while
others agitated on the subject,  "[Sanger] was the only
woman in America in recent years to give information
to women on birth control" (Emma Goldman, <em>Living
My Life, Volume II</em>, New York, 1931,  p. 553). 
Sanger claimed that twenty-thousand pamphlets were
distributed during those three months in 1916 &ndash; the
most immediate benefit to women provided by the
tour.  Undoubtedly for many women in need of
fertility control, everything else was just talk. </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
