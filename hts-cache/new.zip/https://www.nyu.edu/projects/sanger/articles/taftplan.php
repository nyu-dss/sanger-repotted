
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #51 (Spring 2009)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #51 (Spring 2009)</h1>
<div class="maintext">
<h1>"Giving it the Old School Try--Margaret Sanger and the Taft Plan for Human Betterment"</h1>

<p>Ideas came from teachers and doctors, retired folks and weekend inventors. Several farmers shared their barnyard wisdom. There were some crackpots to be sure, loaded up with cure-alls and invested in conspiracy theories. But most of the people who sent Margaret Sanger their suggestions for new contraceptives, sterilization techniques, fertility enhancements, and surefire methods for choosing the sex of a baby were ordinary people recycling old ideas. Sanger dismissed outright most of these inventions and schemes, sometimes responding with a perfunctory letter. But one such proposal she was handed in 1941 was different, both because of its ambitious scope and the status of its author, Horace Taft. Drafted shortly after the Second World War erupted in Europe, Taft called for the creation of a community of super-people, conceived using the sperm of a few exceptional men. Though dangerously echoing some of Hitler&rsquo;s notions of building a master race, but framed through the lens of American exceptionalism, individualism and traditional eugenic goals for human betterment, Taft&rsquo;s plan relied on applying birth control in a novel way. </p>
<p>Horace Dutton Taft (1861-1943) came from one of the most illustrious families in American history. The son of Alphonso Taft, secretary of war and attorney general under President Grant, and brother to President and later Chief Justice William Howard Taft, Horace Taft made a name for himself as an educator. In 1890, the Yale-trained lawyer founded and directed the prestigious Taft School for Boys in Watertown, Connecticut. When he announced his retirement in 1935, <em>Time Magazine</em> said that &ldquo;In a profession studded with Grand Old Men,&rdquo; Horace Taft was &ldquo;the grandest of them all.&rdquo; Pondering life after the Taft School, the tall and thin headmaster quipped, &ldquo;My victuals still taste good,&rdquo; leaving him plenty of energy to devote to a number of causes, including birth control. In retirement Taft chaired the Connecticut Committee for Sane Birth Control Legislation, served as president of the League of Nations Association, and penned his memoir. He also dabbled in armchair eugenics, concocting the &ldquo;crazy experiment in race improvement&rdquo; that he shared with Sanger in the spring of 1941. (<em>New York Times</em>, Jan. 29, 1943; &ldquo;Taftless Taft,&rdquo; <em>Time Magazine</em>, Dec. 16, 1935; Hartford Courant, June 29, 1940; Horace Taft to Florence Rose, Apr. 24, 1941 [LCM 10:717].)</p>
<p>Sanger had met Horace Taft sometime in the late 1930s when he visited a cousin who lived near her in Tucson. When he returned to Tucson in March 1941, he dropped off a draft of his 17-page &ldquo;plan&rdquo; and asked Sanger&rsquo;s help in trying to find a publisher or some other means to share his ideas with the public. Sanger responded a few days later: &ldquo;It has been a long time since I have had such a good time as I had going over your article.&rdquo; She noted that it was an &ldquo;interesting&rdquo; piece, &ldquo;presented with vision and clarity.&rdquo; (Sanger to Taft, April 2, 1941 [LCM 10:704].)</p>
<p>Taft&rsquo;s plan was based on the not uncommon belief that the human race was declining in intelligence and weakening in character. He began by reviving the by now hoary arguments about race suicide, arguing that &ldquo;the fittest . . . fail to increase in number or even to remain stationary while the shiftless, least intelligent and least self-controlled, have large families.&rdquo; He proposed using animal husbandry techniques to improve human beings, envisioning a community of between ten and fifty married couples dedicated to the proposition &ldquo;of begetting an exceptional and constantly improving breed of men and women.&rdquo; In Taft&rsquo;s plan the community&rsquo;s women would bear children conceived through artificial insemination of donor sperm gathered from prominent and &ldquo;very exceptional men&rdquo; of &ldquo;sound health and body,&rdquo; &ldquo;fine character and personality,&rdquo; and &ldquo;powerful mind.&rdquo; Though the community&rsquo;s men would not be the biological fathers of the children, they would fulfill the traditional roles of husbands and fathers. It is unclear why he assumed that the &ldquo;quality&rdquo; inherited by the children of these unions would be more dependent on the father&rsquo;s sperm than the mother&rsquo;s egg. A committee made up of outside experts and a few community representatives would control the donor selection process. The identities of the donors and their children would be kept secret, so as not to arouse jealousies or create unproductive competition. (Horace Taft, &ldquo;Plan,&rdquo; 1941 [LCM 140:427-435].)</p>
<p>Taft&rsquo;s examples of ideal sperm donors were all white, Christian men &ndash; and all by then deceased. They included poet and physician, Oliver Wendell Holmes, Sr. (1809-1894), his son, Supreme Court Justice Oliver Wendell Holmes, Jr. (1841-1935), Theodore Roosevelt&rsquo;s Nobel-Prize winning secretary of state, Elihu Root (1845-1937) , and Harvard President Charles William Eliot (1834-1926). He even suggested his brother, William Howard Taft (1857-1930), though weighing in at over three-hundred pounds, President Taft was clearly not a model of good health and body type. While securing the participation of living sperm donors and prospective mothers would be challenging, Horace Taft thought that the biggest obstacle would be &ldquo;finding ten or twenty men in the country who would join such an organization under the conditions imposed.&rdquo; Birth control was key to the success of the community, since Taft envisioned the husbands and wives using contraceptives to avoid conceiving children that might dilute the gene pool.</p>
<p>Taft decided his experiment would be located outside a major city, convenient enough to employment sources, but in a private and peaceful site, in order to provide the advantages of heredity &ldquo;combined with the best environment.&rdquo; Taft&rsquo;s planned community resembled 19th century utopian experiments which similarly emphasized education, a hard work ethic, and a route to perfectionism through alternate social or sexual mores. Members would pool their earnings in a common fund and generally operate under democratic principles. Men and women would be treated as equals and abide by the rulings of the supervising committee. If the plan succeeded, Taft hoped it would lead to similar communities in other regions and countries. But like the 19th century planners, Taft had not fully resolved economic concerns or how to keep members from leaving the experiment. (Taft, &ldquo;Plan,&rdquo; 1-9; Taft to Henry Pratt Fairchild, Apr. 12, 1941 [LCM 10:710].)</p>
<p>Taft understood that if his plan was published the public would find it &ldquo;shocking.&rdquo; He realized &ldquo;I shall be overwhelmed with abuse, and a great many friends and members of my family will be shocked and ashamed.&rdquo; But at the age of eighty, Taft knew he didn&rsquo;t have the time to wait, and he apparently thought it was his duty to tackle &ldquo;the question [that] seems to me to be the most important one in the long run confronting the human race,&rdquo; owing to his vast experience in building another kind of controlled and exceptional community&ndash;a boy&rsquo;s prep school. </p>
<p>Taft admitted that he had not worked out all the details or figured out how to come to terms with the &ldquo;rather mean human quality which makes men resent the idea of superiority, though that superiority is based on neither caste nor wealth, but only on personal merit.&rdquo; He worried that others would find flaws and wrote that he was &ldquo;prepared for discouragement.&rdquo; And indeed, the early responses he received were not encouraging. Sociologist and eugenicist Henry Pratt Fairfield was &ldquo;genial and sympathetic, but evidently skeptical,&rdquo; while writer Bruce Bliven &ldquo;was polite, but regarded the plan as utterly utopian.&rdquo; (Taft, &ldquo;Plan,&rdquo; 2; Taft to Henry Pratt Fairchild, Apr. 12, 1941 [LCM 10:710].) </p>
<p>While Sanger congratulated Taft on putting his plan on paper, and found it &ldquo;stimulating&rdquo; and &ldquo;exciting,&rdquo; she could not offer the kind of analysis he sought. &ldquo;I am not a biologist,&rdquo; she warned, and deferred her judgment to respected experts with a better understanding of genetics. She even supplied Taft with a list of potential readers, including eugenicists Clarence Little, Leon Cole and Leon Whitney, and physician birth control advocates Robert Dickinson, Clarence Gamble and Frederick Holden. She also acknowledged &ldquo;there is no doubt that it will take tremendous courage to present it to a larger public for consideration,&rdquo; before offering some comments and suggestions. </p>
<p> Taft&rsquo;s plan was almost wholly focused on increasing measurable intelligence, but Sanger argued that &ldquo;a certain variety of characteristics and talents should be a part of the plan.&rdquo; She believed strongly that society should always look to encourage variety rather than uniformity and had criticized eugenic formulas for human betterment that overlooked those positive traits, such as compassion and creativity, that science could not measure. She also suggested that &ldquo;the present generation of Rockefeller boys&rdquo; were &ldquo;excellent examples of what can be achieved through selection and environment and careful training,&rdquo; implying that wealth provided advantages. Indeed, Sanger was dismayed over Taft&rsquo;s assumption that his community would be poor, noting, &ldquo;It would seem an essential basis for good results to have freedom from economic worry.&rdquo; (Sanger to Taft, April 2, 1941 [LCM 10:704].)</p>
<p>Apart from her concerns about the economic health of the community, Sanger was troubled by Taft&rsquo;s reliance on artificial insemination to impregnate the women, wondering whether the &ldquo;absence of erotic stimulation,&rdquo; or sexual intercourse, could reduce the &ldquo;vitality, energy, brilliance&rdquo; of donated sperm. Taft replied that &ldquo;yearly examinations by specialists&rdquo; of children resulting from artificial insemination &ldquo;reveals that both their intellectual and physical health is far above average.&rdquo; It is unclear whether Taft had any contingency plan should the offspring in his community turn out to be merely mortal. (Sanger to Taft, April 2, 1941 [LCM 10:704]; Taft to Sanger, April 11, 1941 [LCM 10:708].)</p>
<p>It is curious that Sanger did not express to Taft (at least not in their correspondence) the fundamental problem she had with the concept of positive eugenics&mdash;encouraging more progeny from &ldquo;better&rdquo; people. She had always stood for the right of women to own and control their own bodies, to decide how many children to have and when to have them, but held that no woman should be pressed or encouraged to have children to enhance the population of any one group. In fact, she had recently been embroiled in a debate with the Birth Control Federation of America over this very issue, protesting the Federation&rsquo;s public encouragement of larger middle and upper class families. Her silence on this point might suggest that she viewed Taft&rsquo;s plan simply as an academic exercise to gain a better understanding of the role of genetics in human reproduction. (Sanger to Taft, April 2, 1941 [LCM 10:704].)</p>
<p>While Sanger continued to see value in emphasizing human improvement through birth control and believed that intelligent family planning practices reduced maternal and infant health problems and led to the rational, voluntary control of inheritable diseases and disabilities, she was reluctant to expand her ideas to encompass a planned eugenic community. She politely entertained Taft&rsquo;s &ldquo;crazy plan,&rdquo; and used the opportunity to encourage his important work in Connecticut to change the laws banning birth control. But she advised Taft that given &ldquo;the present upheaval&rdquo; it was &ldquo;not the best time for ideas to germinate.&rdquo; And, indeed, the racist, pro-natalist eugenics policies of the Nazis would no doubt have undermined Taft&rsquo;s efforts to attract professional interest and find a public outlet for his plan. In any case, he died in 1943, his article never published. The original draft resides in the Taft papers in the Taft School archives, but it is closed to researchers until 2016. The only other known copy is a transcription in the Sanger Papers in the Library of Congress. (Horace Taft to MS, May 8, 1941, Taft, &ldquo;Plan,&rdquo; 15, and Sanger to Taft, May 27, 1941 [LCM 10:719-22].)<br />
</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
