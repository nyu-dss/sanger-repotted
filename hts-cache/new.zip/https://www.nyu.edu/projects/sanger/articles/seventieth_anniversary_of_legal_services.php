
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #5 (Spring 1993)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #5 (Spring 1993)</h1>
<div class="maintext">
<h1>"Seventy Year Anniversary of Legalized Birth Control Services"</h1>				

<p>     In 1923, Margaret Sanger established the Birth Control Clinical Research Bureau (BCCRB), the first legal
birth control service provider in the U.S.  By 1924, under the direction of Dr. Hannah Stone, the BCCRB was not
only the first, but by far the most popular birth control clinic in the United States.  As the successor to Sanger's
illegal Brownsville Clinic of 1916, the BCCRB was operated by licensed physicians within New York State law,
and accepted only married women who required birth control for "the cure or prevention of disease."  </p>

<p>    In addition to providing women with contraceptive advice, the clinic functioned as an experimental testing
ground for Sanger's own social agenda, particularly her determination to prove the connection between birth
control and socio-economic issues.  Clinic staff gathered information on the sexual and reproductive lives of the
thousands of women patients which was used to prove that all women &ndash; not just educated, middle-class women &ndash;
were capable of using contraceptives successfully.  By maintaining detailed records and statistics, the BCCRB
staff demonstrated that birth control devices such as pessaries and spermicidal jelly were effective and safe
methods of contraception.</p>


<p>By
1929,
over
13,000
women had visited the BCCRB, and the New York
medical community began to accept it, albeit
slowly, as a legitimate institution.  Nevertheless many doctors remained uncomfortable with the idea of a clinic
operated by a lay person, and were particularly suspicious of Sanger's radical associations.  Physicians recognized
that although several New York hospitals had opened birth control clinics, most of these failed because women
seemed to prefer women-run clinics.  Indeed, an increasing number of physicians were impressed with the
enormous number of women seeking help from the BCCRB.  Soon, representatives of the New York Academy of Medicine began negotiating with Sanger to appoint a board of
"respected" physicians to oversee the BCCRB's operation.  While Sanger resisted their entreaties to cede control
over the clinic to physicians, by the end of the 1920s she was working closely with many members of the medical
community.</p>

<p>  However civil the relationship between Sanger and the medical community may have been, it did not protect the
BCCRB from harassment or criminal prosecution.  On March 22, undercover detective Anna McNamara visited
the clinic under the name of "Mrs. Tierney."  Dr. Elizabeth Pissoort, a BCCRB physician, examined and treated
McNamara.  Although one visit was sufficient for accumulating the evidence she needed, unbelievably, Detective
McNamara returned to the clinic several times for follow-up treatment.  On April 15, 1929, the New York City
Police, led by Women's Bureau Chief Mary Sullivan, raided the BCCRB and arrested Drs. Hannah Stone &
Elizabeth Pissoort, and nurses Marcella Sideri, Antionette Field, and Sigrid Brestwell and charged them with
violating the same ordinance that Sanger's Brownsville Clinic had challenged 13 years earlier.  </p>

<p>   Press reports of the raid itself portray a disorganized affair.  To the jeers of women patients, police stripped the
clinic of its contents, confiscating birth control equipment, books and pamphlets, even examples of fraudulent
birth control devices.  Sanger told reporters, "The police were rather nasty, but what can you expect?  They
didn't even know how to make a raid.  I've had so much experience with raids I could have taught them
something" (New York World, 4/16/29).  One of the arrested nurses claimed that the police could not tell the
difference between the contraceptive devices and the forceps used to sterilize them.  But the greatest harm
occurred when the police confiscated and then lost (or misplaced) 150 index cards on which were recorded the
names and personal histories of patients.  According to the <em>Herald Tribune<em></em></em> (5/16/29), a witness claimed that "a
policewoman held the missing cards in her lap during the raid.  They dropped to the floor when she moved and a
spectator reminded her that they were valuable and gave her an envelope to put them in."  Sanger later described
the raid as a "woeful failure" because it had "exposed a complete lack of intelligence in those who conducted it"
(<em>NY Telegram</em>, April 23, 1929).  On April 16, the day after the raid, Hannah Stone and her co-defendants were released
on bail, and they immediately re-opened the clinic.</p>

<p>   The public response to the raid was extraordinary: a variety of organizations supported Sanger and the BCCRB
defendants, including the American Civil Liberties Union and the League of Women Voters.  But it was the
medical profession's response to the raid that was especially potent.  Even doctors who did not support the
BCCRB's work were outraged at the seizure of medical records.  As one physician argued, "what [the police] did
was unpardonable...  They ransacked the clinic, and dumped all its private files, including case records, into a
wastebasket and carted them away.  Records were seized that had no bearing on the alleged crime, and that could
be used for all sorts of ulterior purposes..." (<span class="title">New York Times,</em>  April
19, 1929).</p>

<p>In the face of such severe
criticism, the New York
Police Department admitted
they overstepped their
boundaries.  On April 20,
City Magistrate McAdoo
ordered the police to return
the impounded medical
records.  But neither the
Police Department nor the
District Attorney's office
knew the exact
whereabouts of the
BCCRB's missing 150
index cards and neither
office would take
responsibility for their
disappearance.  But Sanger could not let the matter drop.  In her 1931 autobiography, My Fight For Birth Control,
Sanger asserted that specific case records &ndash; and not a "random sample" &ndash; were taken by the police.  Moreover,
she charged that the women whose cards were taken had received threatening phone calls.  Indeed Sanger
concluded that the police department had initiated the raid at the behest of the Catholic Church.  After six months,
the BCCRB ceased their search for the index cards.  Much to the regret of both the BCCRB and future historians,
they were never recovered.  </p>

<p>   Fortunately, the actual trial of the BCCRB defendants was more satisfying.  Defense Attorney Morris Ernst
focused his efforts on proving that no laws that were already in place had been transgressed.  As Ernst argued,
even when Policewoman McNamara went to the clinic for routine visits, neither she nor Dr.
Pissoort had broken
any laws that concerned the giving or sharing of contraceptive advice.  Despite early fears that the presiding
judge, Magistrate Abraham Rosenbluth, would favor the prosecution's side (he had asked Sanger supporters who
were laughing to leave the courtroom), on May 14 Rosenbluth discharged all the defendants stating there was
insufficient evidence to prosecute either the defendants or the BCCRB.  Rosenbluth's decision reaffirmed New
York State's 1919 Crane decision which permitted doctors to prescribe birth control when medically indicated.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
