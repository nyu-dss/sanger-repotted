
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #52 (Fall 2009)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #52 (Fall 2009)</h1>
<div class="maintext">
<h1>"Spermatoxins!"</h1>

<p>It sounds like a B-Movie title from Hollywood&rsquo;s golden age. You can imagine Bela Lugosi leering into the camera to speak the diabolic word that sends young women fleeing in horror: &ldquo;Spermatoxins!&rdquo; </p>
<p>Yet spermatoxins are not the product of a hack script writer&rsquo;s late night inspiration; they really exist. In the early 1930s, spermatoxin research inspired Margaret Sanger to conceive of the contraceptive pill &ndash; little more than a fanciful hope at the time. Controversial then, and still not fully understood now, spermatoxins might be coming soon to a clinic near you. </p>
<p>The study of spermatoxins, or sperm immunology, dates back to 1899 and research conducted by the Austrian pathologist Karl Landsteiner, a Nobel Prize recipient for his discovery of the ABO blood types. Landsteiner found an antigenic response to sperm when it was injected into a foreign species; he immunized rabbits against bull semen. A year later, Russian researcher Serge Metalnikoff, working in the Pasteur Institute, discovered that sperm could sometimes elicit an immune response even when injected into the same species &ndash; guinea pigs in his study. These early breakthroughs prompted scientists to try variations on this research. German investigator von Moxter injected ram sperm into rabbits, and American physician C.G. Farnum injected female rabbits with bull, dog, and human sperm. Most scientists reported some regular period of sterility in the injected females. When Russian microbiologist Mikhail Tushnov conducted extensive experiments with sperm immunization in animals using both live and dead sperm, first publishing his findings in 1911, he suggested that the research could lead to an effective human contraceptive. By the 1920s, some experts also wondered if this immune effect might play a role in infertility cases. In 1921, the American Medical Association ran an editorial in its journal asking &ldquo;If spermatozoa invade the female tissues and cause formation of specific antibodies which are capable of preventing fertilization, may not such a process participate in the problem of sterility?&rdquo; (Editorial, <em>JAMA</em> 77:1 [July 2, 1921]: 42.) </p>
<p>In 1922, American physician Samuel R. Meaker observed and recorded sperm immunity in the human female. The first human trials involving spermatoxins probably took place in 1925, undertaken by Russian researchers. Naiditch in Moscow supposedly immunized 26 out of 32 women using bull sperm, and Kolpikov in Archangel claimed to have immunized 279 women using ram sperm. Both investigators delivered multiple injections of the animal sperm into the woman&rsquo;s bloodstream (usually through the buttocks) at regular intervals to produce a sterile period lasting several months or more. Another Russian spermatoxin trial conducted in 1927 had an efficacy rate of over 90 percent. However, these findings came under intense criticism from other scientists who questioned the health of the test subjects and could not duplicate the findings. (Werner Henle, &ldquo;The Relation of Spermatoxic Immunity to Fertility,&rdquo; <em>Journal of Contraception</em> 2:2 [Feb. 1937], 30-32; Gary N. Clarke, &ldquo;Etiology of Sperm Immunity in Women,&rdquo; <em>Fertility and Sterility </em>91:2 [Feb. 2009], 639; Editorial, JAMA 77:1 [July 2, 1921]: 42 ; Abraham Stone, &ldquo;Notes on the Use of Spermatoxins in Russia,&rdquo; <em>Journal of Contraception </em>1:2 [Dec. 1935]:17-18 and &ldquo;Discussion,&rdquo; in <em>Biological and Medical Aspects of Contraception</em>, ed., Margaret Sanger [Washington 1934], 105-08.) </p>
<p>Margaret Sanger most likely first learned about spermatoxin research in 1928 from Agnes Smedley, an American expatriate who worked for Sanger as a birth control organizer in Germany and then China. Smedley visited Moscow in November 1928 on her way to China and wrote excitedly to Sanger: &ldquo;If you could only come and see, and forget America, Margaret, with all its money and its ability to buy everything and everybody. Just see what these people are doing on nothing!&rdquo; A closeted Communist, Smedley viewed this experiment in collectivism with rosy colored glasses and found the Soviet medical research front inspiring. &ldquo;Regarding sterilization,&rdquo; she wrote Sanger, &ldquo;They place much hope on the &lsquo;Sperma-toxin&rsquo;, which is the injection of the spermatozoan, or a solution from it . . . into the blood of the woman. This sterilizes her for one year (after 6 injections) and at the same time gives her added vigor, sexual energy, and youthfulness.&rdquo; (Ruth Price, <em>The Lives of Agnes Smedley </em>[NewYork, 2005], 170; Agnes Smedley to MS, Nov. 19, 1928 [LCM 10:412].) </p>
<p>Sanger learned more details about sperm immunization at the Seventh International Birth Control Conference in Zurich in September 1930, where a report by Dr. Anna K. Daniels, a New York gynecologist and marriage counselor, on spermatoxin research studies raised hopes that a biologic birth control method was on the horizon. Daniels added that, apart from the contraceptive effect, &ldquo;the female organism is influenced beneficially by absorption of seminal products.&rdquo; How, she did not say. Her report also raised a number of eyebrows among the participants, several of whom downplayed the exceptional results in the Soviet Union. While established researchers were suspicious about the contraceptive effectiveness and predictability of spermatoxins, and worried about side-effects, by now no one questioned that they could produce immune response in females. Daniels concluded her remarks by imagining &ldquo;how wonderful it would be if one could immunize a patient by a simple hypodermic injection once every six months, just as we today immunize children against diphtheria or adults against typhoid.&rdquo; </p>
<p>Sanger was ecstatic after the conference, writing a short time later about &ldquo;a young, enthusiastic new group of biologists and bio-chemists . . . now at work perfecting the science of contraception. . . Encouraging new possibilities are becoming realities.&rdquo; She held back, however, saying anything public about spermatoxins until more was known. (Anna K. Daniels, &ldquo;A Comparative Study of Birth Control Methods with Special Reference to Spermatoxins,&rdquo; in MS, Hannah Stone, eds., <em>The Practice of Contraception</em> [Baltimore, 1931], 109-111; MS, <em>My Fight for Birth Control </em>[New York, 1931], 343-44 .) </p>
<p>Sanger had organized American clinics around the most effective products available then&mdash;occlusive pessaries, which included the rubber diaphragm and cervical cap&mdash;but she was determined to find methods that were less burdensome for women as well as viable and cheap enough to be used in the developing world. Diaphragms were impractical and expensive for poor women and with condoms, women had to rely on their male partners. By the early 1930s Sanger had begun to favor foam powder or foaming jelly paired with a sponge as the best method for the masses. It was cheaper and easier to use than the diaphragm and did not require special fitting or follow-up medical visits. But it was yet another barrier method that many women found inconvenient, messy and sometimes irritating. And like all barrier contraceptives, it interfered with spontaneity. </p>
<p>The more Sanger heard about spermatoxins, the more she wanted to go to the Soviet Union and see firsthand how close they were to perfecting this potentially revolutionary method. &ldquo;I believe we must look to Russia for the &lsquo; pill&rsquo; the magic &lsquo;pill&rsquo;&rdquo;&ndash; she wrote Edith How-Martyn, who helped Sanger run the London-based Birth Control International Information Centre. Sanger considered organizing a birth control conference in the USSR in 1932 but decided it would jeopardize her lobbying efforts in Washington where she and her National Committee on Federal Legislation for Birth Control were working to amend the Comstock laws that classified birth control as obscene. Opposition forces, chiefly Catholic groups, had suggested that birth control was part of a Communist effort to weaken the United States, and Sanger did not want to fuel their conspiracy theory with an ill-timed trip. She wrote How-Martyn in July of 1932 that &ldquo;the opposition has tried desperately to tie our BC work up with Russia &amp; has asked for a Congressional investigation.&rdquo; (MS to Edith How-Martyn, January 10 and July 31, 1932 [<em>MSM</em> C5:314, 416].) </p>
<p>More promising news on spermatoxin research was featured at the 1934 American Conference on Birth Control and National Recovery in Washington. Morris J. Baskin, a Denver-based surgeon and the clinical director of the Denver Maternal Hygiene Committee, presented the results of his ongoing spermatoxin studies, started in 1929. He claimed to have immunized 19 out of 20 women in his first trial and 24 out of 27 in his second &mdash; all of the women having received a large series of injections of human sperm at yearly intervals. He blamed the few failures on an insufficient dosage. While his results were astonishing, Baskin did not yet think the method was practical on a wide scale; it was too difficult to obtain sufficient semen and keep it fresh in the time frame needed to prepare the serum and administer the injections. But these were obstacles he believed could be overcome, telling his colleagues that &ldquo;here we have a method which apparently can be developed into one that is simple, safe and effective.&rdquo; </p>
<p>In a discussion section following Baskin&rsquo;s paper, Dr. Abraham Stone, just back from a tour of the Soviet Union with his wife, Hannah Stone, the director of Sanger&rsquo;s clinic, talked about the ongoing Russian spermatoxin work, including a study similar to Baskin&rsquo;s that was underway in Moscow and had immunized 37 women. He noted that &ldquo;the Russians feel that the use of spermatoxins has come out of the stage of pure theoretical research and has entered into the field of practical experimentation.&rdquo; (Morris J. Baskin, &ldquo;Immunity as a Method of Birth Control,&rdquo; and Abraham Stone, &ldquo;Discussion&rdquo; in <em>Biological and Medical Aspects of Contraception </em>[Washington, 1934], 94-112.) </p>
<p>By the spring of 1934, following diplomatic recognition of the Soviet Union by the U.S. in 1933, Sanger decided she could wait no longer to visit Leningrad and Moscow and learn more about the next stage in spermatoxin research. There was no indication that congressmen in Washington had any serious intention of pursuing a Communist link to birth control, and the red passport stamp no longer aroused quite as much suspicion that its holder was a fellow traveler; thousands of Americans had explored the U.S.S.R. in 1932-33, including a number of Sanger&rsquo;s friends. Sanger wanted to witness &ldquo;what was happening in the greatest social experiment of our age,&rdquo; learn about the legal abortaria in the U.S.S.R. where thousands of abortions were performed each year, and meet with Mikhail Tushnov, the leading Russian expert on spermatoxins. She left in July with her youngest son, Grant, then 26, her secretary Florence Rose, and philanthropist Ethel Clyde. Though they traveled with a tour group that was kept on a short leash by Intourist, the Soviet state tourist agency that controlled nearly every facet of travel in the country, Sanger and Grant, then a medical school student, were able to drift from the pack and to meet with a number of important contacts she had made through the Stones and others, and tour a range of medical facilities. </p>
<p>At every opportunity Sanger inquired about spermatoxin research but received only vague responses. On July 20, she met with Tushnov in Leningrad and learned details of his last spermatoxin study, conducted a few years before. It too had been extremely promising, however, he told Sanger he was being forced to abandon sperm immunization research and contribute his efforts to more &ldquo;utilitarian tasks&rdquo; dictated by the state. He also complained that he was not allowed to publish his research in foreign journals. By the end of her trip, Sanger had learned that spermatoxin studies had been officially discontinued. The Moscow trials that Abraham Stone had reported on at the 1934 conference appeared to have been abandoned by the time Sanger arrived. While the Soviet government attempted to lower the escalating abortion rates, it also wanted to increase its overall birth rate and did not want contraceptive research to be made a priority. (MS, <em>An Autobiography</em> [New York, 1938], 431-60; <em>New York Times</em>, July 8, 1934; MS, &ldquo;Birth Control in Soviet Russia,&rdquo; <em>Birth Control Review </em>2:9 [June 1935]: 3.) </p>
<p>Meanwhile Dr. Istv&aacute;n Sug&aacute;r of Budapest became the most recent phenomenon in the spermatoxin sweepstakes. He used an antigen prepared from bull semen that created temporary sterility first in rabbits and then in a test group of thirty women. However, skepticism about the findings of Sug&aacute;r, Baskin and others was again growing within the research community. In 1936, Chinese biochemist Yu Wang replicated some of the earlier animal studies on spermatoxins but concluded that &ldquo;the induced temporary sterility observed by others was not caused by spermatoxic substances . . . but consequent upon the poor health of the animals as a result of the injections.&rdquo; In a discussion group at the 1936 Conference on Contraceptive Research and Clinical Practice, held in New York, Cheri Appel, a doctor at Sanger&rsquo;s clinic, told a panel that she had recently visited in Moscow with Dr. Naiditch, one of the early researchers who had reported stunning success with sperm immunization trials. Naiditch told her that he too had given up spermatoxin work and that his most recent results were &ldquo;nearly 100% failures.&rdquo; (&ldquo;Discussion,&rdquo; <em>Journal of Contraception </em>2:2 [Feb. 1937]: 32-34.) </p>
<p>Dr. Robert Dickinson, perhaps the most respected voice within the medical world on contraceptives at that time, also found the earlier research in the U.S.S.R. severely flawed because, as earlier critics had pointed out, so many of the test subjects had recently had abortions, which in most cases rendered them sterile for several months. Immunologist Roscoe Hyde added that his spermatoxin research with rabbits produced results that were contrary to earlier findings; all the rabbits became pregnant. He questioned whether previous studies had been conducted under controlled conditions. Writing privately to Sanger, Dickinson dismissed spermatoxins as nothing more than another hyped and unproven method, never credited by respected scientists. He questioned Baskin&rsquo;s credentials and called his claims &ldquo;unconfirmed.&rdquo; He said Hyde&rsquo;s preliminary results &ldquo;throw grave doubt on the previous clinical returns.&rdquo; (Dickinson to MS, Oct. 28, 1936 [LCM 126:12; Vol. 2].) </p>
<p>Additional follow-up studies were published over the next few years. One repudiated Sug&aacute;r&rsquo;s conclusions, and a research paper published in the <em>American Journal of Hygiene </em>in 1940 stated that while &ldquo;it is possible to produce antibodies to sheep, rat, rabbit and guinea pig sperms in laboratory animals . . . These sperm antibodies . . . were ineffective in preventing pregnancy.&rdquo; The general consensus by the early 1940s was that earlier research may have misinterpreted the causes of temporary sterility. If there was an immunologic effect that prevented pregnancy some of the time, it was difficult to predict and impossible to rely on. (&ldquo;Sperm Immunization,&rdquo; <em>Journal of Contraception </em>1:11 [Nov. 1936]: 193-94; &ldquo;Discussion,&rdquo; <em>Journal of Contraception </em>2:2 [Feb. 1937]: 32-34; Elizabeth Parsons and Roscoe Hyde, An Evaluation of Spermatic Sera in the Prevention of Pregnancy,&rdquo; <em>American Journal of Hygiene </em>31 [May 1940]: 89-113.) </p>
<p>Sanger pushed for additional research on spermatoxins through the late 1930s, holding out hope that researchers could unravel the contradictions and find a more consistent approach that would lead to an effective contraceptive. In 1938, she proposed funding a long-term spermatoxin study, but could not gather sufficient support from the research community. However, she never gave up on biological methods. A decade later she encouraged Katharine Dexter McCormick to begin making regular contributions to support the work of Gregory Pincus and his team at the Worcester Foundation for Experimental Biology. Within a few years they had turned their research on progestin as an ovulation suppressant into the magic pill that Sanger envisioned in 1932. (BCCRB/NCMH Meeting Minutes, Oct. 27, 1938 [<em>MSM</em> S61:378].) </p>
<p>While the birth control community all but abandoned spermatoxin research after the early 1940s, several investigators continued work on new approaches to producing antisperm antibodies in animals, but they continued to struggle with the variability of immune response. By the 1960s, the research had turned to focus on the possible link between infertility and sperm immunization. The cause is unknown in more than ten percent of infertility cases, and fertility specialists have hypothesized that a woman&rsquo;s immune reaction to her partner&rsquo;s sperm may be the culprit at least some of the time. In the last decade, researchers have made significant progress toward understanding the etiology in sperm immunity, in identifying a specific human sperm antigen that triggers an antibody in some women who are infertile, and in isolating sperm antibodies that naturally develop in vasectomized men and using them to consistently inhibit sperm function in vitro. Work on animal contraception in this area is even farther ahead. These breakthroughs are clearing the way for new infertility treatments and the real possibility of effective male and female immunocontraceptives that would have fewer side-effects than the anovulant pill. One thing we can say for sure, if and when a contraceptive vaccine is developed, it&rsquo;s highly unlikely it will be marketed as &ldquo;spermatoxin!&rdquo; (Abraham Stone and Norman E. Himes,<em> Planned Parenthood: A Practical Guide to Birth-Control Methods </em>[New York, 1951], 227-29; Clarke, &ldquo;Etiology of Sperm Immunity in Women,&rdquo; 639-43; Rajesh K Naz, &ldquo;Status of Contraceptive Vaccines,&rdquo;<em> American Journal of Reproductive Immunology </em>61:1 [Jan. 2009]: 11-18.)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
