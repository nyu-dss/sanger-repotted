
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #4 (Winter 1992/1993)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #4 (Winter 1992/1993)</h1>
<div class="maintext">
<h1>"The Holdings of the Sophia Smith Collection"</h1>

<p>    One of the tasks undertaken by the project staff at the Sophia Smith Collection in the past year has been
searching the rest of that archives holdings for Sanger documents.  In addition to the second-largest collection of
Margaret Sanger's papers after the Library of Congress, Smith is internationally known as the home of the largest
collection of material on the history of the birth control movement in America.  The task for our staff was to cull
through these collections, including several which were not yet processed, and photocopy Sanger documents for
inclusion in our microfilm.</p>

<p>    In the voluminous Planned Parenthood Federation of America collection we located significant material on
the early history of the birth control movement, from letters relating to Sanger's differences with rival Mary Ware
Dennett to rich documentation of Sanger's congressional lobbying drives in the 1930s.  Many of the organizational
documents in the Planned Parenthood collection. </p>

<p>Several of Sanger's closest friends and associates deposited their
papers at Smith over the last forty years.  Foremost among these was
Florence Rose, Sanger's longtime secretary who was largely
responsible for organizing Sanger's papers for deposit at both the
Library of Congress and the Smith Collection.  The Rose Papers
contain hundreds of letters to and from Sanger, including
correspondence with Pearl Buck, Shidzue Ishimoto Kato, and H.G.
Wells.  The Sanger-Rose correspondence is voluminous and frequent
(in some cases four or five letters daily) and provides a detailed view
of their day to day activities.</p>

<p>The letters Sanger wrote to Rose often reveal less guarded, more
personal reflections, covering topics as varied as her health, and the
fears and anxieties she shared with few others.  </p>

<p>    A significant number of documents were located in the Records of
Planned Parenthood League of Massachusetts  and the papers of its
founder, Blanche Ames.  Together these collections present an unique
look of how Sanger's national policies played out at the state level. 
Ames insisted that women should have the right to be treated by
female doctors, and she worked on developing contraceptives that
could be easily used by working-class women.  One of her innovations was a contraceptive made from a baby's
teething ring or the rim of a Mason jar, items most mothers had.</p>

<p>Smith alumnae Dorothy Hamilton Brush, who arranged for Sanger to donate
her papers of to Smith in 1946, left her own collection to the college as well, a
collection rich in the history of the international birth control movement. 
Brush's papers are an excellent source on Sanger's final decade as a force in the
movement as she fought off severe illness in an attempt to insure the viability of
the international family planning movement.  </p>

<p>    The Brush collection also contains an unpublished play titled "Margaret"
(written by Brush and playwright Leighton Rollins) that chronicles the
remarkable early life of "Margaret Shaw," a fiery Irish redhead who rose from
a small town in upstate New York to open the first birth control clinic in the
country.  The play concludes with Margaret's release from prison in 1917 and
her exultant exclamation "Imprisonment has made me free!" as she embraced
her father and waved to a crowd singing The Marseillaise.</p>

<p>Including the major collections mentioned above, project staff searched a total of
32 collections at the Sophia Smith Collection and Smith College Archives, including the papers of Mary Ritter
Beard, and Elizabeth Cutter Morrow, as well as the records of the Margaret Sanger Research Bureau and the
Smith College Donor Files.  The numerous collections regarding the birth control movement are a significant part
of Smith's vast collection chronicling the history of women.  Together with the main collection of Margaret
Sanger Papers at Smith, these valuable documents will constitute Series 2 of the Sanger Project's microfilm
edition.</p>

<p>The Sophia Smith Collection is currently celebrating their 50th anniversary with an exhibit entitled "Never...
Another Season of Silence:  Laying the Foundation of the Sophia Smith Collection, 1942-1965" in the reading
room of the Smith Collection at the Alumnae Gymnasium at Smith College.  The exhibit opened on October 25,
1992 and will continue until January 8, 1993.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
