
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #59 (Winter 2011)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #59 (Winter 2011)</h1>
<div class="maintext">  
<h1>"Tracing <em>One Package</em> -- The Case that Legalized Birth Control"</h1>

<p>Seventy-five years ago a plain-wrapped package sent from Japan and seized by U. S. Customs delivered a fatal blow to one of the most restrictive and inhibiting federal laws in American history. On December 7, 1936, the U.S. Court of Appeals for the Second Circuit issued a ruling that released &ldquo;One Package, containing 120, more or less, Rubber Pessaries to Prevent Conception&rdquo; from confiscation. It was a historic decision that effectively disabled the Comstock laws and legalized doctor-prescribed contraception. The unusual, cone-shaped Japanese diaphragm was quickly forgotten, but the <em>One Package</em> case still reverberates today through its influence on subsequent court decisions. Orchestrated by Margaret Sanger and her celebrated attorney, Morris Ernst, <em>One Package</em> secured the legal foundation for groundbreaking rulings on reproductive and privacy rights. </p>

<p>After Morris Ernst successfully represented Sanger&rsquo;s Birth Control Clinical Research Bureau (BCCRB) in the 1929 police raid case, he and Sanger began searching for a test case to challenge the 1873 Comstock Act and related anti-obscenity laws, which prohibited the circulation of contraceptives and contraceptive information through the mails. By 1930, these laws were not always enforced, but the legal uncertainty made the distribution process unpredictable. Moreover, the medical profession would not endorse birth control until the courts or Congress legalized doctor-prescribed contraception and removed the taint of obscenity. And without official medical approval the birth control movement had little chance of encouraging government support and incorporating contraceptive services into public health programs&ndash;one of Sanger&rsquo;s chief remaining goals. </p>

<p>Ernst, one of the country&rsquo;s best known civil liberties advocates, was confident that the Comstock laws would be fully whittled away by the courts before Congress got around to repealing them. Several key decisions dating back to 1915 had reduced the reach of the laws and prompted Ernst to predict that judicial nullification was near at hand. But Sanger was not so sure. She hedged her bets, establishing the National Committee on Federal Legislation for Birth Control in 1930 to lobby Congress to amend the troublesome statutes, while she continued to pursue a test case. (Morris Ernst, &ldquo;How We Nullify,&rdquo;<em> The Nation</em> 134 [Jan. 27, 1932]: 113-114.) </p>

<p>Ernst and Sanger worked to target the 1930 Tariff Act, specifically Section 305a, a direct descendant of the Comstock law, which prohibited the importation of contraceptives and contraceptive information, and had been enforced in the early 1930s more often than the laws that banned the interstate mailing and transportation of contraceptives. Not long after the Tariff Act was passed, Sanger learned of several confiscations of birth control devices and literature by the U. S. Customs Bureau in New York and other ports. A seizure of a copy of British birth control advocate Marie Stopes&rsquo; book, <em>Contraception, </em>in December 1930 led to a judicial clarification of the Tariff Act by Judge John Munro Woolsey of the U. S. District Court for the Southern District of New York, who would gain fame in 1933 for his decision to exonerate James Joyce&rsquo;s <em>Ulysses</em> from the Act (Ernst represented the publisher in that case). Woolsey&rsquo;s 1931 decision on <em>Contraception </em>limited the Tariff Act&rsquo;s prohibition on importing birth control to devices only, eliminating literature. Shortly thereafter, Sanger, Ernst and Dr. Hannah Stone, the director of Sanger&rsquo;s clinic, began to work up a &ldquo;dummy&rdquo; contraceptive pamphlet they planned to send back and forth through entry ports to test the strength of Woolsey&rsquo;s interpretation. This scheme proved unnecessary when U.S. Customs seized materials in 1932 and 1933 that provided several good possibilities for test cases. (MS to U.S. Customs Bureau, Oct. 1 and Robert Dickinson to MS, Oct. 10, 1930 [LCM 60:331and 30:495]; <em>New York Times</em>, July 18, 1931; MS to Morris Ernst, March 28, 1932 [LCM 59:166].) </p>

<p>In the early 1930s Sanger ordered a number of shipments of contraceptive devices and literature, mainly from England and Germany, for testing at her clinic and to replenish supplies. Individuals and businesses often sent Sanger contraceptive materials to evaluate. American manufacturers still lagged behind European counterparts in producing reliable diaphragms and spermicidal jellies and creams. And while clinics and many private practice physicians depended on the BCCRB to evaluate products, there was no consumer protection service or regulation in the contraceptive industry. </p>

<p>In the fall of 1931, Dr. Sakae Koyama, the president of the Juzen Hospital in Osaka, Japan, sent Sanger a sample of a new type of pessary or diaphragm. He had designed the device, in large part, for his own needs, &ldquo;I had twelve children,&rdquo; he wrote &ldquo;so there was much trouble and care to raise and educate them.&rdquo; His diaphragm was made of soft rubber in a conical shape with &ldquo;a valve at its end . . . capable of intercepting the passage of semen with greater efficiency.&rdquo; Koyama claimed that the shape and suction action provided a better fit. He patented the device as the Koyama Suction Pessary (also called the Koyama Safe Method) and had hopes of marketing it outside of Japan. Intrigued by the doctor&rsquo;s boasts and impressed with his product&rsquo;s flexibility and low price, Sanger asked for additional pessaries to test on a group of women at the BCCRB. (Koyama to MS, Oct. 17, 1931 and March 26, 1932; MS to Koyama, Feb. 20, 1932 [LCM 18: 1083, 1104, 1096].) </p>

<p>On June 14, 1932, Customs authorities seized Koyama&rsquo;s next shipment to Sanger. Ernst&rsquo;s office promptly contacted Customs and arranged for the pessaries to be returned to Japan. With Sanger as the primary recipient of the package, Ernst did not wish to contest the seizure. Based on earlier court decisions, Ernst knew he could frame a test case argument on the medical legitimacy of contraception, but not with Sanger as the recipient of the package. Her lay status, not to mention her controversial reputation, would only complicate matters. Later in June 1932 Sanger ordered another package of Koyama&rsquo;s pessaries, but this time requested it be sent to Dr. Hannah Stone at the BCCRB. On January 9, 1933, U.S. Customs in New York informed Stone that they had detained, under Section 305 of the Tariff Act, a package of &ldquo;articles for prevention of conception.&rdquo; (H.C. Stuart to MS, June 14, 1932; Alexander Lindey to H. C. Stuart, July 8, 1932; H. C. Stuart to Hannah Stone, Jan. 9, 1933 [LCM 60: 180, 184; LCM 20: 1187].) </p>

<p>After reviewing the seizure, Ernst&rsquo;s associate, Alexander Lindey, informed Sanger that &ldquo;we are of the opinion that if such articles are susceptible of a legal as well as an illegal use, they are legal for importation into this country under the [Tariff] Act.&rdquo; He and Ernst advised pursuing a test case. Sanger secured $500 from Ethel Clyde, one of her more devoted wealthy supporters, to pay for legal fees, and on February 8 authorized Ernst to proceed with a legal challenge. U.S. Customs disagreed with Lindey&rsquo;s interpretation of the law, writing that &ldquo;the articles in question cannot be legally imported even where the same are addressed to a duly qualified physician since the law makes no exception.&rdquo; Customs transmitted the seized articles to the U.S. Attorney who then put into motion proceedings in the district court for the forfeiture, confiscation, and destruction of the seized package. (Lindey to Florence Rose, Jan. 25, 1933; MS to Ernst, Feb. 15, 1934; Rose to Ernst, Feb. 8, 1933; E.S. Hawkins to Greenbaum, Wolff &amp; Ernst, Feb. 8, 1933; Lindey to MS, Nov. 20, 1933 [LCM 60:185, 189, 202; <em>MSM</em> C5: 501, 712].) </p>

<p>In the meantime, as Sanger and Ernst continued to pursue other confiscations, Sanger focused her efforts on her legislative campaign in Washington, sharing the story of the Koyama pessary seizure with congressman as an example of how the law interfered with legitimate requests for medical supplies. Ernst and Lindey kept Sanger updated on the behind-the-scenes legal wrangling over the <em>One Package </em>case and prepared her for a long wait. &ldquo;Our experience has been,&rdquo; Lindey wrote, &ldquo;that red tape unwinds itself slowly.&rdquo; In 1935, after a number of procedural requirements and unspecified delays, the <em>United States v. One Package </em>case finally came to trial, nearly three years after the confiscation. </p>

<p>On December 10, 1935 Morris Ernst, a &ldquo;witty, tweedy, bow-tied man,&rdquo; as the <em>New York Times </em>later described him, came up against Assistant District Attorney John F. Davidson, a straight arrow just a few years out of Harvard Law. Judge Grover M. Moscowitz, a Coolidge appointee who had served on the U.S. Eastern District Court since 1925, presided. Apparently Moscowitz was a last minute replacement for Judge John Clark Knox, who had been criticized earlier in the year for his handling of a public obscenity case concerning Hedy Lamarr&rsquo;s nude swimming and sex scenes in the film <em>Ecstasy</em>.&rdquo; Knox called the controversial Czech film &ldquo;obscene, indecent, immoral and impure&rdquo; and ordered it destroyed. When the more progressive Moscowitz was named as the presiding judge, Ernst breathed a sigh of relief. (MS to Senator Warren Austin, Jan. 10, 1933; NCFLBC, Summary of Legal References, 1934; Lindey to Rose, Feb. 10, 1933 [LCM 20:1187, 60:106, 190]; NCFLBC Press Release, Dec. 9, 1935 [LCM 60:213]<em>;</em><em>New York Times</em>, May 23, 1976 and Aug. 8, 1935.) </p>

<p>Sanger, in India at the time, directed her secretary, Florence Rose, to observe the trial. Rose reported that the court room proceedings were anticlimactic as no one disputed the facts of the case. Hannah Stone admitted to being the recipient of the package and stated that the pessaries were intended for contraceptive use by patients with particular health indications. Ernst summarized the history of the Comstock Act and the case law pertaining to the illegality of birth control. He made no secret of the fact that he viewed this as a test case and assumed the decision would be appealed. His key statement to the court: &ldquo;There is a burden on the Government to prove that these articles were imported for an illicit use and not for a health use.&rdquo; Davidson countered that the question &ldquo;is not whether the statute is a good one or a bad one, but whether it has been violated.&rdquo; Ernst then proceeded to call a series of prominent doctors to the witness stand to testify that they regularly prescribed contraception &ldquo;to keep mothers and children and families healthy and free from disease.&rdquo; </p>

<p>Dr. Frederick C. Holden, among the most respected gynecologists in New York City, was Ernst&rsquo;s first expert witness. He advocated the use of birth control for child-spacing and for women who suffered from various health problems. Neurologist Foster Kennedy and Hannah Stone followed, echoing Holden&rsquo;s testimony. To save time, the court then accepted the &ldquo;blanket&rdquo; testimony of four other distinguished physicians who agreed with the other doctors&rsquo; statements. </p>

<p>The government called just one witness, Frederic Wolcott Bancroft, a leading New York surgeon. Curiously, his testimony supported Ernst&rsquo;s case. Bancroft readily admitted that he prescribed the diaphragm to address medical needs, including a number of diseases, neurological disorders, insanity, epilepsy and venereal disease. He went so far as to endorse child-spacing for health reasons. In her report on the trial, Florence Rose said that Bancroft was &ldquo;so helpful to our side that one wondered whose witness he really was!!&rdquo; Bancroft may also have been responsible for the most bizarre moment in the trial, as Rose recounted: </p>

<blockquote>
<p>&ldquo;. . . to the great entertainment of all present, including Hizzoner, Exhibit A, the pessaries in question, disappeared during the course of the trial, and great suspicion attached to Dr. Bancroft, last seen handling them, and who had left immediately after his testimony!&rdquo; (&ldquo;Transcript of Record,&rdquo;<em> U.S. v. One Package, containing 120, more or less, rubber pessaries to prevent conception</em>, 86 F. 2d 737, May 23, 1936 [<em>MSM</em> C15:550-87]; Rose to MS, Dec. 10, 1935 [<em>MSM</em> S10:767].) </p>
</blockquote>

<p>With the facts of the case accepted by both sides, the judge dismissed the jury after one day. Lawyers submitted additional briefs over the next week and then awaited the judge&rsquo;s ruling. On January 7, 1936, when Rose learned of the court&rsquo;s decision, she immediately sent off a telegram to Sanger, still traveling in Asia: </p>

<p>&ldquo;JAPANESE CASE VICTORY CONGRATULATIONS&rdquo; </p>

<p>In his decision Judge Moscowitz stated that the language in question in the Tariff Act could not be &ldquo;taken literally&rdquo; but must be given &ldquo;reasonable construction.&rdquo; Since the confiscated articles were imported by Hannah Stone for &ldquo;experimental purposes to determine their reliability and usefulness as contraceptives to cure or prevent disease, a lawful purpose, it must be held that the libeled articles do not come within the condemnation of the statute.&rdquo; (Rose to MS, Jan. 7, 1936 [LCM 135: 326]; <em>United States v. One Package</em>, 23 F. Supp. 334, E.D. N.Y. 1936, Jan. 6, 1936 [<em>MSM</em> S69:335].) </p>

<p>The government, as expected, appealed the decision, and in the fall of 1936 the case came before the U. S. Circuit Court of Appeals for the Second Circuit. In the interim, Sanger and her legal advisors, including Ernst, argued over the extent to which the Moscowitz decision provided protection against the Tariff Act and other birth control prohibitions. Sanger believed Ernst was far too confident in his assessment that the battle had for all intents and purposes been won, and that there was no need for a legislative remedy. She decided to wait for the higher court&rsquo;s decision before changing course. (Sanger to Charles Scribner, Apr. 24, 1936 [LCM 59:91].) </p>

<p>On Dec. 7, 1936, the appellate court upheld Moscowitz&rsquo;s decision. Judge Augustus Hand, in a sweeping opinion, addressed all of the Federal prohibitions that originated from the Comstock Act of 1873 as &ldquo;part of a continuous scheme to suppress immoral articles and obscene literature and should so far as possible be construed together and consistently. If this is done, the articles here in question ought not to be forfeited when not intended for an immoral purpose.&rdquo; Hand relied on several earlier decisions, most notably a trademark infringement case, <em>Young&rsquo;s Rubber Corporation v. C. I. Lee, Inc </em>(1930), which questioned the prohibition of contraceptives because they might be used illegally. In assessing the intention of Congress when it passed the Comstock Act, Hand wrote, &ldquo;Its design, in our opinion, was not to prevent the importation, sale, or carriage by mail of things which might intelligently be employed by conscientious and competent physicians for the purpose of saving life or promoting the well being of their patients.&rdquo; Ernst noted that &ldquo;nowhere in its opinion did the Court specifically state under what circumstances a doctor was free to prescribe a contraceptive. The inference was clear that the medical profession was to be sole judge of the propriety of a prescription in a given case, and that as long as a physician exercised his discretion in good faith the legality of his action was not to be questioned.&rdquo; Ernst declared that the decision &ldquo;means the end of birth control laws.&rdquo; <em>(United States v. One Package</em>, 86 F. 2nd 737, Dec. 7, 1936 [<em>MSM</em> S69:372]; Ernst and Lindey, <em>The Censor Marches On </em>[New York, 1940], 165.) </p>

<p>Sanger held off on grand victory statements until the attorney general announced in January 1937 that he would not appeal the case to the Supreme Court. She jubilantly told supporters: &ldquo;there is no further question as to the rights of the medical profession in regard to contraception,&rdquo; and exclaimed, &ldquo;The birth control movement is <em>free</em>.&rdquo; In April she shut down her Washington lobbying organization, and in June the American Medical Association cautiously endorsed doctor-prescribed contraception. (MS, &ldquo;Editorial,&rdquo; <em>National Birth Control News</em>, Feb. 1937, 3-4 [<em>MSM</em> C16:400].) </p>

<p>The <em>One Package </em>decision opened up the ports and mails to contraceptive trade and generally made it legal and acceptable for doctors to dispense birth control to married women. The Comstock laws remained on the books, but except in Connecticut and Massachusetts, law officials and the courts treated the anti-birth control measures as antiquated and irrelevant. It was not until 1970 that the federal obscenity law was overhauled and birth control removed. The decision marked the culmination of legal battles in the first half of the twentieth century over the legitimacy of birth control as medicine, and Justice Hand&rsquo;s liberal language and nod to common sense thinking paved the way for subsequent legal challenges that raised the ante and presumed a right to reproductive choice. It was, as Sanger wrote, the &ldquo;close of one epoch and dawn of another.&rdquo; (MS, &ldquo;A Momentous Decision,&rdquo; Dec. 1936 [<em>MSM</em> S71:876].)  </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
