
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #12 (Spring 1996)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #12 (Spring 1996)</h1>
<div class="maintext">
<h1>"The Passionate Friends: H. G. Wells and Margaret Sanger"</h1>

<p>     "From 1920 on I never went to England without spending part of the time with H. G.," wrote Margaret
Sanger in her 1938 <em>Autobiography</em>.   "England," she wrote upon the death of H. G. Wells fifty years ago this
August, "means London, and London means H. G. Wells" (Tribute to H. G. Wells, August 14, 1946, <em>MSM</em>
S83:611).  From the time they met in 1920 until his death,
Margaret Sanger and H. G. Wells carried on an infrequent, but
often fervent love affair, sustained a deep professional
friendship that particularly aided Sanger in her birth control
work, and maintained an overseas correspondence about love
and war, birth control and the Catholic Church, their travels,
and public scrutiny of their lives.</p>

<p>     Both were well known to the other in 1920 when they
met for the first time at Wells' Easton Glebe estate in Essex. 
Sanger had gained notoriety in England for her several birth
control publications and her work with the British neo-Malthusians, while H. G. Wells was enjoying the apex of his
popularity as distinguished author, social theorist, and spirited
polymath.  Wells had already become a public supporter of
Sanger's work.  In 1916 he signed a letter to Woodrow
Wilson, along with seven other prominent English supporters
of birth control, protesting the indictments against Sanger
stemming from her publication of the <em>Woman Rebel</em>.   </p>

<p>     Upon meeting Wells for the first time, Sanger felt
immediately at ease, somewhat surprised at Wells' affable
manner and graciousness. She later wrote: "There was no
aloofness or coldness in approaching him, no barriers to break
down as with most Englishmen; his twinkling eyes were like
those of a mischievous boy" (<em>Autobiography</em>, p. 268). Like
several of his English contemporaries including sex theorist, Havelock Ellis, newspaper editor and former member
of parliament, Harold Cox, and writer, Hugh de Selincourt, Wells' attraction to the charming and vivacious Sanger
was immediate and intense.  The two began an affair in 1920 that would rekindle each time they were alone,
whether in London, the south of France, or New York.  Wells was particularly forthright in his need to see Sanger,
writing on one occasion: "My plans in New York are ruled entirely by the wish to be with you as much as possible
&ndash; & as much as possible without other people about.  I don't mind paying thousands of dollars if I can get that."
He encouraged her to book a rendezvous apartment for them where he could see her "in the costume of a tropical
island   . . .   Everything else is secondary to this" (Wells to Sanger, December 1921, <em>MSM</em> S2:80).</p>

<p>     Their dedication to their work, hectic schedules, and liaisons with others, not to mention their
unconventional marriages &ndash; both Sanger and Wells asserted marital 
independence and experienced strained relations with their spouses &ndash; made it a challenge to meet alone for any
extended time.  Nevertheless, Sanger and Wells saw each other often in the 1920s during Sanger's numerous trips
to London, as well as  in New York and in Grasse, France.  It was during Sanger's extended stays in England in
1920 and 1921 that they spent their most concentrated time together.  Wells was so taken by Sanger and the
impressive alliance of mentors, lovers, colleagues and friends that she had developed in England that he based his
1922 novel, <em>Secret Places of the Heart</em>, on these memorable visits.</p>

 <p>    The thinly-veiled autobiographical novel depicts an English gentleman, Sir Richard Hardy (Wells), who
is attempting to sort out his marital problems while he travels
the English countryside in the company of a psychiatrist (based
loosely on Havelock Ellis).  Along the way, Hardy encounters
a confident and attractive young American woman named Miss
Grammont (Sanger) who is an avid supporter of birth control. 
The semi-fictional triumvirate of the sexually troubled
protagonist, his Freudian doctor and the independent, alluring,
self-assured American woman, offered Wells an opportunity to
discuss the topics of sexuality, marriage, love, and jealousy:
themes that drive many of his other novels and
autobiographical works. <em>Secret Places of the Heart</em> also served
as a kind of extended love letter from Wells to Sanger in lieu
of the actual thing (his letters were usually brief and
informational).  Late in the book, the protagonist Hardy
characterized his affair with Grammont; it could just as well
have been Wells writing to Sanger:</p>

<blockquote>
 <p>     We have to carry the whole affair on to a Higher
     Plane &ndash; and keep it there.  We two love one another
     &ndash; that has to be admitted now.  . . . But we two are
     too high, our aims and work and obligations are too
     high for any ordinary love making. That sort of thing
     would embarrass us, would spoil everything (<em>Secret
     Places of the Heart</em>, p. 229).</p>
</blockquote>

<p>     Of course the novel dwells on the impossibility of such
an affair surviving in a world encumbered by a more earthly
love, bound by obligations.  Yet Wells rejoices in physical
pleasure, and finds many opportunities in this novel to express
ideas about free-love and sexuality that resemble passages in both Sanger's and Ellis' writings.  Near the end of the
book he writes:</p>

<blockquote>
<p>    It is wonderful enough that we should take food and drink and turn them into imagination, invention and
     creative energy; it is still more wonderful that we should take an animal urging and turn it into a light to
     discover beauty and an impulse towards the utmost achievements of which we are capable (<em>Secret Places
     of the Heart</em>, p. 250-251).
</p>
</blockquote>

<p>     By the 1930s, age, ill health and less frequent
traveling curtailed the physical element of their friendship. 
Increasingly, Sanger looked to Wells for professional support. Wells had written the preface to Sanger's <em>Pivot of
Civilization</em> in 1922 and lent his name to various conferences and fund-raising events.  In 1931, Sanger asked him,
as one of the most celebrated and stately figures of the day, to help launch her national lobbying campaign, the
National Committee on Federal Legislation for Birth Control.  She organized a dinner in Wells' name and succeeded
in eliciting generous praise from him along with attracting significant contributions to her cause.  Wells said of
Sanger in his keynote speech: "She is the greatest woman in the world; the movement she started will grow to be,
a hundred years from now, the most influential of all time in controlling man's destiny on earth" (Address at H.
G. Wells Dinner, included in Quotations About Margaret Sanger by Notable Persons, <em>MSM</em> S77:243).</p>

<p>     During a 1937 meeting, the two found themselves uncharacteristically preoccupied with their ailments and
mortality, rather than the passions of work and play.  Wells later wrote Sanger:</p>

<blockquote>
<p>      
 ". . . Last spring I had neuritis very badly & had my doubts whether the fag end of life is worth living. 
     But people like you & I have so many people getting a sort of courage to live out of us, weak as we may
     be in reality, that we cannot afford to [do] anything but live with the utmost apparent stoutness to the end. 
     I can tell you now that I have loved you very deeply ever since I met you first and I always shall" (H. G.
     Wells to Margaret Sanger, November 4, 1937, <em>MSM</em> S13:760).</p>
</blockquote>

<p>     While there are many letters from Wells, relatively few of Sanger's letters to him have survived, and much
of the correspondence after the 1920s is impersonal and written by secretaries.  But following this 1937 meeting,
and for the next several years, they wrote to each other more frequently. Their correspondence now seemed to dwell
more on war and the Catholic Church than their own relationship or past.  The two disagreed over American
involvement in the war, with Wells, like so many of Sanger's European friends, arguing for U.S. intervention, while
Sanger clung to an uneasy neutrality until the Pearl Harbor bombing.  They found common ground, however, in
sharing a paranoid fear of a monolithic Catholic Church that had surreptitiously pulled the levers that started the
war.  Wells' diatribe against the Roman Catholic Church, <em>Crux Ansata,</em> published in 1943, brought forth fierce
attacks from Catholics and many in the press, but inspired Sanger to keep up her own battles with the Church.  She
applauded H. G. for having the courage to speak out on an issue others shied away from: "We can bang the
Methodists, and shout down the Jehovah's Witnesses, jail them and torture them for their religion, but not a word
can be said against the Roman Catholics.  More Power to you, dear H. G." (Sanger to Wells, February 9, 1944,
<em>MSM</em> C7:608).</p>

<p>     In August of 1946 at the age of 79, H. G. Wells died after a lengthy illness.  It was a dark time for Sanger
who had lost several friends during the war, her husband three years earlier, and was herself suffering from angina
and several other health problems.  The day after Wells died, on the eve of Sanger's historic trip to Stockholm to
participate in a family planning conference, she wrote him a final letter in a tired, messy scrawl.  She mentioned
how difficult it will be for her to travel to London and not see her dear friend.  She regretted that they had not
discussed "our hearafter," and commented that of all people, maybe H. G. "would endeavor to explore the
possibilities of communication with me." She sketched out some memories: a hat she bought for him, "the wrong
one?", and their many "wonderful talks  . . . about women, your women, your loves &ndash; my loves &ndash; our love &ndash;
always we met & picked up the thread of our
last meeting & wove again a friendship which
has endured ever since . . . " (Tribute to H. G.
Wells, August 14, 1946, <em>MSM</em> S83:611).</p>

<p>     In her remaining years Sanger often quoted Wells, and turned his tributes to her into a definitive
authorization of her work.  When supporters sent quotations praising Sanger to the Nobel Committee in Stockholm
in an unsuccessful nomination effort for the Peace Prize, Wells' words resonated above all others: "When the
history of our civilization is written, it will be a biological history and Margaret Sanger will be its heroine" (from
a 1935 speech at Barber's Hall, London, included in <em>Round the World for Birth Control</em>,  Birth Control
International Information Centre, 1937, <em>MSM</em> S62:598).</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
