
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #27 (Spring 2001)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #27 (Spring 2001)</h1>			

<div class="maintext">			
<h1>"The Town Hall Raid"</h1>

<p>This year marks the 80th anniversary of the police suppression of the
November 13, 1921 public birth control meeting at the Town Hall theater
in Manhattan, an event that roused New York's libertarian upper crust to
actively support Margaret Sanger and created a windfall of publicity for
birth control.  The most sensational of several attempts on the part
of the Catholic Church to thwart and silence Sanger in the 1920s, the Town
Hall raid played in the press as though it was orchestrated by Sanger herself,
complete with police bungling and the moral hubris of a Roman Catholic
Archbishop.</p>

<p> Sanger planned the Town Hall meeting as the culmination of the
First American Birth Control Conference (November 10-13), an historic gathering
of prominent scientists, physicians, demographers  and eugenicists,
as well as social workers, birth control advocates and socialites to discuss
the global ramifications of birth control and its potential to lessen the
major social ills of the world.  The conference also launched the
American Birth Control League (ABCL) to promote birth control through education
and lobbying. Sanger invited her English friend Harold Cox, former member
of Parliament and editor of the Edinburgh Review, to present the keynote
address, "<a href="../documents/speech_morality_and_bc.php">Morality and Birth Control</a>," at the concluding public forum.</p>

<p> However, Police Captain Thomas Donahue ordered the doors to the
Town Hall theater locked just minutes before the meeting was to begin. 
When police were forced to unlock the doors a short time later to let out
the crowd that had already gathered in the hall, many outside, including
Sanger, burst in.  Sanger quickly took the podium, and when she began
to speak,  Donahue ordered her arrest. Other activists then sought
the stage, and one of them, Mary Winsor, a member of the new ABCL National
Council, was also arrested.  Police escorted the two women out of
the hall while the audience sang "My Country ‘Tis of Thee."  A "hatless"
Sanger (nearly a crime itself at the time), and Winsor were brought to
the Police Court followed by a large crowd of supporters, and charged with
disorderly conduct. They were discharged soon after for lack of evidence.  "I consider my arrest," Sanger said upon leaving the police station, "in
violation of every principle of liberty that America stands for, and I
shall take this case to the highest courts, if necessary, to preclude the
possibility of it ever happening again." (<em>New York Times</em>, November
14, 1921)</p>

<p> The incident escalated in the press when it was reported that
the New York Archdiocese had pressured the police to shut the meeting down. 
A representative of  Archbishop Patrick J. Hayes telephoned police
headquarters shortly before the meeting, and the Archbishop sent his secretary,
Monsignor Joseph P. Dineen, to meet with Captain Donahue.  Hayes had
perhaps acted in response to Sanger's invitation to attend the forum; she
had  hoped a Church official would rebut her claim that birth control
was moral and engage in a healthy public debate.  Sanger may have
also recognized the greater potential for Church interference, and the
subsequent publicity such interference guaranteed,  if she flaunted
the proposed theme of the meeting in a personal invitation to Hayes.</p>
<p> Dineen defended the suppression in the daily papers: "Decent and
clean-minded people would not discuss a subject such as birth control in
public before children [he claimed four children were present at the meeting;
they turned out to be four Barnard College students with "bobbed hair and
short skirts"] or at all."  The police action was necessary, he added,
because  birth control "attacks the very foundations of human society."
(<em>New York Times</em>, November 15, 1921) Archbishop Hayes issued a statement
a week letter claiming that "The laws of God and man, science, public policy,
human experience are all condemnatory of birth control as preached by a
few irresponsible individuals. . . ."  He then referred to the recent
Eugenics conference in New York as evidence of a scientific repudiation
of birth control, as it promoted the fertility of the "better born." 
He even went so far as to recite a startling anti-Christian, eugenic directive
that "more children from the well-to-do" was a "moral duty." (<em>New York
Times</em>, November 21, 1921) Although  Dineen and Hayes admitted
that a call was placed to the police in opposition to the meeting, they
refused to acknowledge their power to guide or manipulate the police department.</p>
<p> All of New York City's dailies and several magazines, including
the New Republic and The Nation, expressed outrage over police efforts
to restrict free-speech, and criticized Archbishop Hayes for provoking
the raid.  Many prominent New Yorkers, enraged by the assault on free
speech, signed a petition to the police commissioner protesting the suppression
and arrests.  A formal complaint, signed by Sanger's lawyer, Robert
Marsh, the ACLU, several physicians and a number of conference committee
members, and submitted on November 15,  helped initiate a police investigation
into the raid.  On November 22, Chief Inspector William J. Lahey interviewed
several witnesses, including Sanger and Juliet Rublee, the wealthy wife
of attorney and presidential advisor George Rublee.  Juliet Rublee,
one of Sanger's closest friends and a key financial supporter of the birth
control movement, had witnessed the raid and accompanied Sanger and Winsor
to police court.  When Rublee stated in her testimony that she had
read section 1142 of the Penal Code (prohibiting the dissemination of obscene
material or information, including contraception), and disagreed with it,
Assistant Corporation Counsel Martin Dolphin directed his secretary and
stenographer, officer Thomas J. Murphy, to arrest Rublee for violating
the section of the law in question. After four hours in custody, Rublee
was discharged by a magistrate for lack of evidence.  Afterward Rublee
told a reporter: "This is nothing but an attempt at intimidation, but I
do not frighten easily.  If I did, the post card I recently received
would be disquieting.  It was one of several of similar import, but
this one said unless I cease my attacks on Mgr. Dineen and the Roman Catholic
Church I would be killed.  I am not killed, you see; I am merely arrested,
and &ndash; I am not intimidated the least little bit. ( <em>The World</em>,
Dec. 3, 1921)</p>

<p> Rublee's arrest inflamed the controversy over the Catholic Church's
role in police affairs and prompted questions regarding the competency
of police brass.  It also insured a new round of press coverage of
Sanger and birth control, and  prompted a letter to Mayor John F.
Hylan from ten prominent New Yorkers, including attorneys Paul Cravath
and Lewis Delafield, financier Paul Warburg and banker/diplomat Henry Morgenthau,
requesting an investigation into the Town Hall raid and the police treatment
of Rublee.  Commissioner of Accounts David Hirshfield, who  took
over the police investigation,  later admitted that Rublee's arrest
was the result of a "lawyer's mistake," and criticized Captain Donahue
for showing "a lack of intelligence" in ordering the initial arrests of
Sanger and Winsor.  But he discounted any influence exerted on the
police department by the Catholic Church and failed to reprimand the police.</p>

<p> The  mass meeting to discuss "Birth Control &ndash; Is It Moral?"
was rescheduled for November 18 at the Park Theater.  Once again Sanger
invited Archbishop Hayes, along with Catholic University sociologist, Monsignor
John A. Ryan, and John Sumner, head of the Society for the Suppression
of Vice. Only Hayes sent a representative.  The meeting took place
without incident.</p>

<p> Sanger later noted that the Town Hall raid gave her "column after
column" of free publicity with little effort on her part since "the blundering
of the opposition . . . saved my voice." (<em>Autobiography</em>, 309). 
The suppression drew prominent socialite women from some of the wealthiest
and most powerful New York families, including Florence Haskell Corliss
Lamont, Elizabeth Cutter Morrow and Addie Wolff Kahn, to the defense of
the ABCL, effectively christening the new organization as a slightly dangerous,
cutting-edge women's club and insuring adequate financial support and ample
political clout, at least in the short term. The controversy also pulled
back the curtain on a Catholic conspiracy against birth control, glimpsed
by Sanger in previous years, but never so brazen and overt as the Town
Hall raid.  Sanger would refer back to the raid in the years to come
whenever she needed to illustrate the Church's influence over political
leaders and municipalities. For Sanger the whole episode marked a transition
in birth control opposition, and therefore required new strategies and
alliances that began almost immediately after the conference.  No
longer was the government or the specter of Anthony Comstock the chief
enemy of birth control; in Sanger's words "It was now a battle of a republic
against the machinations of the hierarchy of the Roman Catholic Church."
(<em>My Fight For Birth Control</em>, 237)</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
