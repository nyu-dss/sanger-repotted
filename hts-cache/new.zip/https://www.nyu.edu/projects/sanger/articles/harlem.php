
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #54 (Spring 2010)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #54 (Spring 2010)</h1>
<div class="maintext">
<h1>"Looking Uptown: Margaret Sanger and the Harlem Branch Birth Control Clinic"</h1>

<p>
<em>From time to time we publish articles submitted to the Newsletter that are not written by the MSPP staff. In this issue, we are pleased to present an article by Wangui Muigai, who graduated cum laude in 2009 from Harvard College. Ms. Muigai majored in history and science and received the Hoopes prize for her senior honors thesis, &ldquo;The New Emancipation: Birth Control in the Black Community and the Story of the Harlem Branch Birth Control Clinic.&rdquo; She lives and works in New York City. To contact the author, email her at <a href="mailto:wangui.mugai@gmail.com">wangui dot muigai at gmail dot com</a>.</em>
</p>

<p><em>Does contraception cause sterility? </em></p>
<p><em>Is it necessary to have your husband&rsquo;s consent to come to the clinic? </em></p>
<p><em>Is it a fact that if you have only one ovary that you cannot become pregnant? </em></p>
<p><em>If you have ovaries and not tubes can you become pregnant? </em></p>
<p><em>If you have had a hard time with the first baby and the doctor says it is dangerous for you to have another, is that true or just a saying? </em></p>
<p>These are some of the twenty-five questions that black women asked Dr. Marie Levinson, the head doctor for Margaret Sanger&rsquo;s Harlem Branch Birth Control Clinic, after listening to her birth control lecture in Harlem on January 26, 1933. Levinson gave nearly thirty lectures throughout Harlem to audiences ranging from doctors to the general public. This all-female audience assembled before Dr. Levinson showed considerable interest in contraception, and their questions reflected a range of fears and misunderstandings about reproduction. </p>
<p>Through the clinic&rsquo;s work, Harlem women were able to obtain effective contraception and receive authoritative reproductive information in their neighborhood. (&ldquo;Questions Asked After Lecture by Dr. Levinson at New York Urban League,&rdquo; Jan. 26, 1933; &ldquo;Lectures,&rdquo; Dec. 1, 1932-Dec. 1, 1933,&rdquo; [LCM 33:123, 172].) </p>
<p>In the late 1920s, when Sanger looked into opening a clinic in Harlem, the area was nearing the end of its golden Renaissance and struggling with the first effects of the Great Depression. The neighborhood&rsquo;s rates of unemployment, venereal disease, and infant and maternal mortality were all higher than in any other New York City neighborhood. A variety of programs set out to respond to these public health issues, and Sanger identified an opportunity to provide birth control services. (&ldquo;Infant Mortality Rate &amp; Maternal Mortality Rate for New York City and Central Harlem 1934-1940 (per 1000 births).&rdquo; Bureau of Records Reports, Central Statistical Division, Department of Health, New York City.) </p>
<p>She had tried and failed once before in operating a clinic in a black neighborhood. The Clinical Research Bureau (CRB) in downtown Manhattan opened in 1923, and its success inspired a few satellite branches in the city. In 1924, in conjunction with the New York Urban League, the black civil rights organization, Sanger established a small clinic in the largely black Columbus Hill neighborhood, on the west side of midtown. The clinic was one part of a larger effort by social reformers to address the problem of disproportionate black maternal mortality. However, records indicated that in this &ldquo;congested colored district . . . the number of patients applying for advice at this Clinic was rather small, and after a few months it was found advisable to discontinue it for the present.&rdquo; While there are no explanations provided for the low patient turnout, Columbus Hill was in transition, with many African-Americans moving out and resettling in Harlem and elsewhere. The clinic&rsquo;s failure may have also reflected the organizers&rsquo; inability to engage community leaders. (Carole R McCann, <em>Birth Control Politics in the United States, 1916-1945</em>, [Ithaca, 1994], 139; Hannah M. Stone, &ldquo;Report of the CRB of the ABCL for the Year of 1925&rdquo; [<em>MSM</em> S61:185].) </p>
<p>With the Columbus Hill clinic closed and few other affordable alternatives, Harlem women were forced to travel downtown to the CRB for reproductive care. Nearly 2,000 of the 17,000 women registered at the downtown CRB resided in Harlem, and their presence in the CRB at times made white patients uncomfortable. In one letter Sanger noted, &ldquo;if already three or four colored women are in the waiting room of the clinic, we have to distribute them to the upstairs doctors and sometimes postpone the visit of others so it will not look like a colored clinic . . . other patients are inclined to grumble.&rdquo; (&ldquo;Open Birth Control Clinical Bureau in Harlem,&rdquo; <em>New York Amsterdam News</em>, April 16 1930; MS to Morris Waldman, July 2, 1929 [LCM 31:212].) </p>
<p>Sanger remained convinced, despite the failure of the Columbus Hill facility, that another Manhattan clinic was needed to better handle the diversity and influx of women requesting services. In October of 1929 she met with James Hubert, executive secretary of the New York Urban League, to discuss opening a Harlem branch. Sanger wanted to ensure that this time there was strong demand and community support. Likewise, Hubert was aware that many of his colleagues were discussing the advantages of promoting birth control within the black community, and he was keen on having Harlem serve as the pioneer site for this endeavor. They agreed to move forward, and plans were headlined in New York&rsquo;s leading black newspaper, the <em>New York Amsterdam News</em>: &ldquo;Mrs. Margaret Sanger&rsquo;s Move Assures Birth Control Clinic for Harlemites.&rdquo; (<em>New York Amsterdam News</em>, Oct. 16, 1929; McCann, <em>Birth Control Politics, </em>139.) </p>
<p>With the move announced, Sanger searched for funding. This stage of the project was especially difficult given that the clinic was created in the midst of the Depression. After tapping a wide network of supporters, organizations, and philanthropists, Sanger secured funding from three sources. Caroline Bamberger Fuld, of the Bamberger Department Store family and the recent widow of philanthropist Felix Fuld, gave $3,000; the CRB (now renamed the Birth Control Clinical Research Bureau &ndash; BCCRB) Board of Managers contributed $2,000; and the Chicago-based Rosenwald Fund, established by the Sears-Roebuck magnate, Julius Rosenwald, a well-known sponsor of social and health projects in black communities across the country, donated $10,000. (MS to Edwin Embree Oct. 17, 1929 [LCM 31:173B]; Edwin Embree, &ldquo;Annual Reviews 1928-1946,&rdquo; <em>Julius Rosenwald Fund</em> [Chicago], 28-29.)</p>
<p>In choosing who would manage the clinic, Sanger and Hubert knew they needed to engage local leaders if they wanted the clinic to be received as a legitimate and inclusive establishment. She was well aware that in envisioning a venture uptown, a heavy handed, outsider&rsquo;s approach to running a clinic would never work within Harlem&rsquo;s well-established black community. A history of scientific racism, medical experimentation, and segregation made blacks wary of medical institutions and those running them. The clinic would need to be sensitive to such fears if it sought to gain the people&rsquo;s trust. (Rosemary Stevens, <em>In Sickness and In Wealth: American Hospitals in the Twentieth Century</em>, [New York, Basic Books, 1989], 9-10, 137-138.) </p>
<p>Unlike the BCCRB&rsquo;s other branches, the Harlem branch had a separate Advisory Council and medical staff. The fifteen Advisory Council members were all black; people handpicked by Sanger and Hubert as representative of the community. But this was not a board of medical professionals. Some council members had such limited knowledge about birth control that a special pamphlet was created in order to educate them. The board included May Edward Chinn, Harlem&rsquo;s only black female doctor at the time; Mabel Keaton Staupers, Director of the National Association of Colored Graduate Nurses; Dr. Howard Ellis<strong>, </strong>chief of Mental Hygiene at Harlem Hospital and later part of the clinic&rsquo;s medical staff; and Dr. William Lloyd Imes, pastor of St. James Presbyterian Church. (M.O. Bousfield to Michael M. Davis, Rosenwald Fund, Apr. 9, 1932, [LCM 31:199]<strong>; </strong>May Edward Chinn Papers, Box 2, Schomburg Center for Research in Black Culture, New York Public Library.) </p>
<p>Sanger was also keen on seeking support from local ministers &ndash; a group usually unsupportive of birth control. Black ministers in Harlem, however, considered birth control to be connected to larger visions for community development. The three biggest Harlem churches&ndash; Abyssinian Baptist Church, St. James Presbyterian, and St. Philip&rsquo;s Protestant Episcopal &ndash; which had over 16,000 members combined, had great influence over their congregations. Sanger and Dr. Levinson made use of these local institutions by inviting pastors to serve on the Advisory Council and using churches as locations for public lectures. The 1933 Mother&rsquo;s Day service at Abyssinian even included a &ldquo;sermon&rdquo; by Sanger entitled &ldquo;Is Motherhood Sacred?&rdquo; (Linda Gordon, <em>Woman&rsquo;s Body, Woman&rsquo;s Right: A Social History of Birth Control in America</em>, [New York, 1990], 332-333; Helen V. Davis to Advisory Board, Harlem Clinic, May 11, 1933 [LCM 32:603].) </p>
<p>While focusing their efforts towards building an all-black Advisory Council, however, Sanger and Hubert overlooked the importance of including blacks in the clinic&rsquo;s medical staff. Only after receiving a letter in 1932 from a local social worker expressing &ldquo;the hope of our Harlem group that you are going to be able to add one or more Negro workers to your staff in our community sometime in the near future,&rdquo; were immediate plans made to add a black physician and nurses to the staff. (Emmy Jenkins to MS Jul. 23, 1932, [LCM 32: 523].) </p>
<p>Within its first sixteen months, nearly three thousand mostly poor and working class women walked through the doors of the Harlem clinic on 7 th Avenue, near 138 th Street. As part of the clinic&rsquo;s services, women were given a diaphragm and jelly and instructed in its proper use. From its inception, the clinic served a diverse female population, including American-born and immigrant blacks and a surprising number of white women. Hubert did not want the clinic to be restricted to black patients for fear of it being perceived as a second-rate institution. Three-quarters of the women identified as Protestant, and the remaining quarter as Catholic. Foreign-born blacks, many from the British West Indies, visited the Harlem branch and other branches in slightly greater numbers than American-born blacks. In a study run by the BCCRB that analyzed ten thousand of its cases from 1925-1929, of the 321 black patients included in the study, 189 were foreign born. </p>
<p>White women were an unexpected patient population that made use of the clinic, sometimes in greater numbers than blacks. Of the 342 new cases at the Harlem clinic in June 1931, for example, 58 percent were white patients and 42 percent black. Some of the white patients were Harlem residents. Others traveled from other parts of the city to visit the clinic, possibly because they found the location more convenient and appreciated the shorter waiting time compared to the downtown branch. Since all of the BCCRB clinics asked women to pay only what they could, the actual cost for contraceptive services would not have been a major obstacle. (Norman E. Himes, &ldquo;Birth Control in Historical and Clinical Perspective,&rdquo; <em>Annals of the American Academy of Political and Social Science</em>, [1932]: 57; Willa Murray to MS Apr. 11, 1933, [LCM 32: 538A]; Marie Pichel [Levinson] Warner, &ldquo;Birth Control and the Negro,&rdquo; in BCCRB Progress Report, June 1935 [<em>MSM</em> S61:790]; and Warner, &ldquo;Response to &lsquo;TB Among Negroes&rsquo; by Dr. C. St. C. Guild,&rdquo; July 1933 [LCM 32:428]; Marie E. Kopp, <em>Birth Control Practice: Analysis of Ten Thousand Case Histories of the Birth Control Clinical Research Bureau</em>, [New York, 1933], 49-50.) </p>
<p>The clinic promoted the use of safe contraceptives within a diverse population, and also enabled new research opportunities. The BCCRB collected extensive data on white and black women, some of which helped disprove racist ideas that black women did not know how to properly use contraception. A report by Levinson stated, &ldquo;the Harlem Branch found that both negro and white women learned and applied the clinic birth control methods equally well and with 95% success in the cases which continued to use the methods prescribed for them. This was much more than was reported from any other methods used before coming to the Clinic.&rdquo; The clinic&rsquo;s data collection is unique among the majority of fertility studies done from the 1920s to the1950s, as most demographic studies tended to exclude black samples and focus on white females. (Warner, &ldquo;Birth Control and the Negro&rdquo;; Joseph A. McFalls Jr. and George S. Masnick, &ldquo;Birth Control and the Fertility of the U.S. Black Population, 1880-1980,&rdquo; <em>Journal of Family History</em> 6 [Spring 1981]: 90.) </p>
<p>A sample of the clinic&rsquo;s records includes patient profiles such as the following: </p>
<p align="center">Case # 22130 <br>
28 years of age <br>
Husband ill &ndash; unemployed 4 months <br>
3 living children; 1 dead; 2 miscarriages <br></p>

<p align="center">Case #22156 <br>
38 years of age <br>
Husband unemployed all winter. Income $10 week. <br>
Salvation Army gives $2 a week for food <br>
7 living children; 2 miscarriages </p>
<p align="center">(&ldquo;A Few of Many Desperate Cases Coming to Our Clinic,&rdquo; [LCM 33:316].) </p>
<p>The Harlem clinic staff and council were well aware of the economic pressures facing their patients. Two-thirds of black women in Harlem worked, which was four times higher than for American-born whites. In 1931, 38 percent of all the women regardless of race were unemployed. The average income of patients was $16.00 a week to support a family of five. In 1932 the prices of contraceptives were reduced for black women only, in an effort to lower the economic barriers that kept many Harlemites from considering the clinic as an affordable service. While the fee was always voluntary, news of the lowered prices may have helped to attract black women who did not know about the clinic&rsquo;s payment options. Sixty-five percent of black women were unable to afford any financial contribution. (Ira de Augustine Reid, &ldquo;Twenty-four Hundred Negro Families in Harlem,&rdquo; May 1927, 25, Microfilm Sc R3612, Schomburg Archives; Elizabeth Lautermilch, &ldquo;Suggestions Approved by Mrs. Sanger: New Program for Harlem Branch,&rdquo; Oct. 18, 1932 [LCM 33:57].) </p>
<p>From the time the Advisory Council first met, members deliberated whether to change the clinic&rsquo;s name from &ldquo;Research Bureau&rdquo; to &ldquo;Birth Control Research Bureau.&rdquo; Some argued there was no need to camouflage the clinic&rsquo;s work and that the new name would help patients locate the clinic. For women coming from poorer backgrounds, the revised name may have assuaged fears of the clinic conducting medical &ldquo;research&rdquo; on them, which they may have associated with illicit medical experimentation. And as the opening questions demonstrate, concerns that contraception caused sterility were prevalent among many poor and less educated people. In response, pamphlets were made for the Harlem branch that added the word &ldquo;harmless&rdquo; in front of its definition of birth control as a &ldquo;method of avoiding conception by preventing the union of the male sperm and the female sperm.&rdquo; The pamphlets also included an additional section distinguishing birth control from sterilization. It reiterated that birth control &ldquo;is merely a temporary means of preventing undesired pregnancies. It never affects the ability of the mother to have children when she so desires.&rdquo; The clinic&rsquo;s name was eventually changed, and in 1932 it relocated to the New York Urban League Building on 136 th Street, a more visible location. (Advisory Council Meeting Minutes, June 17, 1931, [LCM 33:177] [quote 1]; Dr. Wilbur Drake, &ldquo;The Gynecologist: Some of His Problems and His Obligation to the Present and Future,&rdquo; <em>Journal of the National Medical Association</em> 12 [Jan.-Mar.,1920]: 18; Warner, &ldquo;Birth Control and the Negro,&rdquo; [quotes 2 and 3].) </p>
<p>Such sensitivity to fears of experimentation and sterilization reveal that Sanger and the BCCRB were willing to respond to the community&rsquo;s birth control needs without sticking to preconceived notions of how birth control should be defined or who should have access to contraception. In one letter Sanger wrote, &ldquo;all that I wish to be certain of is that the Harlem Birth Control clinic will be maintained and financed, not for a year or two years but as long as there is demand on the part of colored people for Birth Control information.&rdquo; Sanger did not want another short-lived black clinic like the one that briefly existed in Columbus Hill. (MS to Allison Pierce Moore, June 21, 1935, [LCM 31:379].) </p>
<p>Despite a regular clientele and its enthusiastic reception by leading black intelligentsia, such as W.E.B. DuBois and Charles Johnson, by 1935 the clinic&rsquo;s financial support had dwindled to a point that left its future in serious question. With Sanger&rsquo;s approval, in June the clinic was turned over to the Committee of Mothers Health Centers, a group under the American Birth Control League. After closing for a few months, it re-opened as the Urban League Mother&rsquo;s Health Center. The clinic stayed open until at least 1945. (McCann, <em>Birth Control Politics</em>, 159; Invitation, New York City Committee on Mother&rsquo;s Health, commemoration of ten years of service in Harlem, 1945, Florence Rose Papers, Sophia Smith Collection.) </p>
<p>From the upper levels of management down to the patients, who were more often poor than black, the Harlem clinic was an atypical endeavor. It brought together white reformers, black community activists, and medical professionals, all of whom were concerned about the health and wellbeing of black women and by extension, the community. Such collaboration was rare, not only in the 1930s birth control movement, but also in larger public health reforms of the time. Sanger succeeded in proving that blacks sought safe and effective birth control, and that a community-based approach was the best way to insure their access to it. </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
