
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #43 (Fall 2006)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #43 (Fall 2006)</h1>
<div class="maintext">
<h1>"Sanger's Second Act, Scene One: The Stockholm Conference"</h1>			

<p>This August marked the sixtieth anniversary of the 1946 annual conference in Stockholm of the Riksförbundet för Sexuell Upplysning (RFSU), the Swedish National League for Sex Education.  A modest event, it is only briefly covered in histories of family planning and would have been forgettable if not for the foresight of Sweden's pioneering sex reformer, Elise Ottesen-Jensen, and the attendance of the semi-retired, sixty-six-year-old American birth control leader, Margaret Sanger. Together, these two dynamic women set in motion a series of meetings and conferences that rallied together dedicated workers of the prewar birth control movement in Europe and the United States with a new generation of activists to establish what would become the International Planned Parenthood Federation.</p>

<p>The Stockholm conference was planned initially to be a regional gathering to address issues of sex education, marital adjustment and birth control in theprogressive and  prosperous postwar Sweden.  But the Norwegian-born Ottesen-Jensen, the founder of the RFSU, recognized the need  to reestablish links withinternational sex reform and family planning organizations.  She understood that the pre-war leaders in birth control and sex reform, Germany, Britain and Holland, devastated by the war, could not take the initiative in rebuilding international contacts.   A former member of the World League for Sexual Reform,the peripatetic Ottesen-Jensen spoke wherever she could on spreading the gospel of sexual knowledge and was keen to extend her ideas and programs outside of the Scandinavian countries.  As early as November 1945, with much of Europe still digging out from the war, Ottesen-Jensen sent out feelers to representatives from the U.S., England and Western Europe.  (Elise Ottesen-Jensen to Elna Orrman and MS, Nov. 20, 1945 [<em>MSM</em> S25:262].)</p>

<p>At the time, Sanger was rejoicing in the safe return of her two sons from overseas outposts where they had served as military doctors. Widowed in 1943 and living in Tucson, she spent many of her days in the company of young grandchildren, or painting in the Arizona desert, or readying Willowlake, her Fishkill, New York estate, for sale.  As honorary chairman of the Planned Parenthood Federation of America (PPFA), she buzzed in and out of the office when she was in New York, overseeing a few pet projects and lending her name for fund-raising campaigns, but had little to do with the daily work of the movement.   On the international front, she was just getting back in touch with friends abroad  - many of them still suffering under shortages and rationing and sending them food and clothing.  But she had not yet considered postwar plans for birth control.  There was little money and few resources from which to rebuild the devastated birth control and population organizations in Europe. The London-based Birth Control International Information Centre (BCIIC), established by Sanger and British colleague Edith How-Martyn in 1930, had merged with the British Family Planning Association in 1938, but little had been accomplished in Europe since the outbreak of war.  The movement had been effaced in Germany, Austria and Italy and pushed aside in England, France and Holland.   Projects introduced by Sanger and the BCIIC in India and other parts of Asia in the 1930s had largely been put on hold.</p>

<p>Sanger paid little notice to the proposal for an expanded RFSU conference, for birth control had always been incidental to Ottesen-Jensen's true passion - sex education.  Then Abraham Stone, the director of the Margaret Sanger Research Bureau (MSRB) in New York, convinced Sanger that Ottesen-Jensen looked to "formulate a program for an international organization on problems of population, population control and sex guidance in general.  Most of the people who will be present, I believe, will be those who have been associated with the birth control work in one form or another and there will therefore be a special interest in this phase of the work."  Sanger remembered Ottesen-Jensen, who had attended a conference in the U.S. before the war, as "screamingly funny with her extraordinary dictionary English."  Pleased that birth control would be featured, she applied for a passport and talked her good friend, Dorothy Brush, who had a growing interest in international work, into accompanying her, along with Stone and Dr. Lena Levine from the MSRB. (Abraham Stone to MS, July 2, 1946 and MS to Brush, July 9, 1946 [<em>MSM</em> S25:872 and 891].)</p>

<p>Uncharacteristically, Sanger said little about her expectations for the conference and appeared to view Stockholm as the first leg of a vacation that would end with a happy sojourn in England to check on old friends.  But her spirits were dashed just days before departing when she learned of the death of H. G. Wells, her old lover and intellectual sounding board for the past twenty-five years.  While in London she had planned to see Wells, the one person she trusted to make sense of the postwar landscape in Europe, the fledgling United Nations and the state of affairs in the Soviet Union.</p>

<p>Once she and Brush were en route, however, Sanger's disposition brightened.  Brush remembered them feeling as if they were "two room-mates in college."  They laughed when the Swedish customs official asked Sanger's age and noted that it was not the same as what was listed on her passport.  "Oh, isn't it?" Sanger replied, "I'm sorry, but then you know it never is."  A mix-up in accommodations landed them in "an amusing Swedish pension . . . a tiny room with two cots, a big porcelain stove like those in Hans Andersen and a rubber tree on which we hung our stocking to dry at night." They giggled at a noisy elevator labeled "Hiss," and even found humor in the communal bathroom that at first they assumed was for them alone until a strange man walked in on Sanger taking a sponge bath. (Dorothy Brush, "Margaret Sanger," undated and unpublished manuscript [Brush Papers, Sophia Smith Collection, Smith College].)</p>

<p>The conference, held on August 23-24, attracted about 250 delegates, but only a fifth of them expressed a strong interest in international work; most were there to cover regional issues. Representatives attended from the three Scandinavian countries, the U. S., Britain, Holland and Denmark, a limited group but sufficient in size and standing to warrant turning an entire day over to international concerns.  A few formal papers were given but delegates mainly spoke about the current state of family planning and sex education programs in their countries.  They found a consensus on the need for an international organization to provide up-to-date information, contacts and resources.  Yet there was clearly a leadership void when it came to international matters.  (Beryl Suitters, <em>Be Brave and Angry</em> [London, 1973], 19-20.)</p>

<p>Ottesen-Jensen, who presided over the conference,  impressed Sanger as a "vital . . . vigorous woman of 60," though she had "more emotions than vision." Sanger again questioned Ottesen-Jensen's interest in birth control rather than sex education, writing in her travel log that the "BC Movement in Stockholm is very strong even though Mrs Jensen is mainly interested in unmarried mothers. . . ."  She may have also resented the attention given to Ottesen-Jensen, especially after one reporter called Sanger  "America's Elise Ottesen-Jensen."  It was certainly unusual for Sanger not to be the main attraction or be fawned over by the delegates and press.  (MS to Rose, Aug. 25, 1946 [quotes 1-2]; MS, Travel Log, Aug. 20-26, 1946 [quote 3]  [<em>MSM</em> S26:97; S70:593]; "Expectations for the Future at the Congress for Sexual Information," unidentified publication transcription, 1946 [quote 4] [Sanger Unfilmed, Sophia Smith Collection].)</p>

<p>Whether because of her competitive drive or natural inclination, Sanger asserted her voice and quickly took charge of deliberations over the conference's public declarations. At the podium, Sanger reported to the conference on the developments in the U.S., then turned her attention to international aspects of the population problem and the importance of uniting family planning organizations.   Later, Sanger and Stone spent several hours editing the final draftresolutions created to serve as the basis for forming an international organization; these emphasized the right of individuals to obtain contraception and reproductive care and put a premium on the research and development of inexpensive and effective birth control methods.  Language barriers and translation problems hindered their final work, and some delegates complained that the American and English representatives exercised too much influence over the resolutions, but the conference concluded with unanimity over the decision to form an interim committee that would work toward the establishment of a permanent international organization. "This visit to Stockholm has been very helpful to me," Sanger wrote at the time, "arousing a new interest & expanding my hope for our future."  (Abraham Stone, "The Stockholm Conference on Sex Education, Family Planning and Marriage Counseling," Human Fertility 2 [Sept. 1946], 92-96; MS to Rose, Aug. 25, 1946; MS, Travel Log, Aug. 20-26, 1946 [quote] [<em>MSM</em> S26:97; S70:593] .)</p>

<p>Sanger and her contingent then moved on to England.  There she persuaded the Family Planning Association to host a larger and more representational international conference in Cheltenham in 1948, where the International Committee on Planned Parenthood (ICPP) was formed.  Four years later in Bombay, the ICPP became the International Planned Parenthood Federation (IPPF), which elected Sanger and Lady Dhanvanthi Rama Rau of India as co-honorary presidents.  The leaders returned to Stockholm for the Fourth International Conference in 1953, when Sanger was elected president.  By then her semi-retirement had officially ended, and she would lead the Federation until her eightieth year in 1959, after which Elise Ottesen-Jensen followed as IPPF president.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
