
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #34 (Fall 2003)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #34 (Fall 2003)</h1>
<div class="maintext">
<h1>"Backstage with Sanger and Hepburn"</h1>

<p>"What a remarkable woman &ndash; what imagination, what pertinacity of
purpose &ndash; And how lovely &ndash; There are so few really distinguished women &ndash; I
should say people &ndash; in the world &amp; she certainly was one of them."</p>
<p>We were reminded of these words with the passing of Katharine Hepburn at the
age of 95 on June 29, for surely this tribute aptly describes the strong-minded,
patrician, truly original actress who redefined the role of "leading
woman." But the words above were written by Katharine Hepburn in September
1966 upon the death of Margaret Sanger, an enabler of the kind of independent
woman Hepburn came to symbolize and perhaps something of a model for the
dignified, iconoclastic actress she became. (Hepburn to Grant Sanger, Sept. 13,
1966 [<em>MSM</em> S83:907].)</p>
<p>Margaret Sanger watched Katharine Hepburn flourish as a young actress on the
New York stage and in Hollywood films, a career that a young Sanger had once
envisioned for herself. Her interest was deepened by her close association with
Hepburn’s mother. In the 1930s Sanger worked closely with Katharine Houghton
Hepburn, who joined Sanger’s National Committee on Federal Legislation for
Birth Control as legislative chairman in Washington, DC.</p>
<p>A year older than Sanger, Katharine Houghton Hepburn had grown up, like
Sanger, in Corning, NY &ndash; the "Kathy Houghton of my Corning childhood"
&ndash; but on the other side of the tracks from the working-class Higgins family;
Hepburn’s grandfather founded the Corning Glass Works where several of Sanger’s
brothers worked, and for many years Sanger’s older sister, Mary Higgins,
worked as a domestic in Corning for Katharine Houghton’s aunt and uncle. (MS, <em>Autobiography</em>,
188.)</p>
<p>A long-time suffrage leader, Katharine Houghton Hepburn turned to birth
control &ndash; as did a number of prominent suffragists &ndash; following the passage of
the 19th Amendment in 1920. She helped found the Connecticut Birth Control
League in 1923 and joined the board of directors of Sanger’s American Birth
Control League before lending her organizational skills to Sanger’s lobbying
group in the 1930s.</p>
<p>When Sanger and the younger Katharine Hepburn met is not clear &ndash; probably on
one of Sanger’s frequent trips to the Hartford area in the 1920s &ndash; but Sanger
always expressed an aunt-like devotion to young Katharine, or Kate as Sanger and
other friends addressed her. Working side-by-side with the senior Katharine in
Washington in the early 1930s to find Congressional sponsors for a birth control
bill and organize speakers to give testimony on the Hill, Sanger felt in close
proximity to Kate’s sudden fame.</p>
<p>In 1932 Katharine Hepburn became a stage and screen sensation with her first
critical success on Broadway in<em> The Warrior’s Husband,</em> which led to her
screen debut later that year in <em>A Bill of Divorcement</em>, opposite John
Barrymore. She followed with a string of movie hits in the mid-1930s, including <em>Morning
Glory</em> (for which she won her first Academy Award), and <em>Little Women</em>
in 1933; <em>Spitfire</em> and<em> The Little Minister</em> in 1934; <em>Alice Adams</em>
in 1935; <em>Mary of Scotland</em> and <em>A Woman Rebels</em> in 1936; <em>Quality
Street</em> and<em> Stage Door</em> in 1937; and <em>Bringing Up Baby</em> and <em>Holiday</em>
in 1938.</p>
<p>The worlds of mother and daughter collided in January 1934. As Katharine
Houghton Hepburn spoke at a widely-publicized birth control conference in
Washington and led a delegation to the White House. Kate, hounded by reporters,
was asked to comment on her mother’s work, publicly supported birth control
and the efforts of her mother and Sanger to change the law. She expressed
irritation over how the press referred to her mother as the "mother of the
actress," asserting that it was her mother who was important; not she. In a
series of letters, featured in the upcoming second volume of <em>The Selected
Papers of Margaret Sanger</em>, Katharine Houghton Hepburn asked Sanger to write
to Kate "thanking her" since "it means a good deal of sacrifice
for [her] to stand openly with us." (Barbara Leaming, <em>Katharine Hepburn</em>
[New York, 1995], 292; Katharine Houghton Hepburn to MS, Jan. 24, 1934 [LCM
88:237].)</p>
<p>Sanger wrote to Kate the next day:</p>

  <blockquote>
    <p>"I hope that this battle for Birth Control, where your glorious
    mother stood out so valiantly for her opinions is not going to get you in
    bad.</p>
    <p>You Hepburns have such courage, are such straight shooters, and are so
    straightforward in your thinking that I know it will be difficult for you to
    think of your public&ndash;especially your Catholic public, if you have such a
    thing. I do not say that you should&ndash;I only want to tell you that I adore
    your mother and I think she is wonderful to come and make the splendid fight
    beside us dreading all the time to get you mixed in the affair.</p>
    <p>I am not afraid that anything that your mother says will in any way hurt
    you. You have won your reputation by your own ability and talent, and
    through those qualities alone you will win or lose. If it were otherwise, I
    should certainly say that we should put the soft pedal on the name of
    Hepburn.</p>
    <p>I am not afraid, and I am sure that you are not." (MS to Katharine
    Hepburn, Jan. 25, 1934 [LCM 8:1070])</p>
  </blockquote>

<p>Unsure whether she had accomplished what Kate’s mother requested of her,
Sanger wrote to the senior Katharine:</p>

<blockquote>
    <p>"Now, as to your daughter Kate, I wrote her but for the life of me I
    could not tell that wonderful creature to do anything against her own divine
    inspiration. I believe it is the [<em>don’ts</em>] and the do’s of the
    elders constantly tugging at our young people that give them complexes and
    disturbs a very definite, inspired flare that a few of them have. Your
    Katharine is in that group and I believe that her public loves and adores
    her for her spirit and undaunted courage that she expresses in every part
    she has played so far. To be less than herself in considering a mythical
    public would, dear Kate, be damping down a flame that must have air and room
    to send out its light. The whole thing will die down in a few days and I
    hope you will feel that whatever she does when it expresses her inate
    feeling, is the right thing to do." (MS to Katharine Houghton Hepburn,
    Jan. 26, 1934 [LCM 125:220B])</p>
</blockquote>

<p>Somehow Sanger had misconstrued the older Hepburn’s intentions, believing
the mother wanted to tone down her daughter. Katharine Houghton Hepburn wrote
back in the margins of Sanger’s letter:</p>

<blockquote>
    <p>"What <u>did</u> you think I said? All I wanted was for you to write
    and say you were pleased at her coming out for us as I knew that her studio
    would protest. She admires you &amp; I thought that it would please her. Of
    course she did the right thing — I’d have spanked her if she hadn’t."</p>
</blockquote>

<p>Kate was characteristically nonchalant about this media episode, telling
Sanger:</p>

<blockquote>
    <p>"Don’t worry about me, its much too important for that — When
    they ask me what I think I say that I stand back of every thing that Mother
    &amp; you say on the subject." (Katharine Hepburn to MS, Jan. 29, 1934
    [LCM 8:1071])</p>
</blockquote>

<p>Sanger and Katharine Houghton Hepburn saw each other infrequently after the
dissolution of the National Committee in 1937. But Sanger kept up with Kate’s
career, noting in her calendars when she saw the newest Hepburn film or Broadway
production. Sanger tried to get Kate to speak at a Birth Control Federation
annual meeting in 1941, remembering her words of support for the movement in
1934: "Your words were what one would expect from the daughter of your
mother, and I hope that you had no cause to regret your courage, integrity and
forthrightness on the occasion of which I speak." (MS to Katharine Hepburn,
Oct. 31, 1941 [<em>MSM</em> S20:188].) But Hepburn’s the "Woman of the
Year" &ndash; her first film with Spencer Tracy was released early in 1942 &ndash;
and she was too busy to accept the invitation.</p>
<p>In 1949 Sanger played producer for a play titled "Green Courage,"
written by her friend, the playwright and educator Leighton Rollins. It was a
dramatization of Sanger’s childhood and the early days of the movement, and it
used a chorus of actors portraying famous birth control supporters such as
Oliver Wendall Holmes, George Bernard Shaw, Lord Dawson of Penn, Rabindrinath
Tagore and the President of Smith College, to amplify the morality of the
message. Sanger immediately thought of Katharine Hepburn in the lead role &ndash; the
character named "Margaret Osgood" &ndash; knowing an acceptance by Kate
would guarantee the play’s success. Ambivalent about asking her directly, she
wrote first to Kate’s mother:</p>
<blockquote>
    <p>"Personally and confidentially . . . [Leighton Rollins] has just
    completed a play the theme of which is birth control. I know and remember so
    well what an excellent opinion and judgement you and your family used when
    considering a play for Katharine. Is Katharine in town or in the East and
    nearby? If so, as soon as this play is completed &ndash; which is almost now &ndash;
    would you like to read it?" (MS to Katharine Houghton Hepburn, May 27,
    1949 [<em>MSM</em> S30:31].)</p>
</blockquote>
<p>Katharine Houghton Hepburn politely informed Sanger that Kate was in
Hollywood and would not be East until the fall. She said "that play sounds
interesting," but did not offer to read it or forward it to Kate.
(Katharine Houghton Hepburn to MS, June 3, 1949 [<em>MSM</em> S30:181].) The play
premiered at a community theater in Tucson in March of 1950, sans Hepburn, but
with most of the Tucson Watercolor Guild (Margaret’s merry painting club)
filling the major roles.</p>
<p>In 1951 Sanger received news of Katharine Houghton Hepburn’s sudden death
from a cerebral hemorrhage. She wrote Kate immediately and received in return a
long letter from Kate describing the death scene:</p>
<blockquote>
    <p>"M[other] went up to nap &amp; Dad &amp; I drove to Fenwick — We
    got back at 5:30. Dad went up to get M. as tea was waiting. When she did not
    answer — he found what had happened — Apparently she had got up about 5
    — gone in to bathe &amp; fix her hair — She’d taken off a wooly robe
    she always wrapped in <span class="boldText">[need notation to indicate next 3 words were
    inserted above text]</em> hung it up &amp; was fixing her hair when she must
    have suddenly felt dizzy — went straight back to bed &amp; pulled the
    covers up &amp; with a sweet smile closed her eyes — Dad says she could
    not have know what it was — &amp; she looked so relaxed that she could not
    have suffered or been too frightened — It is dreadful not to have her —
    but thank God if it had to be — it was as it was —</p>
    <p>She loved you very much — was always so proud of you&ndash;- "
    (Katharine Hepburn to MS, March 27, 1951 [<em>MSM</em> S34:177].)</p>
</blockquote>
<p>As Barbara Leaming, Hepburn’s biographer, later learned, the death scene
had been sanitized by Kate with all signs of suffering removed or veiled after
her father’s initial discovery, so he could revisit the room and see the
peaceful resolution she described in the letter to Sanger. (Leaming, <em>Katharine
Hepburn</em> [New York, 1995], 441-2.)</p>
<p>After Sanger’s death in 1966, Katharine Hepburn did involve herself more
directly in the reproductive rights movement, narrating a film about Sanger and
adding her weighty name to Planned Parenthood endeavors. Hepburn was a member of
the PPFA Board of Advocates and Honorary Chair of the PPFA National Leadership
Committee to Keep Abortion Safe and Legal. Speaking about Sanger in 1981,
Hepburn said "it is imperative that I join Planned Parenthood because sadly
even today there are those who would completely destroy all of her tireless work
and deprive all of us of our right to plan our families." (PPFA, Paid Death
Notice, <em>New York Times</em>, July 1, 2003.)</p>
<p>Just two weeks before Katharine Hepburn’s death, her niece, the actress
Katharine Houghton, appeared on CNN’s "Larry King Live" to discuss
her aunt. In response to a question about recent visits with Katharine, Houghton
replied that</p>
<blockquote>
    <p>"I had a letter just before the holidays from New York University,
    asking for permission to publish a letter that she [Katharine] had written
    to Margaret Sanger. . . So I said to my aunt, ‘Do you remember Margaret
    Sanger?’</p>
    <p>‘Yes.’</p>
    <p>What did you think of her?</p>
    <p>‘She was a remarkable woman.’"</p>
</blockquote>
<hr />
<font size="2"><p>Editor’s Note: (published in Winter 2003/2004 issue)</p>
<p>Information in our last issue’s lead article on Katharine
Hepburn, concerning the death of her mother, Katharine Houghton Hepburn, was
taken from a 1995 biography of Katharine Hepburn by Barbara Leaming. The Hepburn
family has notified us that they vigorously dispute Leaming’s conclusions,
including her rendering of this event. Instead they stand by Katharine Hepburn’s
straightforward description of her mother’s death as told to Sanger in the
March 27, 1951 letter quoted in the article. The Hepburn family has also
corrected a misconception about Katharine Houghton Hepburn’s childhood. She
was born and raised in the Buffalo area, not Corning, as Sanger wrote in her
autobiography, though she no doubt often visited Corning, where the Houghton
family, founders of the Corning Glass Works, were well known.</p></font>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
