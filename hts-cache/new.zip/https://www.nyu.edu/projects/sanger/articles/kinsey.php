
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #39 (Spring 2005)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #39 (Spring 2005)</h1>
<div class="maintext">
<h1>"Sex Matters: Sanger and Kinsey Make Sex History"</h1>

<p>The 2004 bio-pic, &ldquo;Kinsey,&rdquo; reminds us of the pivotal role that sex researcher Alfred Kinsey played in the history of sex in the 20 th century. &ldquo;An era of Hush-and-Pretend in the life of our nation may end through the Kinsey Report,&rdquo; wrote the renowned gynecologist Robert L. Dickinson, following the publication of Kinsey&rsquo;s<em> Sexual Behavior in the Human Male</em> in 1948. Several commentators looked all the way back to Darwin to find a scientific publication with comparable social implications. With the reputation of a dispassionate and empirical investigator, Kinsey was the ideal figure to usher in what might be the final stage in the era of sexual enlightenment: a free and full consideration of human sexuality. (Robert L. Dickinson, foreword to Morris L. Ernst and David Loth, <em>American Sexual Behavior and the Kinsey Report </em>[New York, 1948], vii.)</p>

<p>In effect, Kinsey picked up the figurative sexual baton (careful there) from Sanger, whose successful advocacy of birth control helped make possible &ndash; and certainly made more interesting &ndash; Kinsey&rsquo;s voluminous study of sexual behavior. But was there more of an association between these two sexual liberators who are now both commonly celebrated and maligned as the &ldquo;father&rdquo; and &ldquo;mother&rdquo; of the sexual revolution? </p>
<p>At the turn of the century, Havelock Ellis, Sigmund Freud and other European sex psychologists defined non-procreative sex: sex for pleasure, release, affection, sub-conscious needs, assertion of identity and general health and well-being, among other needs and functions; Margaret Sanger and other early sex education and birth control reformers, Emma Goldman, Marie Stopes and Mary Ware Dennett among them, advocated the means (birth control and basic sexual education) to successfully achieve these non-procreative manifestations of the sexual urge; and Kinsey, along with Masters and Johnson and later sex researchers, demonstrated the remarkable array of sexual variation that exists among humans and underscored the conflict between what Kinsey called our &ldquo;physiologic capacities&rdquo; and social and legal codes. 
</p>
<p>That&rsquo;s where we are today: managing the repercussions of both reproductive freedom and greater knowledge of our sexual proclivities, re-marking boundaries, questioning the rationality of laws and codes meant to control sexual behaviors, negotiating sexual mores &ndash; still learning to talk about sex.</p>
<p>As the leading birth control advocate and among the most visible sex educators in the first half of the 20 th century, Sanger was a key link &ndash; the activist link &ndash; between the first and second stages of sex research: between Ellis&rsquo;s <em>Studies in the Psychology of Sex</em> (1897-1928), a monumental seven-volume work that considered sexual patterns and challenged conventional attitudes about homosexuality and women&rsquo;s sexuality, and Kinsey&rsquo;s bombshell studies on male and female sexuality published in 1948 and 1953 that shattered many preconceptions about sexual behavior.</p>
<p>Sanger used Ellis&rsquo;s theories on the importance of sexual fulfillment to frame her own rationale for birth control, one in which she celebrated and to an extent enabled women&rsquo;s eroticism. She took his science to the street, making a case for birth control and sexual education based on a reevaluation of sexuality squarely at odds with many traditional values and legal codes. Her skillful pairing of science and social reform prefigured Kinsey&rsquo;s shrewd use of scientific data to challenge convention and summon reform. As his most recent and thorough biographer, James H. Jones, has argued, and as the recent film of his life makes clear, Kinsey set out to be a reformer, to change the laws and social mores governing sexual behavior, relying, in Jones&rsquo;s words, on the &ldquo;cultural authority of science&rdquo; for respectability and influence. (James H. Jones, <em>Alfred C. Kinsey: A Public/Private Life </em>[New York, 1997], xi.) </p>
<p>Sanger&rsquo;s own research, the contraceptive investigations and patient record studies carried out at her birth control clinic in New York, had an important influence on the kind of objective, individual-history-based sex research first undertaken in the 1920s that gave Kinsey his models. Sanger had a hand in several of the major statistical sex studies prior to Kinsey&rsquo;s, </p>
<p>having had control over one of the only significant bodies of case records on female sexuality and birth control use, generated by her Birth Control Clinical Research Bureau in New York starting in 1923. In 1929, she arranged for statistician Marie Kopp to analyze the clinic&rsquo;s first 10,000 cases. Published in 1934 as <em>Birth Control in Practice</em>, Kopp focused on success and failure rates of contraceptive usage but also included statistical summaries on coital frequency and orgasm rates, among other measurements of female sexual behavior. Her data, however, was taken from married clinic patients in the New York area, a limited sample despite the high number of subjects. There were also several other objective studies of sex behavior based, like Kinsey&rsquo;s work, on personal interviews, including published investigations by Kinsey&rsquo;s mentor Robert Dickinson. These nine or ten studies are cited in Kinsey&rsquo;s books, but their combined pool of histories fell far short of Kinsey&rsquo;s sample. </p>
<p>Interestingly, Kinsey&rsquo;s samples were the first reliable ones to show definite changes in contraceptive use among sexually active women in the interwar period, the height of the birth control movement. Birth control historian James Reed has noted that Kinsey&rsquo;s findings do not show more women necessarily initiated contraceptive use but switched from ineffective methods, withdrawal and douching, to Sanger&rsquo;s recommended diaphragm. Of white married women born between 1920-1929, only 5% reported that they had never practiced contraception while 57% used the diaphragm, a testament to Sanger&rsquo;s success even if Kinsey&rsquo;s sample was skewed toward white, educated, middle-class women. (James W. Reed, <em>The Birth Control Movement and American Society</em>, [Princeton, 1978], 123-4) </p>
<p>While Sanger enjoyed an intimate friendship with Ellis from the time of their first meeting in 1914 to his death in 1939, she did not know Kinsey well. Their correspondence amounts to one exchange in 1953. It is somewhat surprising they did not become more closely associated since Kinsey formed lasting friendships with two influential birth control doctors who were close to Sanger: Abraham Stone, who ran Sanger&rsquo;s clinic starting in 1941, and Dickinson, a leading birth control proponent and another giant figure in the modernization of sex who essentially appointed Kinsey as his successor in the field. Dickinson also gave Kinsey a number of contacts to individuals with unique sexual histories, including the infamous Mr. X., the predatory pedophile that Kinsey, in what many have criticized as his most egregious lapse in judgment, relied upon for much of his most controversial data on pre-adolescent sexuality. Sometime in the late 1940s, with Stone&rsquo;s help, Kinsey also accumulated over 200 sex histories from patients who used the Sanger clinic, including Stone&rsquo;s own sexual history. Curiously, there is no record of Sanger approving Kinsey&rsquo;s interviews with clinic patients and personnel, though presumably she knew of it. (Jones, <em>Kinsey</em>, 507; Wardell B. Pomeroy, <em>Dr. Kinsey and the Institute for Sex Research </em>[New York, 1972], 162-3.) </p>
<p>Why did Sanger keep her distance from Kinsey and not attempt to enlist his support or make use of his findings, as she did with nearly every other major sex and birth control researcher? She clearly respected and saw the immense value in his work. She wrote him following the publication of his volume on <em>Sexual Behavior in the Human Female </em>in 1953: &ldquo;You are certainly to be congratulated on the splendid work that you are doing to arouse a lethargic American public to a new horizon of the sex lives of American men and women.&rdquo; He returned the compliment, adding in his own hand at the bottom of a typed response: &ldquo;Certainly it is very nice to be in touch with you. Dr. Dickinson and I spent time repeatedly discussing the importance of the work you have done.&rdquo; (MS to Kinsey, Nov. 5 and Kinsey to MS, Nov. 23, 1953 [<em>MSM</em> C10:187, 348].) </p>
<p>Sanger may have feared that Kinsey&rsquo;s disclosures about the variety and frequency of sexual experience would spike the never ending debate about whether birth control led to promiscuity. She was probably less concerned with the potential fallout from Kinsey&rsquo;s work at home than abroad. By the early 1950s, she had fully embarked on a new international movement primarily focused on establishing birth control leagues and clinics in Asia, where her work was attacked by religious conservatives. In India, for instance, where she and representatives had been active for over a decade, she went to considerable effort to counter Gandhi&rsquo;s belief that birth control frequently led to immoral, wanton behavior. The widespread publicity generated by Kinsey&rsquo;s revelations put the emphasis back on sex at a time when Sanger sought to focus on population control, the preservation of peace, and economic security through family planning. </p>
<p>Was Kinsey too frank even for Sanger? Certainly his style, or lack thereof, may have left Sanger feeling nostalgic for Ellis&rsquo;s graceful prose. There was no place in Kinsey&rsquo;s work for euphemism or literary pretension. His wide-open dissection of America&rsquo;s sex life made the popular marriage manual style of sex education writing, epitomized by Sanger&rsquo;s <em>Happiness in Marriage</em> and Dutch gynecologist Theodore H. Van de Velde&rsquo;s popular <em>Ideal Marriage</em>, both first published 1926, and even the more scientific-minded sex research of the time, appear stuffy and pass&eacute;. Look at one of Sanger&rsquo;s early statements on sexual expression: </p>
<blockquote>
  <p>Sex expression, rightly understood, is the consummation of love, its completion and its consecration. Sex expression is an art. To become artists in love, men and women must learn to master and control the instruments by which this art is expressed. (<em>Happiness in Marriage</em>, 20) </p>
</blockquote>
<p>In her writings Sanger viewed sexuality through a soft-focus lens, emphasizing an ideal marital state of communion and consummation that took on a very spiritual nature. As outspoken as Sanger demonstrated she could be &ndash; and her early commitment to enable women to engage in sex for pleasure sent shockwaves through the hinterlands &ndash; she refused to abandon her belief in the need for men and women to assume control over their sexuality, not submit to its natural force, and to treat sexuality as a transforming experience. </p>
<p>In contrast, Kinsey&rsquo;s approach to sexuality was extremely mechanistic. The lovely instruments with which Sanger&rsquo;s ideal married couple learned to harmonize were treated by Kinsey as complex physiological responses to be recorded and objectified. He sought to acquire a relevant sampling of all human sexual outlets and strictly avoided the appearance of making any social or moral interpretations. He could not have been less romantic. </p>
<blockquote>
  <p>For most females and males, there appear to be basic physiologic needs which are satisfied by sexual orgasm, whatever the source, and the sum total of such orgasms may constitute a significant entity in the life of an individual. (Kinsey, <em>Sexual Behavior in the Human Female</em> [Philadelphia, 1953], 511.) </p>
</blockquote>
<p>Just as Sanger&rsquo;s sex education writing departed radically from the chastity message emphasized in 19 th century sex advice literature and relegated those earlier works to relics, the number of Kinsey&rsquo;s subjects (18,000 between the two studies) and breadth of his data (incidence and frequency rates on masturbation, sex dreams, orgasms, pre-marital petting, coitus, homosexual contacts, and so on) made earlier sex studies look parochial. </p>
<p>Whether or not Sanger tried to keep from being identified or associated with Kinsey during the overlapping portions of their careers, some of their recent detractors have united them today as the most dangerous secular evangelists of the 20 th century, responsible for redefining our sexual mores, aiding pornography, accelerating divorce rates, pushing sex education into our schools, empowering homosexuals, increasing the number and frequency of sexually transmitted diseases and creating abortion-on-demand. They have been paired-up by recent anti-abortion authors as leading architects in the &ldquo;culture of death,&rdquo; and attacked in tandem by reactionary conservative social critics (see, for instance Dan Flynn&rsquo;s recent book, <em>Intellectual Morons</em>) as dishonest and conniving neurotics driven by inner (sexual) demons and respected today only because the deep flaws in their work have been whitewashed by liberal intellectuals. Those morally opposed to Kinsey and Sanger have never recovered from the sexual revolution: the offspring, many social conservatives rightly argue, of permissiveness and the pill &ndash; a merger of sorts of Kinsey&rsquo;s and Sanger&rsquo;s crusades for sexual liberation. In the nation&rsquo;s social-cultural divide, most recently configured as the red states vs. the blue states, the sexual revolution still remains a dynamic force. </p>
<p>When looking back over the sexual terrain of the 20 th century, what ultimately linked Kinsey and Sanger was their mutual fearlessness in challenging authority and a shared conviction that increased knowledge about sex would fundamentally change American society for the better. &ldquo; . . . we have come to understand,&rdquo; Kinsey wrote in his rational, non-declarative statement of purpose, &ldquo;that the total social organization, and many individuals in it, may benefit by an increase in our understanding of human sexual behavior.&rdquo; Sanger reached for a higher plane: &ldquo;Out of our increasing sex knowledge we shall evolve new ideals of sex,&rdquo; for &ldquo;the truth makes free.&rdquo; (<em>Woman and the New Race</em>, 184, 183; Kinsey, <em>Sexual Behavior in the Human Female</em>, 21.) </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
