
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #18 (Spring 1998)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #18 (Spring 1998)</h1>			

<div class="maintext">
<h1>"The Unrecorded Battle (Part II)"</h1>

<p><em>And now the dramatic conclusion of Margaret Sanger's unpublished short story (for
<a HREF="unrecorded_battle-1.php"> Part I</a> see the Winter 1997/1998 newsletter) in which Peggy Taylor, an innocent from Connecticut newly arrived in the Big City, lands her first job as an assistant nurse to a prosperous New York physician.  Moments after her brief interview with the doctor, she writes home to delay her marriage to "Dick" and tell her mother that she is "coining money" and not to worry about the mortgage payments on the family house. We last left Peggy on the eve of her first day of work as she described her new boss to colleagues at a nursing agency who made little effort to hide their suspicion that this doctor may be too good to be true.  In a state of euphoria, Peggy offered thanks in her prayers for her good fortune and "slept the sleep that only youth and a clear conscience can sleep."</em></p>

<em><p>Once again, we have not corrected Sanger's spelling errors, though we have added missing quotation marks to help clarify the story.</P></em>

<p><hr noshade size="1"></p>

<h3>THE UNRECORDED BATTLE</h3>

<p>The next morning promptly at ten she found herself again at the brown stone front, but instead of the dark butler, the Doctor himself opened [the] door for her, he was immaculately dressed, hair almost shone, mustache curled, which together with the pink carnation in his coat lapel, made her say "dandy" to her self.  He bowed low and long over her hand, not quite the business air of the day before.</p>

<p>"Allow me to assist you" he said as he took her suitcase, and leading the way through the house, he summoned Mrs Thomas, the house keeper, and George the butler, introduced her to them saying, "This is your future Mistress Miss Taylor, hereafter she is to be consulted concerning affairs of the house, and I wish it understood that her wishes are mine."  She followed him up the soft luxurious stairs through this house of elegance, to a large spacious, elegantly furnished room the sight of which made her heart beat for joy; he pushed open the door, allowed her to enter, put the bag inside The Door, and quickly stepped inside and closed the door.  She held her breath a moment not daring to think; then he spoke; "This is your room Miss Taylor, you like this color?"  He watched her closely, "these flowers I had sent in for you to day, these books are yours, in fact, little one the desires of your life shall be filled in my house, you are mistress of this entire place," stepping to her side he said softly, "this is your little bed sweetheart," and stepping to a screen on the other side of the bed pulled it back "and this is mine" he said pointing to another bed which the screen had so cunningly hidden.</p>

<p>During all this conversation she had stood as one petrified but at these last words she gave one blood curdling scream, and rushed for the door, he was there before her, caught her by the throat and roughly pushed her against the closed door.  "You little Devil" he hissed, "what are you here for?  Do you mean to say you did not know what you were coming here for?  Ha ha, then here you've come and here you'll stay, Miss &ndash; Scream, kick, cry to your hearts delight, for no one shall heed you," he thundered.  At these terrible words the blood left her face, her knees trembled, for she at last realized into what a demons den she had come.-  She had seen men in joy, sorrow, agony and death, but this was her first experience at seeing a living devil smile.  But at that smile the fighting blood of her New England ancestors, arose in her, she knew a time had come to fight, and fight to the death,  &ndash;rather than that.</p>

<p>Quicker than it takes to tell, these thoughts flashed through her mind, she raised her head, looked him square between the eyes, and said: "Doctor, I have one thing to say, You are mistaken in me.  I am not that kind of woman.  I came here innocently.  I wish to go away.  Look into my face, look closely, and should you see in that look other than -Purity, then God help me."  At these words he came closer, anger and passion fighting for posession, "You lie" he said "You lie, you huzzy, you have come [here] to spy, you have come here pretending innocense, to pry into my work, but your game won't work with me; Listen," he said hoarsley "Look you into my eyes" Oh, God that horrible face! "and learn what power is; it is greater than the purity which you claim is in yours; one word from me and into this house you'd remain, until I gave the word to release you; a word from me and to the workhouse you would go &ndash; as a prostitute; Yes I have that much power, and more far more; Think little fool, could I run an establishment of this kind without power?  Could I preform from ten to twenty operations a day, without power?  Could I?" He screamed.  "No, no, with all your pretended innocense you must know that.  And further anything you might say of me, would be laughed at, No newspaper in New York City, dare, I repeat it, dare, to print what I have told you &ndash;Why? Power, &ndash; power from on high, high in the world of Capital, influence, and prestage, all of whom I have favored, and in turn favor me."</p>

<p>During this time he had released her, much to her releif, and stood a little distance from her in order to use his hands, for he jesticulated much, but as he told her of the favors he had done his face softened, and came toward her with outstretched arms; Here was no longer the frightened bird, here was a woman holding anger and pride in check, standing resolutely against the door, head held high, lips tightly closed ready for fight, &ndash; she had aged five years, since she came into that room, here was something new, something worth winning, he thought, his whole being shook with passion as he said, "Forgive me, cant you?  Your here, you have all to gain by staying here, why make a mess of this." He kept coming closer as he spoke, and she felt in another second &ndash; it would be too late; "Stop!" she cried, as she raised her arm and pointed at him, her eyes blazed, her face was pale and drawn "-Stop, I say, not one step nearer; you have had your say, now Ill have mine; Im not afraid of you.  Your tyranny and boasted power are nothing to me.</p>

<p>"Of one thing I am certain," she said calmly, "I leave this room as pure as I entered it or I leave it not at all.</p>

<p>Your lies about your influece with scoundrels of this City does not frighten me, for I too am protected by men who are men &ndash; on high, I have back of me the vast army of Medical men in United States, two of whom know I came here to day, knowing this I defy you to touch me," her turn had come now and all fear had gone.</p>

<p>At these words and the reliant look of this slip of a girl the coward cringed, he knew she spoke the truth; he realized she was not the ordinary girl, and not to be bullied; he knew he must give her up, but not until his cruelty had some relief, he folded his arms, put his head cunningly on one side and said; "You are not trying to make me beleive you are pure are you?"  She looked him fully in the eyes and [answered] "I am."  He changed his position slightly, by shifting the other foot forward, bent forward and continued; "Do you mean to tell me you are a virgin"? for one second, she gasped at this cruelty, but looked at him [and] said "I do."  "Swear it," he thundred, -his right arm raised high, his whole being aroused to anger.  "I swear," she said, with [her] head erect, and eyes dancing fire, she saw she had won; He stepped to the door unlocked it, threw it open wide, and shouted "go".  She went.  Then the air was rent with peal after peal of the most diabolical laughter, for a second, her blood seemed to freeze in her veins, she put her hands to her ears to shut out that terrible laugh, but the sight of her suit case tumbling down the stairs brought her to her senses, and soon she was safe outside that den of torture.  On, on she plodded, she knew not where, she cared not where, she was safe, safe, safe. -that was enough for the present.</p>

<p>She had won the battle for her soul, Ah, God! was ever such a battle fought!  Sometime in the afternoon, we see her at the Grand Central Station, buying a ticket for her home town.  Later we see her walking along the dusty road nearing the farm. At a distance we can see a figure bending over a green patch, with sunbonnet pushed far back on her head, and we feel it is her mother.  Peggy sees her, and a lump comes into her throat as she thinks of the dissapointments in store for them all.</p>

<p>She is soon enfolded in the strong arms of that dear mother, and as they sit together under the elm tree, she relates her agonizing experience, to that loyal heart.</p>

<p>A glance at that New England mother will at once tell us better than words where the daughter got her courage and spirit, in time of danger.  Proud, brave and tearless, she took her daughters face in her hands and said; "Peggy," you are a wonderful girl.  I'm prouder of you to day, than I ever was of your great grandfather, who fought and died so valiently at the battle of Bunker Hill.  This unrecorded battle!" she shook her head, "and you my Peggy the Victor."  They sat thus for some time "Ill not go back again Mother, Im so tired, of it all, and Dick has waited so patiently, yes Ive quite decided to stay."</p>

<p>After the house was quite that night, the father and mother walked up and down, the kitchen floor, up and down, hour after hour, arm in arm.  For miles around this honest and sturdy farmer was called Uncle Sam, so vividly did he remind us of our "Uncle Sam."</p>

<p>On, on he walked, up and down far into the dawn, head bent, eyes fixed on the floor, fists clenched, thinking, thinking.  At last he stopped, went to a shelf, took down a rifle he kept there, blew off the dust, wiped it carefully [<em>story ends here</em>].
(LCM, 131:0087) </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
