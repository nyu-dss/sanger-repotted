
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #60 (Spring 2012)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #60 (Spring 2012)</h1>
<div class="maintext">
<h1>"Margaret Sanger Answers Questions on Abortion--an MSPP Exclusive"</h1>

<p> New profiles, condemnations and appraisals of Margaret Sanger appear every week on the Internet and in print. The great majority of these articles, blogs and other writings, fueled in recent months by the controversy over mandatory health care coverage for contraception, are ideological in nature, with a tendency toward vitriolic remarks on one side, or eulogizing on the other. More often than not the title of an opinion piece about Sanger reveals the author&rsquo;s bias and anticipates the arguments that follow. </p>
 <p>Except when it comes to Sanger and abortion. From our unique vantage point we have observed that many who write with confidence about Sanger are insecure and confused when assessing her views on this most heated of all culture war issues. </p>
 <p>Some reproductive rights proponents seem uncomfortable with Sanger&rsquo;s often strong language condemning the practice of abortion. Others suggest that she had to be circumspect because of widespread public disapproval of abortion and the potential for legal trouble (abortion did not become legal until seven years after her death). Those on the other side of the debate, who charge Sanger with instigating a holocaust of the unborn, struggle to explain passages in her writings that appear to echo their own sentiments; some have gone so far as to suggest that Sanger orchestrated a masterful subterfuge-- nary a seam detected in her sheep&rsquo;s clothing. </p>
 <p>Once again the failure to read widely and try to understand Sanger within the context of her time has exposed the historical myopia of Sanger&rsquo;s critics as well as some of her admirers. Even more maddening is the common practice of making broad assumptions about Sanger&rsquo;s position on abortion based on a single quotation, such as her declaration in the first issue of the <em>Woman Rebel </em>that women have &ldquo;The Right to destroy,&rdquo; or her later comment that she had &ldquo;always condemned abortion as dangerous and inhuman.&rdquo; Sanger&rsquo;s views on abortion, like her views on other issues surrounding sexual expression and reproductive control, were complex and impossible to pigeonhole. (MS, &ldquo;On Picket Duty,&rdquo; <em>Woman Rebel </em> [Mar. 1914], 3; MS, &quot;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=302493.xml">Asia Discovers Birth Control</a>,&quot; <em>Reader's Digest </em>[July 1956], 36.) </p>
 <p>Wouldn&rsquo;t it be helpful then if we could interview Sanger and learn a little more about her thoughts on the issue that has most divided America in the years since she died in 1966? Unfortunately, unlike some of Sanger&rsquo;s psychic friends, we don&rsquo;t have clairvoyant powers, nor do we have the office space for a s&eacute;ance. But what we do have are thousands of her writings. So we have constructed an artificial interview by asking questions that establish some context, and then formulating responses out of excerpts from Sanger&rsquo;s articles, debates, books, speeches and letters--her words only. We have made an effort to provide lengthy quotations that get at the crux of Sanger&rsquo;s thinking on abortion, rather than cobble together a few lines from different sources. Her written words on this topic will not satisfy everyone or eliminate controversy over her actions and beliefs, but they should help inform the debate. As always, the source for each quotation is fully cited. </p>
 <p>Sanger never spoke at length on the issue of abortion, but if she had, what follows might bear at least some resemblance to what she would have said. So eat your hearts out Piers Morgan, Bill O&rsquo;Reilly and Rachel Maddow, we snagged the biggest culture war interview ever! </p>
 <p><strong><em>Q. Welcome Mrs. Sanger. Is it your understanding that women turn to abortion because they lack access to contraception? </em></strong></p>
 <p><strong><em> &nbsp;</em></strong><strong>A. </strong>&ldquo;Women in all lands of every religion and creed are forced to resign themselves to unlimited pregnancies unless they have proper information in contraception. When this is denied them their only resort is abortion. Out of fear&mdash;because of their misery, poverty and ill health, they seek to evade a motherhood which would bring with it destitution and possible starvation to an unwanted baby.&rdquo; (MS, &ldquo;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=236121.xml">Woman of the Future</a>,&rdquo; Sept. 1933 [<em>MSM</em> S71:492].) </p>
 <p><strong><em> </em></strong><strong><em>Q. Will abortion always be a means of fertility control for a certain percentage of women? </em></strong></p>
 <p><strong>A: </strong> &ldquo;Family limitation will always be practised as it is now being practised&ndash;either by Birth Control or by abortion. We know that. The one means health and happiness--a stronger, better race. The other means disease, suffering, death.&rdquo; (MS, &ldquo;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=232534.xml">Birth Control or Abortion</a>?&rdquo; <em>Birth Control Review</em> [Dec. 1918]: 3-4 [<em>MSM</em> S70:0809].)<strong></strong></p>
 <p><strong> &nbsp;</strong><strong><em>Q. But do you find abortion to be an acceptable alternative to contraception? </em></strong></p>
 <p><strong>A.</strong> &ldquo;It is an alternative that I cannot too strongly condemn. Although abortion may be resorted to in order to save the life of the mother, the practice of it merely for limitation of offspring is dangerous and vicious.&rdquo; (MS, &ldquo;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=303569.xml">The Pope&rsquo;s Position on Birth Control</a>,&rdquo; <em>The Nation</em>, Jan. 27, 1932 [<em>MSM</em> S71:243; Vol. 2, p. 149.) </p>
 <p><strong><em>Q. Yet you gave out abortion information in the first edition of your birth control methods pamphlet, </em>Family Limitation<em>, published in 1914. </em></strong></p>
 <p><strong>A. </strong>&ldquo;If you are going to have an abortion, make up your mind to it in the first stages, and have it done. On the other hand, there is often a feeling of the strongest desire to continue with the pregnancy. It is for each woman to decide this for herself, but act at once, whichever way you decide.&rdquo; (MS, <em>Family Limitation</em>, 1 st Edition [New York, 1914], 3 [<em>MSM</em> S76:842].) </p>
 <p><strong><em>Q . You faced criticism from other birth control leaders, England&rsquo;s Marie Stopes in particular, for including abortion advice in the early editions of </em>Family Limitation,<em> subjecting the movement to accusations that it advocated abortion. How did you answer Stopes? </em></strong></p>
 <p><em> &nbsp;</em><strong>A</strong>. &ldquo;I regret [. . .] that you have laid so much stress on the sentence about abortion. No one in America views it in the same way. No one doubts my views on the subject. Mainly because I have so strenuously attacked the abortionists &amp; the Government for creating them. Not one voice here has been raised against that part of the pamphlet, and so I regret you have raised an objection to it, for always people are looking for an objection to climb on.&rdquo; (MS to Marie Stopes, Oct. 11, 1915 [<em>MSM</em> C1:100; <em>Vol. 1</em>, pp. 164-65.) </p>
 <p><strong><em>Q. By 1918, your argument was slightly different. What was your view of abortion then? </em></strong></p>
 <p><strong>A.</strong> &ldquo;Any attempt to interfere with the development of the fertilized ovum is called an abortion. No one can doubt that there are times where an abortion is justifiable but they will become unnecessary when care is taken to prevent conception. This is the only cure for abortions.&rdquo; (MS, <em><a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=320146.xml">Family Limitation</a></em>, 8th Edition, revised [1918].) </p>
 <p><strong><em>Q. You took the abortion section out of the American editions of </em>Family Limitation <em>after 1920, and publicly you were careful from then on to consider the option of abortion only when a mother&rsquo;s life was at risk. </em></strong></p>
 <p><strong> &nbsp;</strong><strong>A. </strong>&ldquo;While there are cases where even the law recognizes an abortion as justifiable if recommended by a physician, I assert that the hundreds of thousands of abortions performed in America each year are a disgrace to civilization. I also assert that the responsibility for these abortions and the illness, misery and deaths that come in their train lies at the door of a government whose authority has been stretched beyond the limits of the people&rsquo;s intention and which, in its puritanical blindness, insists upon suffering and death from ignorance, rather than life and happiness from knowledge and prevention.&rdquo; (MS, &ldquo;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=232534.xml">Birth Control or Abortion?</a>&rdquo; <em>Birth Control Review</em> [Dec. 1918]: 3-4 [<em>MSM</em> S70:0809].) </p>
 <p><strong><em> &nbsp;</em></strong><strong><em>Q. So is outlawing abortion the answer? </em></strong></p>
 <p><strong> &nbsp;</strong><strong>A.</strong> &ldquo;The only weapon that women have and the most uncivilized weapon that they have to use if they will not submit to having children every year or every year and a half, the weapon they use is abortion. . . . What does this mean? It means it is a very bad sign if women have to indulge in it, and it means they are absolutely determined that they cannot continue bringing children into the world that they cannot clothe, feed, and shelter. It is woman's instinct, and she knows herself when she should and should not give birth to children, and it is just as natural to trust that instinct and to let her be the one to say and much more natural than it is to leave it to some unknown God for her to judge her by. I claim it is a woman's duty and right to have for herself the right to say when she shall and shall not have children.&rdquo; (MS, &quot;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=236701.xml">Debate On Birth Control: First Speech</a>,&quot; Dec. 12, 1920 [<em>MSM</em> S76:0923 ].) </p>
 <p><strong><em>Q. Do you think that the prohibition on abortion has decreased the number of abortions in America? </em></strong></p>
 <p><strong> &nbsp;</strong><strong>A</strong>. &ldquo;Condemned for ages by moralists and theologians, it has been denounced as a crime second only to murder. Despite the laws against it and the severe penalties inflicted upon the doctor or midwife who performs the illegal operation, it would be difficult if not impossible to produce evidence that there has been any decrease in the practice. This despite the advance of civilization and the manifold efforts that have been made to safeguard maternity.&rdquo; (MS, <em>Motherhood in Bondage </em>[New York, 1928], 394.) </p>
 <p><strong><em>Q. </em><em>As an obstetrical nurse working part-time in the Lower East Side of New York City, just before the start of World War I, you cared for women who had undergone abortions. Can you tell us more about what you saw? </em></strong></p>
 <p><strong> &nbsp;</strong><strong>A</strong>. &ldquo;I saw that it is the working women who fill this death list, for though the master&rsquo;s wife may resort to abortions too, she is given the best care and attention which money can buy. A trained nurse is called in attendance, and every care is taken that there shall be no evil consequences. The worker&rsquo;s wife, on the other hand, must look for the cheapest assistance. The professional abortionist, the filthy midwife, the fake and quack, all feed upon her helplessness, and thrive on her ignorance and misery. I saw that the Comstock laws produce the abortionist, make him a growing and thriving necessity, while the law makers close their Puritan eyes.&rdquo; (MS, &quot;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=305121.xml">Should Women Know?</a>,&quot; <em>The Spur</em> [Feb. 1915]: 58-59 [<em>MSM</em> C16:72] .) </p>

 <p><strong><em>Q. Given these conditions, why would women resort to abortion? </em></strong></p>
 <p><strong>A</strong>. &ldquo;Nearly all of these women will fall into one of two general groups&ndash;the ones who are having children against their wills, and those who, to escape this evil, find refuge in abortion. Being given their choice by society&ndash;to continue to be overburdened mothers or to submit to a humiliating, repulsive, painful and too often gravely dangerous operation, those women in whom the feminine urge to freedom is strongest choose the abortionist. One group goes on bringing children to birth, hoping that they will be born dead or die. The women of the other group strive consciously by drastic means to protect themselves and the children already born.&rdquo; (MS, <em>Woman and the New Race</em> [New York, 1921], 119-120.) </p>
 <p><strong><em>Q. What happens if these women do not get abortions? </em></strong></p>
 <p><strong>A</strong>. &ldquo;For millions of babies whose mothers have not resorted to abortion there is no welcome when they arrive. How often have I stood at the bedside of a woman in childbirth and seen the tears flow in gladness and heard the sigh of &lsquo;Thank God!&rsquo; when told her baby was born dead! What can men know of the fear and dread of unwanted pregnancy? What can men know of the agony of carrying beneath one&rsquo;s heart a little life that tells the mother every instant that there is no room and no chance for it on earth? Even if it should be born alive, the probabilities are that it would perish within a year, after costing its mother untold anguish and suffering.&rdquo; (MS, &ldquo;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=306006.xml">Woman and Birth Control,</a>&rdquo; <em>The Thinker</em> [Dec. 1923]: 69-72 [<em>MSM</em> C16:206] .) </p>
 <p><strong><em>Q. You are clearly sympathetic to the plight&ndash;and stand up for the rights&ndash; of the working-class mother in these difficult cases. Yet many who are opposed to abortion might ask about the rights of the unborn. </em></strong></p>
 <p><strong>A. </strong>&ldquo;We speak of the rights of the unborn. I say that it is time to speak of those who are already born. I also say and know that the infant death rate is effected tremendously by those who arrive first, and those who arrive last. The first child that comes&ndash;the first or second or third children who arrive in a family, have a far better chance than those who arrive later.&rdquo; (MS, &quot;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=236701.xml">Debate On Birth Control: First Speech</a>,&quot; Dec. 12, 1920 [<em>MSM</em> S76:0923 ].)<strong></strong></p>
 <p><strong><em>Q. But haven&rsquo;t you argued that abortion is a risky procedure? </em></strong></p>
 <p><strong>A.</strong> &ldquo;We know that abortion, when performed by skilled hands, under right conditions, brings almost no danger to the life of the patient, and we also know that particular diseases can be more easily combated after such an abortion than during a pregnancy allowed to come to full term. (MS, &quot;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=320522.xml">Why Not Birth Control Clinics in America?</a>,&quot; Mar 1919. <em>American Medicine</em>, Mar. 1919, 164-167 .) </p>
 <p><strong><em>Q. Many women wrote to you, sometimes in a kind of code, or without fully realizing what they were asking, to see if you would refer them to someone who would end a pregnancy. What do you say to these women? </em></strong></p>
 <p><strong>A.</strong> &ldquo;I am sorry that there is nothing I can advise you to do except to consult your doctor who, if your health demands it, may help you. When you ask me the question &lsquo;How can I bring myself around; I am pregnant two months&rsquo;, you are asking for an abortion. Please understand that Birth Control, as I understand it, is never abortion. I do not approve of abortion, nor can I give the address of anyone who will perform the operation.&rdquo; (MS to Client, 1923 [<em>MSM</em> C12:582; <em>Vol. 1</em>, p. 381].) </p>
 <p><strong><em>Q. But your clinic in New York sometimes referred &ldquo;overdue&rdquo; patients (women who were pregnant) to private doctors in order to get a so-called therapeutic abortion. There is no evidence to suggest this was a frequent occurrence, but on one occasion, in 1932, when the assistant director admitted she had referred a young pregnant woman, recently engaged, to a private doctor for an abortion, what did you tell her? </em></strong></p>
 <p><em> </em><strong>A.</strong> &ldquo;I am so glad that you were able to do something for her, but remember, that these cases must not be taken as from the Clinical Research Bureau, if, in your judgment, something of that kind needs to have special attention. It must be understood that whatever you do is on your own personal responsibility and is not authorized by the Clinic. These are the hardest cases that we have to contend with, but we must safe-guard our work and those who stand behind us, such as our Advisory Council, etc.&rdquo; (MS to Marjorie Prevost, Feb. 17, 1932 [LCM 32:225].) </p>
 <p><strong><em>Q. You toured the Soviet Union in 1934 in part to investigate the widespread practice of abortion, which was legal there between 1920 and 1936. What did you discover there? </em></strong></p>
 <p><strong> &nbsp;</strong><strong>A.</strong> &ldquo;As you know, Russia tried out this plan under Government auspices, for years. The results were not altogether satisfactory, though statistics on them are inadequate. There is no doubt that many unwanted and undesirable pregnancies were avoided, but the speed with which the operations was performed, usually without anesthesia, produced unhappy results in some cases. A study made and reported in Russian medical journals indicated a large proportion of morbidity among the women who had had these abortions.&rdquo; (MS to Bernard Oliver, Nov. 24, 1941 [<em>MSM</em> S20:326], <em>Vol. 3</em>, p. 103.) </p>
 <p><strong> &nbsp;</strong><strong><em>Q. Any final thoughts or words of wisdom on this most vexing of issues? </em></strong></p>
 <p><strong>A. </strong>&ldquo;The history of abortion shows that it was opposed by law, by religious canons, by public opinion,&ndash; and the penalties range all the way from ostracism to imprisonment; yet neither threats of hell nor the infliction of physical punishment has availed. The two million abortions annually in this benighted country testify to that. Women will deceive and dare. They will resist and defy the power of Church and State. They will march to the gates of death to gain that liberty, that freedom from unending child-bearing which the awakened woman demands.&rdquo; (MS, &ldquo;<a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=236121.xml">Woman of the Future</a>,&rdquo; Sept. 1933 [<em>MSM</em> S71:492] ).</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
