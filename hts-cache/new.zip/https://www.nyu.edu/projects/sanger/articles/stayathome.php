
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #48 (Spring 2008)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #48 (Spring 2008)</h1>    
<div class="maintext">
<h1>"'Stay at Home, Margaret'--Japan Bars Sanger in 1922"</h1>

<p>There was no stopping Margaret Sanger in the winter of 1921-1922. After launching the American Birth Control League at the historic First American Birth Control Conference in November 1921, she turned yet another arrest &ndash; the police pulled her from the podium at New York&rsquo;s Town Hall during the closing session of the conference -- into headlines that advertised her free speech battle and the birth control cause across the country. The incident also helped extend her prominence overseas where, following recent trips to England and Germany, she had begun to emerge as a leader on international issues related to population and birth control, as she argued that overpopulation led to war. For her next foray abroad, she planned a five-month world tour, beginning with and highlighted by an invitation to deliver five to ten speeches in Japan. She was the fourth prominent Westerner contracted to take part in a lecture series sponsored by <em>The Kaizo</em>, a Japanese monthly review; the previous three could have filled the heart of any all-star speaking roster: Albert Einstein, H. G. Wells and Bertrand Russell. </p>

<p>It would be clear sailing: the countless details of travel had been determined, her thirteen-year-old son Grant had been whisked away from school &ndash; with &ldquo;scarcely enough clean shirts&rdquo; &ndash; ready to accompany his mother on a wide-eyed adventure, and sixty-one-year-old J. Noah Slee, the wealthy new suitor in her life, followed in tow with rejuvenated passion and a fat wallet. Packed up and ready to go in early February, she was bon voyaged by a small party in New York, then set off to San Francisco where she would depart for Yokohama on February 21st. The world was her oyster, as Sanger liked to say, quoting Shakespeare. (MS, <em>Autobiography</em>, 317.) </p>
<p>Then, at the last minute, the Japanese government informed Sanger she would not be permitted to set foot in Japan. Just four days before she was scheduled to sail aboard the passenger ship <em>Taiyo Maru</em>, the Japanese Home Minister directed the Consul General in San Francisco to deny Sanger a visa to enter Japan. Expecting pearls, she was left holding sand. They &ldquo;refuse to let me come to their fairy land,&rdquo; she wrote from San Francisco, &ldquo;&amp; I am sad &amp; unhappy.&rdquo; (MS to Hugh de Selincourt, Feb. 19, 1922 [LCM 3:763].) </p>
<p>Sanger responded by promising not to discuss birth control in Japan, but to visit &ldquo;simply for sightseeing purposes.&rdquo; The answer again was no. The unexpected news was picked up by U. S. and Japanese wire services and soon made headlines both in the U.S. and Japan: &ldquo;Barred By Japan,&rdquo; &ldquo;Our Undesired Emigrant,&rdquo; &ldquo;Japanese Authorities Alarmed Over Birth Control Advocate.&rdquo; (<em>Japan Weekly Chronicle</em>, Feb. 23, 1922 [quote]; <em>Chicago Daily Tribune</em>, Feb. 18, 1922; <em>New York Times</em>, Feb. 20, 1922; <em>Japan Advertiser</em>, Feb. 18, 1922). </p>
<p>Japan&rsquo;s official decision not to <em>vise</em> Sanger&rsquo;s passport not only complicated her ticket reservations (no visa, no tickets) but threatened to become an international incident, testing a fragile U.S.-Japanese diplomatic relationship. The two countries had sparred over immigration policy since the beginning of the century. Although they had come to a &ldquo;Gentleman&rsquo;s Agreement&rdquo; in 1907, with Japan limiting the number of Japanese immigrants to the U.S., tensions still ran high: the notion that Japanese immigrants depressed wages fed anti-Japanese sentiment in California; and the Japanese fumed about the segregation of Japanese students in San Francisco public schools. Sanger initially believed that her predicament was the result of Japan&rsquo;s &ldquo;turning the tables.&rdquo; She surmised that &ldquo;we had implied they were undesirable citizens, and now it was an American who was undesirable to them.&rdquo; But the reasons behind Japan&rsquo;s action to bar Sanger were much more complicated and probably had nothing to do with immigration policy and everything to do with political timing. (Janet Hunter,<em> Concise Dictionary of Modern Japanese History </em>[Berkeley, CA: 1984], 49 [quote 1]; MS, <em>Autobiography</em>, 317 [quotes 2-3].) </p>
<p>While Sanger was making her way to San Francisco, Japan&rsquo;s Home and Justice Ministries were drafting a &ldquo;Law to Control Radical Social Movements,&rdquo; better known as the &ldquo;Dangerous Thoughts Bill,&rdquo; an effort to control the spread of socialism, anarchism and Bolshevism in Japan. This new law, introduced into the House of Peers on February 21, the same day Sanger was to sail, was intended to give officials more power to silence propaganda and keep out foreigners they believed threatened the moral order and polity of Japan. Birth control was not included in this bill. Yet the vague language and broad scope of the bill allowed authorities to crack down on any ideas they found repugnant, inflammatory or threatening. &ldquo;The minute the Government heard of Birth Control,&rdquo; ran an editorial in the influential Japanese magazine, <em>Toyo Keizai Shimpo</em>, &ldquo;it at once adopted the attitude that it is a very dangerous thing, without any consideration of its pros and cons.&rdquo; (&ldquo;Dangerous Thoughts Under Control,&rdquo; <em>Japan Times &amp; Mail</em>, March 2, 1922; &ldquo;Editorial&rdquo; <em>Toyo Keizai Shimpo</em>, Feb. 25, 1922 [quote] [translated in <em>Japan Times &amp; Mail</em>, March 2, 1922.) </p>
<p>To the leadership of the Taish &Ccedil; era Takahashi government, birth control threatened a long-standing policy that encouraged population growth and military and political expansion. However, as there were no laws that specifically outlawed birth control in Japan, it was likely Sanger&rsquo;s radicalism, more than her birth control message, that prompted the Home Ministry&rsquo;s harsh reaction. When she asked the polite and apologetic Japanese Consul General in San Francisco whether Japan objected to her or to her cause, he &ldquo;notified me it was both.&rdquo; After all, Sanger was still considered a dangerous radical in the U.S. with ties to anarchists and Wobblies (Industrial Workers of the World) and a long police record. Although she worked diligently in the early 1920s to distance herself from World War I- era radicalism, Sanger still carried the baggage of her Bohemian heyday. (Elise K. Tipton, &ldquo;Birth Control and the Population Problem,&rdquo; in<em> Society and the State in Interwar Japan</em>, Elise K. Tipton, ed. [London, 1997], 43-44; MS, <em>Autobiography</em>, 317 [quote].) </p>
<p>The <em>New York Times</em>, on the other hand, advanced the theory that Japan did not want to offend American authorities by extending hospitality to a woman who &ldquo;had fallen under the displeasure of authority, ecclesiastical and political, in her own country.&rdquo; The <em>Times</em> implied that the New York City commissioners and police officials involved in the recent Town Hall raid might have tipped off Japanese Foreign Office personnel about Sanger&rsquo;s anti-authoritarian activities. Sanger biographer Ellen Chesler suggests yet another reason for Japan&rsquo;s decision: that the FBI, still compiling its impressive file on Sanger, may have intervened because the U.S. feared Sanger&rsquo;s &ldquo;potential influence over the rise of Communist sentiment in Japan.&rdquo; (<em>New York Times</em>, Feb. 20, 1922; Ellen Chesler, <em>Woman of Valor: Margaret Sanger and the Birth Control Movement in America</em> [New York, 1992], 246.) </p>
<p>Some applauded Japan&rsquo;s protective inclination and frowned upon Sanger&rsquo;s missionary zeal. An editorial in the <em>Los Angeles Times </em>called Sanger&rsquo;s proposed speaking tour &ldquo;a rather gross piece of impertinence.&rdquo; How dare she advocate in Japan &ldquo;what is so intimately domestic, so embarrassingly controversial&rdquo; when birth control remained illegal in the U.S. &ldquo;For the sake of international amity,&rdquo; the <em>L.A. Times</em> advised, &ldquo;for the sake of the reputation of the United States, for the sake of your own good manners stay at home, Margaret.&rdquo; (<em>Los Angeles Times </em>, Feb. 22, 1922.) </p>
<p>But Sanger had no intention of staying put. She was confident that the Japanese government&rsquo;s refusal to let her in was &ldquo;due to a misunderstanding of her message,&rdquo; and that she would be able to change minds once she met with officials on board the ship where she would have ample opportunity to press her case. More than a hundred Japanese who had traveled with the Japanese delegation to the 1922 Washington Naval Conference--diplomats, professors, doctors and military men--would be aboard the <em>Taiyo Maru</em>, returning to Tokyo. Sanger&rsquo;s immediate challenge was to secure a ticket. Since the ship would sail on to Chinese ports following a stop in Yokohama, Sanger was able to get a Chinese visa and a ticket to Shanghai by agreeing in writing not to leave the ship when it docked in a Japanese port. (<em>New York Times</em>, Feb. 19, 1922.) </p>
<p>As she had done repeatedly and successfully thus far in her short career in the face of opposition from any form of authority, Sanger appealed to the public. In this case, the press followed her every move; not only had local and wire reporters come to cover her story but so did several Japanese reporters who planned to accompany the Washington Conference delegates home. The visa controversy allowed Sanger to speak frankly about birth control in the press &ldquo;unmolested by the authorities,&rdquo; as one wire service reported it in Japan. She also had ample opportunity to publicly highlight her main concern about Japan, that it &ldquo;is a country but little greater in size than the state of California. It has a population which is almost half that of the United States and a birth rate that is increasing the population at a rate of 800,000 a year above the death rate.&rdquo; She proclaimed, &ldquo;If Japan would accept birth control openly and set about a scientific limitation of her population increase the problem of her over-population would be solved. Otherwise I can see nothing but a war of aggression that must come inevitably within the next twenty or twenty-five years. Japan will reach a place where the expansion of territory will be imperative.&rdquo; (<em>Japan Advertiser</em>, Feb. 22, 1922 [quote 1]; <em>New York Times</em>, Feb. 18, 1922 [quote 2].) </p>
<p>The whirlwind publicity surrounding Sanger may have convinced the Japanese authorities to reconsider their initial stand. They needed to dampen a firestorm that threatened to overshadow the return of the Japanese Washington Conference delegates and that had already created more advance publicity for the cause of birth control than Sanger herself or her Japanese hosts could have manufactured. &ldquo;The authorities have given Mrs. Sanger,&rdquo; wrote the editor of the <em>Japan Advertiser</em>, &ldquo;the finest advertisement in their power and every newspaper reader in Japan will shortly know more about birth control than he or she would have known if no effort had been made to hush it up.&rdquo; The government was also fighting off internal criticism from the press which generally viewed the incident with embarrassment. An editorial in the <em>Japan Weekly Chronicle</em> concluded that &ldquo;Probably no Japanese Government ever committed a more incomprehensible act .&rdquo; There were even reports of dissension within the Home Office where the &ldquo;younger element&rdquo; opposed such a &ldquo;narrow-minded attitude.&rdquo; (<em>Japan Advertiser, </em>March 2, 1922 [quote 1]; Feb. 18, 1922 [quote 3];<em> Japan Weekly Chronicle</em>, March 2, 1922 [quote 2].) </p>
<p>On February 21, the Japanese Foreign Office announced that its decision to deny a visa to Sanger was nothing more than a &ldquo;warning&rdquo; that she would not be permitted to lecture on &ldquo;an improper subject for public discussion,&rdquo; but that it would not prohibit her from visiting Japan, even without a <em>vised</em> passport. This ambiguous reversal left Sanger wondering about her options as she sailed off to what one Japanese paper called &ldquo;the Land of the Rising Sun and the Closed Mouth.&rdquo; (<em>New York Times</em>, Feb. 21, 1922 [quotes 1-2]; <em>Japan Times &amp; Mail</em>, March 9, 1922 [quote 3].) </p>
<p>&ldquo;I always chose to go forward,&rdquo; Sanger later wrote, &ldquo;and there was always a chance that a way might open.&rdquo; Once on board the <em>Taiyo Maru</em>, Sanger set out to insure that she could not only disembark in Japan but keep her scheduled speaking engagements. She released a statement from the ship that she had no plans to specifically discuss methods of birth control but would confine her remarks to &ldquo;the necessity of birth control for social improvement.&rdquo; At the same time she sought the attention of several prominent Japanese leaders. Two days out of port a group of Japanese passengers requested that she address them on the birth control movement. Afterwards, she had a discussion with Admiral Baron Tomosaburo Kato, the head of the Washington Conference delegation and a rising political leader in Japan (he became prime minister just three months later). She also charmed the Vice Minister of Foreign Affairs, and others on board, who if they did not fully embrace Sanger&rsquo;s rationale for birth control, appreciated the economic aspects of her argument. A number of Japanese passengers also expressed a personal interest in birth control, visiting Sanger in her stateroom &ldquo;to be informed.&rdquo; After meeting with Sanger, both the Admiral and the Vice Minister separately cabled the Home Office in Tokyo asking that Sanger be allowed to land and lecture without constraints. (MS, <em>Autobiography</em>, 317-319 [quote]; <em>Japan Times &amp; Mail</em>, March 7, 1922.) </p>
<p>Yet even as the <em>Taiyo Maru </em>pulled into the port of Yokohama, Sanger had not yet received official word that she would be permitted to disembark. &ldquo;From the various invitations I am receiving to speak before representative groups,&rdquo; she wrote at sea on March 8, &ldquo;it would seem I must be going to land.&rdquo; Conflicting telegrams told her she might be allowed to speak but not in public, that she might be permitted to speak in public but not on birth control, and that she would only be able to speak to private groups. There were press reports stating that the Home Office in Tokyo continued to weigh its &ldquo;misgivings as to the perils of birth control&rdquo; and might assign &ldquo;investigators&rdquo; to follow Sanger around. And according to the <em>Yomiuri</em> newspaper, the director of police for the Home Office said he was &ldquo;determined&rdquo; to keep Sanger from touching land. She also was told that thousands awaited her arrival and groups that both supported and opposed her visit had been speaking out in the press. She wrote, &ldquo;I await with interest the results of all this publicity-- There has been tremendous interest all through Japan &amp; if I address all the people who are asking me I shall be worked thin.&rdquo; She appeared, however, to relish the opportunity: &ldquo;I have had a good lazy trip,&rdquo; she told a friend, &ldquo;rested fully and am now ready to &lsquo;eat &lsquo;em alive.&rsquo;&rdquo; (MS to Anne Kennedy, March 8, 1922 [ <em>MSM</em> S2:125] [quotes 1, 5-6]; <em>Japan Times &amp; Mail</em>, March 7, 1922 [quotes 2-3]; <em>Japan Weekly Chronicle</em>, March 2, 1922 [quote 4]; <em>MS, </em>Journal Entry, March 9, 1922 [<em>MSM</em> S70:29-30]; MS, <em>Autobiography</em>, 319.) </p>
<p>The <em>Taiyo Maru </em>anchored in the Yokohama harbor on March 10 and was immediately surrounded by police launches, health department boats, mail tenders and boats carrying reporters. Seventy passes had been issued to the press and a throng of reporters and photographers pushed on to the ship. As the <em>Japan Times &amp; Mail </em>described it: &ldquo;The eager news men rushed up the gangway and scurried about in search of a notable news story. Was it Admiral Baron Kato they sought? It was not.&rdquo; Rather, they &ldquo;flocked onward until they found the modest quarters in which abode a modest little American woman and her handsome young son, Mrs. Sanger and the cause of Birth Control were what the press of Japan was interested in &ndash; the Peace [Washington] Conference was an old story.&rdquo; (<em>Japan Times &amp; Mail</em>, March 11, 1922.) </p>
<p>Sanger was besieged by both the press and Japanese officialdom. Police, who privately and jokingly referred to her as &ldquo;Mrs. Sangai,&rdquo; translated to mean &ldquo;destructive of production,&rdquo; handed her detailed questionnaires to be filled out, while government agents asked who paid her expenses and inquired about her contacts in Japan. After some delay she was told to apply to the American Consul in Tokyo to arrange her entrance, and a cable was sent. She signed a statement promising not to give a public lecture on birth control. Then at least twenty-five members of the press crammed into her small quarters as cameras flashed and clicked and reporters called out questions. &ldquo;Every reporter,&rdquo; she wrote, &ldquo;expressed his regrets that the government was acting this way &amp; said the people of Japan want me to come here and desire to hear about birth control.&rdquo; Her Japanese hosts and friends also boarded and helped her to navigate the bureaucratic demands. Baroness Shidzue Ishimoto, the most outspoken proponent of birth control in Japan appeared &ldquo;in her native costume.&rdquo; She and her husband, Baron Keikichi Ishimoto, a member of the House of Peers, translated for Sanger and used their considerable influence to try and expedite her landing. A delegation of women came forward to extend their welcome. More delays ensued as the U.S. Consul sent a representative but not the appropriate papers. (<em>Japan Times &amp; Mail</em>, March 9 [quote 1] and 11, 1922; MS, Journal Entry, March 10, 1922 [<em>MSM</em> S70:31-36] [quotes 2-3].) </p>
<p>As was later learned, final permission for Sanger to land had been given only the night before &ldquo;after a series of negotiations&rdquo; &ndash; among prefectural authorities in Yokohama, the Home Minister, the Foreign Office, the House of Peers and the Police Affairs Bureau of the Metropolitan Police Department in Tokyo &ndash; who &ldquo;made the diplomacy at the Washington Conference look like child&rsquo;s play.&rdquo; After five hours spent on the ship in quarantine, Sanger descended the gangway just as the sun set on her first glimpses of Japan. Customs promptly confiscated forty copies of her <em>Family Limitation</em> pamphlet, but she had given friends other sensitive materials to carry off the boat for her. Finally her ordeal had ended, and she and Grant were hurried off to the Ishimoto&rsquo;s home in Tokyo (and Slee to a hotel) for hot baths and bed. &ldquo;It seems complicated so far,&rdquo; Sanger wrote that night about the most distant and foreign place she had yet visited, &ldquo;but familiarity eases &amp; simplifies every problem.&rdquo; (<em>Japan Times &amp; Mail</em>, March 11, 1922<em> [quote 1]; Japan Advertiser</em>, March 11, 1922; MS, Journal Entry, March 10, 1922 [<em>MSM</em> S70:36] [quote 2].) </p>
<p>Over the next month Sanger gave a dozen public lectures, overcoming her ban on public speaking by addressing crowds that the police had been told were &ldquo;invited&rdquo; by various private organizations. She also met with scores of private groups and gave countless interviews. Birth control became the topic of the day as newspapers reported daily on her activities and magazines ran profiles and articles about her ideas. Baroness Ishimoto claimed that those few weeks in March and early April transformed Sanger&rsquo;s name into a household word for many years after. A public relations triumph, Sanger&rsquo;s tour also inspired a Japanese birth control movement to coalesce in her wake. Ishimoto later wrote that &ldquo;Not since Commodore Perry had forced Japan to open its doors to foreign commerce, in 1852, had an American created such a sensation.&rdquo; She added, &ldquo;if the government had deliberately tried to focus interest on birth control, it could not have done a better job.&rdquo; (Tipton, &ldquo;Birth Control and the Population Problem,&rdquo; 46; Shidzue (Ishimoto) Kato,<em> A Fight for Women&rsquo;s Happiness: Pioneering the Family Planning Movement in Japan </em>[Tokyo, 1984], 52 [quotes].) </p>
<p>[Our final volume,<em> The Selected Papers of Margaret Sanger, Volume IV: Around the World for Birth Control, 1920-1960</em>, will cover Sanger&rsquo;s 1922 World Tour in depth and incorporate some of the documents referenced in this article. The Volume will also include documents relating to General Douglas MacArthur&rsquo;s ban on Sanger visiting Japan, under American occupation, in 1950.]  </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
