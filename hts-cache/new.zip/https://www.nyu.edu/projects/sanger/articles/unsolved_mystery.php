
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #7 (Spring 1994)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #7 (Spring 1994)</h1>
<div class="maintext">  
<h1>"An Unsolved Mystery: The Case of Ye&acirc;nnis"</h1>

<p>    One of the most exhilarating and frustrating aspects of our work is the task of identifying authors and
recipients of documents.  While our success rate is remarkably high, there are a few mysteries we have as yet
been unable to solve.  Among the most challenging is the identity of the author of a letter we discovered among
the 45,000 Sanger documents in the Sophia Smith Collection.  Dated only "Monday 12 noon" and signed
"Ye&acirc;nnis" this neatly scribed 20-page letter begins: "Dearest Margaret: -  Six days of real suffering were enough
to make me feel that to suffer for you it is not suffering.  It is the sweetest feeling.  It is life.  And I live only for
you and with you." </p>
<p>     Like many authors of love letters, Ye&acirc;nnis brazenly repeats declarations of love and devotion and is careful to
communicate that his passion transcends mere passions of the flesh. For example, Ye&acirc;nnis reminds Sanger of
when they met:  "Did I fall in love with you?  No,
I did not and I am glad I did not have a sexual
attraction then for you.  You were more then sex. 
Subconsciously I wanted to tell you (right then if I
could) all about me and all about my life."   He 
apparently discussed marriage with Sanger and had
even asked her to elope. "Although I am sure of
your love", Ye&acirc;nnis declared, "the fact that we
could be apart even for a short period created in
me a fear, a strong fear, and while I am glad we
did not elope and thus we will have no reason of
regret, in reality I am sorry I did not force you to
run away."</p>

<p>    Sanger either got cold feet, or more likely, did
not respond to Ye&acirc;nnis's outpourings in anything approaching equal rapture;  she evidently wrote to him to back
out of the marriage, and possibly the relationship.  But Ye&acirc;nnis couldn't accept her decision:  "I do respect your
'resolve' and gladly I suffer by it...," he responded, "Yet it is killing a little by little my life.... You are my ideal
lover and no matter how I try to justify or not our love or your resolve I come to one conclusion that you are my
ideal lover."  It is possible that Sanger's rejection of Ye&acirc;nnis's proposal was not because  she would not marry
him, but because she could not.  While she had become estranged from first husband, William Sanger, in 1913
and beginning in December 1914 had asked him for a divorce, it was not finalized until October 14, 1921.  </p>

<p>      Unfortunately, we have very little evidence available to help us in
identifying the author.  Sanger did scrawl "The rival" at the top of the first
page, and early on we thought this might be a reference to Walter Roberts,
a some-time lover who attracted much of William Sanger's jealousy. 
However, Roberts' handwriting clearly did not provide a match, and
Ye&acirc;nnis wrote with an awkwardness and formality quite unlike the graceful
style and tone of Roberts' letters. This is the only letter that we have located
among Sanger's papers from anyone signed "Ye&acirc;nnis."  We are not even
certain if our reading of the handwritten signature is correct.  It seems to
spell Ye&acirc;nnis, but it could also be Liannis, Yiannis, or Jeannis.  It is likely
that the name is an alias or nickname.  "Ye&acirc;nnis" could be a Greek version
of the name "John," and might refer to John Reed who, according to Sanger
family lore, was romantically involved with Sanger.  But like Roberts,
Reed's handwriting does not match that of Ye&acirc;nnis.  A comparison of
handwriting also eliminated Sanger's other probable lovers and admirers of
the late teens: Billy Williams, Herbert Simonds, Lorenzo Portet, and Harold Hersey.  </p>
<p>    The document does offer several additional tantalizing clues.  Ye&acirc;nnis appears to have been active, or at least
sympathetic to the labor left and at one point writes, "If Big Bill or any one else could not see real love, equal and
mutual, and they only know how to give advice, to me it does not matter."  This is undoubtedly a reference to
William "Big Bill" Haywood, a radical leader of the Industrial Workers of the World whom Sanger knew and
admired.  At another point, Ye&acirc;nnis mentions Sanger's concern about staying on good terms with the "S.P.," a
likely reference to the Socialist Party.  These clues might help narrow down the date of the letter.  Sanger was
most active in the work of the Socialist Party and the labor left before 1916.  We know that Sanger had a falling
out with the Socialist Party in 1917 over its support of Frederick Blossom, whom she had accused of misusing
funds while he served as editor of the Birth Control Review.  It would appear that the letter was written before
knowledge of this had become widespread.  In addition, Ye&acirc;nnis writes: "When I was at a meeting for the Social
War someone told us you did not care to have anything to do with an anti-political paper....".  This is a probable
reference to The Social War, a Chicago-based anarchist journal published in 1917.  However, none of this is
conclusive nor has it enabled us to identify Ye&acirc;nnis.</p>

<p>We will continue to track clues and compare handwriting to try to pin down the identity of the elusive author,
but for now he remains a mystery.  If any of our readers have any leads that could help us to discover the identity
of Ye&acirc;nnis, we would appreciate hearing from you.</p>
<p>For updates on this story see <a href="mystery_solved.php">Mystery
Solved</a> and <a href="yeannis_revisited.php">Ye&acirc;nnis Revisited</a>.</p>

</div>	

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
