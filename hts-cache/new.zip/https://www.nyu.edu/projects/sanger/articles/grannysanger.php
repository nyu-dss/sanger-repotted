
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #65 (Fall 2013)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #65 (Fall 2013)</h1>
<div class="maintext">
<h1>"'Granny Sanger' Drops a Bomb - A Ten Year Moratorium on Births"</h1>

<p>It was an impetuous decision–some would say reckless–to make such a statement to the press without a prepared text and no staff by her side.  But that didn't stop Margaret Sanger from dropping what she called an "atomic bomb  . . . into the old world," as she boarded a plane to London on June 30, 1947.  She told reporters at La Guardia Field in New York: "Hungry countries should not have another child for a decade."  She went on to explain her reasoning and express concern for the postwar recovery in Europe, but much of this never made it into the wire reports that went out to nearly every English-language newspaper and to news agencies across the world, and that resulted in front-page articles with headlines that screamed: "Baby Ban Plan," "Stop Births," "Ten Years' Moratorium on Birth Advocated." (MS to Robert C. Nowe, Aug. 22, 1947 [MSM S27:414]; <em>New York Daily News</em>, July 1, 1947; <em>Oakland Tribune</em>, July 4, 1947, Washington Post, July 1, 1947; <em>Manchester Guardian</em>, July 1, 1947.)</p>

<p>With so much of the world trying to boost populations after inconceivable death tolls and physical and moral devastation left by the war, Sanger must have known her words would be viewed as incendiary--and also attention-getting.  Having been off the radar during the war years, her controversial statement landed her back in the news and into the eye of a publicity storm, discussing population concerns before a small army of print reporters and news reel producers encamped in the lobby of her London hotel.  She timed her urgent proposal to fall on the eve of an important trip to meet with British family planning leaders to organize a population conference and establish an international birth control organization.  She also planned to attend a conference on infertility at Oxford University.  </p>

<p>Sanger had called for birth moratoriums before, most recently in 1931, at the height of the Depression, when she suggested a two-year halt to child-bearing.  "Children should not be brought into the world to complicate the economic problems of their parents and further burden charitable institutions," she said then.  But never before had she publicly advocated anything close to a 
ten-year ban, on the face of it an  absurd request, but one that was           
sure to get people talking.  She justified the severity of her prescription by pointing to the catastrophic results of ongoing famine in many parts of the world at the same time that birth rates were rising.  Although conditions were improving in Western Europe by 1947, strict rationing remained in force, and many families still struggled to feed their children.  (<em>Chicago Daily Tribune</em>, Sept. 19, 1931.)</p>

<p>Without notes or a press release to fall back on, Sanger told reporters that war-torn countries must "do all in their power to help keep women from having children until the food and economic situations are adjusted there."  She believed European and Asian nations  "continue to overflow their boundaries, crowd their resources and breed themselves into new famines.  Many of them will ultimately breed themselves into another war."  But in Sanger's view the risk was not limited to Europe and Asia.  Rather, "the whole world should be interested in the intelligent limitation of population." She held up the United States as a model, where "a favorable balance of population and resources" had led to a rising standard of living. Asked about countries that needed to boost their workforce, she replied, "I think the adults who are living today could be moved into those countries where they need labor. Use the manpower that's there today, and don't bring any more children into the world to starve." Who would fight the wars, a reporter asked.  "At least there would be fewer people to be battered to death," she responded, with evident disdain over the question, before boarding her American Overseas plane to London. (<em>New York Daily News</em>, July 1, 1947.)</p>

<p>Meeting with British and wire reporters the next day in the posh Savoy Hotel, Sanger elaborated on the moratorium proposal, having had some time on the flight to flesh out her ideas.  She had made notes on the plane about women in war-torn countries who believed "they are giving birth to death not to life.  To bring children into these conditions is not kind nor fair to those already born & to those unborn." For the press, she consolidated this thought into one harrowing phrase; she asked that women not bring children into a world of "living death." Sanger also called for the involvement of the United Nations in this plan.  Instead of  encouraging people to have more children, she wanted the UN to take the lead in promoting baby quotas for all countries. She then asked "what mothers in England think of my plan.  I am prepared for attacks on it." (MS, July 1947 [MSM S77:49]; <em>Racine Journal-Times</em>, July 2, 1947; <em>Oakland Tribune</em>, July 4, 1947; <em>Sheboygan Press</em>, July 2, 1947.)</p>

<p>Prepared or not, the attacks began almost immediately.  "Granny Slee Calls for Slowdown on Babies," ran one headline, referring to the name of Sanger's second husband and establishing a "Granny" epithet, picked up by other publications, that suggested Sanger was old and out of touch. "Ban on Babies is All Wet, Cry Angry Britons," blared a headline in an American paper.  But it was London's  <em>Daily Mirror</em> which led the charge against Sanger: "There are lots of things we want from America and can't get, and some things that we get but don't want.  Into that latter category comes Mrs. Sanger."  They advised her to take her "nonsense" back to America, adding, "Her proposal would be about as practical as telling the sun to stand still or the tide to turn back."  An Associated Press report quoted a defensive Hampstead mother of three exclaiming, "Perfectly fantastic! The idea--saying we haven't enough food to bring up our children properly.  Did you ever see redder cheeks or sturdier legs than my babies have got?"  A barrister said, "I am afraid this Mrs. Sanger underestimates the--shall we say emotional needs?--that lead to the production of babies." (<em>Daily Mail</em>, July 2, 1947, quoted in Beryl Suitters, <em>Be Brave and Angry</em> [London, 1973], 23; <em>Chicago Daily Tribune</em>, July 4, 1947; <em>Daily Mirror</em> quoted in <em>Oakland Tribune</em>, July 4, 1947 and <em>Daily Boston Globe,</em> July 4, 1947.)</p>

<p>Clearly Sanger's plan had touched a raw nerve. Not only were the British, like all nations recovering from the war, keen on celebrating the joys of new life in the wake of death and demoralization, but they took great pride in the strides they had made in combating hunger and disease during the long, dark war years.  Britain had implemented an effective and egalitarian rationing system and new public health policies that had improved the general health of the nation, resulting in lower disease rates and a significant drop in infant mortality.  With all that this resilient country had sacrificed in combating Hitler--not only some 300,000 deaths but also virtual bankruptcy and the widespread destruction of its infrastructure--the Brits did not take lightly to any outside criticism.  (Keith Lowe, <em>Savage Continent</em> [New York, 2012], 14, 60-67.)</p>

<p>Others in the press questioned the practical ramifications of Sanger's proposal.  The <em>Daily Mail</em> discounted the immediate postwar population increase that had troubled Sanger, writing that "The boom in births which followed the war is partly artificial and is almost over."  They noted that population experts were predicting a sizable drop in the birth rate, and that most women had "already taken Granny Sanger's advice." Another source, reported by Sanger in a letter, blasted that "Granny Slee better stay home & teach the American G.I.s how to avoid leaving illegitimate children for England girls to work for!!!" (<em>Daily Mail</em> quoted in <em>Oakland Tribune</em>, July 4, 1947; MS to Florence Rose, July 26, 1947 [<em>MSM</em> S27:320].)  </p>

<p>The British weekly, <em>The Spectator</em>, imagined a future England and Europe that had adopted Sanger's moratorium: </p>

<blockquote>Suppose the women in question started taking the good advice now—and there is no time like the present. This is 1947. Some babies might still come dropping in till about next March, but then the supply would peter out completely. By March, 1958, therefore, there would be no children in this country, or any other ‘hungry' European country, under ten. In March, 1968, the ten to twenty generation would be non-existent. In March, 1978, the twenty-thirties, about as valuable an age-group as any, would just not be there. It may be a good idea, though from some obliquity of vision I seem able only to see the flaws. However, it doesn't really matter very much. Nature will frustrate a million Mrs. Slees." (<em>The Spectator</em>, July 3, 1947.)</blockquote>

<p>Some newspapers used the ruckus to urge British families to have more babies, advertising baby subsidies--five shillings a week for each child after the first.  The government offered other incentives as well, such as special ration books for expectant mothers to secure extra food and clothing.  But one  prominent voice opposed England's pronatalist policies and publicly agreed with Sanger's moratorium. Australia's Minister for Immigration, Arthur Calwell, argued that "Britain has more people than she can conveniently feed in peace and war" and should hold off on childbearing. But he had his own motive in depicting Britain as starved and crowded; he was trying to entice British citizens to the open spaces, plentiful food sources and new opportunities awaiting them Down Under, where Australia sought to bolster its industrial output by increasing its worker population.  (<em>Oakland Tribune</em>, July 4, 1947; <em>Manchester Guardian</em>, Aug. 19, 1947.)	</p>
<p>While the British may have been especially resentful toward an American telling them to, in effect, be unfruitful and diminish, Americans reacted similarly. In person-on-the-street interviews following Sanger's first statements to the press, not one thought the moratorium worth considering.  A secretary called Sanger's idea "very foolish and extremely stupid."  "What is the purpose of living if we humans can't have children," commented a handkerchief dealer in Manhattan.  </p>
<p>A Brooklyn police officer scoffed, "The suggestion is so ridiculous that it barely merits discussion." The <em>Pittsburgh Post-Gazette</em> responded in an editorial, "Whatever the merits of her past accomplishments, Margaret Sanger Slee has plainly pursued the birth control thesis to its ultimate absurdity in this proposal. What she now advocates is an experiment in mass suicide."  The paper concluded: "Years of war have reduced the world's resources, diminished its potential production.  Even so, we have not yet reached so bankrupt a state that we must declare a moratorium on human life." (<em>Pittsburgh Post-Gazette</em>, July 7, 1947.)</p>

<p>Not surprisingly, the Catholic Church piled on, with the Vatican taking the lead. Pope Pius XII used the opportunity to reject contraception as a means to alleviate suffering in poor and overpopulated countries. Without specifically naming Sanger, he referred to "shameless proposals made by irresponsible persons." The Vatican newspaper, <em>L''Osservatore Romano</em>, added that "such encouragement" to limit the birth rate was not needed in "many countries dismayed by a fearful decline in births." A recap of the Catholic response to the moratorium proposal in The Observer, the official newspaper of the Rockford, Illinois diocese, was paired with another article that captured a prevalent sentiment at the time among Catholics and many others; it was titled, "Veteran Refuses to Rent Home to Childless Couple." (<em>New York Times</em>, July 9, 1947; <em>Lethbridge Herald</em>, July 9, 1947; The Observer, July 20, 1947.)</p>

<p>A jet-lagged Sanger was unprepared for the press onslaught and overwhelmed by the personal attacks.   She vented to her assistants back in the United States:</p>

<p>I was so weary & tired as I had not slept all night on the plane & as I had no prepared statement on the 10 year moratorium idea. It was the most trying and exhausting experience Id really had. Photos, snaps, movies, the Pathe – Paramount took pictures. The RKO and others wanted me to go to the studios. I refused." (MS to Mary Compton Johnson, July 5, 1947 [<em>MSM</em> S27:248].)</p>

<p>The reporters held up the Savoy wires until the press room offered to sieve the calls for me.  The Pathe & Paramount flicks set up lights as I walked off the elevator to catch me & make me look fat, old mean–superficial & Granny.  (MS to Florence Rose, July 26, 1947 [<em>MSM</em> S27:320])	</p>

<p>Even Sanger's English friends, as well as her natural allies in Britain, family planning advocates, failed to come to her side.  Hugh de Selincourt, Sanger's onetime lover and close correspondent, could only comment on "How the strange ladies buzzed in the Food office over Granny Slee!" Peeved that she had not let him know she was coming to England, he offered little support beyond pining, as he always did, to see her. Other friends were oddly silent.  The neo-Malthusian publication, the New Generation, applauded Sanger's honesty but decided that "the time is not quite ripe" for her blunt message.  The Family Planning Association (FPA) tried to distance itself from Sanger and the controversy, fearing they would be labeled anti-baby.  It sent out a press release "disassociating the F. P. A. From the statement attributed to Mrs. Sanger." The whole episode threatened to turn the FPA's scientific conference on "Infertility–its Causes and Cure," to be held in Oxford on July 26-27, and to which Sanger had been invited, into a media circus.  The British Paramount Film News asked to film proceedings of the conference, unheard of at that time when most scientific gatherings of this sort were largely ignored by the press.  </p>

<p>Sanger noted that the FPA was "up in the air at my remarks" and ill-equipped to handle the media barrage if she traveled to Oxford.  She finally bowed out of the conference, snuck out of the Savoy Hotel, and hid in a friend's flat in Earl's Court and with friends south of London until "things quieted down."  The London-based sex reformer, Norman Haire, later reviewing that week's events for a colleague, thought that Sanger was "snubbed very badly" by the FPA and others in Britain.  (Hugh de Selincourt to MS, July, 1947;  MS to Florence Rose, July 26, 1947 [<em>MSM</em> S27: 339, 320]; FPA, Quarterly Letter to Members, July 1947 [MS Unfilmed]; "Margaret Sanger in England," <em>New Generation</em> [August 1947]: 53; Suitters, <em>Be Brave and Angry</em>, 24;  Diana Wyndham, <em>Norman Haire and the Study of Sex</em> [Sydney, 2012], 368.)</p>

<p>Despite being steam-rolled by the press, Sanger stubbornly stayed on message and refused to admit she had overreached in seeking an impossible result.  She noted that many in the public agreed with her.  She claimed to have received 130 letters in three days "and only five of them were against the idea, two being abusive."  (To our knowledge, none of these letters has survived.)  Was her proposal at all "unsound," someone asked a few days after her initial comments.  "Not a bit of it," Sanger answered.  She eased up slightly on camera, in an interview with the British Pathé for their weekly "One Minute News" reel, first aired on July 7, 1947. "Mrs. Slee, in this country having babies is the only thing left which is both un-rationed and untaxed, do you think we really ought to stop?" she was asked.  Sanger smiled, appreciating her interviewer's sense of humor, before replying, "Well I suppose a subject like that is really so personal that it is entirely up to the parents to decide." But she could not keep herself from reiterating that "I believe there should be no more babies in starving countries for the next ten years." Even more than a month later, after returning home, Sanger refused to budge.  "I am right," she wrote after describing her tribulations in England to a friend, "absolutely." ("Margaret Sanger in England," 53; <em>New York Times</em>, July 4, 1947; www.britishpathe.com/video/one-minute-news-8; MS to Robert C. Nowe, Aug. 22, 1947 [<em>MSM</em> S27:414].) </p>

<p>Sanger knew her proposal was impracticable and understood it would be viewed as insensitive. "I suppose my ideas will upset all my friends," she said at one point, referring to the people of England, a country she had always viewed as something of a second home.  But rusty though she was with public relations, having been semi-retired and in relative seclusion since just before the war, she gambled that the moratorium idea would reset a debate over population control that had dissipated with the war and had not yet reemerged in the midst of a postwar baby boom.  She continued to believe it was crucial to any sensible postwar planning.  The risk she had faced was lasting ridicule and a backlash against the birth control movement that could slow its progress.  It didn't happen.  Sanger was back in England a year later rallying support for a global population 
policy and headlining the historic International Congress on Population and World Resources in Relation to the Family, held in Cheltenham in August 1948.  The Congress launched the first viable postwar international birth control organization, the International Committee on Planned Parenthood in 1949, which became the International Planned Parenthood Federation three years later.  With all of the publicity over the moratorium, Sanger had once again asserted herself as the most recognizable leader of the birth control movement.  Now a grandmother closing in on seventy years of age, "Granny Sanger" had also become the most sought after voice on population planning, a subject that was rapidly growing in interest. (<em>New York Times</em>, July 4, 1947.)</p>

<p>To watch Sanger's interview for Pathe News online, see  <a href="http://www.britishpathe.com/">http://www.britishpathe.com/</a> and search for "Margaret Slee."</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
