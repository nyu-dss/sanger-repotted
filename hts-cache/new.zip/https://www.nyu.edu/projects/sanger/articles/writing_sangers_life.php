
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #14 (Winter 1996/1997)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #14 (Winter 1996/1997)</h1>
<div class="maintext">
<h1>"Writing Sanger's Life"</h1>

<p>From the time she first gained significant attention as the leading proponent of
birth control in 1914, Sanger recognized the necessity of selling her own story in order
to win a following for her cause.  In interviews and speeches given during the early
years of her crusade, Sanger spoke often of her mother's suffering after the births of
eleven children and she reminded audiences of her own maternity.  She offered vivid
accounts of her nursing career, in particular the dramatic story of Sadie Sachs, the
young mother cast off by medical indifference who died of complications related to
repeat abortions. Later in life she continually retold and often revised accounts of her
1916 arrest and imprisonment for opening the Brownsville Clinic in Brooklyn, and
other episodes that marked her years of protest.  Sanger's version of her life story
cloaked her in authenticity (she was clearly not another elite suffrage veteran far
removed from working class strife) and often camouflaged the more unsavory aspects
of her protest movement: the endless promotion, the lobbyist's deal-making, the bitter
in-fighting.</p>  

<p>In fact, Sanger's well-honed story became, in effect, the standard narrative
history of the birth control movement.  In a savvy public relations move she put out
her first autobiography in 1931, long before anyone had completed a proper biography
of her or a comprehensive account of the birth control movement.  Just seven years
later when more publicity was needed for the final stages of her decade-long, faltering
congressional lobbying campaign, she wrote another. Advancing Samuel Johnson's
belief that "every man's life may be best written by himself," Sanger knew that by
writing her own life (twice) she could best control and continue to make use of her
past.</p>

<p>Sanger had written several books by the time she sat down to work on her first
autobiography, <em>My Fight for Birth Control</em> (1931), in 1930.  Her approach in
composing most of her books was the same: work with writers and movement
veterans that she trusted to outline the book, sketch out or draft chapters on her own,
then turn the manuscript over to more seasoned writers and editors.  For My Fight
Sanger approached journalist Guy Moyston, an early socialist friend, a former foreign
correspondent with the Associated Press, and the author of several plays, film scripts
and magazine articles.  Before agreeing to help,  Moyston expressed several concerns
with Sanger's plans:</P>

<blockquote><p>... it is a dangerous project &ndash; dangerous because it well might imperil the
important work you are now engaged in.  As I see it, a work purporting to be
a real history of the movement must necessarily attempt to evaluate judiciously
all of the factors concerned in it.  Blame, as well as praise, would have to be
assigned, and it seems to me that a lot of chips would fly if you hewed to the
historian's line. . . Another consideration is that your modesty would not permit
you to play up yourself adequately, and as you yourself are the movement, you
could not possibly do justice to the subject. (Guy Moyston to MS, January 31,
1930, LCM 9:742).
</p></blockquote>

<p>  In the midst of beginning a major congressional lobbying campaign in
Washington, Sanger was unconcerned about conforming to a historian's methodology
(in fact she would later back-track from claims that the book was a history).   Her
goals were much more immediate and practical. Both the hurried pace of her writing
and the decision to compose the book during the hectic summer and fall of 1930
(wedged in between her work to inaugurate the National Committee on Federal
Legislation for Birth Control and organize the Seventh International Neo-Malthusian and
Birth Control Conference in Zurich), suggest that Sanger, on the eve of her battles
with Congress, wanted to swiftly reach out and grasp a public that was finally
swinging around to her side. The danger Moyston feared &ndash; the book rekindling feuds
within the movement &ndash; had never silenced her before.  What Sanger did fear was a
loss of momentum if the movement grew quiet and complacent and discontinued the
successful practice of recycling past trials and glories.  She wrote in her second
autobiography, "I could sympathize with the indignant old radical who left a birth control congress
sniffing,  This thing has got too darned safe for me!" (<em>Autobiography</em>, p. 412.)
The potential gains of
getting her story out to a
larger audience far
outweighed any clear or
hidden dangers.</p>

<p>As for Moyston's
concern that Sanger's
modesty might inhibit her
writing: he must not have
known her very well. 
Sanger had successfully put
herself in the forefront of
the movement for over
fifteen years and wasted
few words in various
publications and speeches
in reducing fellow and
sometimes competing birth
control reformers &ndash; Marie
Stopes, Emma Goldman,
Mary Ware Dennett, to
name the most prominent &ndash;
to subsidiary roles. She
seldom hesitated to give
herself credit or promote
her efforts, although
sometimes it was done
with a hint of modesty.</p>

<p>Nevertheless, the portrait Sanger created in <em>My Fight</em> resembles the
autobiographical depictions of other women reformers of the day in its use of what
historian Jill Kerr Conway describes as "the convention of being drawn to act by
forces of destiny outside their control." However, in <em>My Fight</em> Sanger largely
abandoned the passive character structure that was used in many biographies of
women: a depiction of the central figure as a beneficiary of circumstance, someone
who relies on the wisdom of a parent or mentor, one who ultimately is led to act, as
opposed to biographical treatments of men that tended to show greater independence
and decisive, purposeful actions.   In Sanger's story, even though destiny calls forth
("I knew a new day had come for me and a new world as well" [<em>My Fight</em>, p. 56]), she
is firmly in charge, assertive, a catalyst, a leader, and others are powerless to stop
her: "When once I believed in doing a thing, nothing could prevent my doing it," (<em>My
Fight</em>, p. 3). She also doesn't shy away from reminding us that her heroism was
evident even in pedestrian moments:</p>


<blockquote><p>When one of the deck stewards asked if I had a nurse or maid to help me
attend [to my three children] I said  No,' that it was no trouble.  He replied with
grave concern:  Well, Madam, it's the likes of you that has in  em the makings
of a real 'ero" (<em>My Fight</em>, p. 75).</p></blockquote>

<p>It is not clear how much of a role Guy Moyston or others played in drafting <em>My
Fight for Birth Control.</em>   It appears that Sanger deviated from her usual book writing
methods and actually wrote much of this first autobiography.  Her calendars and
letters during the summer and fall of 1930 make mention of the steady progress of the
manuscript as well as the difficulties of drawing out and culling memories.  She wrote
to Blakely Hall, her editor at Farrar & Rinehart:</p>

<blockquote><p>When I begin to dig down deep in my memory I get sick in the solar plexus.
(Thats doubtless a meaty bit for the  Freudians' or Psychologists) Especially is
this true when I think of the days & weeks of mental turmoil when it was
impossible to decide what     to do next (MS to Blakely Hall, July 24, 1930,
<em>MSM</em> S5:727).</p></blockquote>

<p>But just a day later Sanger reported on her progress to her husband: </p>

<blockquote><p>I wrote & wrote on my autobiography most of the day & while its still very
scrappy & disconnected, I am going to keep on digging down & back into my
memory until I dig all the vital things up - then patch them into a proper pattern
(MS to J. Noah Slee, July 25, 1930, <em>MSM</em> S5:737).
</p></blockquote>

<p>And the next day she told him that the  "autobiography runs like golden sand" (MS
to Slee, July 26, 1930, <em>MSM</em> S5:740).  </p>

<p>Apart from Moyston, several other individuals may have worked on the
manuscript, including early co-worker Anne Kennedy, the biographer, editor and drama
critic Robert Parker, and charities organizer John Kingsbury, although Sanger does not
credit anyone else with helping her.  The final prose was surely polished by others, but
there is little doubt that Sanger composed the basic text of the book; much of it is
close in both tone and content to material she wrote for earlier speeches and articles.</p>

<p>Although <em>My Fight</em>  received mostly favorable reviews when it came out in
1931 (the <em>New York Times Book Review</em>'s one-hundredth anniversary edition included
a reprint of Florence Finch Kelly's celebratory review [October 6, 1996]), Sanger found
herself defending it from friends and foe alike. Some accused her of ignoring
contributions by a host of movement workers, while others discounted the book as
poor history.  After making some attempts to support the work as accurate history,
Sanger down-played her efforts in the pages of the <em>Birth Control Review </em>and claimed
emphatically that it was neither history nor autobiography, "nor was it intended to be
more than reminiscences of the part that one person played in the movement"  (MS
to Editor, <em>Birth Control Review</em>, Vol. XV, no. 11, November 1931).</p>

<p>Whether it was poorly marketed, as Sanger later claimed, or simply mistimed,
<em>My Fight</em> fizzled and quickly went out of print.  Knowing she had a marketable story
on her hands, Sanger kept up interest in books about her life, and finally tempted W.
W. Norton to publish another autobiography in 1938.  Again, Sanger hoped a revival
of her story would jump start her cause as she scrambled to secure the endorsements
of politicians, major medical associations, religious institutions and social welfare
groups to counterbalance her failed attempts to get
favorable legislation passed in Congress.</p>

<p>This time around Sanger passed off the writing
duties to two ghost writers, Rackham Holt and Walter
Hayward, who both had journalism and business writing
backgrounds.  They taped conversations with Sanger
over several months in 1936 and 1937, rummaged
through movement records, and reconstituted much of
<em>My Fight</em> to complete <em>Margaret Sanger, An
Autobiography</em> in 1938.  A busier and less directed book
than its predecessor, the<em> Autobiography</em> toned down the
drama and heroics and provided a more leisurely tour of
Sanger's career to date.  Sections on Sanger's personal
life were generally short and anecdotal.  The reviews
were more mixed than before, but still mostly positive. 
And this time Sanger made sure to distribute the book
with more vigor through her birth control movement
channels, sending copies to governors wives,
philanthropic organizations, community centers, and a
long list of prominent individuals.  But once again sales
were low, and Sanger accused the publisher of lackluster
support and poor marketing.  </p>

<p>It was during the initial stages of piecing together
the second autobiography that Sanger learned that
Harold Brainerd Hersey, a free-lance writer and poet who
worked with Sanger on the <em>Birth Control Review</em> as an editor and occasional
contributor, planned to write a history of the movement with Sanger as the central
figure. Sanger wrote to him that she thought their similar projects might be redundant,
but essentially dismissed Hersey's intention as just another old friend with a flattering
proposal (MS to Hersey, October 20, 1936, <em>MSM</em> S11:713). When she heard
from friends and family in January and February of 1937 that Hersey was conducting
interviews and deeply engrossed in his work, she sought a meeting with him.  Not
only was Sanger worried about  potential competition with her own book, she
abhorred the idea of a former co-worker and lover &ndash; the two carried on a brief love
affair in the early 1920s, just prior to Sanger's marriage to J. Noah Slee &ndash; digging up
her past.  She wrote in an obvious panic to longtime secretary Florence Rose:</p>

<blockquote><p>Well Hersey did go out to Corning & my brother said he was cheap & awful &ndash;
He ran about wild talking to everyone over 80 that he could find.  He has a
complex which makes him avoid talking to intelligent people. He caters to the
poorest, most ignorant & likes what they say . . . He is no
biographer but a pulp journalist & I'm finished.  I've written his publisher & to
him.  He gives me a pain so there &ndash; (MS to Florence Rose, February 11, 1937,
<em>MSM</em> S12:537-538)
</p></blockquote>

<p>In an attempt to diffuse the
situation Sanger extracted a verbal
agreement from Hersey in which he
would write an "interpretation of MS as
a crusader" and that every word would
meet with Sanger's approval before
she would grant her consent.  In better
spirits she met with Hersey and his
literary agent/publisher Robert Speller
over drinks at the Ambassador Hotel in
New York.   But following some
pleasantries, Hersey pulled out a book
jacket and advance publicity materials
for his book.  According to Sanger, he
then declined to submit his manuscript
to her.  Incensed, Sanger refused to
cooperate any further or endorse the
biography. She even considered the
possibility of buying Hersey off (MS to
Florence Rose, March 1937, <em>MSM</em> S12:774).  As late as October of 1937
Sanger remained intransigent and
angry.  She wrote to ghost writer
Hayward: " I hoped against hope that
Hersey would drop dead or have some
other calamity befall him before he
finished what he calls a  Biography'" (MS to Walter Hayward, October 19, 1937, <em>MSM</em>
S13:625).</p>

<p>In the end Sanger triumphed for Hersey grew disenchanted with his book once
she refused to back it, and then saw his publisher go under.  Instead Hersey donated
the manuscript to the New York Public Library in 1939, calling it a "lamentable
venture," though he did not explain his final reasons for abandoning hopes of
publication. (Hersey to H. M. Lydenburg, August 29, 1939, a letter included in the
manuscript). It seems probable from reading the manuscript that Hersey's respect and
affection for Sanger prevented him from publishing his book against her wishes, even
though it turned out to be an adulatory biography.  A year later he explained to 
Sanger: </p>

<blockquote><p>I regret that my stern pride forbade me to permit you to examine the manuscript
of the book I had long dreamed of writing . . . The sardonic element in the
entire sad affair is that the book is and never was anything but a friendly piece
of work (Harold Hersey to MS,      August 6, 1940, <em>MSM</em>, S18:247-248).
</p></blockquote>

<p>Full of exclamations and poetic flourishes, Hersey's unpublished <em>Margaret
Sanger: Biography of the Birth Control Pioneer</em> is nevertheless an excellent history of
the early roots of the birth control movement, particularly the chapters covering
Sanger's early radicalism.  Hersey depicts Sanger as having taken a conscious, step-by-step approach to advocating and championing birth control.  In Hersey's account
Sanger did not stumble into the work or get swept along with the movement; rather
she made careful decisions and shaped events.  She was, he concludes several times,
a true visionary: "It is most illuminating the way Margaret Sanger has always seen far,
far ahead" (p. 135).  The final work is sharply focused on Sanger's career with little
attention given to her personal life.  It is also disjointed, overly laudatory and generally
uncritical.  However, it remains the only biography of Sanger written by a
contemporary and survives as a valuable source for  information on Sanger's activism
in the pre-World War I years.</p>

<p>While Hersey's manuscript collected dust in the New York Public Library, and
Sanger's autobiographies became little more than collectors' items and fodder for
Planned Parenthood Federation of America public relations staff, several other parties
approached Sanger with plans for a biography.  Each project had a fatal flaw for
Sanger (an unaccomplished writer, an unknown publisher, bad timing) until a young
free-lance writer and magazine editor named Lawrence Lader contacted her in 1953. 
Armed with an appealing biographical article he wrote in 1949 for Coronet magazine
on the New York theater family, the Lunts, and with the backing of a respectable
publisher in Doubleday, the enthusiastic and charming Lader promised Sanger a
detailed and uplifting biography over which she would have the final say.  Although
cautious, Sanger agreed, no doubt seeking a public reminder of her past achievements
as she organized the International Planned Parenthood Federation following a
triumphant international conference in Bombay in 1952.</p>

<p>In the early stages of his work, Lader's flattering enthusiasm for his subject kept
Sanger responsive and engaged. "But how does one put over the radiance, the
inexhaustible flame of your own driving force?," he wrote to her in July of 1953
(Lawrence Lader to MS, July 25, 1953, <em>MSM</em> S41:639-640). Lader made
significant progress in pulling together interviews and documentation on Sanger's early
career.  However, only a few months into his research, Lader began encountering
many dead ends in pursuing material on Sanger's personal life.  Sanger commiserated,
telling him she had "much sympathy for your having started to write a whole life of
a person who grudges every episode of her life in the telling of the memory.  But I
really want to help you as much as I can" (MS to Lader, December 3, 1953, <em>MSM</em>
S42:297).  However her offers to help were sometimes disingenuous.   </p>

<p>Sanger not only forbade access to her diaries and to  correspondence with
husbands, lovers, family and many friends, she also subtly discouraged her close
friends from cooperating.  She even restricted conversations between herself and
Lader, over such things as her recollections of her daughter Peggy's death.  Finding
many of his chapters to be uneven (too spotty in sections discussing Sanger's
personal life, her own reflections and her two marriages in particular), Lader kept
pleading for Sanger to release more material to him.  Exasperated, she wrote "you
seem to be reaching for the untouchable &ndash; why?  There is so much material available
to you to use but nothing seems to satisfy ever wanting the forbidden fruit &ndash; a male
characteristic" (MS to Lader, December 3, 1953, <em>MSM</em> S42:300).  She later
wrote a friend that Lader was "like a dog with a bone, digging and digging into the
past, and into the psychic experiences of ones life that really could make you quite ill"
(MS to Ellen Watumull, <em>MSM</em> C18, April 4, 1955).</p>

<p>When Sanger did offer her recollections or views they frequently ran counter
to the contents of the restricted letters and diaries.  For instance, she provided Lader
with a humorous and benign summary of her marriage to J. Noah Slee, but her
journals held evidence of a destructive relationship marked by petty behavior.  Always
the lobbyist for her own best place in history, Sanger also offered negative innuendos
about other birth control reformers who might compete with her legacy and
discounted them as women "who never touched the subject until after I returned from
England at the end of 1915...." (MS to Lader, October 13, 1953, <em>MSM</em> S41:865-866).</p>

<p>When Lader completed "one of the hardest jobs, maybe the hardest I'll ever
tackle" in the summer of 1954, his largest obstacle still lay in his path to publication
(Lader to MS, April 16, 1954, <em>MSM</em> S43:582).  Sanger criticized the book as
being gossipy, poorly structured and exhibiting toward the end a loss of enthusiasm
on the part of the author. Not willing to admit that the book's major shortcomings
were due to its lack of source material, Sanger went so far as to suggest another
writer be brought in.  However, she respected Lader, admired his hard work and
perseverance, and in the end met her obligations to him.  After making many
corrections and deletions on the final manuscript during a convalescence from a bout
of pneumonia (in which, she later admitted, she had trouble concentrating on the
work), Sanger reluctantly okayed the manuscript.  <em>The Margaret Sanger Story and the
Fight for Birth Control</em> was published in the spring of 1955.</p>

<p>Sanger seemed pleased to have yet another well controlled incarnation of her
life's story making the rounds, noting that "as I had the last word I was able to
eliminate a great deal of gossip that he picked up here and there, and I think altogether
the book stands very well (MS to Ellen Watumull, <em>MSM</em> C18, April 4, 1955).  Yet
when friends noted errors or who criticized the book for disregarding  the work of
others in the movement, Sanger became defensive, explaining:</p>

<blockquote><p>I did not approve of the book!  I approved of the corrections that were made,
and that one can never be sure of, for over and over again I made a correction
on one page, only to find the same error carried over in perhaps a little different
language two or three chapters on.  The changes made your head dizzy trying
to catch up to the tricks of the trade of that young man (MS to Dorothy Brush,
March 3, 1955, <em>MSM</em> S46:374).</p></blockquote>

<p>Without Sanger's unqualified enthusiasm, <em>The Margaret Sanger Story</em> was
doomed to the same fate as her autobiographies.  While Sanger did arrange a few
book signings and helped set up distribution through Planned Parenthood offices, the
book registered only modest sales.  The Book of the Month Club picked it for their
recommended list, but Doubleday could not work out a deal with a major magazine to
excerpt portions.  Reviews were generally favorable but not especially prominent. 
Both Sanger and Lader cited pressure against the publisher from the Catholic Church
as having a negative impact on sales.</p>

<p>In the end Lader's biography did not differ markedly from Sanger's
autobiographies, though it updated her work since 1938.  Possibly reflecting her input,
it reads like a long tribute and lacks objectivity in its assessments.  The most  valuable
result of his work for us today may be found in the rich correspondence between
Lader and Sanger in which she discussed her past at length and with emotion, a
relatively uncommon occurrence in Sanger's letters.</p>

<p>Sanger died in 1966 without an objective, independently written biography of
her having been published in her lifetime, a circumstance she might have privately
applauded. It is not surprising then that Sanger's autobiographical work, even though
it served as  propaganda and tailored many facts, established a definitive life story and
movement history that fed the
public relations departments of the
various birth control organizations
Sanger founded.  It is surprising that
her story went essentially unrevised
and unchallenged for a good thirty
years.  In fact it would take several
years after her death before David
Kennedy's controversial and highly
critical study of Sanger's pre-World
War II career, <em>Birth Control in
America: The Career of Margaret
Sanger </em>(1970), found an eager
university audience.  But Kennedy's
book was a study of the American
birth control movement, not a full-scale biography of Sanger.  Two
more traditional biographies were
published in the 1970s, Emily Taft Douglas' <em>Margaret Sanger: Pioneer of the Future</em>
in 1970 and Madeline Gray's <em>Margaret Sanger: A Biography of the Champion of Birth
Control </em>in 1978, but both works were riddled with inaccuracies (many carried over
from Sanger's autobiographies), poorly documented, and, in the case of Gray's book
in particular, preoccupied with gossipy tidbits and Sanger's tabloid-worthy love affairs. 
Two excellent studies of the birth control movement produced provocative but limited
interpretations of Sanger's role and impact: James Reed's <em>From Private Vice to Public
Virtue: The Birth Control Movement and American Society</em>, published in 1978, and
Linda Gordon's 1976 <em>Woman's Body, Woman's Right: A Social History of Birth
Control in America</em>. The first detailed, comprehensive, scholarly biography of Sanger
was not written until 1992 when Ellen Chesler weighed in with <em>Woman of Valor:
Margaret Sanger and the Birth Control Movement in America</em>, a book that builds
significantly on Sanger's autobiographical work by correcting errors, offering ample
context and addressing the second half of Sanger's career, a period overlooked by
previous scholars.</p>

<p>Chesler's biography is intimate and compelling.  It merges Sanger's public and
private lives in a single account, a task that Lader and Hersey failed to accomplish in
the midst of the living Sanger, and a challenge that frightened off many would-be
biographers, including Sanger friends Dorothy Brush and Robert Parker.   As is the
case with most biographies however, the subject's own voice is muffled in Chesler's
work.  Part of the problem stems from Sanger's writing style and phraseology. 
Sanger's words are illustrative but rarely resonate or give dimension to the
biographical portrait.  Her unpublished writing is anything but epigrammatic, seldom
self-revealing in short passages, and frequently unclear or contradictory when taken
out of context.  Her two autobiographies fail to compensate as the first is largely a
work of propaganda &ndash; bearing little resemblance to memoir &ndash; while the second was
almost completely ghost-written. </p>

<p>Clearly Sanger's own words need to be made accessible in a usable, condensed
format that will complement the fine interpretive scholarship contributed by Chesler,
Reed, Gordon and others, and will revitalize and inform the two autobiographies.  Now
that the Margaret Sanger Papers Project has published the extensive two-series
microfilm edition of her previously unfilmed papers and is completing an index to all
extant Sanger documents, providing scholars with access to nearly every word written
by Margaret Sanger, we aim to publish a selective two-volume book edition of
transcribed and annotated letters and unpublished writings by Sanger that will speak
in her own voice.  The book edition will not only highlight the events that propelled
Sanger's leadership of the birth control crusade, and the strategies, ideas and
controversies that underlay this momentous protest movement, the volumes will
include letters and other writings that provide crucial insights into Sanger's struggle
to balance her roles as mother, wife, lover, and friend against her all consuming cause. 
At a time when Sanger's words are increasingly being appropriated by reproductive
rights workers, anti-abortion advocates, the press, politicians, and even playwrights
and filmmakers, it is imperative that an accurate and readable source of her
unpublished writings is available.</p>

<p>At the end of his unpublished biography of Sanger, Harold Hersey cautioned
future biographers:</p>

<blockquote><p>My attempt to write the story of this
extraordinary woman can never hope to be any
more than the faint, shadowy outline of the
substance itself.  Nor do I believe that any later
biographer will find his assignment a
comfortable one.  Somewhat like a
paleontologist, he will be compelled to do the
work of reconstructing an elusive personality
on paper from the scattered bones of
contention.  The official records will increase,
but the personal records, already sparse, will
decrease (Margaret Sanger: Biography of the
Birth Control Pioneer, p. 336).
</p></blockquote>

<p>Others undoubtedly agreed with him and abandoned
work along the way.  Yet the Margaret Sanger Papers
Project continues to find new material by and about
Sanger every year.  No one who wrote about Sanger
in the past had access to all of the documents
uncovered by the Project (several hundred in just the
past two years), nor did they benefit from our
organization and arrangement of this material.  In
terms of the written record, the best time to write
Sanger's life is now.</p>

</div>	

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
