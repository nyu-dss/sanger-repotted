
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #40 (Fall 2005)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #40 (Fall 2005)</h1>
<div class="maintext">
<h1>"Countdown in Holyoke: Sanger Snubbed in Paper City"</h1>

<p> Margaret Sanger is coming to Holyoke tonight &ndash; no one knows where, not even Margaret Sanger.&rdquo; That was the front page news reported in the <em>Holyoke Transcript and Telegram </em>on the afternoon of October 17, 1940, just a few hours before Sanger was scheduled to speak in Holyoke, Mass. known as the &ldquo;Paper City&rdquo; because of its large and prosperous paper mills. </p>

<p>Sanger was nearing the end of an exhausting five-day, eleven-city tour of Massachusetts to drum up support for a petition-referendum to amend the state&rsquo;s birth control laws, which made it a crime for physicians to provide contraceptive care. By 1940, Connecticut was the only other state that still enforced similar archaic laws governing birth control. The first three days of Sanger&rsquo;s tour, organized and sponsored by the Massachusetts Mothers&rsquo; Health Council, had been uneventful, apart from a group of heckling priests in Worcester. The largely Catholic, industrial city of Holyoke, however was a different story. The events that unfolded in the Paper City from October 13-17 divided its 55,000 inhabitants, deepened the rift between the Catholic and Protestant churches and drew the attention of religious leaders throughout the nation. Today in Western Massachusetts it is still remembered as the &ldquo;Sanger incident.&rdquo; </p>

<p>What follows is a countdown to Sanger&rsquo;s appearance, scheduled for 8 p.m. on October 17th at the First Congregational Church in Holyoke. The Standing Committee of the Congregational Church had voted unanimously on September 29 to grant permission to the Mothers&rsquo; Health Council for the use of church premises. </p>

<p><strong>Sunday, October 13</strong></p>
<p>10:00 a.m. &ndash; Sanger kicks off her Massachusetts tour at the Community Church in Boston. </p>
<p>At the same time, the 80-year-old dean of the Catholic clergy in Holyoke, the Right Reverend Monsignor John F. Fagan, denounces Sanger and birth control at a mass given at St. Jerome&rsquo;s Church. In an official declaration released to the press, he calls Sanger &ldquo;a nationally known defender of vice&rdquo; and characterizes those engaged in birth control work as &ldquo;unpatriotic and a disgrace to the Christian community.&rdquo; He implores the Catholic majority in Holyoke to &ldquo;actively oppose any attempt to label this locality as a center of such immoral doctrine.&rdquo; (<em>Holyoke Transcript</em>, Oct. 14, 1940.) Fagan&rsquo;s remarks are echoed by at least one other prominent priest in the area, Rev. George S. L. Connor in Springfield, who warns that Sanger is bringing her &ldquo;pail of filth&rdquo; to enlist the aid of &ldquo;dog-loving women.&rdquo; (<em>Springfield Union</em>, Oct. 14, 1940.) </p>
<p><strong>Monday, October 14</strong></p>
<p>A reporter for the <em>Holyoke Daily Transcript and Telegram </em>says the city is &ldquo;seething&rdquo; following the declaration made against Sanger by Catholic clergy. For many Holyoke citizens, this is the first time they hear of Sanger&rsquo;s scheduled visit. The newspaper brings in a reporter from outside the community to cover a story seen as &ldquo;too hot . . . to touch&rdquo; for anyone who had to &ldquo;live here the rest of his life.&rdquo; (Underwood, <em>Protestant &amp; Catholic</em>, 7.) </p>
<p>Other Catholic groups take official action to oppose Sanger&rsquo;s appearance. The Isabella Court of the Massachusetts Catholic Order of Foresters, passes a motion instructing its &ldquo;Chief Ranger&rdquo; to draw up a resolution protesting Sanger&rsquo;s visit. </p>
<p>2:30 p.m. &ndash; Sanger speaks at the Hyannis Woman&rsquo;s Club in Hyannis. </p>
<p>8:00 p.m. &ndash; Sanger delivers a public lecture at the New Bedford Hotel in New Bedford. </p>
<p><strong>Tuesday, October 15 </strong></p>
<p>12 p.m. &ndash; The Holyoke Rotarians, made up of Catholic and Protestant business and professional men, meet at a downtown hotel for their regular monthly luncheon. Two important laymen of the First Congregational Church are confronted by Catholic laymen and asked to answer for the Congregational Church&rsquo;s decision to allow Sanger to speak there. One of the Congregational laymen, among the most prominent men in the city, is James H. Wakelin, president of the Holyoke National Bank and an owner of the McAuslan &amp; Wakelin Department Store. The Catholic Rotarians insist that the First Church is antagonizing Holyoke Catholics, and suggest to their Protestant friends that it would be an unwise business decision, in a city with a strong Catholic majority, for the First Church to host Sanger&rsquo;s meeting. </p>
<p>2:00 p.m. &ndash; A worried James Wakelin calls his pastor, Reverend Ronald J. Tamblyn of First Church, to report the veiled threat made by the Catholic Rotarians. Though not a trustee, Wakelin is the Church&rsquo;s organist and choir director. Tamblyn responds that the First Church would &ldquo;suffer a humiliating moral defeat&rdquo; if it rescinded its offer to Sanger. Wakelin agrees that they must hold firm even if there are economic consequences. Later, Tamblyn remembers that Wakelin seemed &ldquo;quite terrified by the specter of economic boycott.&rdquo; (Underwood, <em>Protestant &amp; Catholic</em>, 7.) </p>
<p>3:00 p.m. &ndash; Sanger speaks at the First Church in Salem. </p>
<p>8:00 p.m. &ndash; Sanger speaks on &ldquo;The Challenge to Massachusetts&rdquo; at the Balmoral Hall in Andover. </p>
<p><strong>Wednesday, October 16</strong></p>
<p>8:00 a.m. &ndash; Msgr. John F. Fagan telephones James Wakelin to express his dismay over the First Church&rsquo;s involvement with birth controllers and to set up a private meeting with Wakelin. </p>
<p>9:00 a.m. &ndash; Wakelin meets Msgr. Fagan and another pastor at the St. Jerome&rsquo;s rectory. Fagan convinces the banker that the Mothers&rsquo; Health Council is an immoral group that has &ldquo;done everything but commit the sex act in public.&rdquo; (Underwood, <em>Protestant &amp; Catholic</em>, 9.) He equates birth control with abortion and insists that the Church must fight Sanger&rsquo;s appearance in every way it can. He does not rule out the use of economic boycott and reminds Wakelin that St. Jerome&rsquo;s has over $30,000 on deposit at his bank. </p>
<p>1:00 p.m. &ndash; Under pressure from Wakelin and other businessmen, Rev. Tamblyn reluctantly calls a meeting of the First Church Standing Committee. Though short of the quorum, the committee votes five to two to rescind permission to use the Church&rsquo;s parish house for Sanger&rsquo;s meeting. In a statement to the press, the Committee explains that &ldquo;This action was taken because of the vigorous opposition to the program as reported in the newspapers and elsewhere. The action taken was purely for the sake of community harmony. . . .&rdquo; (<em>Holyoke Transcript</em>, Oct. 17, 1940.) Tamblyn scurries to help find another meeting venue for Sanger and calls other Protestant churches in the area. Not only do none of them come forward, but other pastors are critical of the First Church&rsquo;s handling of the affair, wondering why Tamblyn did not adequately prepare for such controversy. &ldquo;Never raise the devil if you can&rsquo;t bring him down,&rdquo; the reproachful pastor of the Grace Congregational Church tells Tamblyn. (Underwood, <em>Protestant &amp; Catholic</em>, 14.) </p>
<p>2:30 p.m. &ndash; Sanger delivers a lecture at the First Unitarian Church in Gardner. </p>
<p>7:00 p.m. &ndash; Eugene Belisle, the executive director of the Massachusetts Mothers&rsquo; Health Council, calls J. Gerliep, the steward of the Turn Verein Hall, the German Lutheran social society in Holyoke. Gerliep agrees to rent the hall to the Council for Sanger&rsquo;s appearance. Local papers are contacted and receive the new meeting information for publication the next day. </p>
<p>That evening Sanger issues a statement to the press condemning the First Church cancellation, stating that it is &ldquo;a violation of civil and religious freedom&rdquo; that demands &ldquo;investigation and protest by every person and organization concerned with civil liberties, religious freedom and tolerance.&rdquo; She calls this attempt to silence her a &ldquo;story of minority religious arrogance, bigotry and dictatorial terrorism&rdquo; that will warrant state and national interest. (<em>Springfield Republican</em>, Oct. 16, 1940) </p>
<p>8:00 p.m. &ndash; Sanger speaks at Tuckerman Hall in Worcester, despite the effort of Catholic groups in Worcester to block her appearance. </p>
<p><strong>Thursday, October 17</strong></p>
<p>12:00 p.m. &ndash; The Massachusetts Mothers&rsquo; Health Council pays Turn Verein Hall $10 to reserve use of the hall for 8 p.m. that evening and is issued a receipt. </p>
<p>2:00 p.m. &ndash; Sanger arrives at a supporter&rsquo;s home in Longmeadow, just outside of Springfield. Around the same time, a reporter calls the Massachusetts Mothers&rsquo; Health Council to inform them that Edward Kurth, president of the Turn Verein Hall, has withdrawn use of the hall for Sanger&rsquo;s appearance that evening. Both Kurth and the Hall steward, Gerliep, call to apologize to the Council but refuse to elaborate on the breach of contract. Gerliep later admitted he had received threats &ldquo;damning me to hell for my hatred of Catholics, and warning me I would lose my job.&rdquo; He also said that Msgr. Fagan spoke to him that morning. Fagan then contacted a local Catholic alderman who subsequently pressured Kurth to break the contract. (Underwood, <em>Protestant &amp; Catholic</em>, 15.) </p>
<p>3:00 p.m. &ndash; At a tea gathering in Longmeadow, Sanger responds to a reporter&rsquo;s call regarding her plans for that evening. &ldquo;This certainly does not seem like the United States,&rdquo; she tells the <em>Holyoke Transcript</em>, &ldquo;it&rsquo;s more like Russia or perhaps Germany. I really can&rsquo;t understand it.&rdquo; When pressed on where she might speak that night, she replies, &ldquo;It might have to be from a street corner; I really don&rsquo;t know.&rdquo; In the paper that evening the <em>Transcript</em> describes Sanger as &ldquo;twice married&rdquo; and points out that she had been traveling the state in a &ldquo;convertible coupe.&rdquo; (<em>Holyoke Transcript</em>, Oct. 17,1940.) </p>
<p>4:00-6:30 p.m. &ndash; Mothers&rsquo; Health Council staff and local supporters scramble to find a vacant hall, church, or even a store or parking lot. The City Clerk is approached about the use of city hall or some other municipal building, but he refuses to cooperate without the permission of Mayor Henry J. Toepfert, who is reported to be out of town. The police marshal is reluctant to grant a permit for a street meeting without the mayor&rsquo;s approval. </p>
<p>6:30 p.m. &ndash; Anna Sullivan, the secretary of Local 113 of the Textile Workers Union of America, C.I.O., calls the Mothers&rsquo; Council headquarters in Holyoke to offer the Union&rsquo;s office rooms. Sullivan, a married Catholic laywoman, later explained her motive: &ldquo;I was burned up that in a town of this sort where I thought we had progressed to the point where freedom of speech was accepted, a group had to fight for a place to meet.&rdquo; (Underwood, <em>Protestant &amp; Catholic</em>, 19.) The Mothers&rsquo; Council readily accepts her offer, and they immediately start a telephone chain to inform supporters. </p>
<p>8:00 p.m. &ndash; Between 70 and 100 people, including several local ministers and a number of prominent Holyoke citizens, fill the small rooms at the Textile Union office. Three police officers are stationed in the corridors and keep watch of the street. Reverend Tamblyn of the First Church speaks first, offering a short defense of free speech. And though his Church had capitulated to Catholic pressure, he adds: &ldquo;I do not like to run when others are attacked.&rdquo; (<em>Holyoke Transcript</em>, Oct. 18, 1940.) </p>
<p>Three other speakers provide introduction and then Sanger, dressed in a dark blue suit and looking &ldquo;small and frail&rdquo; according to one report, stands up in a doorway that has become the speakers&rsquo; area. (<em>Springfield Union</em>, Oct. 18, 1940.) She cannot resist directing a comment to Tamblyn: &ldquo;The movement has almost succeeded although our Congregational ministers occasionally get weak, don&rsquo;t they, Mr. Tamblyn?&rdquo; (<em>Holyoke Transcript</em>, Oct. 18, 1940.) </p>
<p>She brings her audience up to date on the current petition campaign to change the state law, then shares the personal toll of her crusade &ndash; she has been &ldquo;stoned, arrested and convicted.&rdquo; But &ldquo;her work has not been in vain,&rdquo; for there are more than 500 clinics in the country in 1940 and she has received a million letters from women and men seeking contraceptive advice. No one, she scolds, &ldquo;should take it upon themselves to interfere with [the] parents&rsquo; right to settle between themselves how many children they should have and when they should have them.&rdquo; She reminds everyone that birth control &ldquo;does not interfere with or destroy life. . . . It has taken people 24 years to learn that birth control is not abortion.&rdquo; (<em>Springfield Union</em>, Oct. 18, 1940.) </p>
<p>Departing from her prepared speech to address the recent events in Holyoke, Sanger declares that &ldquo;All religions have the right to express themselves, but when religion steps out of the sanctuary of the spiritual atmosphere, and descends to the market place, then we have the right to criticize it.&rdquo; (<em>Springfield Union</em>, Oct. 18, 1940.) It has been for her &ldquo;like old times,&rdquo; she says almost nostalgically. She is both surprised and invigorated by the bold and enterprising opposition in Holyoke, reminiscent of the kind of powerful counter-force she went up against repeatedly in the 1920s and occasionally in the 1930s, now largely subdued by the overwhelming acceptance of birth control. (<em>Holyoke Transcript</em>, Oct. 18, 1940.) Her uninterrupted speech ends with a question and answer period. It has been, after all, a peaceful night. </p>
<p><strong>Friday, October 18</strong></p>
<p>1:00 a.m. &ndash; Sanger sends a telegram to Birth Control Federation offices in New York City: &ldquo;NO PLACE IN THIS TOWN FOR US POOR ORPHAN ANNIES UP TO 630 TONIGHT FINALLY CIO GAVE US ASSEMBLAGE AND SPLENDID MEETING TOOK PLACE.&rdquo; (MS to Florence Rose, Oct. 18, 1940 [<em>MSM</em> S18:535].) </p>
<p>Sanger spoke in Greenfield and Pittsfield, on the 18th, completing the tour without another incident. &ldquo;That week,&rdquo; Sanger wrote about a month later, &ldquo;got speaking out of my system for good.&rdquo; Though there were many more speeches to come, it was the last of her major speaking tours, and the last time the Catholic Church would successfully interfere with one of Sanger&rsquo;s public meetings. (MS to Mabel &amp; John Kingsbury, Nov. 27, 1940 [<em>MSM</em> C7:138].) </p>
<p>Following Sanger&rsquo;s visit, Holyoke slowly recovered from the event. Many of the sermons, editorials and statements issued by community leaders in the immediate aftermath were intended to cool the religious animosity that had simmered to the boiling point. Holyoke Mayor Toepfert called the matter &ldquo;a slight flare-up&rdquo; and suggested blithely that &ldquo;everyone forget about it as soon as possible.&rdquo; (Underwood, <em>Protestant &amp; Catholic</em>, 24.) That did not happen. </p>
<p>The Federal Council of Churches sent an investigator in November to compile a factual report to be published and issued to Protestant leaders; Protestants in Holyoke reacted to the timidity shown by their clergy with angry letters to church officials, threats of resignation and declarations challenging the integrity of those who reneged on agreements or closed their doors to Sanger; Catholic clergy were accused of being too aloof to the Protestant minority; and dissenting Catholics rebuked their clergymen for the veiled threats of boycott. However, Msgr. Fagan, the main instigator of the protest and pressure tactics, was impenitent and matter-of-fact when he gave an interview several weeks later. &ldquo;Religion,&rdquo; he told the Federal Churches investigator, &ldquo;has been the occasion of more wars and hatreds than anything else.&rdquo; (Wood, &ldquo;Free Speech in Holyoke,&rdquo; <em>Information Service,</em> Mar. 22, 1941.) </p>
<p>On the national level, the Federal Council report on Holyoke, which carefully summarized the facts of the incident, was released to its twenty-two religious bodies as well as civil liberties groups and published in March of 1941. Several national Catholic publications ran opinion pieces on Holyoke, including the weekly, <em>Ave Maria</em>, which featured an article blaring the headline &ldquo;Mrs. Sanger Retreats&rdquo;; it called the incident &ldquo;an encouraging gesture to the lonesome Catholic stand on birth control.&rdquo; (<em>The Ave Maria</em>, July-Dec., 1940, 581.) </p>
<p>The events in Holyoke also prompted the Birth Control Federation of America to accelerate plans already underway to formulate a new strategy for confronting Catholic opposition. Finally, the incident focused national attention once again on the birth control laws in Massachusetts. The petition drive that Sanger aided finally led to a referendum vote in 1942. It was soundly defeated because the opposition had successfully defined contraception as a form of abortion and linked birth control with &ldquo;race suicide&rdquo; just as the U.S. was entering the war. In August 1966, just weeks before Sanger&rsquo;s death, the Commonwealth became the last state in the nation to legalize birth control for married women. </p>
<p>Several months after the Holyoke incident, Sanger continued to recount the event to friends and Federation leaders. She was concerned that planned parenthood groups had grown too complacent to fight the Roman Catholic Church. &ldquo;We have moved up into the social strata to get money to run the cause. In this strata, they do not like fighting crusading spirits, they want pleasant harmonious conciliatory efforts, to bring about results . . . I shudder for the future.&rdquo; (MS to Rabbi Sidney Goldstein, Jan. 16, 1941 [LCM 118:43B].) </p>
<p>(<strong>Note on sources</strong>: The countdown to Sanger&rsquo;s Holyoke speech was pieced together from the <em>Springfield Union, </em>the <em>Springfield Republican </em>and the <em>Holyoke Daily Transcript and Telegram</em>, October 14-21, 1940; &ldquo;A Preliminary Statement of Facts Concerning the Holyoke Affair,&rdquo; issued by the Massachusetts Mothers&rsquo; Health Council, October 23, 1940 [Records of the Planned Parenthood League of Massachusetts, the Sophia Smith Collection, Smith College]; and L. Foster Wood, &ldquo;The Free Speech Issue in Holyoke, Mass.,&rdquo; <em>Information Service </em>[March 22, 1941]. Meetings and discussions were reconstructed based mainly on the Federal Council report in <em>Information Service </em>and interviews conducted by Kenneth Wilson Underwood in <em>Protestant and Catholic: Religious and Social Interaction in an Industrial Community </em>[Boston, 1961], 3-38.)  </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
