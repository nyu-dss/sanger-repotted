
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #56 (Winter 2010/2011)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #56 (Winter 2010/2011)</h1>			

<div class="maintext">
<h1>"But <em>You</em> Can Call Me....."</h1>

<blockquote><p><em>&ldquo;It would have saved trouble had I remained Perkins from the first, this changing of women's names is a nuisance we are now happily outgrowing.&rdquo; &ndash; Charlotte Perkins Gilman in 1935 </em></p>
</blockquote>

<p>Editors of women&rsquo;s papers confront a challenge editors of men&rsquo;s papers don&rsquo;t always have to consider: variants on their subject&rsquo;s name. Margaret Sanger signed documents as &ldquo;Margaret Higgins&rdquo; (her birth name), &ldquo;Margaret Sanger&rdquo; (after her marriage in 1902), &ldquo;Mrs. William Sanger&rdquo; (very occasionally), and for a brief time, &ldquo;Bertha Watson&rdquo; (the alias she used during her 1914-1915 exile). </p>

<p>Following her marriage to J. Noah Slee in 1922, she continued to use &ldquo;Margaret Sanger&rdquo; most of the time and almost always in public, but usually went by &ldquo;Mrs. J. Noah Slee&rdquo; or &ldquo;Mrs. Margaret Slee&rdquo; when traveling or if she wanted to remain under the radar, such as in 1932 when she snuck into Italy despite a ban on her imposed by Mussolini. This gave Sanger a bit of a Batman/Bruce Wayne existence she seemed to delight in, as it often tripped up opponents, old lovers and others trying to track her down on board a ship or in a hotel. Some newspapers, in an attempt to be thorough and accurate, supplied two names, implying that the woman had two distinct lives. The <em>New York Times </em>referred in 1934 to &ldquo;Margaret Sanger, who in private life is Mrs. J. Noah Slee.&rdquo; (May 27, 1934). </p>

<p>Sanger also got a kick out of being mistaken for Margaret Sangster, the popular Victorian-era American poet of Christian verse: </p>

<blockquote><p><em>
&ldquo;Sometimes, in the dusk of evening,/ I only shut my eyes,/And the children are all about me,/A vision from the skies&rdquo;</em></p>
</blockquote>

<p>Sangster probably would have keeled over dead because of the frequent name mixup had not she already died in 1912, a couple of years before Sanger&rsquo;s became notorious as the &ldquo;Woman Rebel.&rdquo; Despite the poet Sangster&rsquo;s well-reported death, the birth control reformer Sanger continued to be confused with her; even as late as 1936 the<em> Los Angeles Times </em>reported a talk given on birth control by that well-known &ldquo;Margaret Sangster&rdquo; (Apr. 10, 1936).</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
