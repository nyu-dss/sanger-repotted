
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #19 (Fall 1998)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #19 (Fall 1998)</h1>
<div class="maintext">
<h1>"Claverack College"</h1>

<p>Since we discussed Margaret Sanger's informal, adult
education in the preceding article on the <a href="../articles/ms_and_modern_school.php">Modern School</a>, it
seemed relevant to briefly describe her formal education,
completed just about 100 years ago. </p>

<p>In 1895, at the age of 16, Margaret Higgins left her home in Corning, NY, to begin a three-year term at Claverack College
and Hudson River Institute located in the Catskill mountains
near the town of Hudson, NY.  She had expressed an interest
in medicine, and a good preparatory school presented the best
means of completing the first step toward a goal of attending
Cornell University and possibly the medical school.  Founded
in 1854, Claverack College was a respected coeducational
institution and successful stepping stone to a university
education.  Its 1889 brochure read: "The design of this
institution is to afford facilities for thorough and systematic
education to young men and women, and at the same time
furnish them a comfortable, cultured christian home." (Sanger
Papers &ndash; Unfilmed Portion &ndash; Sophia Smith Collection, Box
17, Folder 8)</p>

<p> It was, however, unusual for those with limited means such as
the Higgins' to send a daughter to a preparatory school; most
Corning families supplied the Corning Glass Works with
factory workers and wives of factory workers.  But Margaret's
older sisters, Anna  and Mary, working as a secretary and
domestic worker respectively, were able to save enough
money to pay Margaret's tuition. Claverack gave Sanger her
only formal education and proved to be a socially and
intellectually liberating experience.</p>

<p>Sanger quickly formed some close friendships at Claverack
and became particularly fond of an elegant New York City
girl, Esther Farquharson, who aspired to be an actress and left
after a year to pursue her dreams.  Following Esther's lead,

Sanger briefly considered leaving Claverack to become an
actress &ndash; even preparing an application and photographs for
an acting school in New York City and then dismissing the
idea upon receiving a request for her measurements. (<em>Autobiography</em>, pp.37-
38.)  While at Claverack, Margaret also
met and entered into a secret engagement with fellow student
Corey Albertson, who outmaneuvered other suitors until
William Sanger came into the picture in 1902. </p>

<p>Amelia Stewart Michell, another fellow student who followed
Sanger from Claverack to nursing school, remembered
Margaret  as "one of the most popular girls in school; I would
be inclined to say the most popular with both the girls and the
boys . . . How proficient she was.  She could sew as well as
cook . . . dance divinely; excel in her classes without
becoming a bookworm."  She added that
Sanger was a voracious reader but showed
no signs of interest in "radical ideas."
(quoted in Hersey, p. 61) Sanger recalled
herself in those years as a bit of a rabble-rouser and a burgeoning suffragist, writing
an essay on women's rights and taking a
strong stand for suffrage in discussions
and formal debates. (<em>Autobiography</em>, p.
38)</p>

<p>Unfortunately, her sisters were only able
to pay the Claverack tuition for two years,
forcing Margaret to try a vocation. In
1898, she took a position in a southern
New Jersey public school teaching
English to foreign-born first graders.  By
her own admission she was not "suited by
temperament" to the teaching profession,
and family circumstances soon intervened
to disrupt any thoughts she may have had
of remaining at the school.  With the news
that her mother's consumption had
worsened, Margaret Sanger returned to
Corning to nurse her mother and attend to
household duties. Following her mother's
death in 1899, Sanger arranged through
the family of Esther Farquharson to be admitted as a
probationer into the newly established nurse's training
program at the White Plains Hospital in White Plains, NY.
Margaret Sanger never graduated from Claverack, but she
later wrote that "Going away to school was epochal in my
life." (<em>Autobiography</em>, p. 35) </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
