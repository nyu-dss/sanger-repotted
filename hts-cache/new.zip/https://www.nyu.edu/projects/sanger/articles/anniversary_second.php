
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #16 (Fall 1997)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #16 (Fall 1997)</h1>
<div class="maintext">
<h1>"Anniversary of a Second Marriage"</h1>

<p>Seventy-five years ago this month, Margaret Sanger secretly married South African born J. Noah
H. Slee, founder and president of the Three-In-One Oil Company. Slee pursued Sanger after he
met her at a dinner party in New York in the spring of 1921. He accompanied her on a 1922
world tour, remained in Europe while Sanger attended to birth control work in the summer of
1922, received a divorce in August from his first wife, and finally married Margaret Sanger
before a city clerk in London on September 18.</p>
<p>
Sanger's appointment book entry for September 18, 1922 indicates that from the onset she
viewed the marriage as a practical convenience (maybe even an inconvenience). The entry
reads: "JN Rectory 11 am," followed by "lunch Harold Cox 1 pm." (<span class="italicText">MSM</span> S78:515) It was
a short honeymoon to say the least. Cox was one of several prominent Englishmen in Sanger's
circle of social and sexual companions that included H. G. Wells, Hugh DeSelincourt and
Havelock Ellis. Sanger spent considerable time with those friends while apart from Slee in the
weeks leading up to her marriage.</p>
<p>
The state of secrecy within which Sanger held the marriage for well over a year also suggests
that she was ill at ease with other's presumptions and possibly unsure about her own motives.
Even several close friends did not find out until several months later. Hugh DeSelincourt sent
sincere congratulations when he learned two months after the event, but could not resist a jab at 
Sanger's new found wealth, commenting that his "prices" are now "high," and "the pounds" that
will surely be raining down on all "shall be spent on flowers. I shall love getting them." (Hugh
DeSelincourt to MS, Nov. 12, 1922, <span class="italicText">MSM</span> S2:200).</p>
<p>
Many who knew Margaret Sanger did not learn of the marriage until newspapers around the
country ran reports in February of 1924, almost 18 months later. Sanger's sister Mary wrote her:
"The 'cat seems to be out of the bag' from the headlines in our newspaper. It had to come of
course." (Mary Higgins to MS, Feb. 20, 1924, MSM S2:506). Prominent headlines in 
society pages blared the gossipy news: "MILLIONAIRE MARRIED MRS. SANGER AFTER WORLD-WIDE CHASE," "BIRTH CONTROL ADVOCATE WAS SECRET BRIDE," "MRS.
SANGER ADMITS SHE WEDDED RICH OIL MAGNATE," "MARRIAGE OUT," COUPLE KEEPS MARRIAGE SECRET YEAR AND HALF," and "AROUND-WORLD WOOER WON
HAND OF MRS. SANGER." The New York Times wrote that when they reached Mr. Slee at 
his home and asked him to confirm or deny the report, Slee gave a terse and rather odd
statement: "Mrs. Sanger won't talk about it tonight. The subject is an old one"
(<span class="italicText">New York Times</span>, Feb. 18, 1924). When Sanger finally did respond to the press she issued the statement:  </p>
<blockquote>
<p>    My private life and my work for the birth control movement are kept separate entirely.    Since my marriage to Mr. Slee, I have been able to devote myself to my work more    intensely than ever before. He has been of such assistance and never interferes with what I    am doing. He has his business. I have mine.
(<span class="italicText">Buffalo Times</span>, Feb. 20, 1924). </p>
</blockquote>
<p>Undoubtedly Sanger feared that once her marriage to a wealthy businessman became public
news many friends and acquaintances who had lent a hand during the infancy of the birth control
movement would emerge to ask her for money. Writing in her Autobiography, she claimed they
did: </p>
<blockquote>
<p>    Within one week letters began to arrive from all over the United States and Canada. One    man wrote he had helped me get up a meeting at San Francisco and now needed a printing    press &ndash; would I mail him the trifling sum of three thousand dollars? Another brought to    mind I had had dinner at his home when lecturing in his city, and now that he had painted    enough pictures to hold an exhibit, would I finance it?</p>
<p>
Dozens of ministers, old men , old ladies, writers, sculptors wanted me to set them up in    business, musical concert work, bookshops, recalling the time they had taken me in cars to    meetings, or that I had slept in their beds. Parents requested me to send their children to    schools, to Europe, to sanatoriums &ndash; heaven knows what. I never knew people could need    so much . . . But all I could do was write back that I had no more wealth than before &ndash; my    husband's was his own. And I still required as many contributions to birth control as ever<br />
(<span class="italicText">Autobiography</span>, p. 356).</p>
</blockquote>
<p>Well, not quite. Tax records show that Slee contributed regular sums to Sanger's endeavors &ndash;
primarily the American Birth Control League and Birth Control Clinical Research Bureau (he
also served as treasurer for both organizations). And Slee used his money to support several of
his wife's needy friends and co-workers, including Agnes Smedley during her stints of birth
control work in India and China, and Havelock Ellis in his later years. Whether sparked by love,
or purely a strategic initiative on Sanger's part, or both, the marriage afforded her personal
financial security and greatly stabilized the economic health of the American birth control
movement.</p>
<p>
"We will be happy," Sanger wrote to Slee shortly after their first anniversary, "in spite of your
money" (MS to Slee, Nov. 1, 1923, <span class="italicText">MSM</span> S2:399). But it was not money that tested
this marriage so much as the great gulfs of separation. For much of the 1920s and 1930s Sanger
spent as many nights on the road and overseas as she did at home. At home too she cherished her
independence, insisting on separate quarters and hosting frequent guests in whom Slee had no
interest. And even though Sanger clearly communicated to Slee, before they took their vows, her
need to preserve an independent life, the couple's sporadic cohabitation both stressed and
probably saved their marriage. In her diaries, Sanger claimed on more than one occasion that 
sharing a house with Slee for long stretches of time made them quarrelsome and bitter. The
marriage lasted against many odds for twenty-one years until Slee's death at the age of 82 in
1943.</p>
<p>
Although Sanger flirted with the idea of marriage at least one more time &ndash;in the late 1940s to a
much younger man, a painter named Hobson Pittman &ndash; she retained her dual identity as Mrs.
Slee of Tucson, Arizona and Margaret Sanger of the world.
</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
