
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #36 (Spring 2004)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #36 (Spring 2004)</h1>
<div class="maintext">
<h1>"Early Sanger Letters Found"</h1>

<p>In December we received ten new Sanger letters covering the start of the
birth control movement. The letters were written between 1914-1916 by Margaret
Sanger to Hazel McLean Dreis (1890-1964), an internationally known bookbinder
who was associated with leftist circles in Berkeley, CA in the 1910s and
possibly with the radical journal <em> Land and Liberty</em>, edited by W. M. Owen
in Hayward, CA. The letters were in the possession of one of Dreis’s friends,
whose family sent them to us.</p>
<p>Radical poet J. Edward Morgan gave McLean’s name to Sanger, who wrote to
her on April 12, 1914 to ask if she would, as "a rebel woman," write a
piece for Sanger’s monthly <em>Woman Rebel</em>, which had just been launched in
March. It does not appear McLean sent Sanger anything for publication, but
Sanger’s initial letter sparked a friendship.</p>
<p>Over the next two years Sanger kept McLean informed about the government’s
suppression of the <em>Woman Rebel</em>, her indictment and exile in Europe.
"I have been indicted," Sanger wrote McLean in October 1914
"&amp; trial will be set in a few days – I have been secretly informed
that I am to get the limit – But I don’t believe it – I still hold that
jail is not my goal – but the work is to be done &amp; I am going to do it –
someplace." She sent McLean bundles of <em>Family Limitations</em>to be
distributed in the Bay area. From Liverpool, Sanger told McLean about her plans
to meet the exiled Italian anarchist Errico Malatesta and her first conversation
with Lorenzo Portet, the successor to Francisco Ferrer as head of the Modern
School movement, who would soon become Sanger’s lover. Upon her return to the
U.S., Sanger described seeing her children after a year-long separation. She
related that her five-year-old daughter Peggy told her "You had a different
face before you went away." Older brother Grant quickly said "Yes but
we like this one too." Sanger added: "I’m not sure its very
complimentary but someway horrible experiences will leave their mark."</p>

<p>Hazel McLean and Sanger finally met each other when Sanger came to San
Francisco in June 1916 as part of a cross-country tour. "It was a joy to
meet you &amp; find you so lovable &amp; big," Sanger wrote to her from
Portland, OR on June 18. Back in New York in August, Sanger again praised McLean
for her "character, beauty &amp; brains - How can a movement be anything
without individuals with ‘<u>guts</u>’–"</p>
<p>These marvelous letters have been added to the Sanger Papers in the Sophia
Smith Collection, Smith College and will be included by the Project when it
publishes a set of addendum reels to the <em>Collected Documents Series</em> of
our microfilm edition. If any of you have any Sanger letters or writings, or
know someone that does, please contact us. Nothing is too little, or too late!</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
