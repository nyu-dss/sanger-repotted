
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #7 (Spring 1994)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #7 (Spring 1994)</h1>
<div class="maintext">
<h1>"The World Center for Women's Archives:  A Look Back at a Novel Idea"</h1>

<p>    "We have worked intensively on this project;
forming the organization first, raising money,
collecting archives and, perhaps even more
important, trying to make the United States archive
minded....We have opened the minds of people all
over the country to the necessity of collecting and
preserving archives &ndash; especially about women." 
(Sanger Papers, Library of Congress)  While this
sentiment accurately reflects the goals of the
Margaret Sanger Papers Project (and most
women's archives and editing projects), the
statement was actually made on September 16,
1940 by Inez Hayes Irwin describing the struggles
of the World Center for Women's Archives
(WCWA).   Historian Mary Ritter Beard had
founded the WCWA out of frustration over the
difficulty she encountered in trying to locate
women's papers.  Beard realized that before
historians could examine or interpret women's
contributions to civilization and incorporate their
accomplishments into their books and curricula,
they needed to examine primary source material on
women's lives.  But such material was not easy to
find.</p>

<p>     Beard's quest to collect and preserve the documentary evidence of women's history began in earnest when, in
1935, she was approached by Hungarian-born pacifist-feminist Rosika Schwimmer with the idea of establishing a
center to document women's roles in the peace movement.  Beard quickly expanded the idea to establish an
archive and education center for the study of women.  The World Center for Women's Archives (WCWA) had its
first organizational board meeting in New York on October 15, 1935.  In addition to appointing a board of
directors (chaired by Inez Hayes Irwin) as its main decision-making body, the inaugural meeting invited well-known women sponsors to serve in an advisory capacity.  With endorsements from prominent women like Eleanor
Roosevelt and Frances Perkins, and support from Fannie Hurst, Mary Ware Dennett, Georgia O'Keefe, Katharine
Houghton Hepburn, Mary Van Kleeck, Juliet Barrett Rublee, Alice Paul and Margaret Sanger, among others, the
WCWA was officially launched on December 15, 1937, at the Biltmore Hotel in New York City.</p>

<p>     "NO DOCUMENTS, NO HISTORY," was the motto (coined by French historian Fustel de Coulanges) of the
WCWA, reflecting Beard's conviction that women's history requires the preservation of women's sources. "What
documents, then, have women?  What history?" she asked, for without these records "women may be blotted from
the story and the thought about history as completely as if they had never lived....But what do the women of today
know about the women of yesterday to whom they are so closely linked for better or for worse?  What are the
women of tomorrow to know about the women of today?" (WCWA Pamphlet, ca. 1939, Sanger Papers, Library
of Congress)  The creation of the WCWA was to be the answer for those concerned with preserving the history
and achievements of women.  Its purpose was:  "To make a systematic search for undeposited source materials
dealing with women's lives and activities....To reproduce important materials, already deposited elsewhere, by
means of microfilming and other modern processes..." (WCWA Brochure, International Organization Records,
Sophia Smith Collection)</p>

<p>    In the four years of its existence, the WCWA
helped highlight the richness and depth preserved
in the records of women's history.  Its preliminary
work in soliciting women to donate, deposit, or
pledge their papers and records to an archives
proved to be invaluable.  Materials which were
promised to the WCWA included the records of
the National League of Women Voters, the
National Consumer League, the National Council
of Jewish Women, and the National Association of
Women Lawyers.  Among the women who
pledged their personal papers to the Center were
Ida Tarbell, Eleanor Roosevelt, Carrie Chapman
Catt, and Judge Florence Allen.  Among the
collections in the Center's possession at the time of
its dissolution were those of Lillian Wald, Kate C.
Hurd-Mead, Catherine Beecher, and an impressive
collection of records, maps, and charts belonging
to Amelia Earhart.  </p>

<p>     Although predominantly reflecting the
achievements of notable white American women,
the WCWA also collected materials concerning the
women's movement in Germany and the history of
Japanese women from the mythological age
through 1935.  Prefiguring the emergence of the
new social history and feminist history, the
founders defined the WCWA's collection mission
broadly, asserting that women's history would be
found not only in the written record, but also in oral histories, objects and artifacts. They mounted an exhibit of
Native American women's pottery that included a pictorial history and ancient medicine aprons which told the lore
of herb women. From its offices in New York and Washington, the Center also compiled and distributed lists of
secondary sources essential to the study of women, served as a clearinghouse for information about women at
other institutions, and furnished information for a series of radio talks on women in American society. </p>

<p>     Yet despite the wide publicity and initial support from prominent individuals, the WCWA was unable to build
a permanent future for itself.  By the end of the decade, the war in Europe preoccupied the WCWA's sponsors,
overshadowing their interest in documenting the lives of women.  Faced with a lack of funding, weakened by
disagreements among its leadership and Beard's resignation in 1940, the Center was forced to close its doors on
September 16, 1940.   Though the Center failed, Inez Hayes Irwin sent a hopeful message to the Center's
sponsors: "When the quiet days of peace and reconstruction come, we are sure there will be many such
organizations as we have worked so hard to form and perhaps ultimately the big central one that was our dream."
(Irwin to Sanger, 9/16/1940, Sanger Papers, Library of Congress)</p>

<p>   After the Center's closing, the collections gathered by the WCWA were either returned to their owners or
entrusted to other repositories.  Yet the WCWA left a lasting impact as several colleges and universities began
collecting source material for the study of women, and individual women became aware of the importance of
taking steps to preserve the records of their lives.  Although Margaret Sanger never donated her letters to the
WCWA, less than two years after it was disbanded, she began to transfer the first large collection of her papers to
the Library of Congress; in 1949, encouraged by her close friend Dorothy Brush, Sanger donated her other papers
to the Sophia Smith Collection at Smith College.  Ironically, Mary Beard destroyed the majority of her own
personal papers.</p>

<p>     Committed to "put women in the record," Mary Beard and the WCWA sought to do what the Sophia Smith
Collection (Women's History Archive) at Smith College and the Schlesinger Library at Radcliffe College are in
fact doing &ndash; collecting and preserving the records of American women's history. At the same time, editing
projects such as the Sanger Papers and other women's editions are working to assemble and disseminate women's
papers through books, microform, and new CD-ROM technology.  </p>

<p>     While Beard's notion of one central archive for women's records and papers remains the stuff of dreams the
possibility of making it a reality is increasingly viable.  Technological advances such as digital image storage may
provide a way in which one central database can access images of hundreds of thousands of women's records and
papers.  As the Sanger Papers project explores these new methods of disseminating the records of Sanger's life,
we are hopeful that it will take us a step closer to making Beard's dream a reality.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
