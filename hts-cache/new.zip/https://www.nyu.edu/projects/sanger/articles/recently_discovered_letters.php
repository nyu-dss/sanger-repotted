
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #11 (Winter 1995)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #11 (Winter 1995)</h1>
<div class="maintext">
<h1>"Recently Discovered Sanger Letters Reveal Insights Into the Early Birth Control Movement"</h1>

<p>Juliet Rublee (1876-1966), free-thinking socialite and wife of lawyer and
political adviser George Rublee, was Margaret Sanger's closest friend and one of
her most devoted allies in the birth control movement (see profile of <a href="documenting_friendship.php">Rublee</a>
in the Fall 1992 issue of the <em>Sanger Papers Project Newsletter</em>). Their
correspondence, covering over four decades, provides the most colorful, frank,
and revealing portraits of the two unusual women and reveals crucial elements in
the development of the American birth control movement.</p>

<p>For understanding Margaret Sanger the correspondence is crucial for it was in her
handwritten letters to her most intimate friend that Sanger was most willing to open
her heart and mind.  However, until recently the surviving correspondence, located
among the collection of Sanger's papers at the Sophia Smith Collection at Smith
College, consisted of a disproportionate number of Rublee's letters to Sanger.  The
imbalance was partially restored in 1988 when the Sanger Project located
approximately 150 letters at Dartmouth College, but several large gaps in the
correspondence remained, most conspicuously Sanger's letters to Rublee written
between 1947 and 1961.  Some earlier letters seemed to be missing as well, and we
had concluded that many of Sanger's letters to Rublee had either been destroyed
(often at Sanger's request) or lost.</p>

<p>This summer, Mrs. Ellen Rublee, the wife of Juliet Rublee's nephew, George Rublee
contacted the Sanger Project with the exciting news that she had located an
additional cache of Margaret Sanger's letters to Rublee among hundreds of papers left
by her late father-in-law at his home in New Hampshire.  Mr. and Mrs. Rublee
generously gave the Project access to the over two hundred heretofore unseen Sanger
letters.  Written between June of 1917 and July of 1955, these handwritten letters
reveal Sanger's thoughts and feelings about her family, friends and colleagues, her
views on the events of the day, and both her rash judgements and considered
ruminations concerning the birth control movement.</p>

<p>Among the most significant elements of this new find are the surprising number of
Sanger's letters written between 1916 and 1920, a period when there was little time
or money to copy letters and Sanger and her staff saved fewer documents. 
Consequently, historians of the birth control movement and Sanger's biographers
have had to rely heavily on her autobiographies, written some 25 years later for
Sanger's thoughts, feelings and motives for this critical period.  This new cache of
Sanger's letters to Rublee provides an intimate, first-hand account of her views of the
people, events, and issues she faced as she struggled to shepherd the fledgling
movement through its difficult early years.</p>

<p>Rublee's involvement with Sanger and the birth control movement began in
October 1916, when she responded with outrage over Sanger's arrest and trial for
opening the Brownsville clinic by contributing her time, money, and name to
Sanger's cause. Grateful for the moral and financial support Rublee offered,
Sanger quickly accepted her patronage. She also eagerly took up Rublee's offer
to recruit additional support among the wealthy and powerful movers and shakers
of the Rublees' social circle. In one instance, Sanger asked, 'I am sending you
under separate cover two books [copies of] 'The Case for Birth Control' and
wonder if you could in some tactful way get one of them to Judge Hand and the
other give to Mr. Dowe without their knowing I sent them. I'm afraid they would
both think I am trying to prejudice the Courts and the Colleges. I am too, but
they should not know it.' (August 23, 1917, <em>MSM C</em>)</p>

<p>Before long, Rublee emerged as far more than a benefactor and fellow activist
for birth control; she became one of Sanger's closest friends and confidantes.
After her 1917 Brownsville trial Sanger focused her efforts on publishing The
Birth Control Review, a monthly journal promoting the cause. In the spring of
1917 Sanger accused her managing editor, fellow Socialist Frederick Blossom, of
mismanaging Review funds and then initiated legal proceedings against him.
Writing from her summer home in Truro, Massachusetts, Sanger confided to Rublee,
'you will be amused to hear of Dr. B. He has been so petty that I am ashamed of
the masculine. However it is all over &ndash; he shares the office until Oct or until
I make other arrangements. But he is out as far as representing me is concerned
.... The Blossom affair greatly upset and depressed me for days &amp; days, so I
just ran away here. I just can't deal with 'fish-wife' minds &amp; must let them
alone.' (July 13, 1917, <em>MSM C</em>). By October, Sanger was scrambling for
funds to keep the <em>Review</em>  in business, and had asked the National Birth
Control League, formed by Mary Ware Dennett in 1915, for support but was worried
by the damage the Blossom affair had done to her reputation in the movement.
'You can never know the <U>treachery</U>  of the person spoken of (B.),' she
wrote Rublee. 'It makes me feel queer every time I see a good looking man with a
minister face. I do not know what happened at the Nat. I have not heard a word
tho I wrote Mrs. Pinchot asking the Nat to help with the Magazine. ' (October
10, 1917, <span class="italicText">MSM C</em>) As Sanger was being accused by her Socialist Party
associates of betraying their cause, and efforts to gain sustained support from
the National Birth Control League failed, it was Juliet Rublee who provided
badly needed financial assistance. Sanger, in turn, began to confide more openly
in her loyal new friend:</p>

<blockquote>
<p> 
  'The National have upset me a good deal on their decision not to help the
  Review. It seemed such an opportunity for them to do a very important thing.
  Certainly the B.C. Magazine has a <U>future</U>  and the burden of all the
  movement should not fall upon
<U>so few</U>  to carry. Were it not for your friendly spirit I'm afraid I
  should have run away, this week, to some cave and spent the rest of my life
  laughing at the world. The task before me seems so colossal to undertake alone
  and that is what it means since the N.B.C.L. decided not to help .... So much
  has been doing with Mr. Blossom that I just had to give over his letters to
  Mr. Goldstein [Sanger's attorney] to attend to for me. The slanders &amp;
  insinuations were too beneath me to notice - 'going over to the rich' etc.
  etc. He is doing himself (only) much harm. It is impossible dear lady to
  express to you how deeply I feel and what gratitude for your help with this
  office.' (December 4, 1917, <em>MSM C</em>)</p>
</blockquote>

<p>But Sanger still needed to
find sustained support to keep the <em>Review</em>  going. She told Rublee she
was considering turning the magazine over to Dr. William Robinson, one of the
earliest and most respected physician advocates of birth control, but hesitated,
explaining, 'I never have liked the way he treats the subject &amp; of course
feel that women must be found who believe enough in this cause to carry this
magazine without making it a <U>trade</U>  journal. Yet unless women can be
found who are ready to do this for a year at least I may have to pass it over to
him.' (December 29, 1917, <em>MSM-C</em>). Rublee took the hint and joined with
other prominent women including Mary Knoblauch and Jessie Ashley to form the New
York Women's Publishing Company. Each member purchased $ 1 00 shares of the
company in ' order to provide the capital which funded publication of the <em>Review</em>.
Rublee, the first to contribute, served as president of the company which
sustained the <em>Review</em>  until 1923 when Sanger's American Birth Control
League took on the responsibility.</p>

<p>During this time, Sanger also continued her efforts to provide verbal advice
on contraception out of an office at 104 Fifth Avenue paid for by Rublee. 'We
are going on with our office work quietly making an underground campaign in the
foreign ranks, Italian, Jewish, Hungarian &ndash; I feel sure this will help these
people for never was there greater need of keeping the families down.' (October
10, 1917, <em>MSM-C </em>) Sanger sent Rublee samples of the heart-rending
letters she regularly received. 'What a blessed woman you are,' she told Rublee,
'the little room is the joy of my life &ndash; women coming from all over. I'm
feeling like a mother to the world these days. All kinds of questions, problems
to be solved and men &amp; women seem to think by coming &amp; looking at me
-all will be right. (December 4, 1917, <em>MSM C</em>).</p>

<p>In 1918, when her conviction for opening the Brownsville. Clinic was upheld
on appeal, Sanger explained the impact of the decision to Rublee and laid out
the next step for the movement:</p>

<blockquote>
<p> 
 "The case before the Court of Appeals at Albany was affirmed
          &ndash; but with the decision came an opinion by Judge Crane in which he
          stated that under <U>1145</U>
          Physicians can &amp;, may) give information to women in order to <U>prevent</U> 
          disease or to
<U>cure</U>  disease. This is considered by the Judges &amp; Lawyers here as a
          victory for us! We can no longer say that the Doctor can not give this
          information to tubercular women &amp; those suffering with other
          ailments. Now we must let the Doctors know this decision &amp; get the
          women to ask them for it." (January 22, 1918, <em>MSM C</em>).</p>
</blockquote>

<p>By June of 1919, Sanger was working in conjunction with the National Birth
Control League on a legislative campaign to expand the decision to allow nurses
as well as doctors to give contraceptive information.<p>Sanger's fight to keep
the birth control movement alive in turbulent years after was difficult. As she
told Rublee, 'I do so want to get a good Editorial board at work on the <em>Review </em>especially
since the Dist. Atty laid great stress on the fact ... that I stood alone among
women in USA in desiring B.C. He -,aid none of the suffragists were advancing it
&amp; not one state where women had suffrage had a law been changed!!! Alas tis
sadly too true but it must not be true for very long." (December 10, 1919,
<em>MSM C</em>)</p>

<p>The perspective that the early Sanger to Rublee letters provide on the birth control
movement during World War I and after is only one of the many topics which are
illuminated by this invaluable cache of correspondence.  Providing a rare glimpse of
Sanger's hopes, fears, and plans for the movement without the self-censorship that
appears in her correspondence with less intimate friends and colleagues, these letters
are critical to filling in the gaps in our knowledge of the early organizational days. 
This new addition to an already rich collection of correspondence will add detail and
dimension to future studies of Sanger's role in the development of the birth control
movement.</p>

<p>George and Ellen Rublee have generously agreed to donate the entire new cache of
original Sanger-Rublee letters to the Sophia Smith Collection at Smith College, along
with a significant amount of correspondence between Juliet Rublee and many other
notable twentieth-century figures.  While these documents arrived too late to be
included in the already filmed S<em>mith College Collections Series</em>, we at the Sanger Papers
are immensely grateful to the Rublees for making these documents available to us in
time for inclusion in the <em>Collected Documents Series</em> of the Margaret Sanger Papers
Microfilm Edition.<br /><br /></p>

<p><em>NOTE: Citations from this article were drawn from Sanger's letters to
Juliet Rublee which will be donated to the Sophia Smith Collection, Smith
College as the Juliet Rublee Papers.</em></p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
