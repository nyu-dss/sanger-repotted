
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #19 (Fall 1998)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #19 (Fall 1998)</h1>			

<div class="maintext">
<h1>"Ye&acirc;nnis Revisited"</h1>

<p>Back in 1994 we shared a <a href="unsolved_mystery.php">mystery</a> with our readers about a
love letter to Margaret Sanger signed only "Ye&acirc;nnis." We
pored over the letter to glean any information that might
illuminate the identity of the author and compared the
handwriting against other letters from Sanger's male friends at
the time.  We thought we had found the answer and in our Fall
1994 newsletter, <a href="mystery_solved.php">unmasked Ye&acirc;nnis</a> as a young Italian-American radical named John
DiGregorio, whose active love
life Sanger had referred to in a later letter fragment. The
handwriting in the Ye&acirc;nnis letter very closely matched other
letters signed by DiGregorio. Mystery solved &ndash; onto the next
challenge.</p>

<p>Well you can imagine our surprise when Ye&acirc;nnis resurfaced in our research this past summer, not as John Di Gregorio, but  as Greek anarchist and publisher  John Rompapas who nearly ran off with Sanger in 1913. Rompapas emerged as the real "Ye&acirc;nnis" as we were trying to identify the individual Margaret and William Sanger were referring to in their letters
when they discussed "R" or "JR," an individual who tested their marriage a final time.  William Sanger also called him
"the Greek" and left enough additional clues to finally solve this identity crisis once and for all.  Confirmation came when
we found a folder of letters written by one individual to Mabel Dodge Luhan in the Beinecke Library at Yale &ndash; one letter signed "Ye&acirc;nnis" and the next signed  "John Rompapas" (Rompapas and DiGregorio do, by the way, share strikingly 
similar handwriting). </p>

<p>Now our challenge is to find out more about  Rompapas.  What we know thus far is that John Rompapas founded the
Rabelais Press, a New York radical publishing house that funded the <em>Revolutionary Almanac</em>, a journal edited by the notorious anarchists, Hippolyte Havel.  Rabelais Press published Sanger's sex hygiene articles in book form with the
titles <em>What Every Mother Should Know and What Every Girl Should Know</em>.  And we know from the only surviving letter of Rompapas to Sanger (the Ye&acirc;nnis letter) that he supported the Social War, another anarchist publication edited by Havel and Robert Lee Warwick.  In an interview with historian Paul Avrich, writer Manuel Komroff called Rompapas a tobacco importer (Paul Avrich, ed. <em>Anarchist Voices</em>, 1995, p. 202).  And a blurb in the <em>New York Times</em> (April 4, 1915) listed a petition of bankruptcy filed against John Rompapas Books and
Postcards at 325 Madison Street in New York. Several sources confirm that he frequented both the Ferrer Center and Mabel
Dodge Luhan's salon. Mabel Dodge described him as having a ". . . handsome body. Black Hair and the darkest brown eyes
far apart in his strong face." Dodge also contended that after she rejected his overtures, "John Rompapas turned away from
me then to Margaret Sanger, who was at the beginning of her birth control movement.  He helped her a great deal." (Mabel
Dodge Luhan, <em>Movers and Shakers</em>, 1985, pp. 65-66) Lastly, he is the author of two books:  <em>Greek Language Self Taught</em>, published in 1916, and <em>Book of My Life</em>, published by his own Rabelais Press in 1914. The latter appears at first glance to be an autobiography, but offers only rambling thoughts on love and revolution.  No names are given, and the only specific information we learn about the author is that at one time he
worked as a store clerk.</p> 

<p>We know even less about Rompapas' relationship with Margaret Sanger.  They probably met either at the Ferrer
Center, or at Mabel Dodge's, and appear to have started an affair during the summer of 1913 when the Sanger family was
vacationing in Provincetown, Massachusetts. Angry references to the affair in William Sanger's letters to Margaret in 1913
through 1915 suggest that Rompapas asked Margaret to live with him and offered to support the Sanger children.  William
Sanger accusingly wrote to his wife: "You should have lived with him (JR) if it was not for the d&ndash;n Catholic tradition you
were brought up in." (William Sanger to MS, January 10, 1915, <em>MSM</em>, S01:377.) A 1953 letter from another early Sanger associate mentions that Rompapas was one of four or five people present in a historic meeting in Sanger's apartment in the winter of 1914 where she launched the <em>Woman Rebel</em> (Otto Bobsien to MS, October 25, 1953, <em>MSM</em>, S41:956).  It is not clear what role he played in the <em>Woman Rebel</em>, although he had funded other publications and may have given Sanger seed money. We have found no further sign of
Rompapas after 1915.</p> 

<p>Sanger's ties with Rompapas imply that she was far more immersed in anarchist circles in New York than had previously
been established and helps to explain her association with several anarchist publications.  Rompapas may have drawn her
more deeply into a radical underworld she had only glimpsed before. The extreme revolutionary tone of the <em>Woman Rebel</em>, considered harsh even by many Sanger sympathizers of the day, and unlike anything else she had written up to that time, seems less startling now that we know a  little more of Sanger's circle in 1913-1914. </p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
