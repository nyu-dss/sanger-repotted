
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Newsletter #23 (Winter 1999/2000)</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Newsletter #23 (Winter 1999/2000)</h1>
<div class="maintext">
<h1>"Gandhi and Sanger Debate Love, Lust and Birth Control"</h1>

<p>Population gauges flew past the six billion mark this fall.  In mid-October, the United
Nations dubbed a newborn son of Bosnian Refugees the official six billionth person. About the
same time many population groups announced that India spilled over the one billion mark,
though the Indian government will not recognize this undesirable milestone until next spring. As
we try to fathom these numbers, and that other round number on everyone's mind (2000), we
thought it timely to look back at a historic meeting between two reformers (who have recently
turned up together on lists of most important people of the century and the millennium) whose
words and actions had an undeniable though incalculable effect on twentieth century population
growth:  Margaret Sanger and Mahatma Gandhi.</p>

<p>Sanger toured India for nine weeks in 1935-1936 at the Invitation of the All India Women's
Conference.  She wrote to Gandhi before her arrival.  He responded: "Do by all means come
whenever you can, and you shall stay with me, if you would not mind what must appear to you to
be our extreme simplicity; we have no masters and no servants here" (quoted in
<em>Autobiography</em>, 465-6).  They met for two days in December of 1935 to discuss
birth control, population and the plight of women in India.  While Sanger claimed she mainly
wanted to pay her respects and give a personal tribute to Gandhi, she coveted nothing less than
his endorsement of birth control.  Gandhi promoted the spiritual bonds of marriage, which, he
argued, were strengthened by continence.  He reluctantly agreed to consider sanctioning the safe
period or rhythm method, but rejected Sanger's plea for contraception to control population
growth, fearing it would lead to an increase in non-procreative sex, which he viewed as immoral
lust.  Instead he hoped small families would become a social custom and that social pressure &ndash;
maybe even appropriate laws &ndash; would force most couples to abstain from sex once their families
were complete.</p>

<p>What follows is a portion of the transcript of their discussion at Gandhi's ashram in Wardha
on December 3,  1935.   It was recorded in shorthand and later transcribed by Sanger's traveling
secretary, Anna Jane Philips, and placed in a file of material on the India trip that Sanger put
together in preparation for several articles she wrote on the meeting (see LCM 129:535-546).
There is no other record of this meeting, and there is no way to insure that the transcript is
accurate, though Sanger's account of her two days, included in her travel diary for 1935-1936, is
consistent with the conversation transcript (see LCM 1:226-229). An article recounting the
meeting was published in<em>Asia Magazine</em> in November, 1936, but omitted
several large and illuminating portions of the conversation.  The complete transcript has never
been published in its entirety.  While we are only inc <em>The Selected Papers of
Margaret Sanger</em>.</p>


<p><b>Dec 3rd 1935 Wardha India</b></p>

<p><em>MRS. SANGER:</em> Mr. Gandhi, you and I have the interest of humanity at heart
but while both of us have that thing in common, you have greater influence with the masses of
humanity. I believe no nation can be free until its women have control over the power that is
peculiarly theirs, I mean the power of procreation, that powerful force which allowed to run free
has messed up the affairs of the world. </p>

<p>I believe that human nature is good in itself.  I believe that men and women are essentially
good.  I believe that uncontrolled breeding has made the world a pretty sorry mess.  I've read
your books.  I know your belief in continence and the importance you place upon it.  Your
influence stretches far beyond India.  Your word means something to women in other countries
besides India.  Even the opposition at home often quotes you in opposing our legislative
campaign for birth control.  I have an invitation from the All India Women's Conference to come
to their meeting in December as guest speaker but you see it is really only a pretense to come to
see you.  The real reason I came is to see if we could not agree upon a fundamental principle and
some practical means of helping the women of the world.</p>

<p>Women's lack of control over fecundity results in over-population, in poverty, misery and
war. Should women control this force which has made so much trouble in their lives? Have they
a right to control the power of procreation? Do you see any practical solution for this problem
which in my humble opinion is the direct cause of much of the chaos in the world today?</p>

<p><em>MR. GANDHI:</em> I suppose you know that all my life I have been dinning into
the ears of women the fact that they are their own mistresses, not only in this but in all matters. I
began my work with my own wife. While I have abused my wife in many respects, I have tried to
be her teacher also. If today she is somewhat literate it is because I became her teacher. I was not
the ideal teacher because I was a brute. The animal passion in me was too strong and I could not
become the ideal teacher. My wife I made the orbit of all women. In her I studied all women. I
came in contact with many European women in South Africa but I knew practically every Indian
woman there. I worked with them. I tried to show them they were not slaves either of their
husbands or parents, that they had as much right to resist their husbands as their parents, not only
in the political field but in the domestic as well. But the trouble was that some would not resist
their husbands. I feel that I speak with some confidence and knowledge because I have worked
with and talked with and studied many women. </p>

<p>But the remedy is in the hands of the women themselves. The struggle is difficult for them
but I do not blame them. I blame the men. Men have legislated against them. Man has regarded
woman as his tool. She has learned to be his tool and in the end found it easy and pleasurable to
be such, because when one drags another in his fall the descent is easy.</p>

<p>I have come in contact with some women of the West but not many so that my deductions
about them may be faulty but I have known tens of thousands of women in India, their
experiences and their aspirations. I have discussed it with some of my educated sisters but I have
questioned their authority to speak on behalf of their unsophisticated sisters, because they have
never mixed with them. The educated ones have never felt one with them. But I have. They have
regarded me as half a woman because I have completely identified myself with them.</p>

<p>I have identified myself with my wife to the same extent but she observes certain decencies
with me, which I have not done with her. I intimately know her. I have made use of her. But I do
not suppose there are many women who can claim to have followed their husbands so slavishly
as she has. She has followed, sometimes reluctantly, but her reluctance has had a tinge of
obedience in it, for she is a good Hindu wife. I have so often challenged her and asked her to lead
her own independent life but she will not do so. She is too much a Hindu wife for that.</p>

<p>I have felt that during the years still left to me that if I can drive home to women's minds the
truth that they are free, there will [be] no birth control problem in India. If they will only learn to
say "no" to their husbands when they approach them carnally!  I do not suppose all husbands are
brutes and if women only knew how to resist them, all will be well.  I have been able to teach
women who have come in contact with me how to resist their husbands. The real problem is that
they do not want to resist them. I have been reading about this cause which you advocate so
eloquently.  I know some of the great people in the world agree with you.  In India I would
mention only two great representative names, Tagore and Mrs. Naidu.  I know I have them all
arrayed against me.  I have tried to think with them.  I have held long arguments with Sherwood
Eddy and Kirby Page.  I have listened silently, very carefully while they talked to me.  But always
I have had to say to myself, "Why is it that I cannot see eye to eye with them on this thing?" 
Then too I gave long hours to Mrs. How-Martyn.  She did not convince me but she prepared me
for you.  She said, "Ah, you are not convinced, but wait until Mrs. Sanger talks to you."</p>

<p>My fundamental position is that so far as the women of India are concerned, even if the
method you advocate were a solution, it is a long way off, for the women of India have so many
things to think of now. Don't tell me of the educated girl of India. She will be your slave, much
to her damage, I'm afraid.</p>

<p><em>MRS. SANGER:</em> You mean for instance that the women of the chawls will be
against me, the women in the tenements of Bombay?</p>

<p><em>MR. GANDHI:</em> Yes.</p>

<p><em>MRS. SANGER:</em> I disagree with you. When I was in Bombay one of the first
places I went was to see these women of the tenements. I saw them sitting around, each with
three, four or more children. We asked them how many children they had had, how many were
dead. There were always some dead. Then we asked how many more they were going to have
and every woman but one held out her hands in supplication as though saying, "No more. Pray
God, no more!" It showed that they were already awakened to this idea. Again and again they ask
what to do to prevent more children from coming into the world. I want to go to the villages and
see whether this desire to have fewer children is not there. Let us not worry about the methods.
Let us first discover whether they want more children or [not]. That will be the beginning.</p>

<p><em> MR. GANDHI:</em> I don't want to say that women want children but that they will
not do the thing that will keep them from having more children. They will not resist their
husbands. Then I suppose you will say, if neither party resists, why should they not adopt
artificial methods.</p>

<p><em> MRS. SANGER:</em> You have been a great advocate of civil disobedience Mr.
Gandhi. Do you also recommend that the women of India adopt legal and marital
disobedience?</p>

<p><em> MR. GANDHI: </em> Yes, I do. But no resistance bordering upon bitterness will be
necessary in 99 out of 100 cases. If a wife says to her husband, "No, I don't want it," he will
make no trouble. But she hasn't been taught.  Her parents in most cases won't teach it to her. 
There are some cases I have found, cases when I have known the parents, that the parents have
said to the husband, "For heaven's sake don't force our daughter to do that."  I have come across
amenable husbands too.</p>

<p><em> MRS. SANGER:</em> But that advice is not practical. It means a revolution in the
home. It leads to divorce. The average marriage contract assumes that intercourse and the
married relationship shall be harmonious.</p>

<p><em> MR. GANDHI: </em> There should be mutual consent. Without it the thing will be
wholly wrong.</p>

<p><em> MRS. SANGER:</em> That is right, but the problem is not often discussed by young
people before marriage, although our young people of today are beginning to discuss it more and
more, which is a very good thing. But consider the turmoil, the unhappiness it means for the
woman if she resists her husband! What if he puts her out of her home? In some states in the
United States a wife has no rights if she resists her husband. What can she do? I do not know the
law in India but custom compels her to submit to the sexual needs of her husband.</p>

<p><em> MR. GANDHI:</em> There are no such laws here.</p>

<p><em> MRS. SANGER: </em> Yes, but the custom is here. Customs are harder to change
than laws.</p>

<p><em>MR. GANDHI:</em> Yes.</p>

<p><em> MRS. SANGER:</em> You are giving them advice which they cannot accept.
Would it not make their condition worse?</p>

<p><em> MR. GANDHI:</em> Not if they learn the art of resistance. It boils down to
education. I want women to learn the primary right of resistance. She thinks now that she has not
got it. Among the women of India it is most difficult to drive home this truth. If I were to devote
myself to birth control I would miss this primary education.</p>

<p><em> MRS. SANGER:</em> But cannot education go with birth control? In England many
social workers claim that if they can instruct the poorer women in birth control before their fifth
child is born, before the women have fallen into poverty and drink and degradation, these women
can be helped. In America in the clinics it has been found that in a number of cases where women
have been given birth control information and freed from undesired pregnancies for a period of
from eighteen months to two years that the woman and her husband have become self-reliant and
self-supporting and the case has been closed on the welfare books. The woman has more hope.
She is not haunted by the fear of more and more and still more pregnancies. Every case shows a
better condition of the woman's mind, more patience, love, education in the woman's life and
home after she has been freed of the worry of having too many children. </p>

<p>Mr. Gandhi, do you not see a great difference between sex-love and sex-lust? Isn't it sex-lust
and not sex-love which you oppose?</p>

<p><em> MR. GANDHI: </em> Yes it is. But when both want to satisfy animal passion
without having to suffer the consequences of their act, it is not love. It is lust. But if love is pure
it will transcend animal passion and will regulate itself. We have not had enough education of the
passions. When a husband says, "Let us not have children but have relations," what is that but
animal passion? If they do not want to have any more children, they should simply refuse to
unite.</p>

<p><em> MRS. SANGER:</em> Then you hold that all sex union is lust except that for the
specific purpose of having children?</p>

<p><em> MR. GANDHI:</em> Yes.</p>

<p><em> MRS. SANGER:</em> I think that is a weak position, Mr. Gandhi. The act is the
same. The force that brings two people together is sex attraction a biological urge which finds
expression in sex union. There are two kinds of passion, one is a force around which centers
respect, consideration and reverence known as love. The [latter] kind may be the stepladder to
God. I do not call that kind of love lust, even when it finds expression in sex union, with or
without children.</p>

<p><em> MR. GANDHI:</em> I think there is a flaw in that position and the world will not
have to wait long before it discovers it. I have found the same thing in old Sanskrit volumes,
found lust clothed in the dress of love. But I know from my own experience that as long as I
looked upon my wife carnally, we had no real understanding. Our love did not reach a high
plane. There was affection of course between us. Affection there has been between us always but
we came closer and closer the more we, or rather I, became restrained. There never was want of
restraint on the part of my wife. Very often she would show restraint, but she rarely resisted me
although she showed disinclination very often. All the time I wanted carnal pleasure I could not
serve her. She would be a fairly learned woman today if I had not let this lust interfere with her
education. She is not dull witted, but it takes all one's resources to drive home a lesson. I had
plenty of time at my disposal to teach her before I became involved in public affairs but I didn't
take advantage of it. When I had outlived animal passion and found a better mission in life, I had
no time.</p>

<p><em> MRS. SANGER:</em> I think lust is a very different thing than love. I believe in sex
love. Perhaps love in sex is a new thing in our evolution and develops in the human race as we
evolve toward a higher consciousness. But it is generally acknowledged to be a very real thing a
force that cannot be denied.</p>

<p><em> MR. GANDHI:</em> I've read all that.  My past experience does not bear it out.  In
books you read something and the wish becomes father to the thought.  There is so much poetry
thrown in that you become intoxicated with it and what was vice becomes virtue.</p>

<p><em> MRS. SANGER:</em> But to be logical you have to say there are different kinds of
love.</p>

<p><em> MR. GANDHI:</em> It becomes a lustful thing when you take love for your own
satisfaction.  It is just the same with food.  If food is taken only for pleasure it is lust.  You do not
take chocolate for the sake of your physical need.  You take it for pleasure and then ask the
doctor for an antidote.  Perhaps you tell the doctor that whiskey befogs your brain and he gives
you an antidote.  Would it not be better not to take the chocolate or whisky?</p>

<p><em> MRS. SANGER:</em> No, I don't accept that analogy.</p>

<p><em> MR. GANDHI:</em> No, you will not accept the analogy because you think this sex
expression without desire for children is a need of the soul, a contention I don't support.</p>

<p><em> MRS. SANGER:</em> Yes, sex expression with love is a spiritual need and I claim
that the quality of this expression is more important than the result for the quality of the
relationship is there, regardless of results.  We all know that the great majority of children are
born as an accident, without the parents having any desire for conception.  Seldom are two
people drawn together in the sex act by their desire to have children.  When this is done it is a
rare exception.</p>

<p><em> MR. GANDHI:</em> May one man have pure sex love as distinguished from sex
lust with more than one woman or a woman with more than one man? Your literature is full of
that.</p>

<p><em> MRS. SANGER: </em> Love, no. Lust, yes. But I think pure love comes of
itself.</p>

<p><em> MR. GANDHI:</em> No, it does not come of itself. If you have a love for more than
one woman, how do you know which is which?</p>

<p><em> MRS. SANGER:</em> If we can have a choice in our mates there is a natural sex
attraction between two people. You then have a different experience and in the experience an
expression of love which makes you a finer human being. Sex lust is spent in prostitution, the
sort of relationship which makes a man run away after the act, disgusted, ashamed of himself, but
a sex love is a relationship which makes for oneness, for completeness between the husband and
wife and contributes to a finer understanding and a greater spiritual harmony.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
