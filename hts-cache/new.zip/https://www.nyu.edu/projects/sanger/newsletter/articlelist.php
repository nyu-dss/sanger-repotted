﻿
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Newsletter / Selected List of Articles</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter" class="selected">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Selected List of Articles</h1>
<div class="maintext">

<p>As time permits, articles from older issues of the Newsletter will be mounted. The most recent additions are marked with <img src="../articles/reddot.gif" width="16" height="16">.  Illustrations found in the print version of the newsletter have not been included on the website.</p>
<ul class="thin"><li><a href="../articles/mike_wallace.php">30 Minutes With Mike Wallace</a>, Winter 2004/2005, #38</li>
<li><a href="../articles/anniversary_second.php">Anniversary of a Second Marriage</a>, Fall 1997, #16</li>
<li><a href="../articles/hepburn.php">Backstage with Sanger and Hepburn</a>, Fall 2003, #34</li>
<li><a href="../articles/keller.php">Battling the Powers of Light and Darkness--Helen Keller, Margaret Sanger and Birth Control</a>, Winter 2009/2010, #53</li>
<li><a href="../articles/bees_with_more_buzz.php">The Birds and the Bees With More Buzz</a>, Winter 1997/1998, #17</li>
<li><a href="../articles/good_old_boys.php">Birth Control and the Good Old Boys in Congress</a>, Winter 2000/2001, #26</li>
<li><a href="../articles/bc_comes_of_age.php">Birth Control Comes of Age</a>, Spring 2007 #45</li>
<li><a href="../articles/bc_international.php">Birth Control International Information Centre-An International Outpost for Birth Control</a>, Fall 2011, #58.</li>
<li><a href="../articles/kitty_marion.php">Birth Control on the Streets of New York</a>, Fall 2004, #37</li>
<li><a href="../articles/bc_or_race_control.php">Birth Control or Race Control?: Sanger and the Negro Project,</a> Fall 2001, #28</li>
<li>Brownsville Clinic Video Planned, Summer 1991, #1</li>
<li>Buck-Sanger, West-East, by Robert Shaffer, Fall 1996, #13</li>
<li><a href="../articles/bush_family_planning.php">Bush Family Planning</a>, Winter 2006/2007, #44</li>
<li><a href="../articles/youcancall.php">But <em>you</em> can call me....</a>, Winter 2011, #56</li>
<li>Celebrations of the Brownsville Anniversary at NYU and the Sophia Smith Collection, Winter 1991, #2</li>
<li><a href="../articles/cervical_caps.php">Cervical Caps as "Bonbons from France" and Other Sights and Scenes in the Working Friendship of Two Birth Control Pioneers</a>, Fall 1999, #22.</li>
<li><a href="../articles/gilman.php">Charlotte Perkins Gilman Tribute to Birth Control</a>, Spring 1997, #15</li>
<li>Chicken a la Sanger, Winter 1991, #2</li>
<li><a href="../articles/claverack_college.php">Claverack College</a>, Fall 1998, #19</li>
<li><a href="../articles/clientletters.php">Client Letters--Via Air Mail</a>, Spring 2011, #57</li>
<li>Collected Documents Series Completed!, Spring 1996, #12</li>
<li><a href="../articles/countdown_in_holyoke.php">Countdown in Holyoke: Sanger Snubbed in Paper City</a>, Fall 2005, #40</li>
<li><a href="../articles/dancing.php">Dancing with a Voodoo Priest--Sanger, Art, and Birth Control in Haiti,</a> Winter 2008/2009, #50</li>
<li>Dateline MS, Fall 1992, #3</li>
<li><a href="../articles/hatemail.php">&quot;Dear Madam, I Abhor You,&quot; and Other Selections from Sanger's Hate Mail</a>, Winter 2007/2008, #47</li>
<li><a href="../articles/demonization_of_ms.php">The Demonization of Margaret Sanger</a>, Fall 1997, #16</li>
<li><a href="../articles/depopulation.php">Depopulation!</a>, Winter 2006/2007 #44</li>
<li><a href="../articles/doing_time_on_prison_reform.php">Doing Time on Prison Reform</a>, Spring 1998, #18</li>
<li><a href="../articles/documenting_friendship.php">Documenting a Friendship</a>, Fall 1992, #3</li>
<li><a href="../articles/early_letters.php">Early Sanger Letters Found</a>, Spring 2004, #36</li>
<li>Electronic Sanger, Spring 1997, #15</li>
<li>Exhibit Planned, Summer 1991, #1</li>
<li><a href="../articles/family_values.php">Family Values in Margaret Sanger's Time</a>, Winter 1992/1993, #4</li>
<li><a href="../articles/fiji_herbs.php">Fiji Herbs from a Bird Man &ndash; Sanger's Continuing Quest for New Birth Control</a>, Winter 2003/2004, #35</li>
<li>First Sanger Microfilm Series Completed!, Winter 1994/1995, #9</li>
<li><a href="../articles/foam_powder_and_sponge.php">Foam Powder and Sponge: The Quest for Doctorless Birth Control</a>, Spring 1997, #15</li>
<li><a href="../articles/from_geneva_to_cairo.php">From Geneva to Cairo: Sanger and the First World Population Conference</a>, Fall 1994, #8</li>
<li>Furor Over Sanger's Induction Into Arizona Women's Hall of Fame, Winter 1991, #2</li>
<li><a href="../articles/gandhi_debate.php">Gandhi and Sanger Debate Love, Lust and Birth Control</a>, Winter 1999/2000, #23</li>
<li><a href="../articles/taftplan.php">Giving it the Old School Try--Sanger and the Taft Plan for Human Betterment</a>, Spring 2009, #51</li>
<li><a href="../articles/grannysanger.php">"Granny Sanger" Drops a Bomb - A Ten Year Moratorium on Births</a>, Fall 2013 #64</li>
<li><a href="../articles/hail_to_male.php">Hail to the Male!</a>, Fall 2003, #34</li>
<li><a href="../articles/hands_up.php">Hands Up!</a>, Winter 2003/2004, #35</li>
<li><a href="../articles/hannah_stone.php">Hannah Stone: The Madonna of the Clinic</a>, Winter 1994/1995, #9</li>
<li><a href="../articles/happiness.php">Happiness (?) in Marriage</a>, Fall 2007, #46</li>
<li><a href="../articles/heart_to_japan.php">'The Heart to Go to Japan'</a>, Spring 1996, #12</li>
<li><a href="../articles/holdings_at_smith.php">The Holdings of the Sophia Smith Collection,</a> Winter 1992/1993, #4</li>
<li><a href="../articles/hong_kong.php">Hong Kong</a>, Fall 1997, #16</li>
<li><a href="../articles/mussolini.php"> Il Duce v. the Woman Rebel: It's Birth Control or War!</a>, Fall 2008, #49</li>
<li><a href="../articles/imaginary_encounters.php">Imaginary Encounters</a>, Winter 2000/2001, #26</li>
<li><a href="../articles/ippf_fortieth.php">International Planned Parenthood Celebrates 40th Anniversary</a>, Fall 1992, #3</li>
<li>Introduction to the Project, Summer 1991, #1</li>
<li>International Search for Sanger Documents, Summer, 1991, #1</li>
<li><a href="../articles/johnrock.php">John Rock's Catholic Faith: Sanger's Hard Pill to Swallow</a>, Fall 2010, #55</li>
<li><a href="../articles/king_and_i.php">The King and I: Sanger Remembers Havelock Ellis</a>, Spring 2000, #24</li>
<li><a href="../articles/latestfight.php">The (Latest) Fight for Federal Funding for Birth Control</a>, Spring 2011 #57</li>
<li><a href="../articles/lowly_condom.php">The Lowly Condom--Sanger's Missed Opportunity?</a> Spring 2015, #68</li><img src="../articles/reddot.gif" width="16" height="16"></li>
<li><a href="../articles/ms_abortion.php">Margaret Sanger Answers Questions on Abortion--An MSPP Exclusive</a>, Spring 2012, #60</li>
<li><a href="../articles/harlem.php">Looking Uptown: Margaret Sanger and the Harlem Branch Birth Control Clinic</a>, Spring 2010, #54, by Wangui Mugai</li>
<li><a href="../articles/ms_arizona_years.php">Margaret Sanger: the Arizona Years</a>, Winter 1994/1995, #9</li>
<li><a href="../articles/ms_and_edith_how_martyn.php">Margaret Sanger and Edith How-Martyn: An Intimate Correspondence</a>, Spring 1993, #5</li>
<li><a href="../articles/ms_and_eleanor_roosevelt.php">Margaret Sanger and Eleanor Roosevelt: The Burdens of Public Life</a>, Winter 1995, #11</li>
<li>The Margaret Sanger Film Project, Winter 1991, #2</li>
<li><a href="../articles/ms_and_glorious_chain.php">Margaret Sanger and 'a Glorious Chain of Clinics',</a> Winter 1994/1995, #9</li>
<li><a href="../articles/sanger_gagged.php">Margaret Sanger Gagged!</a>, Spring 2004, #36</li>
<li><a href="../articles/ms_and_modern_school.php">Margaret Sanger and the Modern School,</a> Fall 1998, #19</li>
<li><a href="../articles/ms_and_refugee_department.php">Margaret Sanger and the Refugee Department</a>, Spring 1993, #5</li>
<li>Margaret Storrs Grierson, Spring 1998, #18</li>
<li>Microfilming Scheduled at Smith College, Spring 1993, #5</li>
<li>Microfilming of Sanger Papers to Begin at Smith College, Winter 1993/1994, #6</li>
<li>Model Editions Partnership Released, Spring 1999, #21</li>
<li><a href="../articles/motherhood_in_bondage.php">Motherhood in Bondage</a>, Winter 1993/1994, #6</li>
<li>Movie-Made Sanger, Winter 1991, #2 <li><a href="../articles/mystery_solved.php">A Mystery Solved: Yeannis Unmasked!</a>, Fall 1994, #8</li>
<li><a href="../articles/bcpreventivehealth.php">An MSPP Editorial: Birth Control as Preventitive Health Care-A Hundred Years in the Making</a>, Spring 2014, #66</li>
<li><a href="../articles/nervous_laughter.php">Nervous Laughter</a>, Winter 1998/1999, #20</li>
<li>New Publications, Fall 1992, #3</li>
<li><a href="../articles/bain.php">Newly Obtained Documents Shed Light on Sanger's 1914 Escape into Exile</a>, Winter 2013/2014, #65 </li>
<li>News from Smith College, Fall 1996, #13</li>
<li>Noteworthy, Spring 1996, #12</li>
<li><a href="../articles/on_the_road_for_bc.php">On the Road for Birth Control</a>, Spring 1999, #21</li>
<li>Our International Search Continues...In Germany, Winter 1992/1993, #4</li>
<li><a href="../articles/our_ms_lifshiz.php">Our Margaret Sanger: Anna Lifshiz</a>, Spring 1997, #15</li>
<li><a href="../articles/our_ms_mccormick.php">Our Margaret Sanger: Katharine Dexter McCormick</a>, Spring 1999, #21</li>
<li><a href="../articles/our_ms_richard.php">Our Margaret Sanger: Olive Byrne Richard</a>, Winter 1996/1997, #14</li>
<li><a href="../articles/passionate_friends.php">The Passionate Friends: H.G. Wells and Margaret Sanger</a>, Spring 1996, #12</li>
<li><a href="../articles/presidential_politics.php">Presidential Politics: Sanger in the Voting Booth</a>, Fall 1992, #3</li>
<li>Project Status: The Microfilm, Summer 1991, #1</li>
<li><a href="../articles/recently_discovered_letters.php">Recently Discovered Letters Reveal Insights Into Birth Control Movement</a>, Winter 1995, #11</li>
<li><a href="../articles/zurich.php">The Quest for Contraceptive Knowledge: Marking the 80th Anniversary of the Zurich Conference</a>, Winter 2011, #56</li>
<li>Radio Sanger, Winter 1993/1994, #6</li>
<li>Researchers Using the Sanger Papers Winter 1991, #2 , Winter 1993/1994, #6</li>
<li><a href="../articles/ru486.php">The RU 486 Controversy: Echoes of <span class="italicText">U.S. v. One Package</span></a>, Fall 1992, #3</li>
<li><a href="../articles/sanger_and_red_virgin.php">Sanger and the "Red Virgin,</a>" Fall 2002, #30</li>
<li>Sanger by Ansel Adams, Winter 1997/1998, #17</li>
<li><a href="../articles/sanger_censorship_and_catholic_church.php">Sanger, Censorship and the Catholic Church: The Latest Battle in a Long War</a>, Winter 1993/1994, #6</li>
<li><a href="../articles/sanger_finds_a_home_at_smith.php">Sanger Finds a Home in the Sophia Smith Collection</a>, Fall 1995, #10</li>
<li>Sanger Gets a Makeover: Body Cures and Beauty Cares, Winter 2005/2006, #41</li>
<li><a href="../articles/sanger-hitler_equation.php">The Sanger-Hitler Equation</a>, Winter 2002/2003, #32</li>
<li>Sanger Leagues: <a href="../articles/cleveland.php">&quot;Cleveland: the first wee voice of Birth Control,&quot;</a> Fall 2006, #43</li>
<li>Sanger Leagues: <a href="../articles/denver.php">&quot;Rocky Mountain Birth Control,</a>&quot; Fall 2007, #46</li>
<li><a href="../articles/sanger_macarthur.php">Sanger, MacArthur and Birth Control in Japan</a>, Spring/Summer 1994, #7</li>
<li>Sanger Papers Microfilm Edition, Spring/Summer 1994, #7</li>
<li>The Sanger Project and the Model Editions Partnership, Fall 1995, #10</li>
<li>The Sanger Project on the World Wide Web! Spring 1997, #15</li>
<li>Sanger Project Receives Manuscript Collection from the Watumull Foundation, Fall 1996, #13</li>
<li><a href="../articles/sanger_on_trial.php">Sanger on Trial: The Brownsville Clinic Testimony</a>, Fall 2000, #25</li>
<li><a href="../articles/sangers_role_in_contraceptive_technology.php">Sanger's Role in the Development of Contraceptive Technologies</a>, Winter 1993/1994, #6</li>
<li><a href="../articles/hungergames.php">Sanger's Hunger Games--A Postwar German Odyssey</a>, Fall 2012, #61</li>
<li><a href="../articles/stockholm.php">Sanger's Second Act, Scene One: The Stockholm Conference</a>, Fall 2006, #43</li>
<li><a href="../articles/sangers_stamp.php">Sanger's Stamp of Approval</a>, Spring 2007, #45</li>
<li>Sanger Uncensored, Summer 1991, #1</li>
<li><a href="../articles/sanger_in_ussr.php">Sanger in the U.S.S.R</a>., Fall 1992, #3</li>
<li>Sanger Interview with the <em>Chicago Defender</em>, Spring 2006, #42</li>
<li><a href="../articles/sanger_speaks_out_against_war.php">Sanger Speaks Out Against War</a>, Spring 2003, #33</li>
<li>Sanger Video Completed!, Fall 1992, #3</li>
<li><a href="../articles/sanger_vs_famous_father.php">Sanger vs. Famous Father of 18!</a>, Winter 2001/2002, #29</li>
<li><a href="../articles/sanger_and_ww2.php">Sanger and World War II,</a> Fall 1995, #10</li>
<li>The Search Continues, Fall 1992, #3</li>
<li>Searching for Sanger in the Land of Google, Spring 2006, #42</li>
<li><a href="../articles/seventieth_anniversary_of_brownsville.php">Seventy Fifth Anniversary of the Brownsville Clinic</a>, Winter 1991, #2</li>
<li><a href="../articles/seventieth_anniversary_of_legal_services.php">Seventy Year Anniversary of Legalized Birth Control Services</a>, Spring 1993, #5</li>
<li><a href="../articles/kinsey.php">Sex Matters: Sanger and Kinsey Make Sex History</a>, Spring 2005, #39</li>
<li><a href="../articles/shes_got_rhythm.php">She's Got Rhythm? A Safe Period for Sanger and the Church</a>, Fall 2002, #31</li>
<li>Status of the Microfilm Edition, Fall 1994, #8</li>
<li><a href="../articles/stayathome.php">&quot;Stay at Home, Margaret,&quot;--Japan Bars Sanger in 1922</a>, Spring 2008, #48</li>
<li><a href="../articles/soulless.php">The Soul-less Maid</a>, Winter 2007/2008, #47</li>
<li><a href="../articles/spermatoxins.php">Spermatoxins!,</a> Fall 2009, #52</li>
<li>Summer Interns at the Sanger Papers Project, Fall 1995, #10</li>
<li><a href="../articles/ten_questions_for_ms.php">Ten Questions for Margaret Sanger on the Question of Women</a>, Winter 1998/1999, #20</li>
<li><a href="../articles/town_hall_raid.php">The Town Hall Raid</a>, Spring 2001, #27</li>
<li><a href="../articles/tracing_one_package.php">Tracing <em>One Package</em>-- the Case that Legalized Birth Control</a>, Winter 2012, #59</li>
<li><a href="../articles/travelswithms.php">Travels with Margaret: Dorothy Brush's Portrait of Sanger</a>, Spring 2013 #63 </li>
<li><a href="../articles/unrecorded_battle-1.php">The Unrecorded Battle, (Part I)</a>, Winter 1997/1998, #17</li>
<li><a href="../articles/unrecorded_battle-2.php">The Unrecorded Battle, (Part II)</a>, Spring 1998, #18</li>
<li><a href="../articles/unsolved_mystery.php">An Unsolved Mystery: The Case of Ye&acirc;nnis</a>, Spring/Summer 1994, #7</li>
<li><a href="../articles/speech_use_of_pessary.php">The Use of the Pessary, (transcribed Sanger document</a>), Spring 2001, #27</li>
<li><a href="../articles/willowlake.php">Willowlake: Sanger's Refuge in Fishkill</a>, Winter 1992/1993, #4</li>
<li><a href="../articles/womansplace.php">A Woman's Place</a>, Spring 2009, #51</li>
<li><a href="../articles/world_center_for_womens_archives.php">World Center for Women's Archives: A Look Back at a Novel Idea</a>, Spring 1994, #7</li>
<li><a href="../articles/writing_sangers_life.php">Writing Sanger's Life</a>, Winter 1996/1997, #14</li>
<li><a href="../articles/yeannis_revisited.php"> Yeannis Revisited</a>, Fall 1998, #19</li>
</ul>
</p>
</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Newsletter</h1>
		<div id="subnav">
			<a href="../newsletter/index.php">About</a><br>
			<b><a href="../newsletter/articlelist.php">Article List</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
