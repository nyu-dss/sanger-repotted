
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / About Sanger / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger" class="selected">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>International Committee on Planned Parenthood</h1>
<h2>History</h2>

<p>The International Committee on Planned Parenthood (ICPP) was a provisional organization formed after the 1948 International Congress on Population and World Resources held in Cheltenham, England. The ICPP's objective was to collect and disseminate information on human fertility and birth control, sex education, and population problems, along with organizing programs, conferences and other activities related to birth control education. Initial funding for the ICPP came from a grant from the Brush Foundation of Cleveland. The Committee's headquarters were set up in London under the auspices of the Family Planning Association of England, and maintained by the five member organizations: the Family Planning Association of England, the Planned Parenthood Federation of America, the Margaret Sanger Research Bureau, the Nederlandse Vereniging Voor Sexuale Hervorming (the Netherlands), and the Riksförbundet for Sexuell Upplysning (Sweden). The Committee consisted of two representatives from each of the European members and three representatives from the two American members and met annually in London from 1949-1951.</p>

<p>The ICPP established contacts with family planning organizations in over twenty countries throughout the world, providing clinics and doctors with contraceptive information and supplies, films and sometimes field workers. It also responded to queries from individuals and served as a directory of clinic services. The Committee helped facilitate testing of contraceptive devices, primarily the foam powder/jelly and diaphragm method, in Madras and Bombay, India and in the British West Indies. Representatives of ICPP toured several countries in Asia and the Americas, reporting on conditions and needs. After 1950, the ICPP concentrated its efforts on organizing family planning centers in India and sponsoring a third world conference. By a resolution passed at the Third International Conference on Planned Parenthood in Bombay, India in November 1952, the ICPP was replaced by the International Planned Parenthood Federation (IPPF), with the five member organizations of the ICPP joined by family planning associations from India, Hong Kong, Singapore, and West Germany. In January of 1952, the ICPP began publication of a bulletin, Around the World News of Population and Birth Control, which after November became the chief publication of the IPPF.</p>

<p>Margaret Sanger had helped to organize the 1948 International Congress on Population Problems and World Resources in Cheltenham, at which time she proposed the formation of an international committee. She secured initial funding for the ICPP from the Brush Foundation, and raised a large percentage of the ICPP's operating budget, along with funds to organize the 1952 Third International Conference on Planned Parenthood. She served as the sole Committee representative from the Margaret Sanger Research Bureau and was given the title of founder of the ICPP.</p>


<h2>Organizational Structure</h2>

<p>The ICPP consisted of five member organizations with nine representatives, two from each European member and three representatives from the two American members. The Committee included a president and honorary secretary, a secretary, treasurer, and editor of the bulletin. The Secretary carried out the daily work of the Committee along with assistance from the Family Planning Association of England and the Margaret Sanger Research Bureau. The Committee's representatives met in London once a year from 1949 to 1951 and retained full control over the organization's policy and procedures. Many of the proposals and projects of the organization were discussed and resolved through correspondence. The five member organizations also assisted with fund-raising, research, and communications with clinics, doctors and birth control organizers around the world.</p>

<b>World Information Bureau:</b>
<p>A proposed Bureau in New York that was to assist the London office of the ICPP. A board was formed to establish the     Bureau, but the idea was abandoned sometime in 1951.</p>

<h2>ICPP Member Representatives and Staff Members</h2>

<p><ul class="thin">
<li>Boas, Conrad Van Emde - Representative, Nederlandse Vereniging Voor Sexuale Hervorming
<li>Brush, Dorothy Hamilton - Editor, Around the World News of Population and Birth Control
<li>Cohen, Helen Donington - Secretary
<li>Houghton, Vera - Secretary
<li>Lorimer, Frank - Representative, Planned Parenthood Federation of America
<li>Nielsen, Nils - Representative, Riksförbundet For Sexuell Upplysning
<li>Ottesen-Jensen, Elise - Representative, Riksförbundet For Sexuell Upplysning
<li>Pyke, Margaret A. - Representative, Family Planning Association of Great Britain
<li>Sanger, Margaret - Founder, Representative, Margaret Sanger Research Bureau
<li>Stone, Abraham - Representative, Planned Parenthood Federation of America
<li>Storm, Wim F. - Representative, Nederlandse Vereniging Voor Sexuale Hervorming
<li>Vogt, William - Representative, Planned Parenthood Federation of America
<li>Wright, Helena Lowenfeld - Honorary Treasurer; Representative, Family Planning Association of Great Britain

<h2>Related Sources</h2>

<p>The records of the ICPP are included among the records of the IPPF, located at the Population Centre at the University of Cardiff. The Collected Documents Series includes substantial material drawn from these records and others on the conferences, correspondence with Committee members, and reports. The Smith College Collections Series includes correspondence related to the ICPP and between members of the Committee, along with minutes and reports, a draft of the first issue of Around the World News of Population and Birth Control, and several organizational memos. The Sophia Smith Collection holds a complete set of Around the World News of Population and Birth Control. Very few records related to the ICPP are located on the Library of Congress microfilm, although it contains information on the 1952 Third International Conference and some relevant correspondence.</p>

<p><b>For other organizations involved with the ICPP, see:</b>
<ul class="thin-indent">
<li>IPPF for records of the successor organization established in 1952  
<li>MSRB for records related to international work
<li>PPFA for records related to international work
</ul>
</p>

<p><b>For conferences related to the ICPP or sponsored by the ICPP, see:</b>
<ul class="thin-indent">
<li>1948 International Congress on Population Problems and World Resources
<li>1952 Third International Conference on Planned Parenthood
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>
	
        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>About Sanger</h1>
		<div id="subnav">
			<a href="../aboutms/index.php">Biographical Sketch</a><br>
			<b><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></b><br>
			<a href="../aboutms/sanger_archive.php">The Sanger Archive</a><br>
			<a href="../aboutms/ms_writings.php">Sanger's Writing</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
