
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / About Sanger / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger" class="selected">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>The Brownsville Clinic and Committee of 100</h1>
<h2>History</h2>

<p>Margaret Sanger opened the first birth control clinic in the U.S. on October 16, 1916 in the Brownsville section of Brooklyn, New York. Sanger, her sister Ethel Byrne, who was a registered nurse, and Fania Mindell, an interpreter from Chicago, rented a small store-front space in Brownsville and canvassed the area with flyers written in English, Yiddish and Italian advertising the services of a birth control clinic. Sanger modeled the Brownsville Clinic after the birth control clinics she had observed in Holland in 1915. For ten cents each woman received Sanger's pamphlet What Every Girl Should Know, a short lecture on the female reproductive system, and instructions on the use of various contraceptives. The Clinic served more than 100 women on the first day and some 400 until October 26 when an undercover police woman and vice-squad officers placed Sanger, Byrne and Mindell under arrest. After being arraigned, Sanger spent the night in jail and was released the next morning. She re-opened the Clinic on November 14, only to be arrested a second time and charged with maintaining a public nuisance. Sanger opened the Clinic once again on November 16, but police forced the landlord to evict Sanger and her staff, and the Clinic closed its doors a final time.</p>

<p> Sanger, Byrne and Mindell went to trial in January of 1917. Byrne, tried first, was convicted and sentenced to 30 days in Blackwell's Island prison and immediately went on a hunger strike. After 185 hours without food or water, she was forcibly fed. Before Byrne's condition proved fatal, Sanger and supporters prompted New York's Governor Whitman to issue a pardon. Sanger's own trial began on January 29, and she too was convicted. However, the court offered her a suspended sentence if she promised not to repeat the offense. She refused and was offered a choice of a fine or jail sentence. She chose the latter and spent thirty days in the Queens County Penitentiary without incident. Sanger's co-worker Fania Mindell was then tried, convicted and fined fifty dollars for disturbing the peace.</p>

<p>Sanger appealed her conviction, and her case journeyed through the courts for a year. In January of 1918, the New York Court of Appeals sustained her conviction. However, Judge Frederick Crane's decision included a more liberal interpretation of New York State's "Little Comstock" law, enabling physicians for the first time to legally prescribe contraception for general health reasons rather than exclusively for venereal disease. In effect the ruling afforded women in New York at least some access to contraception.</p>

<p> The Committee of 100 was organized in January of 1917 by Gertrude Pinchot and other prominent women members of the National Birth Control League to protest the Brownsville Clinic arrests. It also raised a significant sum of money to aid with legal costs, and helped to arrange the meeting between Sanger and Governor Whitman that led to the early release of Ethel Byrne from prison. The Committee, which included Mary Ware Dennett, Rose Pastor Stokes, Crystal Eastman and Juliet Rublee, held a successful protest rally which Sanger addressed at Carnegie Hall on January 28, 1917, the night before her trial began. The Committee also published a booklet titled The Birth Control Movement, offering a succinct history of the movement, highlights of Sanger's pioneering work, and a discussion of the positive effects of family limitation. The Committee of 100 disbanded shortly after the Brownsville Clinic trials were over, but its members continued to support Sanger and the birth control movement by funding her monthly journal, The Birth Control Review, founded in 1917,and by lending their support to the First American Birth Control Conference in 1921 which led to the establishment of the American Birth Control League.</p>


<h2>Organizational Structure</h2>

<p><b>Brownsville Clinic Staff:</b><br>
Sanger directed the Brownsville Clinic and served as a nurse along with her sister, Ethel Byrne. Fania Mindell assisted with administrative work and acted as a translator. Elizabeth Stuyvesant assisted with administrative tasks.</p>

<p><b>Committee of 100:</b><br>
Officers consisted of a chairman, two vice-chairmen, and a treasurer.</p>


<h2>Officers of the Committee of 100</h2>

<p>For a complete list of Committee of 100 members, see the pamphlet The Birth Control Movement, under the Brownsville
Clinic/Committee of 100 in the <a href="../../publications/collected_documents.php">Collected Documents Series</a>.</p>

<p><ul class="thin">
<li>	Cothren, Marion B. - Treasurer
<li>	Graves, Mrs. William Leon - Vice-Chairman
<li>	Pinchot, Gertrude Minturn - Chairman
<li>	Williams, Mrs. John H. - Vice-Chairman
</ul>
</p>

<h2>Related Sources</h2>

<p>Documentation on the operation of the Brownsville Clinic is scarce. Most of the extant records of the Clinic and the Committee of 100 are contained in the Collected Documents Series and on the Library of Congress microfilm, including legal records and correspondence about the trial, several letters written by Sanger from prison, and other material. The Collected Documents Series also includes minutes and resolutions of the Committee of 100. The Smith College Collections Series contains only a copy of the advertising flyer for the Clinic and several letters related to Sanger's trial and imprisonment, including two letters written from prison. The closing of the Clinic and related trials were well covered in the press, including in the New York Times, New York Herald Tribune and Brooklyn Eagle. The New York Call and The Birth Control Review also contain articles and editorials on the trials and prison sentences.</p>

<p><b>For legal records related to the Clinic trials and appeals, see</b>:<br>
<ul class="thin-indent">
<li>1916-1919 State of New York vs. Margaret Sanger et al.
</ul>
</p>

<p><b>For Sanger's writings about the Clinic and ensuing trials, see</b>:<br>
<ul class="thin-indent">
<li>Articles and Speeches, 1916-1918
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>
	
        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>About Sanger</h1>
		<div id="subnav">
			<a href="../aboutms/index.php">Biographical Sketch</a><br>
			<b><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></b><br>
			<a href="../aboutms/sanger_archive.php">The Sanger Archive</a><br>
			<a href="../aboutms/ms_writings.php">Sanger's Writing</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
