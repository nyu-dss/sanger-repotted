
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / About Sanger / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger" class="selected">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>World Population Emergency Campaign</h1>
<h2>History</h2>

<p>The World Population Emergency Campaign (WPEC), a private organization administered by the <a href="organization_ippf.php">International PlannedParenthood Federation</a> (IPPF), was set up for the purpose of alerting Americans to the danger of the "world population explosion" and raising money for international birth control programs. Its founding conference held on March 20, 1960 in Princeton, N. J. was organized by Hugh Moore, founder of the Dixie Cup Corporation and an IPPF council member, and by
General William H. Draper Jr., whose well-publicized 1959 presidential report recommended that the federal government assist
nations seeking to control their population growth.</p>

<p>With the use of the slogan, "Not just another cause, but the problem of our time," WPEC worked to publicize the potential
perils arising from rapid world population growth. Through advertisements in the New York Times, meetings with business
leaders in various cities, and mass mailings signed respectively by Margaret Sanger and novelist, James A. Michener, WPEC
also worked to raise funds for IPPF--Western Hemisphere Region projects. Through the IPPF--Western Hemisphere Region's Allocation Committee, the WPEC funds were distributed to such organizations as the Family Planning Association of India for a
mobile field clinic; the IPPF Far Eastern Region for the training of Indonesian doctors; and the Margaret Sanger Research
Bureau in New York City for free distribution abroad of birth control literature and devices.</p>

<p>Margaret Sanger was not involved with the daily activities of the WPEC; rather her primary role was as a fund-raiser. In
addition to lending her name to its mass mailings, she counseled the leadership of WPEC on fund-raising strategies and public
relations. Drafts of proposed form letters reveal her efforts to diminish the WPEC's attempts to appeal to Americans' fears of
"communist exploitation" in overpopulated countries. WPEC's largest fund-raising event was the Margaret Sanger World
Tribute held in New York City on May 11-12, 1961, the 45th anniversary of Sanger's opening of the Brownsville Clinic. With
this conference and dinner chaired by Sir Julian Huxley, the Tribute fund immediately exceeded its $100,000 goal. Sanger's
attendance was her last major public appearance.</p>

<p>WPEC operated independently for just over a year before it agreed to a merger with the <a href="organization_ppfa.php">Planned Parenthood Federation ofAmerica</a> (PPFA) in the fall of 1961. Although the PPFA added WPEC to its name and invited Campaign members to serve on its board, the merger had little effect on PPFA operations, save that it increased the funds available for PPFA's international efforts in conjunction with IPPF. It was, however, a short-lived enterprise; by 1963, PPFA dropped WPEC from its official name.</p>


<h2>Organizational Structures and Committees</h2>

<b>Margaret Sanger Tribute Committee:</b>
<p>Consisted of Steering Committee members who organized the World Tribute to honor Sanger in 1961.</p>

<b>National Committee:</b>
<p>Composed of the original members of the Steering Committee along with prominent donors.</p>

<b>Projects Committee (Projects and Allocations Committee):</b>
<p>Comprised of members of the Steering Committee, the Projects Committee evaluated requests for funds submitted to the WPEC before they were brought before the Steering Committee.</p>

<b>Steering Committee:</b>
<p>Consisted of a chair, 3 vice-chairs, a treasurer, and a secretary. The Steering Committee oversaw the operation of WPEC, and was primarily concerned with fund-raising and public relations.</p>

<p>Other committees included Budget and Finance and Fund-raising.</p>

<h2>WPEC Officers and Committee Members</h2>

<p><ul class="thin">
<li>Babbott Jr., Frank L. - Steering Committee; National Committee
<li>Barton, Bruce - Convener of founding conference; Steering Committee; National Committee
<li>Bennett, Russell H. - Steering Committee; National Committee
<li>Boushall, Thomas C. - National Committee
<li>Brooke, Joel I. - Steering Committee
<li>Brown, Harrison - Convener of founding conference; Steering Committee; National Committee
<li>Brush, Dorothy Hamilton - Steering Committee; National Committee
<li>Bullitt, John C. - Steering Committee; National Committee
<li>Burdick, C. Lalor - Steering Committee; National Committee
<li>Cabot, Henry B. - Steering Committee; National Committee
<li>Cadbury, George W. - Steering Committee
<li>Cake, Wallace Ellwood - Steering Committee; National Committee
<li>Canfield, Jane - Steering Committee; National Committee
<li>Clayton, Will - Convener of founding conference; Vice-Chair of National Committee
<li>Compton, Dorothy D. - Steering Committee
<li>Copeland, Lammot DuPont - Convener of founding conference; Chair of Steering Committee; Co-Chair of National
Committee
<li>Crabtree, James A. - National Committee
<li>Davis, Kingsley - Steering Committee; National Committee
<li>Davis, Matthew D. - National Committee
<li>Day Jr., Rufus S. - Treasurer of Steering Committee; Treasurer of National Committee
<li>Dickey, Harry S. - National Committee
<li>Dorr, John V. N. - Steering Committee; National Committee
<li>Draper Jr., William H. - Convener of founding conference; Vice-Chair of Steering Committee; Co-Chair of National
Committee
<li>Dullitt, John - Steering Committee
<li>Duncan, Alexander E. - National Committee
<li>Eccles, Marriner Stoddard - National Committee
<li>Edison, Mrs. Theodore - Steering Committee
<li>Edison, Theodore - Steering Committee
<li>Ferguson, Frances Hand - Steering Committee; National Committee
<li>French, Graham - Steering Committee; National Committee
<li>Griessemer, Thomas O. - Secretary of Steering Committee; Secretary of National Committee
<li>Harnischfeger, W. H. - National Committee
<li>Hauser, Phillip M. - Steering Committee; National Committee
<li>Hayward, Sam T. - National Committee
<li>Hazard, Leland - National Committee
<li>Heffelfinger, F. Peavy - Vice-Chair of Steering Committee; National Committee
<li>Heffelfinger, Mrs. F. Peavy - National Committee
<li>Hoagland, Hudson - National Committee
<li>Hopkins, Prynce - Steering Committee; National Committee
<li>Johnson, Joseph E. - Steering Committee; National Committee
<li>Knapp, Sherman R. - Steering Committee; National Committee
<li>Kyle, Richard S. - Steering Committee; National Committee
<li>Lamont, Thomas S. - National Committee
<li>Land, James N. Sr. - Steering Committee
<li>Livingston Jr., Goodhue - Steering Committee
<li>Lloyd, Glen A. - National Committee
<li>Marts, Arnaud - Steering Committee; National Committee
<li>McClintock, Mrs. Harvey - Steering Committee
<li>McCormick, Fowler - National Committee
<li>McCracken, Robert T. - Steering Committee; National Committee
<li>McKee, Frederick C. - Steering Committee
<li>McIntryre, Bernard G. - Associate campaign director; consultant to Steering Committee
<li>Michener, James A. - Steering Committee; National Committee>
<li>Moore, Hugh - Convener; Vice-Chair of Steering Committee; Chair of Steering Committee after National Committee
formed
<li>Morain, Lloyd L. - Steering Committee; National Committee
<li>Mudd, Stuart - National Committee
<li>Neutra, Richard J. - National Committee
<li>Norman, Dorothy S. - National Committee
<li>Nuveen, John - Vice-Chair of Steering Committee; Vice-Chair of National Committee; member of Budget and Finance
Committee
<li>Oram, Harold L. - Campaign director; consultant to Steering Committee
<li>Pillsbury, Eleanor Bellows - Steering Committee; National Committee
<li>Prentice, Rockefeller - National Committee
<li>Richter, Mrs. Stanley L. - Steering Committee
<li>Royce, Donald - National Committee
<li>Sanger, Margaret - Steering Committee; National Committee
<li>Schockley, William - National Committee
<li>Scripps, Charles E. - Steering Committee; National Committee
<li>Senior, Clarence - Steering Committee
<li>Smith, Ralph Lee - Consultant to Steering Committee
<li>Spencer, Harold B. - Consultant to Steering Committee
<li>Stebbins, Ernest L. - National Committee
<li>Swensrud, Sidney A. - National Committee
<li>Vanderbilt, William H. - Steering Committee; National Committee
<li>Watumull, Ellen Jensen - Steering Committee
<li>Weir, Roslyn C. - National Committee
</ul>
</p>


<h2>Related Sources</h2>

<p>The <a href="../../publications/smith_series.php">Smith College Collections Series</a> includes WPEC minutes, organizational memos, publications, reports, and form letters
drawn from an incomplete set of records of the WPEC (1960-1961) located among Sanger's papers at the Sophia Smith
Collection, Smith College. The <a href="../../publications/library_of_congress.php">Library of Congress microfilm</a> does not contain any WPEC records and very little
documentation on PPFA after 1956. The <a href="../../publications/collected_documents.php">Collected Documents Series</a> contains scattered material concerning the
WPEC, including correspondence with WPEC organizer Hugh Moore.</p>

<p><b>For other organizations involved with the WPEC, see:</b>
<ul class="thin-indent">
<li>IPPF--WHR for records related to the establishment of WPEC
<li>PPFA for records related to the 1961 merger and for records of the resulting organization, PPFA--WPEC
</ul>
</p>

<p><b>For tribute sponsored by the WPEC, see:</b>
<ul class="thin-indent">
<li>1961 - World Tribute to Margaret Sanger
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>About Sanger</h1>
		<div id="subnav">
			<a href="../aboutms/index.php">Biographical Sketch</a><br>
			<b><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></b><br>
			<a href="../aboutms/sanger_archive.php">The Sanger Archive</a><br>
			<a href="../aboutms/ms_writings.php">Sanger's Writing</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
