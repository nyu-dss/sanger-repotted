
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / About Sanger / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger" class="selected">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>The Margaret Sanger Research Bureau</h1>
<h2>History</h2>

<p>The Margaret Sanger Research Bureau (MSRB) began as the <a href="organization_bccrb.php">Clinical Research Bureau</a> in 1923, which operated under the direction of the American Birth Control League (ABCL). In 1928, Sanger resigned as president of the ABCL and assumed full control of the clinic, renaming it the Birth Control Clinical Research Bureau (BCCRB). The BCCRB reunited with the ABCL in a 1939 merger that  created the <a href="organization_bcfa.php">Birth Control Federation of America</a> --changed to <a href="organization_ppfa.php">Planned Parenthood Federation of America</a> (PPFA) in 1942 -- but  retained much of its independence. In 1940, the clinic changed its name to the MSRB in honor of its founder.</p>

<p>Under the guidelines of the 1939 merger, the MSRB was only loosely affiliated  with PPFA until the mid-1950s, when budget deficits forced the Bureau to  more closely align its services with the work of the Federation in exchange for
financial assistance. The Bureau assisted with PPFA fund-raising, accommodated an increased number of PPFA board
members on its board of trustees, and became the clinical research arm of the PPFA. In return PPFA covered the Bureau's
growing annual deficits and supported individual doctors and researchers on the Bureau staff with grants. The Bureau continued
to struggle with its finances in the 1960s, prompting an affiliation with Columbia University in 1968. However, in 1974 rising
costs forced the Bureau to shut down its 17 West 16th Street building and combine its staff with Planned Parenthood of New
York City in a new facility on Second Avenue called the Margaret Sanger Center in New York. In 1992, Planned Parenthood
of New York City moved to the corner of Bleecker and Mulberry Streets, a site renamed Margaret Sanger Square.</p>

<p>From 1940, when the Bureau changed its name, until 1962, the last year of Sanger's involvement with the MSRB, the Bureau
provided comprehensive contraceptive services for women and couples, and became the largest combined birth control and
fertility center in the world. The diaphragm and spermicidal jelly was the Bureau's most prescribed method of birth control,
although the shortage of rubber during World War II accelerated MSRB-sponsored research and testing of other
contraceptives, including intrauterine devices, thought they were not widely used until the 1960s. By 1961, the Bureau was also
offering the anovulant pill to its patients. While the Bureau did not perform abortions until 1973, it
did run an Overdue Clinic that diagnosed and counseled pregnant women and referred patients to local hospitals and private doctors for medical care and in some cases legal therapeutic abortions. However, the Bureau took care to make it clear that its staff would provide no assistance if a woman requested an abortion.</p>

<p>After Medical Director Hannah Stone's death in 1941, Abraham Stone, her husband and successor, altered and expanded the
MSRB to accommodate his growing interest and expertise in the field of infertility. In 1945, Stone inaugurated a Fertility Service
that offered counseling, testing, and treatment for infertile couples. He expanded the Bureau's Marriage Consultation Service
and steered the Research Department into a greater emphasis on infertility studies. While the Bureau continued to be associated
with its contraceptive services, the number of users dropped steadily in the post-war years as contraception became more
widely available through private physicians. However, the Bureau grew as a teaching center, offering seminars, research
projects and clinical work for visiting doctors, nurses, and medical students. In addition to its medical and research programs,
the Bureau also offered a fellowship program for gynecologists and obstetricians for intensive training in birth control technique.</p>

<p>Margaret Sanger, the founder and director of the Bureau, withdrew from day-to-day MSRB affairs in the 1940s, spending most
of her time in semi-retirement at her home in Tucson. As director, she continued to make many of the budgetary and personnel
decisions, but left most matters regarding the daily operation of the Bureau in the hands of the executive secretary and medical director. Though she disagreed with how the Clinic had evolved under Abraham Stone's leadership and sought to diminish the
growing prominence of the its Fertility Service, she continued to raise funds for the MSRB. In 1950 Sanger turned over even
more control to Stone, naming him director and selling him the West 16th Street building, but she remained on the board of
trustees and continued to offer Stone her counsel.</p>


<h2>Organizational Structure</h2>

<b>Board of Managers/Trustees:</b>
<p>Consisted of the director, medical director, several physicians, benefactors, and usually two or more members of PPFA's Board of Directors. The Board advised on all aspects of the Bureau's operations, supervised budgetary matters and personnel decisions, and represented the MSRB in the medical community.</p>

<b>Contraceptive Service:</b>
<p>All new Bureau patients received an orientation lecture and medical examination. Physicians prescribed contraceptives in accordance with individual needs. The Bureau also offered a Safe Period Service for patients interested in the rhythm method, and a Diagnostic Service or Overdue Clinic to determine if women experiencing delayed menstrual periods were pregnant. They were interviewed, examined, and diagnosed only. If necessary they were referred to a private physician or local hospital.</p>

<b>Education Department:</b>
<p>Provided a Training Service consisting of lectures demonstrations, seminars and research projects for visiting doctors, nurses, medical students, and social workers. The Department also gave organized lectures and screenings of films for patients and staff, distributed literature on birth control and fertility, including a suggested readings list, and oversaw the Bureau's library.</p>

<b>Fertility Service:</b>
<p>Starting in 1945, patients with fertility problems referred by their physician or a public health agency received an orientation lecture, an examination, testing, and possibly some form of treatment. Certain treatments, including artificial insemination were performed at the clinic. Endocrinological and psychotherapeutic services were also available for cases of glandular dysfunction and emotional problems associated with infertility. The Fertility Service department also included a Preconception Service that offered exams and counseling for couples planning to conceive.</p>

<b>Marriage Consultation Services:</b>
<p>Offered both group and individual counseling sessions before and after marriage. A "Premarital Service" provided lectures and group discussions dealing with social, physical and psychological aspects of marriage and the family. The Marital Problems Service offered consultations for married couples primarily with sexual problems and was merged in 1953 with the Marriage Consultation Center of the Community Church of New York.</p>

<b>Medical (and Scientific) Administrative Committee:</b>
<p>Consisted of MSRB and PPFA board members organized in 1955 to negotiate cooperative research projects between the two organizations and report on new medical findings. The name of the Committee changed several times in the 1950s and 1960s.</p>

<b>Research Department:</b>
<p>Carried out research on all aspects of human fertility, and performed clinical testing on new contraceptive products. After World War II, the Bureau concentrated on infertility research.</p>

<b>Staff:</b>
<p>The core staff consisted of a director, medical director, associate medical director(s), a medical consultant, full and part-time physicians (from 10 in 1940 to 30 in the early 1950s, and including gynecologists, urologists, endocrinologists, psychiatrists, and a cytologist), 9 or 10 nurses, social worker(s), lab technicians, an executive secretary, a treasurer, and 10 to 12 clerical and part-time employees.</p>

<p>(Many other committees operated for various periods of time between 1940 and 1962, including the Budget and Finance, Fundraising, Nominating, Personnel, New Directions, Administration, Associates, and Theater Benefit committees).</p>

<h2>Staff, Board of Trustees, and Officers (1940-1962)</h2>

<p><ul class="thin">
<li>Aitken, Gerard - Board of Trustees
<li>Alhadeff, N. - Staff Physician
<li>Allen, Mrs. Hale - Board of Trustees
<li>Amelar, Richard D. - Staff Physician
<li>Appel, Cheri - Staff Physician
<li>Appleton, Shelly - Board of Trustees
<li>Arnold, Elizabeth - Medical (and Scientific) Administrative Committee; Administrative Staff
<li>Baum, Margaret Hays - Secretary; Vice-Chairman, Board of Trustees
<li>Baumgold, Deborah - Staff Physician
<li>Behrens, Gertrude - Staff Physician
<li>Bein, William - Board of Trustees
<li>Berkeley, Ruth - Staff Physician
<li>Berthet, ? - Staff Nurse
<li>Blatt, M. - Staff Physician
<li>Blodgett, Stephen W. - Treasurer; Board of Trustees
<li>Blom, Frieda J. - Staff Nurse; Administrative Assistant
<li>Brampton, ? - Staff Nurse
<li>Broh-Kahn, Eleanor - Board of Trustees
<li>Brumbaugh, Henrietta - ?
<li>Bruno, D. - Staff Physician
<li>Brush, Dorothy Hamilton - Board of Trustees
<li>Calderone, Mary Steichen - Medical (and Scientific) Administrative Committee
<li>Carbonnier, Jeanne - Staff Physician
<li>Chambers, Mrs. Frank - Administrative Assistant
<li>Childs, Coyetta - Administrative Assistant
<li>Ciner, L. - Staff Physician
<li>Colgate, Mrs. Gilbert - Board of Trustees
<li>Cook, Charles - Chairman, Board of Trustees; Legal Advisor
<li>Crary, Calvert - Treasurer; Board of Trustees
<li>Crawley, Lawrence Q. - Staff Physician; Board of Trustees; Associate Medical Director; Medical (and Scientific)
Administrative Committee
<li>Decker, Albert - Staff Physician
<li>DeMuth, Lillian - Staff Physician
<li>DePaoli, D. - Staff Physician
<li>Dickinson, Robert Latou - Senior Medical Consultant; Board of Trustees
<li>Dourmashkin, L. - Staff Physician
<li>Epstein, J. - Staff Physician
<li>Ferguson, Frances Hand - Board of Trustees
<li>Forman, ? - Staff Nurse
<li>Flowers, Estelle W. - Executive Secretary
<li>Gamble, Clarence James - Board of Trustees; Medical (and Scientific) Administrative Committee
<li>Gerstel, Gerda - Staff Physician
<li>Godfrey, ? - Staff Nurse
<li>Gottlieb, S. - Staff Physician
<li>Gowanloch, Louise - Staff Physician
<li>Grafenberg, Ernest - Staff Physician
<li>Greenberg, Emanuel M. - Staff Physician
<li>Gruggel, Christine - Staff Physician
<li>Guttmacher, Alan F. - Director; Board of Trustees; Medical (and Scientific) Administrative Committee
<li>Hamilton, ? - Staff Physician
<li>Hardin, Verna - Staff Physician
<li>Harrington, Rev. Donald - Board of Trustees
<li>Harrison, Pauline L. - Board of Trustees
<li>Harshman, Richard R. - Assistant Treasurer; Board of Trustees
<li>Hartman, Carl G. - Research Consultant; Medical (and Scientific) Administrative Committee
<li>Heiner, R. Graham - Board of Trustees
<li>Herman, Harry - Board of Trustees
<li>Hilliman, Mrs. Serrell - Board of Trustees
<li>Hopkins, Josephine - Staff Physician
<li>Houmere, Mildred Lacroix - Staff Nurse
<li>Imberman, R. - Staff Physician
<li>Ingalls, Mabel S. - Board of Trustees
<li>Ingersoll, Marion Crary - Board of Trustees
<li>Jern, H. - Staff Physician
<li>Johnson, Mary Compton - Executive Secretary
<li>Jones, ? - Staff Nurse
<li>Knapp, Robert - Board of Trustees
<li>Knapp, Mary Louise - Staff Nurse
<li>Korn, Charles - Treasurer; Board of Trustees
<li>Kupperman, Herbert S. - Staff Physician; Medical (and Scientific) Administrative Committee
<li>Laidlaw, ? - Staff Physician
<li>Lawson, ? - Staff Nurse
<li>Lee, ? - Staff Nurse
<li>Levine, Charlotte - Administrative Secretary; Medical (and Scientific) Administrative Committee
<li>Levine, Lena -- Staff Physician; Board of Trustees; Associate Medical Director; Medical (and Scientific) Administrative
Committee
<li>Lewis, A. - Staff Physician
<li>Lewis, Frances - Staff Physician
<li>Lindner, Mae E. - ?
<li>Lindstrom, Helga - ?
<li>Livermore, Ruth Hamilton - Staff Nurse
<li>Loeb, Mrs. Robert - Board of Trustees
<li>Luck, Mabel D. - Staff Nurse
<li>MacLeod, John - Staff Physician; Medical (and Scientific) Administrative Committee
<li>Macy, Mrs. Edward Warren - Board of Trustees
<li>Mali, Henry J. - Board of Trustees
<li>Marshall, ? - Staff Physician
<li>Mazzola, Linda - Staff Physician
<li>McClintock, Earl -Board of Trustees
<li>McLane, Charles - Medical (and Scientific) Administrative Committee
<li>McLean, Kenneth - Staff Physician
<li>Mendell, Martha - Staff Physician
<li>Miller, Katherine W. - Staff Physician
<li>Mills, Leslie - Board of Trustees
<li>Mintz, ? - Staff Physician
<li>Moore, Louise - Board of Trustees
<li>Noland, Raymond - Staff Physician
<li>Northup, Jane - Staff Physician
<li>Norton, ? - Staff Physician
<li>Ober, William B. - Staff Physician
<li>Orron, A. - Staff Physician
<li>Osterman, E. - Staff Physician
<li>Piel, Eleanor Jackson -Board of Trustees
<li>Piel, Gerard -Board of Trustees
<li>Pierson, Richard N. - Board of Trustees
<li>Portnoy, Louis - Staff Physician
<li>Post, A. - Staff Physician
<li>Purcell, Ida M. - ?
<li>Robbins, Mrs. Ira - Board of Trustees
<li>Romaine, Adelaide - Staff Physician
<li>Rose, Florence - Administrative Assistant
<li>Rosenfeld, L. - Staff Physician
<li>Sanger, Grant - Associate Medical Director
<li>Sanger, Margaret - Founder; Director; Chairman, Board of Trustees
<li>Schuster, Max Lincoln - Board of Trustees
<li>Schuster, Ray Haskell - Board of Trustees
<li>Seidl, J. - Staff Physician
<li>Shields, Frances E. - Staff Physician; Associate Medical Director; Board of Trustees
<li>Siegmann, Evelyn W. - ?
<li>Silechia, Emily - Administrative Assistant
<li>Slee, J. Noah - Treasurer
<li>Sobrero, Aquiles J. - Staff Physician; Director; Research Director; Medical (and Scientific) Administrative Committee
<li>Stewart, Virginia - Staff Physician
<li>Stone, Abraham - Medical Director; Director; Chairman, Board of Trustees; Medical (and Scientific) Administrative
Committee
<li>Stone, Hannah - Medical Director
<li>Stromsoe, Bergliot - Staff Physician
<li>Swords, Jacquelin - Board of Trustees; Legal Advisor
<li>Taylor, Jeanette J. - Board of Trustees
<li>Tietze, Christopher - Staff Physician; Medical (and Scientific) Administrative Committee
<li>Van Vleck, Jr., Joseph - Board of Trustees
<li>Vogt, William - Board of Trustees
<li>Ward, Mildred D. - Medical (and Scientific) Administrative Committee
<li>Wasserberg, I - Staff Physician
<li>Webb, Ernest C. - Board of Trustees
<li>Webster, ? - Staff Nurse
<li>Weiser, Frances J. -Staff Physician
<li>Werner, Sidney C. - Medical Consultant
<li>White, Mary M. - Staff Physician
<li>Whitefield, Elizabeth - Staff Nurse
<li>Willett, ? - Staff Nurse
<li>Woodelton, Edith - Staff Physician
<li>Workum, Emily Harneill - President; Board of Trustees
<li>Wright, Cecil Damon - Executive Secretary
</ul>
</p>


<h2>Related Sources</h2>

<p> The <a href="../../publications/collected_documents.php">Collected Documents Series</a> contains correspondence with Bureau staff, medical staff minutes and minutes of the board of trustees largely drawn from the Abraham Stone Papers located at the Houghton Library. The <a href="../../publications/smith_series.php">Smith College Collections Series</a> contains correspondence primarily between Sanger and the executive secretary or other administrative staff at the Bureau regarding budget and personnel decisions and other issues, as well as some organizational records. The <a href="../../publications/library_of_congress.php">Library of Congress microfilm</a> contains some Bureau correspondence files, a few personnel files, publications and a small number of minutes and reports.</p>

<p><b>For other organizations involved with the MSRB, see:</b>
<ul class="thin-indent">
<li>BCCRB for records of the Bureau prior to the 1940 name change
<li>BCFA and PPFA for records related to the Bureau's affiliation with the Federation
<li>IPPF for records related to international work and conferences that Bureau members took part in or that the Bureau supported or sponsored
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>
	
        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>About Sanger</h1>
		<div id="subnav">
			<a href="../aboutms/index.php">Biographical Sketch</a><br>
			<b><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></b><br>
			<a href="../aboutms/sanger_archive.php">The Sanger Archive</a><br>
			<a href="../aboutms/ms_writings.php">Sanger's Writing</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
