
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / About Sanger / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger" class="selected">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>New York Birth Control League</h1>
<h2>History</h2>

<p>Established in December 1916, the New York Birth Control League (NYBCL) was organized in the wake of Margaret Sanger's October arrest for opening the Brownsville Clinic, the nation's first birth control clinic. In addition to providing support for Sanger's legal battles, the League's goals were to secure an amendment to state and federal laws that would allow physicians and registered nurses to dispense contraceptives; and toadvocate and encourage birth control as a means of safe-guarding women's health, and promoting social welfare. The League competed for funding and publicity with Mary Ware Dennett's National Birth Control League, also based in New York.</p>

<p>Frederick Blossom, a young Socialist Party worker from Cleveland, organized the League while serving as managing editor of Sanger's journal, The Birth Control Review. Using the same Fifth Avenue office as the Review, the League raised money for Sanger's defense fund and helped organize the Carnegie Hall mass meeting held on January 29, 1917, the eve of Sanger's trial. The League appears to have also contributed funds and staff time to the Review, which published its first issue in February of 1917. It also distributed booklets and other educational literature, but there is little evidence to suggest that it accomplished any other significant work.</p>

<p>Though it was organized for her benefit, Margaret Sanger never actually belonged to the League. By the summer of 1917, in fact, Sanger became its chief antagonist when she accused Blossom of taking Birth Control Review revenues along with account books and lists of subscribers. Blossom who was in charge of the Review's books, while also serving as president and then treasurer of the League, could not account for the missing funds, but angrily denied any wrong-doing and publicly attacked Sanger's credibility. An investigation by a committee of Socialist Party members exonerated Blossom, but Sanger rejected the committee's report, claiming it was biased and incompetent. Nevertheless, she dropped the charges but the League probably disbanded sometime in 1918.</p>


<h2>organizational structure and committees</h2>

<p>The League consisted of a president, 2 vice presidents, a secretary, a treasurer, a finance committee, and a Margaret Sanger Defense Committee. It is not clear how frequently the NYBCL convened meetings or to what extent the officers contributed to the League's program.</p>

<h2>NYBCL Officers and Staff</h2>

<p><ul class="thin">
<li>Blossom, Frederick A. - President; Treasurer
<li>Fruchter, Henry I. - Administrative Assistant/Secretary
<li>Goldstein, Jonah J. - Treasurer
<li>Goldstein, Rev. Sidney E. - Vice President
<li>Greene, Louise A. - Treasurer
<li>Hope, Augusta P. - Chairman, Finance Committee
<li>Hunt, M. Louise - Secretary
<li>Myers, Hiram - Treasurer; Assistant Treasurer
<li>Stone, Mrs. Eugene - President
<li>Stuyvesant, Elizabeth - Secretary
<li>Todd, Helen - Vice President
</ul>
</p>


<h2>Related Sources</h2>

<p>Surviving records of the New York Birth Control League are scarce. The <a href="../../publications/collected_documents.php">Collected Documents Series</a> includes
correspondence from Sanger to members of the Socialist Party and to supporter Juliet Rublee in which she discusses the
League and the Blossom affair. Issues of the <span class="italicText"> Birth Control Review</span> for 1917 and 1918 contain references to the League and fund-raising notices for the Margaret Sanger Defense Fund. The <a href="../../publications/smith_series.php">Smith College Collections Series </a>contains only two 1916 press releases that refer to initial interest on the part of Sanger and Blossom in starting such an organization but does not contain any records of the League itself. The <a href="../../publications/library_of_congress.php">Library of Congress microfilm</a> includes two files of correspondence related to the League, including letters between Blossom and Sanger, and Blossom and Jonah J. Goldstein (Sanger's attorney in the Brownsville Clinic trials and a treasurer of the League), among others.</p>

<p><b>For other organizations associated with the NYBCL, see:</b>
<ul class="thin-indent">
<li>Birth Control Review for material related to Frederick Blossom
</ul>
</p>

<p><b>For legal records associated with the NYBCL, see:</b>
<ul class="thin-indent">
<li>Frederick Blossom/Margaret Sanger Dispute
<li>State of New York v. Margaret Sanger ( Brownsville Clinic)
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>
	
        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>About Sanger</h1>
		<div id="subnav">
			<a href="../aboutms/index.php">Biographical Sketch</a><br>
			<b><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></b><br>
			<a href="../aboutms/sanger_archive.php">The Sanger Archive</a><br>
			<a href="../aboutms/ms_writings.php">Sanger's Writing</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
