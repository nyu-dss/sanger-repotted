
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / About Sanger / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger" class="selected">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>Joint Committee of the ABCL and BCCRB</h1>
<h2>History</h2>

<p>In June of 1938, the <a href="organization_abcl.php">American Birth Control League</a> (ABCL) and <a href="organization_bccrb.php">Birth Control Clinical Research Bureau</a> (BCCRB) formed a Joint Committee to consider closer coordination of all research, teaching, field organization, clinical work, and educational activities of the League and the Bureau. This effort was aimed at countering financial problems faced by both the League and the BCCRB as donors split their contributions between the two organizations, and as competition over clinic affiliations and disagreements about lobbying activities between the two groups intensified. The Committee's goal was to develop a program that would provide for greater efficiency in service and administration of clinics and state organizations, and to consider the feasibility of a merger.</p>

<p>Several meetings between representatives of the two organizations as well as the <a href="organization_cmh.php">National Committee on Maternal Health</a>, and the management firm, John Price Jones, Inc., led to fact-finding studies and a "Summarized Factual Report with Analysis and Conclusions" submitted by D. Kenneth Rose of John Price Jones, Inc. and George Aubrey Hastings. The report found that considerable duplication of work of the two organizations existed in every branch of their activities. Based on this report, the Committee's final recommendation was for a complete merger. On January 19, 1939 the two organizations officially merged into the <a href="organization_bcfa.php">Birth Control Federation of America</a>. The Committee approved a slate of new officers, with Richard N. Pierson as chairman and president pro tem. Margaret Sanger was consigned to the limited role of honorary chairman of the board of directors.</p>


<h2>Organizational Structure</h2>

<p>The Joint Committee consisted of 13 members, assisted by representatives of the management firm of John Price Jones, Inc.</p>

<h2>Members of the Joint Committee</h2>

<p><ul class="thin">
<li>Bangs, Catherine Clement
<li>Blagden, Mabel Whitney
<li>Blodgett, Marguerite
<li>Brush, Dorothy Hamilton
<li>Colgate, Gilbert
<li>Dickinson, Robert Latou
<li>Holden, Frederick C.
<li>Pierson, Richard N. - Chairman
<li>Potter, Rose
<li>Rose, D. Kenneth, John Price Jones, Inc.
<li>Sanger, Margaret
<li>Stone, Abraham
<li>Suarez, Evelyn
<li>Wile, Ira Solomon
</ul>
</p>


<h2>Related Sources</h2>

<p>The Collected Documents Series and the Library of Congress microfilm contain only a few records and limited correspondence related to the merger. More extensive meeting minutes, press releases and reports of the Joint Committee are located in the <a href="../publications/smith_series.php">Smith College Collections Series</a>, which also contains relevant correspondence concerning the merger.</p>

<p><b>For organizations involved with the Joint Committee, see:</b>
<ul class="thin-indent">
<li>ABCL for records related to the League's activities prior to the merger
<li>BCCRB for records related to the Bureau's activities prior to the merger
<li>BCCA for records documenting efforts to coordinate the activities of the ABCL and BCCRB in 1937
<li>BCFA for records of the merged organization, 1939-1942
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>
	
        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>About Sanger</h1>
		<div id="subnav">
			<a href="../aboutms/index.php">Biographical Sketch</a><br>
			<b><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></b><br>
			<a href="../aboutms/sanger_archive.php">The Sanger Archive</a><br>
			<a href="../aboutms/ms_writings.php">Sanger's Writing</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
