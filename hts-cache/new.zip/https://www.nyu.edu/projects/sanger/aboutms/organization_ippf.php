
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / About Sanger / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger" class="selected">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>International Planned Parenthood Federation</h1>
<h2>History</h2>

<p>The International Planned Parenthood Federation (IPPF) was formally founded on November 29, 1952, by a resolution of the Third International Conference on Planned Parenthood in Bombay, India. The IPPF was formed out of the provisional International Committee on Planned Parenthood (ICPP) as a permanent organization dedicated to the advancement and acceptance of family planning around the world. The original four member nations of the ICPP, the U.S., Great Britain, Sweden, and the Netherlands, were joined by national birth control organizations from West Germany, India, Hong Kong, and Singapore. Japan, which had not yet created a national federation of birth control organizations, was made an associate member. The IPPF incorporated new member nations each year and formed a regional structure in 1953. By 1961, the IPPF consisted of thirty-two members divided into four regions.</p>

<p>The IPPF continued to pursue the aims and objectives of the ICPP, including the collection and dissemination of information on birth control and human reproduction, population problems, and sex education, as well as furthering research, training and organizational activities in these fields. But the IPPF dedicated more of its resources to the creation of new family planning associations, and building a federation of existing organizations. The IPPF also gave greater priority to the development of an inexpensive and easily accessible contraceptive and assisted with research and testing of foam powder spermicides and the anovulant pill, among other methods. It organized and sponsored three major international conferences in 1953, 1955, and 1959, and many smaller regional conferences and seminars around the world. The Federation also published a monthly bulletin, The operating budget for the IPPF came primarily from member dues, while donors and foundations, particularly in the U.S., provided funding for the conferences and various special projects.</p>

<p>Margaret Sanger, who had helped to form the ICPP in 1948, was the principal force behind the decision to create a permanent federation at the Bombay conference in 1952. First appointed honorary co-president in 1952 with Lady Dhanvanthi Rama Rau of India, the IPPF council elected her president in 1953 at the 4th International Conference on Planned Parenthood in Stockholm, Sweden (Lady Dhanvanthi Rama Rau was voted chairman). When Sanger resigned as president in 1959 at the Sixth International Conference on Planned Parenthood in New Delhi, India, she was given the titles of founder and president emeritus. Beginning in 1952, Sanger also led the Western Hemisphere Region of the IPPF, serving as its president until 1955, as a member of its executive committee until the late 1950s, and a member of the council until the early 1960s.</p>

<p>Sanger assumed the major leadership role in the IPPF at a time when declining health greatly limited her activities. During her tenure as president a core group of IPPF officers and governing body members, including Elise Ottesen-Jensen (Sweden), Dhanvanthi Rama Rau, C. P. Blacker (England), and Vera Houghton (England) became the key decision makers, though they communicated regularly with Sanger about IPPF policy and actions. Sanger meanwhile used her energies to pursue several key goals. She sought to focus the Federation's limited resources on expanding birth control efforts in India and Japan -- two countries whose governments supported birth control measures -- and to utilize the conference forum she had developed for the 1927 World Population Congress in Geneva as the chief means of unifying the autonomous family planning members, and attracting and educating new member organizations. She also raised substantial funds for the international conferences and for the Western Hemisphere Region of the IPPF. Sanger's goal was to have government public health and welfare departments provide sustained, affordable and effective birth control services. The IPPF continues to pursue the crux of her agenda today.</p>


<h2>Organizational Structure</h2>

<b>Member Organizations:</b><br>
<p>By 1962, 32 organizations were federated as the IPPF. The Federation also included numerous associate members and affiliated organizations.</p>

<b>Member Organizations by region (including first year of membership):</b><br><br>

Indian Ocean

<p><ul class="thin-indent">
<li>Family Planning Association of Burma (1961)
<li>Family Planning Association, Ceylon (1954)
<li>Family Planning Association of India (1953)
<li>Family Planning Association of Nepal (1960)
<li>Family Planning Association of Pakistan (1955)
</ul>
</p>

Far East and Australia

<p><ul class="thin-indent">
<li>Family Planning Association of Australia (1953)
<li>Family Planning Association of Hong Kong (1953)
<li>Family Planning Federation of Japan (1954)
<li>Planned Parenthood Federation of Korea (1961)
<li>New Zealand Family Planning Association (1959)
<li>Family Planning Association, Singapore (1953)
<li>Family Planning Association of Thailand (1960)
<li>Federation of Family Planning Associations, Malaya (1961)
</ul>
</p>

Western Hemisphere

<p><ul class="thin-indent">
<li>Barbados Family Planning Association (1957)
<li>Medical and Health Department, Bermuda (1957)
<li>Jamaica Family Planning Association (1957)
<li>Asociacion Puertorriqueña pro Bienestar de la Familia (1954)
<li>Family Planning Association of Trinidad and Tobago (1961)
<li>Planned Parenthood Federation of America (1953)
</ul>
</p>

Europe, Near East, and Africia

<p><ul class="thin-indent">
<li>Belgische Vereniging voor Seksuele Voorlichting (1955)
<li>Norsk Foreningen for Familiepl-anlaegning (1955)
<li>Vaestoliitto, Finland (1959)
<li>Mouvement Francais pour le Planning Familial (1959)
<li>ProFamilia: Deutsche Gesellscaft für Ehe und Familie (1953)
<li>Associazione Italiana per l'Educaczione Demografica (1954)
<li>Family Welfare Association of Maritius (1959)
<li>Nederlandse Vereniging voor Sexuele Hervorming (1953)
<li>Towarzystwo Swiadomego Macierzynstwa, Poland (1959)
<li>South Africa National Council for Maternal Welfare (1953)
<li>Riksförbundet für Sexuell Upplysning (1953)
<li>Service de la Sante Publique (1959)
<li>Family Planning Association of England (1953)
</ul>
</p>

<b>Around the World News of Population and Birth Control:</b><br>
<p>Monthly bulletin published by the IPPF, translated into several languages, and distributed throughout the world. Edited until the late 1950s by Dorothy Brush, the bulletin served as the Federation's primary means of disseminating information and was envisioned by Sanger as "the glue" that would bind together the international movement. The bulletin covered the ctivities of the Federation and included news updates on regions and specific countries, occasional messages from the president, and short articles on relevant topics. The Brush Foundation of Cleveland, Ohio underwrote the operating expenses of the bulletin.</p>

<b>Constitutional Committee:</b><br>
<p>Composed of five Governing Body members, the Committee considered amendments to the IPPF Constitution, evaluated constitutional discrepancies, and oversaw procedure for nominations.</p>

<b>Council:</b><br>
<p>The Council consisted of one to three representatives from each member organization, co-opted members (appointed by the Governing Body and not necessarily affiliated with a regional or national organization), and regional representatives (one or two from each region), who met at the international conferences roughly every two years. Council members served on the Governing Body.</p>

<b>Editorial Committee:</b><br>
<p>Made up of six members of the Governing Body responsible for editorial decisions affecting the bulletin.</p>

<b>Executive Committee:</b><br>
<p>Composed of members appointed by the Governing Body from among its members and including the president, chairman, vice-chairman, secretary and treasurers of the Governing Body, a representative from each full member association with more than one delegate on the Council, and a representative from each region. The Executive Committee proposed policy measures, administered fund-raising efforts, allocated funds, and evaluated the aims and objectives of the organization.</p>

<b>Field Committee:</b><br>
<p>Assisted with and reported on field work projects that were instigated and authorized by regions. The Committee also oversaw volunteers who worked in accordance with IPPF policies, and worked closely with Clarence Gamble who privately toured Asia and Africa in support of new birth control organizations and to conduct research on new contraceptives.</p>

<b>Finance Committee/Working Finance Committee:</b><br>
<p>The Finance Committee consisted of two treasurers and one representative from each of the four regions and made recommendations to the Governing Body related to the allocation of funds. It also appointed ad-hoc fund-raising committees.</p>

<b>Governing Body:</b><br>
<p>The Governing Body was composed of Council members and officers, and conducted the main business of the organization, including the election of officers, allocation of funds, election of member organizations, establishment of new regions, determination of time and place for conferences, and the formulation and amendment of rules. Though it met every two years, usually at international conferences, much of the work and communication of the body was accomplished through correspondence.</p>

<b>Headquarters:</b><br>
<p>The London headquarters carried out the daily activities of the organization, including tour planning, training sessions for doctors, conference organization, and scheduling. It acted as a central advice bureau for member organizations, doctors, clinics and many individuals from around the world. Form letters, organizational memos and most publications originated from headquarters. The executive secretary ran the London office.</p>

<b>Medical Committee/Medical Sub-Committee:</b><br>
<p>Composed of medical representatives from member countries and several officers of the Federation, the Medical Committee collected and distributed information regarding relevant medical and research findings of member organizations, maintained a bibliography of books and articles on family planning, advised members and individual doctors, issued a bulletin, supplied information about current research projects, set standards for clinics, and established policy regarding medical research.</p>

<b>Nomination Committee:</b><br>
<p>Composed of two members from each region entrusted to nominate officers and Governing Body members not on the Council.</p>

<b>Officers:</b><br>
<p>Consisted of a president, chairman, vice-chairman, vice presidents (two per region), treasurers, an executive secretary, and an editor of the bulletin.</p>

<b>Regional Organizations:</b><br>
<p>Regional organizations were established by member organizations in specific geographical locations as defined by the Governing Body. Each regional organization determined its own structure, elected its own officers, and formulated it own committees. Regional organizations instigated and oversaw projects, and raised funds for their own regions.</p>

<b>Regional Representatives:</b><br>
<p>Consisted of one or two representatives from each of the four world regions: the Indian Ocean; Americas/Western Hemisphere; Europe, Near East, and Africa; and the Western Pacific/Far East and Australasia regions. Regional representatives were members of the Council, Governing Body and Executive Committee.</p>

<b>Sub-Committee on Tests for Contraceptive Products/Evaluation Sub-Committee:</b><br>
<p>Consisted of Medical Committee members who established international standards for the testing of contraceptive products and reported on test results from projects around the world.</p>

<b>U.S. Committee:</b><br>
<p>A committee formed by Sanger in 1956 to raise $175,000 for a two-year development program to fund specific IPPF-sponsored projects. The Committee sought contributions primarily from large foundations, and served as a conduit between the Brush and Watumull foundations and the IPPF. The U.S. Committee consisted of a board of trustees composed of Sanger as president, an assistant to the president, the U.S. treasurer of the IPPF, along with up to two representatives from the Brush and Watumull Foundations. Officers for the Committee included a president, vice-president, secretary and treasurer. The U.S. Committee helped with the preliminary organization of and fund-raising for the proposed Sixth International Conference on Planned Parenthood that was scheduled to be held in Washington, DC in 1957 or 1958. The U.S. Committee disbanded in 1958, shortly after plans for the Washington conference were shelved (the conference was re-scheduled for New Delhi in 1959). Sanger also established an informal advisory group in 1953 sometimes referred to as the U.S. Committee or U.S. Advisory Group.</p>

<b>Western Hemisphere Region (WHR):</b><br>
<p>Initially called the Americas Region, the WHR was formed in 1953 and consisted of one member organization, the Planned Parenthood Federation of America (PPFA). The WHR was initially housed at the PPFA offices in New York City but later moved to the Margaret Sanger Research Bureau. The WHR consisted of a president, two vice-presidents, a secretary and a treasurer. From 1953 to 1955 a Steering Committee conducted the business of the WHR, but then gave way to a Council and Executive Committee that were formed during the First Western Hemisphere Conference on Planned Parenthood held in San Juan, Puerto Rico in 1955.</p>

<p>The Council was comprised of WHR officers and IPPF Council members from the region. The Executive Committee consisted of a small number of Council members and largely managed budget and affairs of the region. The WHR included various committees, such as Field Work, Campaign, Publishing, Nominating, Finance, Allocation, and Resolution committees, and numerous ad-hoc committees. In 1960, WHR-member Hugh Moore established the World Population Emergency Campaign (WPEC) as a fund-raising vehicle operating under the auspices of the WHR. Funds collected by the WPEC were allocated for use by the WHR.</p>

<p>The WHR worked within the region to stimulate the formation of new planned parenthood organizations, assist in scientific research, organize international conferences, meetings and seminars in the region, and raise funds. The WHR focused its resources on Central and South America, the Caribbean, and Puerto Rico, areas where Catholic opposition to contraceptive services was greatest.</p>

<p>Margaret Sanger served as president of the WHR from 1953 to 1955, was a council member until the early 1960s, and served on the Executive Committee until the late 1950s. She played a major leadership role in the WHR, hand-picking the Steering Committee and insuring through the WHR's ties to the MSRB that the WHR would remain largely under the influence of her leadership.</p>

<b>Work Program Committee/Program Committee/Management and Planning Committee:</b><br>
<p>Consisted of Governing Body members responsible for drafting agendas of future work plans and prioritizing the Federation's many projects.</p>

<p>The IPPF included numerous other committees, ad-hoc committees, and sub-committees, many of which were short-lived, or formed to work on conference arrangements. These included the Credentials Committee, Headquarters Changes Committee, Conference Resolution Committee, Conference Steering Committee, and Research Committee.</p>

<h2>IPPF Council, Governing Body, and Board Members, Officers and Regional Representatives for 1952-1962</h2>

<p><ul class="thin">
<li>Adams, Lady - WHR (West Indies): President; Executive Committee; Council
<li>Aldama, Arturo - WHR (Mexico): Council
<li>Amstutz, Celeste B. - IPPF (Family Planning Association of Singapore): Council (Co-opted member); Governing Body; Regional Representative (Far East and Australasia)
<li>BangXang, Erb Na - IPPF (Family Planning Association of Thailand): Council; Governing Body
<li>BangXang, Mrs. Erb Na - IPPF (Family Planning Association of Thailand): Council; Governing Body
<li>Baum, Margaret Hays - WHR (U.S.): Executive Committee; Council
<li>Belaval, Mrs. Edgar - WHR (Puerto Rico): Council
<li>Blacker, C. P. - IPPF (Eugenics Society): Vice-Chairman; Administrative Chairman; Governing Body; Executive Committee; Chairman, Management and Planning Committee
Boas, Conrad Van Emde - IPPF (Nederlandse Vereniging Voor Sexuele Hervorming): Regional Vice- President; Council; Governing Body; Regional Representative (Europe, Near East & Africa)
<li>Braestrup, Agnete - IPPF (Foreningen for Familieplanlaegning, Denmark): Regional Vice-President; Governing Body
<li>Brush, Dorothy Hamilton - IPPF (Brush Foundation/Planned Parenthood Federation of America): Editor, Around the World News of Population and Birth Control; Council (Co-opted member); Governing Body; Executive Committee; Advisor for Field Work Services; WHR (U.S.): Council; Executive Committee
<li>Burson, Mrs. Frank R. - WHR (Aruba): Council
<li>Butcher, Margery K. - IPPF (Family Planning Association, Singapore): Council; Governing Body; Executive Committee; Regional
Representative (Western Pacific/Far East and Australasia)
<li>Byer, Morris A. - WHR (Barbados): Council
<li>Cadbury, Barbara - IPPF (Canada): Council (Co-opted member); Governing Body; WHR (Canada): Council; Executive Committee
<li>Cadbury, George W. - IPPF (Canada): Council (Co-opted member); Governing Body; Special Representative; Field Director; WHR (Canada): Executive Committee; Council
<li>Canfield, Cass - IPPF (Planned Parenthood Federation of America): Council; Governing Body
<li>Canfield, Jane - WHR (U.S.): Council; Executive Committee
<li>Chinnatamby, Siva - IPPF (Family Planning Association, Ceylon): Council (Co-opted member); Governing Body
<li>Chun, Daphne - IPPF (Family Planning Association of Hong Kong): Council (Co-opted member); Governing Body
<li>Cofresi, Emilio - IPPF (Asociaci¢n Puertorriqueña pro Bienestar de la Familia): Council; Governing Body; WHR: Executive Committee
<li>Cordero, Rafael de J. - WHR (Puerto Rico): Council
<li>Day, Rufus S. Jr. - IPPF (Brush Foundation): Treasurer; Governing Body; Executive Committee; Convener, Constitution Committee; WHR (U.S.): Treasurer; Executive Committee; Council
<li>Dear, Jack - WHR (Barbados): Council
<li>De Lopez, Lola V. - WHR (El Salvador): Council
<li>Del Toro, Enrique Campos - WHR (Puerto Rico): Council
<li>Durand-Wever, Anne Marie - IPPF (Pro-Familia): Council; Governing Body
<li>Evang, Karl - IPPF (Norway) - Council (Co-opted member); Governing Body
<li>Farquharson, Gladys May - WHR (Jamaica): Council
<li>Ferguson, Frances Hand - IPPF (Planned Parenthood Federation of America): Regional Vice-President; Governing Body; WHR (U.S.): Vice-President; Executive Committee; Council
<li>Fernando, Constance - IPPF (Family Planning Association, Ceylon): Council; Governing Body; Regional Representative (Indian Ocean)
<li>Fisher, Jerome C.- IPPF (Brush Foundation): Treasurer; Governing Body; Executive Committee; WHR (U.S.): Treasurer; Executive Committee
<li>Foo, Mrs. Y. C. - IPPF (Federation of Malaya Family Planning Associations): Council; Governing Body
<li>Frazer, Simon M. - WHR (Bermuda): Vice-President; Executive Committee; Council
<li>Gamble, Clarence James - WHR (U.S.): Executive Committee
<li>Gasparro, Patricia - IPPF: Executive Secretary
<li>Goh, Sai Poh "Constance" Wee- IPPF (Family Planning Association, Singapore) - Vice-President; Council; Governing Body; Regional Representative (Far East and Australasia); Executive Committee
<li>Gonzales, Abraham Diaz - WHR (Puerto Rico): Council
<li>Gore, Sushila S. - IPPF (Family Planning Association of India): Council, Governing Body
<li>Griessemer, Thomas O. - IPPF (U.S.): Council; Governing Body; Executive Committee; Regional Representative (WHR); Convener, Constitution Committee; WHR (U.S.): Secretary; Executive Committee; Council
<li>Grove-White, Mary - IPPF (Family Planning Association, Singapore): Council; Governing Body
<li>Guttmacher, Alan F. - IPPF (Planned Parenthood Federation of America): Council; Governing Body; WHR (U.S.): Council; Executive Committee
<li>Harmsen, Hans - IPPF (Pro-Familia): Council; Governing Body; Executive Committee
<li>Hnatek, Ladislav - IPPF (Czechoslovakia): Council (Co-opted member); Governing Body
<li>Houghton, Vera - IPPF: Executive Secretary; Governing Body
<li>Hutson, Frank C. - IPPF (Barbados Family Planning Association): Council; Governing Body; WHR (Barbados): Vice-President; Executive Committee; Council
<li>Ingersoll, Marion Crary - WHR (U.S.): Council; Executive Committee
<li>Inayatullah, Attiya - IPPF (Family Planning Association of Pakistan): Council; Governing Body
<li>Jackson, Lawrence Nelson - IPPF (England): Editor, Around the World News of Population and Birth Control; Governing Body; Executive Committee; Convener, Editorial Committee
<li>Jackson, Margaret C. N.- IPPF (Family Planning Association of England): Convener, Evaluation Sub- Committee
<li>Jacobs, Elizabeth - IPPF (Jamaica Family Planning Association): Regional Vice-President; Governing Body; WHR (Jamaica): President; Council; Executive Committee
<li>Jacobs, Lentworth - IPPF (Jamaica Family Planning Association): Council; Governing Body; WHR (Jamaica): Vice-President; Executive Committee; Council
Jacobsen, Charles - IPPF (Foreningen for Familieplanlaegning, Denmark): Council; Governing Body
<li>Janer, Jose L.- IPPF (Puerto Rico): Council (Co-opted member); Governing Body; WHR (Puerto Rico): Council; Executive Committee
<li>Jolly, Elizabeth Maude - IPPF (Family Planning Association of Hong Kong): Council; Governing Body
<li>Johnson, Winifred - WHR (Trinidad): Council
<li>Kabir, A. M. A. - IPPF (Family Planning Association of Pakistan): Council; Governing Body
<li>Kacprzak, Marcin - IPPF (Poland): Council (Co-opted member); Governing Body
<li>Karunaratne, W. A. - IPPF (Family Planning Association of Ceylon) - Council; Governing Body
<li>Kato, Baroness Shidzue Ishimoto - IPPF (Family Planning Federation of Japan): Regional Vice-President; Governing Body
<li>Kaufman, Alvin R. - WHR (Canada): Council
<li>Kennedy, Anne - WHR (Haiti): Council; Executive Committee
<li>Khan, N. H. A. - IPPF (Pakistan): Council (Co-opted member); Governing Body
<li>Khosla, R. N. - IPPF (Family Planning Association, Punjab): Regional Vice-President; Governing Body
<li>Koya, Yoshio - IPPF (Family Planning Federation of Japan): Regional Vice-President; Governing Body; Executive Committee
<li>Kubo, Hideshi - IPPF (Family Planning Association of Japan): Council; Governing Body
<li>Leghari, A. M. K. - IPPF (Family Planning Association of Pakistan): Council; Governing Body
<li>Levine, Lena - WHR (U.S.): Council; Executive Committee
<li>Levy, Roy - IPPF (Jamaica Family Planning Association): Council; Governing Body; WHR (Jamaica): Council; Executive Committee
<li>Lim, Maggie - IPPF (Family Planning Association, Singapore): Council; Governing Body
<li>Liong, Rose Lee Hah - IPPF (Family Planning Association of Hong Kong): Regional Vice-President; Governing Body; Council
<li>Livingston, Eve - WHR (Jamaica): Council
<li>Lunn, Joan - IPPF (Family Planning Association of New Zealand): Council; Governing Body
<li>Macias, Gonzalo Blanco - WHR (Mexico): Council
<li>Mahabir, Dorothy - WHR (Trinidad): Council
<li>Mathan, Mrs. A. - IPPF (Family Planning Association of India):Council; Governing Body.
<li>May, Laurie - IPPF: Assistant to Executive Secretary.
<li>Mehlan, K. H. - IPPF (East Germany): Council (Co-opted member); Governing Body
<li>Mendoza, Ofelia -WHR: Field Director
<li>Menon, Lakshmi N.- IPPF (India): Council (Co-opted member); Governing Body
<li>Meza, Maria De R. - WHR (Mexico): Council
<li>Moore, Hugh - IPPF (U.S.): Council (Co-opted member); Governing Body; WHR (U.S.): Council; Executive Committee
<li>Morain, Mary - WHR (U.S.): Council
<li>Morrison, Joan - IPPF (South Africa National Council for Maternal and Family Welfare): Council; Governing Body
<li>Mukerjee, Radhakamal - IPPF (India): Council (Co-opted member); Governing Body
<li>Oram, Harold L. - WHR: Consultant
<li>Ottesen-Jensen, Elise - IPPF (Riksförbundet für Sexuell Upplysning, Sweden): President; Regional Vice- President; Governing Body; Executive Committee
<li>Parkes, A. S. - IPPF (England): Convener, Research Committee
<li>Peers, Rotha - IPPF (Family Planning Association of England): Council; Governing Body; Regional Representative (Europe, Near East and Africa); Secretary, Medical Sub-Committee
<li>Phadke, G. M. - IPPF (Family Planning Association of India): Council; Governing Body
<li>Pillsbury, Eleanor Bellows - IPPF (Planned Parenthood Federation of America): Vice-President; Governing Body; Executive Committee; Regional Representative (Americas/Western Hemisphere); Convener, Credentials Committee; WHR (U.S.) Vice-President; Chairman,
Executive Committee; Council
<li>Pilpel, Harriet F. - WHR (U.S.): Executive Committee
<li>Ponce, Tegualda - WHR (Chile): Council
<li>Pyke, Margaret A. - IPPF (Family Planning Association of England): Council; Governing Body; Executive Committee; Administrative Chairman, Management and Planning Committee; Convener, Nomination Committee
<li>Qadir, Manzoor - IPPF (Family Planning Association of Pakistan): Council; Governing Body
<li>Raisman, Sir Jeremy - IPPF (England): Treasurer; Governing Body; Executive Committee
<li>Rama Rau, Lady Dhanvanthi - IPPF (Family Planning Association of India): Honorary President; Chairman; Governing Body; Executive Committee
<li>Ramos, Rafael Menendez - IPPF (Asociaci¢n Puertorrique¤a pro Bienestar de la Familia): Council; Governing Body; WHR (Puerto Rico):
President; Vice-President; Executive Committee; Council
<li>Rao, Devi Krishna - IPPF (Family Planning Association of India): Council; Governing Body; Executive Committee; Regional Representative (Indian Ocean)
<li>Raphael, Nancy - IPPF (Family Planning Association of England): Council; Governing Body; Executive Committee; Regional Representative (Europe, Near East and Africa)
<li>Rettie, Joan - IPPF (Family Planning Association of England): Council; Governing Body; Regional Representative (Europe, Near East and Africa)
<li>Rice-Wray, Edris - WHR (Puerto Rico): Council
<li>Rizk, Hanna - IPPF (Egypt): Council (Co-opted member); Governing Body
<li>Robins, Sylvia - WHR (Aruba): Council
<li>Sanger, Margaret - IPPF (Margaret Sanger Research Bureau): President; Founder; Honorary President; Governing Body; Executive
Committee; WHR (U.S.): President; Executive Committee; Council
<li>Scott, Ursula - IPPF (South African National Council for Maternal and Family Welfare): Council; Governing Body
<li>Senior, Clarence - WHR (U.S.): Vice President, Executive Committee; Council
<li>Sheridan, Pamela - IPPF (Family Planning Association of England): Council; Governing Body
<li>Sheth, A. U. - IPPF (Family Planning Association of Kenya): Council (Co-opted member); Governing Body
<li>Shimojo, Yasumaro - IPPF (Family Planning Federation of Japan): Council; Governing Body
<li>Shirodkar, V. N. - IPPF (Family Planning Association of India): Council; Governing Body
<li>Sivapragasam, T. - IPPF (Federation of Malaya Family Planning Associations): Council (Co-opted member); Governing Body
<li>Sjovall, Elisabet - IPPF (Riksf”rbundet für Sexuell Upplysning, Sweden): Council; Governing Body; Executive Committee
<li>Sjovall, Thorsten - IPPF (Riksf”rbundet für Sexuell Upplysning, Sweden): Council; Governing Body
<li>Sodhy, L. S. - IPPF (Federation of Malaya Family Planning Associations): Council; Governing Body
<li>Stone, Abraham - IPPF (Margaret Sanger Research Bureau): Regional Vice-President; Governing Body; Executive Committee; WHR (U.S.): Council; Executive Committee
<li>Sunnen, Joseph - WHR (U.S.): Council
<li>Swaab, L. I. - IPPF (Nederlandse Vereniging Voor Sexuele Hervorming): Council; Governing Body
<li>Swingler Joan - - IPPF: Executive Secretary
<li>Tewson, Lady - IPPF (Family Planning Association of England): Council; Governing Body
<li>Tietze, Christopher - IPPF (Planned Parenthood Federation of America): Convener, Field Trials Sub- Committee; WHR (U.S.): Council; Executive Committee
<li>Tree, Ronald - WHR (Barbados): Council; Executive Committee
<li>Van Huet, P. A. - IPPF (Nederlandse Vereniging Voor Sexuele Hervorming): Council; Governing Body; Executive Committee
<li>Van Vleck, Joseph Jr. - IPPF (Planned Parenthood Federation of America): Council; Governing Body; WHR (U.S.): Vice-Chairman, Executive Committee; Council
<li>Vejabul, Pierra - IPPF (Family Planning Association of Thailand): Council (Co-opted member); Governing Body
<li>Victor, Rene - WHR (Haiti): Council
<li>Vogt, William - IPPF (Planned Parenthood Federation of America): Council; Governing Body; Chairman, Program Committee; WHR (U.S.): Council; Executive Committee
<li>Von Renthe-Fink, Barbara - IPPF (Pro-Familia): Council; Governing Body
<li>Wadia, Avabai B. - IPPF (Family Planning Association of India): Regional Vice-President; Governing Body; Executive Committee
<li>Waheed, Saida - IPPF (Family Planning Association of Pakistan): Regional Vice-President; Governing Body; Executive Committee
<li>Walmsley, Lewis C. - WHR (Canada): Council
<li>Waterman, J. A. - WHR (Trinidad): Vice-President; Executive Committee; Council
<li>Watumull, Ellen Jensen - IPPF (Watumull Foundation/Hawaii/U.S.): Assistant to the President; Council (Co-opted member); Governing Body; Executive Committee; WHR (Hawaii/U.S.): Council
<li>Weir, Roslyn M. - WHR (U.S.): Council; Executive Committee
<li>Whyte, G. Aird - IPPF (Eugenics Society): Treasurer; Governing Body; Executive Committee
<li>Wilkinson, Henry - WHR (Bermuda) : Council
<li>Wright, Helena Lowenfeld - IPPF (Family Planning Association of England): Council, Governing Body; Chairman, Medical Committee and Medical Sub-Committee
<li>Yang, Jae-Mo - IPPF (Planned Parenthood Federation of Korea): Council; Governing Body
<li>Zalduondo, Celestina - WHR (Puerto Rico): Council
</ul>
</p>
<h2>Related Sources</h2>

<p>The Collected Documents Series contains a considerable amount of material on the IPPF drawn from the IPPF collection located at the University of Cardiff's Population Centre including correspondence, reports, minutes, and other material. The Smith College Collections Series contains a large amount of material on the IPPF Western Hemisphere Region, as well as considerable documentation of the IPPF, including minutes, reports, organizational memos, constitutions and other materials. It also includes a large amount of material on the international conferences. Both the Collected Documents and Smith College Collections Series include extensive correspondence between Sanger and IPPF officers and members, particularly Vera Houghton, C. P. Blacker, Elise Ottesen-Jensen, Dhanvanthi Rama Rau, Clarence Gamble, Thomas Griessemer and Ellen Watumull, among others. Several membership lists, directories, and some correspondence were not included in this edition, but are available to researchers in the Sophia Smith Collection at Smith College. The Library of Congress microfilm contains very little documentation on the international movement, except for some scattered correspondence, PPFA materials related to international work, and records of the 3rd, 4th and 5th international conferences. For a concise history of the early years of the IPPF see Beryl Suitters, (London, 1973).</p>

<p><b>For other organizations involved with the IPPF, see:</b>
<ul class="thin-indent">
<li>ICPP for records of the previous international organization
<li>PPFA for records related to international work 
<li>MSRB for records related to international work
<li>WPEC for records related to the IPPF Western Hemisphere Region and IPPF funding
</ul>
</p>

<p><b>For conferences related to the IPPF or sponsored by the IPPF, see:</b>
<ul class="thin-indent">
<li>1952 3rd International Conference on Planned Parenthood
<li>1953 4th International Conference on Planned Parenthood
<li>1955 1st Western Hemisphere Conference on Population Problems and Family Planning
<li>1955 5th International Conference on Planned Parenthood
<li>1957 Proposed 6th International Conference on Planned Parenthood
<li>1959 6th International Conference on Planned Parenthood
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>About Sanger</h1>
		<div id="subnav">
			<a href="../aboutms/index.php">Biographical Sketch</a><br>
			<b><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></b><br>
			<a href="../aboutms/sanger_archive.php">The Sanger Archive</a><br>
			<a href="../aboutms/ms_writings.php">Sanger's Writing</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
