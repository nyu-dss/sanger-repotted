
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / About Sanger / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger" class="selected">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>Birth Control Federation of America</h1>
<h2>History</h2>

<p> The Birth Control Federation of America (BCFA) was established on January 19, 1939 through a merger of the  American Birth Control League (ABCL) and the  Birth Control Clinical Research Bureau (BCCRB). The reorganization into the BCFA was negotiated in meetings of a joint committee of representatives from both organizations. The committee concluded that only through united action and cooperative use of resources, rather than competition and duplication of services and publicity would they achieve efficiency in administration and broader acceptance of the birth control movement. At a special membership meeting held on January 29, 1942 the BCFA changed its name to the Planned Parenthood Federation of America (PPFA).</p>

<p>Through the work of its various departments, the BCFA supported birth control activities throughout the United States. It distributed contraceptive information to clinics, conducted laboratory and clinical research in contraceptive methods (primarily through the BCCRB), supported state committees and leagues, and promoted the inclusion of courses on contraceptive techniques in medical school curricula. In addition, the BCFA lobbied to have contraceptive services included in existing public health programs, and lobbied for legislation favorable to the increased availability of contraceptives. The Federation also managed several rural health projects, including a Negro Project in the South, carried out with the support of many prominent black leaders.</p>

<p>The BCFA marked the first time in the birth control movement that men held nearly all of the major leadership positions. Relegated to a limited role as honorary chairman of the BCFA, Margaret Sanger was not closely involved in most policy decisions or in the daily activities of this organization. However, she did serve as an advisor, chief fund-raiser and frequent gadfly, opposing the leadership of the Federation on many occasions.</p>

<h2>Organizational Structure</h2>

<p><b>Affiliates (Members):</b><br>
State member organizations and local groups whose purposes and activities were consistent with the Federation. Members were accepted or rejected by the Federation's Board of Directors. Each member affiliate supplied a representative who served on the Board of Directors. The Federation supplied affiliates with educational material, program proposals, advisory services, and arranged for field worker visits.</p>

<p><b>Board of Directors:</b><br>
State representatives and directors-at-large. The Board elected the Executive Committee, developed national policies, and supervised all facets of the organization.</p>

<p><b>Clinic Service Department:</b><br>
In association with the Medical Department assisted clinics in improving medical standards, certified clinics, and issued a directory of clinics and clinical services in the United States and Canada; oversaw the Mother's Advice Department which answered approximately 1,000 "client letters" annually.</p>

<p><b>Executive Committee:</b><br>
The president, national director, honorary chairman, chairman of the board, chairmen of operating committees, and selected members of the Board of Directors. The Committee was responsible for the daily operations of the Federation.</p>

<p><b>Extension Department:</b><br>
In addition to managing rural health projects that were started in 1938 by the BCCRB primarily for the purpose of distributing a new foam powder contraceptive, the Extension Department also administered the Negro Project, and a project to distribute birth control information to migrant families in the West.</p>

<p><b>Medical Department:</b><br>
Assisted clinics in meeting medical standards and helped secure medical supplies for rural health projects; distributed medical literature and films for its teaching programs; conducted laboratory and clinical research.</p>

<p><b>National Advisory Council:</b><br>
Group of prominent citizens organized to advise the Federation and improve the public perception of birth control.</p>

<p><b>National Committee on Planned Parenthood</strong> (Also Citizens Committee on Planned Parenthood):</b><br>
Group of BCFA members from across the nation organized to conduct a national fundraising campaign. Its members included more than 1,100 leaders in religion, medicine, education, literature, and public affairs.</p>

<p><b>National Medical Council on Birth Control:</b><br>
An advisory group consisting of medical doctors from around the country.</p>

<p><b>Negro Project:</b><br>
A project of the Extension Department, in cooperation with the Medical, Public Information, and Regional Organization Departments. The Negro Project was supervised by a special committee that included Margaret Sanger, Mary Lasker, and Clarence Gamble. It was guided by a national Negro Advisory Council made up of representatives of 25 major black organizations and universities, and included many prominent black leaders. With the help of local community organizations the Negro Project assembled clinical data to influence the adoption of clinics and contraceptive techniques primarily in the black communities of the South. The Negro Project managed two demonstration projects in Nashville, Tennessee and Berkeley County, South Carolina.</p>

<p><b>Public Information Department:</b><br>
Mounted exhibits; issued press releases; distributed films, press and magazine articles and various educational literature; acted as clearing house of information on contraceptive research; continued publication of The Birth Control Review (previously published by ABCL and discontinued by the BCFA in 1939), and the monthly publication of The Journal of Contraception (previously published by the BCCRB from 1935 through March of 1939) which was renamed Human Fertility in 1940; and maintained a Speaker's Bureau.</p>

<p><b>Public Progress Committee:</b><br>
A committee that organized letter writing campaigns in response to actions by public health officials and politicians as well as publications and coverage of birth control in the press.</p>

<p><b>Regional Organization Department:</b><br>
Involved primarily in educational activities throughout the United States. It launched a general campaign to extend the practice of birth control by expanding local committees and clinics, and organizing state leagues.</p>

<p><b>Staff:</b><br>
A National director, assistants to the director, office manager, comptroller and secretaries. The national director was responsible for developing and administrating the program, and for much of the fund-raising. Officers included a president, vice presidents, a secretary and a treasurer.</p>

<h2>BCFA Staff, Officers, Board and Committee members</h2>

<p>Names of Board members who served as State Representatives are followed by their state.</p>

<p><ul class="thin">
<li>    Abrams, Ray H. - Board of Directors (Pennsylvania)
<li>    Armstrong, Mrs. Benjamin - Board of Directors (New Hampshire)  
<li>    Atkinson, Dorothy B. - Board of Directors (Minnesota)  
<li>    Babcock, Caroline Lexow - Executive Committee; Board of Directors  
<li>    Bailey Jr., Mrs. Jennings - Board of Directors (Maryland)  
<li>    Bangs, Catherine Clement - Executive Committee; Board of Directors  
<li>    Barclay, Elizabeth M. - Board of Directors  
<li>    Barker, Marian B. - Board of Directors  
<li>    Barnes, Janet W. - Executive Committee; Board of Directors  
<li>    Barstow, Rev. Robbins W. - Board of Directors (Connecticut)  
<li>    Berger, Rebecca - Administrative Staff  
<li>    Bingham, Barry - Board of Directors  
<li>    Bladgen, Mabel Whitney - Board of Directors  
<li>    Blodgett, Marguerite - Secretary; Associate Treasurer; Board of Directors  
<li>    Blodgett, Stephen W. - Executive Committee; Board of Directors  
<li>    Bond, Mrs. Wilbert W. - Board of Directors (Iowa)  
<li>    Breakey, Judith J. - Board of Directors (Michigan)  
<li>    Brooks, Christina - Administrative Staff  
<li>    Brown, Mrs. William Thayer - Executive Committee; Board of Directors (New York)  
<li>    Browne, Mrs. Virgil - Board of Directors (Oklahoma)  
<li>    Brush, Dorothy Hamilton - Board of Directors  
<li>    Burge, Mrs. Joseph D. - Board of Directors (Kentucky)  
<li>    Campbell, Lorraine Leeson - Board of Directors (Massachusetts)  
<li>    Carpenter, Helen Graham Fairbank - Board of Directors (Illinois)  
<li>    Chaffee, Mrs. Thomas K. - Board of Directors (Rhode Island)  
<li>    Clement, Mrs. Hugh - Board of Directors (Vermont)  
<li>    Clyde, Ethel - Board of Directors  
<li>    Cole, William E. - Board of Directors (Tennessee)  
<li>    Colgate, Gilbert - Treasurer; Executive Committee; Board of Directors  
<li>    Conrad, Elmira - Director, Clinic Service Department  
<li>    Creadick, A. N. - Board of Directors  
<li>    Cushman Jr., Mrs. Arthur - Executive Committee; Board of Directors  
<li>    De Beck, Mrs. William - Board of Directors (Florida)  
<li>    Delafield, Mrs. Edward C. - Board of Directors  
<li>    DeRham, Edith Colby - Board of Directors  
<li>    DeRham, Henry L. - Board of Directors  
<li>    Dickinson, Robert Latou - Vice President  
<li>    Downs, Mrs. Ellason - Board of Directors  
<li>    Fairchild, Henry Pratt - Vice President  
<li>    Fuld, Carrie B. F. - Board of Directors  
<li>    Gamble, Clarence James - Executive Committee; Board of Directors  
<li>    Garver, Chauncey B. - Board of Directors  
<li>    Goldberg, Ruth - Comptroller  
<li>    Goldstein, Rabbi Sidney E. - Board of Directors  
<li>    Groves, Ernest R. - Board of Directors  
<li>    Hammond, Mrs. John Henry - Board of Directors  
<li>    Harris, Muriel Bent - Board of Directors (Illinois)  
<li>    Hawkridge, Linda M. - Board of Directors (Massachusetts)  
<li>    Hegeman, Mrs. Coles - Board of Directors (Rhode Island)  
<li>    Holden, Frederick C. - Vice President; Executive Committee; Board of Directors  
<li>    Howells, Abbey White - Board of Directors  
<li>    Huse, Penelope B. P. - Administrative Staff  
<li>    Ilsley, Mrs. Robert G. - Board of Directors (New Jersey)  
<li>    Iselin, Mrs. O'Donnell - Board of Directors  
<li>    Johnson, Mary Compton - Administrative Staff  
<li>    Jones, Eleanor Dwight - Board of Directors  
<li>    Kahn, Addie Wolff - Board of Directors  
<li>    Kinsolving, Rev. Arthur B. - Board of Directors  
<li>    Kirk, Mrs. Arthur S. - Board of Directors (Iowa)  
<li>    Lamont, Elinor P. - Executive Committee; Board of Directors  
<li>    Lamont, Florence Haskell Corliss - Board of Directors  
<li>    Lasker, Mary Reinhardt - Secretary; Executive Committee; Board of Directors  
<li>    Lawrence, George H. - Board of Directors (North Carolina)  
<li>    Lewis, Morris - Acting Director, Public Information Department  
<li>    Lindabury, Mrs. Richard H. - Board of Directors (New Jersey)  
<li>    Lipman, Julia Austin - Board of Directors (California)  
<li>    Little, Clarence Cook - Vice President; Chairman, Advisory Council; Board of Directors  
<li>    Madden, Jane - Administrative Staff  
<li>    Mali, Katharine - Chairman, Regional Organization Committee; Executive Committee; Board of Directors  
<li>    Marsh, Charlotte Delafield - Board of Directors  
<li>    May, Isidore - Board of Directors (West Virginia)  
<li>    McClintock, Beatrice - Executive Committee; Board of Directors  
<li>    McPheeters, Mrs. Samuel B. - Board of Directors (Missouri)  
<li>    Moore, Allison Pierce - Executive Committee; Board of Directors  
<li>    Morrell, Dorothea - Administrative Staff  
<li>    Morris, Woodbridge E. - General Director; Director, Medical Department  
<li>    Nelms, Agnese Carter - Board of Directors (Texas)  
<li>    Noble, Mrs. Charles - Board of Directors (Michigan)  
<li>    Offutt, Mrs. Casper - Board of Directors (Nebraska)  
<li>    Pease, Sally - Board of Directors (Connecticut)
<li>    Pfeifer Jr., Mrs. Harry - Board of Directors (Arkansas)  
<li>    Philbin, Mrs. Stephen H. - Board of Directors
<li>    Pierson, Richard N. - President; Chairman, Medical Committee; Executive Committee; Chairman of the Board of Directors  
<li>    Plunkett, F. O. - Board of Directors (Virginia)  
<li>    Potter, Rose - Executive Committee; Board of Directors  
<li>    Preston, Mrs. William P. T. - Board of Directors  
<li>    Rassieur, Mrs. George - Board of Directors (Missouri)  
<li>    Ripley, Katie Rice - Board of Directors
<li>    Rose, D. Kenneth - Executive Vice President; National Director  
<li>    Rose, Florence - Public Information Department/Extension Department; Administrative Staff  
<li>    Rosenthal, Mrs. Moritz - Board of Directors  
<li>    Ross, Lida - Board of Directors (Tennessee)
<li>    Rothschild, Carola Warburg - Board of Directors  
<li>    Rublee, Juliet Barrett - Board of Directors  
<li>    Sanger, Margaret - Honorary Chairman; Executive Committee; Board of Directors  
<li>    Schiff, Mrs. John M. - Board of Directors  
<li>    Scribner, Charles Edwin - Board of Directors  
<li>    Shaw, Mrs. Earl - Board of Directors (North Dakota)  
<li>    Sheldon, Mrs. Charles - Board of Directors (Vermont)  
<li>    Shepard, Mrs. Frank P. - Board of Directors  
<li>    Simon, Caroline K. - Administrative Staff  
<li>    Small, Mrs. Deane - Board of Directors (Maine)  
<li>    Smith, Charles M. - Director, Public Information Department  
<li>    Stone, Abraham - Executive Committee; Board of Directors  
<li>    Stone, Hannah Mayer - Board of Directors  
<li>    Suarez, Evelyn - Executive Committee; Board of Directors  
<li>    Taylor, Jeanette J. - Executive Committee; Board of Directors
<li>    Thorpe, Helen - Board of Directors  
<li>    Tilton, Benjamin T. - Board of Directors  
<li>    Timme, Ida Haar - Board of Directors  
<li>    Tompkins, Jean Burnet - Board of Directors  
<li>    Trent, Kathryn - Director, Regional Organization Department  
<li>    Tweed, Harrison - Board of Directors  
<li>    Upson, William Hazlett - Board of Directors (Vermont)  
<li>    Ustick, Mrs. Laurence - Board of Directors (Pennsylvania)  
<li>    Vanderbilt, Anne - Board of Directors  
<li>    Walker, C. Lester - Chairman, Public Information Committee; Executive Committee; Board of Directors  
<li>    Ware, H. Hudnall - Board of Directors (Virginia)  
<li>    Wile, Ira Solomon - Executive Committee; Board of Directors  
<li>    Willson, Edith E. - Board of Directors (District of Columbia)  
<li>    Wilson, Mrs. Harry - Board of Directors (Indiana)  
<li>    Winslow, C. E. A. - Vice President; Board of Directors  
<li>    Wood, Mabel Travis - Administrative Staff  
<li>    Wood, Mrs. Willis D. - Board of Directors  
<li>    Woodbury, Mrs. Peter - Board of Directors (New Hampshire)  
<li>    Worthington, Clara C. - Board of Directors (Delaware)  
<li>    Wright, Cele Damon - Assistant to the Director  
<li>    Zukoski, Bernadine - Board of Directors (Alabama)
</ul>
</p>

<h2>Related Sources</h2>

<p>The <a href="../../publications/collected_documents.php">Collected Documents Series</a> includes minutes, reports, publications and policy statements. Both the <a href="../../publications/smith_series.php">Smith College Collections Series</a> and the <a href="../../publications/library_of_congress.php">Library of Congress microfilm</a> hold substantial materials on the BCFA, including minutes, reports, organizational memos, publications and form letters. The Library of Congress microfilm also contains BCFA state and subject files, and miscellaneous printed material. Additional BCFA reports, third-party correspondence and other materials that were not included in this edition are available at the Sophia Smith Collection, Smith College.</p>

<p><b>For other organizations involved with the BCFA, see</b>:
<ul class="thin-indent">
<li>Joint Committee ABCL and BCCRB for records related to the merger<br />
<li>BCCRB for records related to clinical services and laboratory research<br />
<li>PPFA for records of the organization after the name change in 1942<br />
</ul>
</p>

<p><b>For conferences sponsored by the BCFA see</b>:
<ul class="thin-indent">
<li>1939 Southern Conference on Tomorrow's Children<br />
<li>1941 BCFA Conference
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>About Sanger</h1>
		<div id="subnav">
			<a href="../aboutms/index.php">Biographical Sketch</a><br>
			<b><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></b><br>
			<a href="../aboutms/sanger_archive.php">The Sanger Archive</a><br>
			<a href="../aboutms/ms_writings.php">Sanger's Writing</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
