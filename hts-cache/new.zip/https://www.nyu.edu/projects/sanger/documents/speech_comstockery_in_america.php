
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Documents Online / Selected Writings</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online" class="selected">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Selected Writings</h1>
<div class="maintext">
<h2>"COMSTOCKERY IN AMERICA"
<br />By Margaret H. Sanger</h2>

<p align="left">  [<span class="italicText">July 1915</span>]<br />

</p>

<p align="left"> There is nothing which causes so much laughter or calls forth so many joking comments by people in Europe as Comstockery in America. Our English cousins have a vague idea of its intricacies but the Latin mind, either Italian, French or Spanish, cannot grasp the idea of its existence.<br />

<br />

America stands in the eyes of the younger generations of the various countries of Europe as a great hope and inspiration for the development of a free race. What, then, is their surprise and disappointment to learn that an American woman, born on American soil, must leave the "land of the free and home of the brave" to escape imprisonment for discussing the subject of Family Limitation.<br />

<br />

When the Latin hears this he storms and rages and asks where the integrity of manhood has gone, that it will allow such an infringement on one's personal liberty.<br />

<br />

But the English calmly shake their heads and tell you that the same issue was fought out in London in 1877 when Annie Besant and Charles Bradlaugh braved the courts and won freedom in their cause for British subjects for all time. They will tell you they sympathize, but can do little to help you, for the place to fight "Comstockery in America" is in America.</p>

<p align="left"> There is no doubt of the truth of this assertion, so in order to fight Comstockery we must know who and what is behind it and put a strong searchlight on actions, which are considered by all classes of people throughout the civilized world as most contemptible and despicable.</p>

<p align="center"><br />

<br />

Comstock's influence.</p>

<p align="left"><br />

Anthony Comstock was born in 1844. He has been Secretary and Special Agent for the Society for the Suppression of Vice since 1873; also U. S. Post Office Inspector since the same year. He records that he has destroyed 160 tons of literature and brought 3,760 "criminals" to "justice" during these years.<br />

<br />

There is no doubt in the minds of thinking people that the influence of the Church in America has gradually been declining since the days of Robert Ingersoll and that today, as a power, it has almost entirely collapsed. But the relentless war which Ingersoll waged against the Church and the present-day power of Comstock are somewhat connected: the Church feeling its power<br />

going from it, through Ingersoll's influence, grasped at the straw held out to it by the Government, called the "Comstock laws." These were passed in 1873, and prohibit the sending of any matter through the mails which, in the opinion of Anthony Comstock, the Postal Authorities choose to call "obscene."<br />

<br />

Thus, the Church, hiding behind the closed doors of the suppression of Vice Society, works its timid and poisonous way through the Government via its special agent, Comstock.<br />

<br />

The passing of the Comstock laws in 1873 was designed to aid and abet both moral and religious prejudice and persecutions. This aroused the wrath of the free-thinking and liberty- loving populace, and in 1878 great agitation was aroused against these laws: a petition was presented to Congress, headed by the name of Robert G. Ingersoll and signed by 70,000 "freemen," requesting the repeal of these outrageous laws. They were passed and executed ostensibly to prevent the passage of obscene literature through the U. S. mails, but actually were designed and enforced to destroy the liberty of conscience and thought in matters of religion and against the freedom of the press.<br />

<br />

The petition caused great agitation and aroused so much interest that a few years later the law was revised, removing the interference of religious prejudice, but the moral interference was left and Anthony Comstock then became the official guardian of American morality.</p>

<p align="center"><br />

<br />

Persecutions.<br />

</p>

<p align="left"> Since that power was entrusted to Comstock, it was most natural that he should "make good" and give some evidence of the need of his special service.<br />

<br />

This he proves by sending out his minions of agents (Government spies) to tempt obscure booksellers to sell him a prohibited book. One case on record is of a father and son, running a book store in the lower East Side of New York City. The agents came again and again asking for a certain medical book. The father stated that he did not have it, and the agent then induced him to order one for him. The father, thinking there was a demand for the book, sent to the publisher and purchased a copy, which the Agent called for the following day, paid for it and turned around and arrested the bookseller. He was dragged off to court and was sentenced to one year in Blackwell's Island. The son was also fined, and as I have not the records here with me, I can not say if he was not also imprisoned.<br />

<br />

The case of Moses Harmon is familiar to all. This man of seventy years, residing in Chicago, editing the paper "Lucifer," in which he discussed birth control and kindred subjects, was arrested six or seven times, sentenced to imprisonment year after year,, always resuming the fight when he came from prison, until finally his health gave way through his sufferings and imprisonment,<br />

and he died, a victim of Comstock persecution.<br />

<br />

There have been many publications during these years which have been suppressed by the orders of Comstock, and the publisher imprisoned, but one of the latest, and most flagrant disregard of Press Freedom was in the suppression and confiscation of the monthly publication, "The Woman Rebel." This was a working woman's paper, the first of its kind ever issued in America. It had for its motto: "Working Women, build up within yourselves a conscious fighting character against all things which enslave you," and claimed that one of the working woman's greatest enslavements was her ignorance of the means<br />

to control the size of her family. The editor promised to defy the existing law and to impart such information to the readers of "The Woman Rebel" and urged all working women to rally to its support.<br />

<br />

The first issue in March, 1914, was suppressed. The May, July, August, September and October issues were suppressed and confiscated, and three indictments, on the March, May and July issues, covering twelve counts, were returned against me, as the editor, by the Federal Grand Jury. One of the counts against me was for an article called "Open Discussion." This was a<br />

discussion of the subject of birth control and was considered "obscene." Another was an article announcing the organization of The Birth Control League, setting forth its object and methods of organization. All the indictments were returned and counts were made on all articles which discussed the idea of the Working Woman keeping down the number of her family.</p>

<p align="left"><br />

"The Woman Rebel" did not advocate the practice of this knowledge as a "panacea" for the present economic enslavement, but it did urge the practice of it as the most important immediate step which should be taken toward the economic emancipation of the workers. Thousands of letters poured in to me from all over the country. I was besieged with requests for the information from all kinds and classes of people. Nearly every letter agreed with me that too long have the workers produced the slave class, the children for the mills, the soldiers for the wars, and the time had come to watch the masters produce their own slaves if they must have them. We know the capitalist class must have a slave class, bred in poverty and reared in ignorance. That is why it is quite consistent with their laws that there should be a heavy penalty of five years' imprisonment for imparting information as to the means of preventing conception. Industry in the U.S.A. is fairly new; it is reaching out in foreign lands to capture trade and to undersell its rival competitors. They have only one way to do this, and that is to get labor cheap. The cheapest labor is that of women and children; the larger the number of children in a family, the earlier they enter the factory. We need only to look to our mill towns to see the truth of this statement; to the conditions in the cotton mills of the South where little<br />

boys and girls, eight, nine and ten years of age, wend their sleepy way to the mills in the morning before the winter sun has risen, to work at a killing tension for twelve hours as helper to the mother, and return again when the sun has set.<br />

<br />

We, who know the conditions there, know that the father cannot get a man's wage, because a child's labor can be had. There is an average of nine children to every family in these and in other industrial sections where child labor exists and wages run low and infant mortality runs high.<br />

<br />

Many of the stockholders of these mills are legislators and congressmen who have to do with the making of the laws. Naturally it is to their interest that child slaves be born into the world and their duty is to enforce the laws to that end.<br />

<br />

"The Woman Rebel" told the Working Woman these things, and told her that a large family of children is one of the greatest obstacles in the way to obtain economic freedom for her class. It is the greatest burden to them in all ways, for no matter how spirited and revolutionary one may feel, the piteous cry of hunger of several little ones will compel a man to forego the future good of his class to the present need of his family.<br />

<br />

It is the man with a large family who is so often the burden of a strike. He is usually the hardest to bring out on strike, for it is he and his who suffer the most through its duration. Everywhere, in the shop, in the army of the unemployed, in the bread line where men are ready to take the place of a striker, it is the large family problem which is the chief of the multitudes of miseries confront the working class today.<br />

<br />

"The Woman Rebel" told the Working Woman that there is no freedom for her until she has this knowledge which will enable her to say if she will become a mother or not. The fewer children she had to cook, wash and toil for, the more leisure she would have to read, think and develop. That freedom demands leisure, and her first freedom must be in her right of herself over her own body; the right to say what she will do with it in marriage and out of it; the right to become a mother, or not, as she desires and sees fit to do; that all these rights swing around the pivot of the means to prevent conception, and every woman had the right to have this knowledge if she wished it.<br />

<br />

As editor and publisher of "The Woman Rebel," I felt a great satisfaction and inspiration in the response which came from working men and women all over America. For fourteen years I have been much in the nursing field, and know too well the intolerable conditions among the workers which a large family does not decrease.<br />

<br />

I saw that the working women ask for this knowledge to prevent bringing more children into the world, and saw the medical profession shake its head in silence at this request.</p>

<p align="left"> I saw that the women of wealth obtain this information with little difficulty, while the working man's wife must continue to bring children into the world she could not feed or clothe, or else resort to an abortion.<br />

<br />

I saw that it was the working class women who fill the death list which results from abortion, for though the women of wealth have abortions performed too, there is given them the best medical care and attention money can buy; trained nurses watch over them, and there is seldom any evil consequence. But the working woman must look for the cheapest assistance. The professional abortionist; the unclean midwives, the fake and quack -- all feed upon her helplessness and thrive and prosper on her ignorance. It is the Comstock laws which produce the abortionist and make him a thriving necessity while the lawmakers close their Puritan eyes.<br />

<br />

I saw that it is the working class children who fill the mills, factories, sweatshops, orphan asylums and reformatories, because through ignorance they were brought into the world, and this ignorance continues to be perpetuated.<br />

<br />

I resolved, after a visit to France, where children are loved and wanted and cared for and educated, to devote my time and effort in giving this information to women who applied for it. I resolved to defy the law, not behind a barricade of law books and technicalities, but by giving the information to the workers directly in factory and workshop.<br />

<br />

This was done by the publication of a small pamphlet, "Family Limitations," of which one hundred thousand copies were distributed in factories and mines throughout the U. S.<br />

<br />

When my case was called for trial I requested a postponement of three weeks to prepare it. The judge refused this, and not desiring to fritter away my time by these legal annoyances, which sap one's strength and unfit one for any useful work, I decided to take an indefinite postponement and left for London.<br />

<br />

While this work was being carried on in New York, William Sanger, my husband and comrade, was in Europe. At the outbreak of the war he returned, just as I was leaving. He knew nothing of my work or the Birth Control Movement.<br />

<br />

Nevertheless, in January, a man called at his studio, representing himself as a socialist and friend of mine, and asked for a pamphlet on "Family Limitations." Mr. Sanger at first refused it saying he had none, but after urgent pleading on the part of the supposed "comrade," Mr. Sanger went to my desk and found two, one of which he gave him. A few minutes later this "comrade" returned with Anthony Comstock, who arrested Mr. Sanger and searched his studio. He was placed under arrest and allowed to go out on bail.<br />

<br />

The trial came up in April, but the judge refused a jury trial, saying the pamphlet was "awful." (As author of the pamphlet, I will guarantee there was nothing in the "awful pamphlet" that Mr. Judge or Mr. District Attorney<br />

either had not discussed many times with their wives or with other men.)<br />

<br />

The Free Speech League have taken up Mr. Sanger's case, and are fighting for a jury trial. At the time of writing I do not know the outcome. Although I have been compelled to flee to a place of safety to carry out my work unmolested, when I have accomplished all that I intend to do, and say all that I desire to say on the birth control subject, and give all the means to prevent conception given in other countries, I shall return to America and resume my trial.</p>

<p align="left"> It is to be hoped that the American people will turn their eyes in the direction of the outrageous postal laws and fight them to a finish. Certainly the Constitution of the U. S. never intended that Congress should go beyond the duties of efficiency, when it was authorized to establish post-offices. It is certain that there was no intention that it should pass judgment on the moral qualities of the matter to be conveyed (any more than the intellectual or religious); it was intended and authorized to be an efficient mechanical institution, not a moral or religious one. The people of Ingersoll's day fought and won freedom from 

Government interference in religious thought. Can not the people of today win our and our children's freedom from its interference in moral thought?<br />

<br />

Comstockery must die! Education on the means to prevent conception and publicity on Comstock's actions is the surest weapon to strike the blow. When people have the knowledge to prevent conceptions then the law becomes useless and falls away like the dead skin of a snake.<br />

<br />

There is little doubt but that my return to America will mean a long term of imprisonment. But that will not stop the propaganda of Birth Control; there will ever be the glowing satisfaction that the authorities cannot imprison one's contempt for them, or deprive the workers of the knowledge they have already gained.</p>


</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Documents Online</h1>
		<div id="subnav">
			<a href="../documents/index.php">About</a><br>
			<b><a href="../documents/selected.php">Selected Writings</a></b><br>
			<a href="../documents/electroniced.php">Electronic Edition - Beta</a><br>
			<a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a><br>
			<a href="../documents/othersites.php">Documents on Other Sites</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
	