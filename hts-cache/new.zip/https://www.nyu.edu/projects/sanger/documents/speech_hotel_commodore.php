
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Documents Online / Selected Writings</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online" class="selected">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Selected Writings</h1>
<div class="maintext">
<h2>"HOTEL COMMODORE SPEECH"
<br />By Margaret H. Sanger</h2>

<p align="left"> "Birth Control will save the world from another and more devastating holocaust such as the great war which has left a continent in one vast stretch of want and misery. Enlightened minds every-where are seeing this, while the less awakened among the populations in all nations are speedily recognizing this great fact.<br />

<br />

"After six months study abroad of various countries from the point of view of birth control, I have returned with a stronger conviction than ever of the work we must do, of the responsibility that rests upon the shoulders of the American women engaged in furthering the ideals of humanity, of a better, stronger civilization, if we ever hope to attain that international reconstruction that will establish world peace.<br />

<br />

"Nor am I alone in this belief that it is the action of the women of this country that is needed for this. I am happy to be able today to bring you, to bring to the entire womanhood of America, a message and a plea from some of Europe's most distinguished scientists, diplomats, and economists. That message is:<br />

<br />

"We agree with the advocates of Birth Control, that not world peace is possible without a reduction of the birth rate and immediate action towards its international accomplishment."<br />

<br />

"The men and women who have asked me to bring this message to America for her own salvation are known to you all as the finest flower of intellectual, economic and scientific thought in England. They include Dean Inge, of St. Paul's Cathedral, London, Harold J. Cox, editor of the Edinburgh Review, ex. M.P. J.O. [<span class="italicText">Bland</span>] noted authority on Eastern subjects, formerly ambassador to Japan, Leonard Reese, editor of the London Sunday Times; Dr. Marie Stopes, famous paleontologist and biologist; Edith How Martin, candidate for Parliament and member of the county council of Middlesex; Sir Lyndob<br />

Macassy, K.C.; H.G. Wells and Arnold Bennett.</p>

<p> "Meanwhile, while Europe is solving this grave problem, what is America doing? We are breeding, breeding, breeding, excess numbers -- -- for what? For another condition like that of Europe in 1914, with its dingy overcrowded communities that sought in blood-shed an outlet and a relief from the tragedy of existence?<br />

<br />

"For unless we apply fundamental remedies to these conditions we will fast approach the same congested and confused state which may and is likely to produce an outburst of the same nature as the European struggle that in four years laid a world in ruin.</p>

<p> We shall come to find ourselves in the same position as Japan, of whom we read even in the most conservative press, the ominous portent of her over-whelming and rising tide of population. There are those who even prophesy that a war is looming anew because of Japan's struggle to support this overcrowded condition of society. There will be the same excuses as those of Germany for her aggressive efforts at conquest -- -- a place for her population -- -- but a second disaster will be infinitely more terrible and death-dealing.<br />

<br />

"Birth Control is the conscious voluntary regulation of the birth rate by scientific means that prevents conception. Birth Control has always been in operation. It dates back wellnigh to the beginning of time. We see in the study of Nature how she ruthlessly limits the population by famine, wars and pestilence. She sweeps the diseased, the weakling and the feebleminded to the wall with her great gestures that clean the world for the fit and the strong. But we will not allow nature to take her course. If we would, we would not have the state of society that we have today.<br />

<br />

"What does humanity do? We, with our ideas and with our humane consideration, we rescue the diseased, the feebleminded and the weaklings. We erect enormous institutions for them and fill them with their progeny. Our laws are all passed in support of the same blind system -- -- the effort to cure rather than to prevent.</p>

<p> "What are the conditions today in the world? Our institutions are bankrupt. Our people are dissatisfied with government -- -- distrustfull of hollow panaceas for the future. Our hospitals, orphan asylums, homes and other places set aside to house the weak, and the physically unfit, are crowded and stripped of their efficiency. Disease and weakness is crowding upon our the resources of the world. The leaders and thinkers are in a maze of confusion and no one knows what is going to happen next."<br />

<br />

"How are we going to meet these conditions? By legislation and palliative measures. We erect maternity and child welfare centers and exhaust human resources in trying to show the mother how to have more children that she does not want. We still continue in all our fields of endeavor to work a cure rather than a prevention. We ignore the fundamental ill of humanity -- -- overcrowding and increasing the weak -- -- we study conditions but make no effort to prevent the same conditions in the future.<br />

<br />

"These conditions are worldwide. I went to Germany for a short time primarily for the purpose of investigating the birth strike at Munich and to study the new preventive said to have been invented in 1914, but I remained to see much more. I found that the women are the real sufferers of the war. They have brought a population into existence today that is even larger than before the war. They are bowed down with</p>

<p> "The physicians and the scientists whom I interviewed are still afraid to trust women with preventive knowledge. But there is a growing group of scientists, economists and thinkers who have recognized that Germany must reduce her population. This is the hope of those broken people. They told me that they consider Birth Control the immediate salvation of Germany and that the country must cease to dream of world imperialism and trade conquests and devote itself to the development of art, science and philosophy.<br />

<br />

"Since there are no laws in Europe against giving preventive information I was able during my stay in England and Scotland to impart such information to more than 25,000 people, mainly women.</p>

<p> "These women are working women of the &lsquo;Women's Co-Operative Guild.' There has been great opposition to Birth Control on the part of labor leaders for the past forty years and I was amazed and delighted at the elemental urge that drove these women to my lectures by the thousands in spite of the enmity against it. When I left England to return to America I had invitations that would keep me on the lecture platform without rest for the next two years.</p>

<p> "Although I feel it was an achievement to have reached those thousands upon thousands of women who in turn will impart the information to thousands of others, to me that was not enough. I want clinics established in England as well as America.<br />

<br />

"I was able to bring together a remarkable group of people in England to work for Birth Control. They are drawn from the most advanced scientists, social workers and publicists in that country. Among them are:<br />

<br />

Harold Cox<br />

J.O.P. Bland<br />

Leonard Reese,<br />

Dr. Marie Stopes<br />

Edith How Martin<br />

Sir Lyndon Macassey.<br />

<br />

This committee asked me to present a program -- -- with a plan to cut the work in England. This plan was accepted. A clinic is to be established in London. Twenty field workers, nurses and social workers, are to be sent out to arouse the English people to the necessity of immediate action.<br />

<br />

"I have returned to America for six months to organize a similar group here, and to present a plan for co-operation with England. Let us, as English speaking people unite and work together in this great issue.<br />

<br />

"We cannot as occidentals, presume to ask the oriental races, of whom it is feared, will overrun the earth, to decrease their population while we encourage a high birth rate among ourselves.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Documents Online</h1>
		<div id="subnav">
			<a href="../documents/index.php">About</a><br>
			<b><a href="../documents/selected.php">Selected Writings</a></b><br>
			<a href="../documents/electroniced.php">Electronic Edition - Beta</a><br>
			<a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a><br>
			<a href="../documents/othersites.php">Documents on Other Sites</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
	