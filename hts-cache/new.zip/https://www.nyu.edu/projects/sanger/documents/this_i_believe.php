
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Documents Online / Selected Writings</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online" class="selected">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Selected Writings</h1>
<div class="maintext">

<h2>"THIS I BELIEVE"
<br />By Margaret H. Sanger</h2>

<p align="left">[<span class="italicText">November 1953</span>]<br /></p>

<p><img src="ms-50s.jpg" width="184" height="266" align="right" style="margin-left: 15px;">
Listen to an mp3 recording of Margaret Sanger's November 1953 <a href="Margaret_Sanger.mp3" target="_new">broadcast</a> on Edward R. Murrow's <em>This I Believe</em> radio program, provided to the Sanger Project by the <a href="http://www.npr.org/templates/story/story.php?storyId=4538138" target="_new2">National Public Radio</a>.  The text of the speech below comes from Margaret Sanger's Papers at the Library of Congress (130:620). Several earlier drafts of the speech appear on the Sanger microfilm, but this version is the closest to the one spoken by Sanger. </p>

<p><hr noshade size="1" /></p>

<p>
This I believe, first of all: that all our basic convictions must be tested and transmuted in the crucible of experience&ndash;and sometimes, the more bitter the experience, the more valid the purified belief.<br />
</p>
<p>As a child, one of a large family, I learned that the thing I did best was the thing I liked to do. This realization of doing and getting results was what I have later called an awakening consciousness.</p>
<p>
There is an old Indian proverb which has inspired me in the work of my adult life. &ldquo;Build thou beyond thyself, but first be sure that thou, thyself, be strong and healthy in body and mind.&rdquo; To build, to work, to plan to do something, not for yourself, not for your own benefit, but &ldquo;beyond thyself&rdquo;&ndash;and when this idea permeates the mind, you begin to think in terms of a future. I began to think of a world beyond myself when I first took an interest in nursing the sick.</p>
<p>
As a nurse, I was in contact with the ill and the infirm. I knew something about the health and disease of bodies, but for a long time, I was baffled at the tremendous personal problems of life, of marriage, of living, and of just being. Here indeed was a challenge to &ldquo;build beyond thyself.&rdquo; Where was I to begin? I found the answer at every door. For I began to believe there was something I could do toward increasing an understanding of these basic human problems. To build beyond myself, I must tap all inner resources of stamina and courage, of resolution within myself. I was prepared to face opposition, even ridicule, denunciation. But I had also to prepare myself, in defense of these unpopular beliefs, I had to prepare myself to face courts and even prisons. But I resolved to stand up, alone if necessary, against all the entrenched forces which opposed me.
</p>
<p>I started my battle some forty years ago. The women and mothers whom I wanted to help, also wanted to help me; they, too, wanted to build beyond the self, in creating healthy children and bringing them up in life to be happy and useful citizens. I believed it was my duty to place motherhood on a higher level than enslavement and accident. I was convinced we must care about people; we must reach out to help them in their despair.
</p>
<p>For these beliefs I was denounced, arrested, I was in and out of police courts and higher courts, and indictments hung over my life for several years. But nothing could alter my beliefs. Because I saw these as truths, I stubbornly stuck to my convictions.
</p>
<p>No matter what it may cost in health, in misunderstanding, in sacrifice, something had to be done, and I felt that I was called by the force of circumstances to do it. Because of my philosophy and my work, my life has been enriched and full. My interests have expanded from local conditions and needs, to a world horizon, where peace on earth may be achieved when children are wanted before they are conceived. A new conciousness will take place, a new race will be born to bring peace on earth. This belief has withstood the crucible of my life&rsquo;s joyous struggle. It remains my basic belief today.
</p>
<p>This I believe&ndash;at the end, as at the beginning of my long crusade for the future of the human race.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Documents Online</h1>
		<div id="subnav">
			<a href="../documents/index.php">About</a><br>
			<b><a href="../documents/selected.php">Selected Writings</a></b><br>
			<a href="../documents/electroniced.php">Electronic Edition - Beta</a><br>
			<a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a><br>
			<a href="../documents/othersites.php">Documents on Other Sites</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
	