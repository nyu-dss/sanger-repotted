
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Documents Online / Selected Writings</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online" class="selected">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Selected Writings</h1>
<div class="maintext">
<h2>"WOMAN'S ERROR AND HER DEBT"
<br />By Margaret H. Sanger</h2>

<p align="left">[<span class="italicText">August 1921</span>]<br />

</p>

<p> The most far-reaching social development of modern times is the revolt of woman against sex servitude. The most important force in the remaking of the world is a free motherhood. Beside this force, the elaborate international programmes of modern statesmen are weak and superficial. Diplomats may formulate leagues of nations and nations may pledge their utmost strength to maintain them, statesmen may dream of reconstructing the world out of alliances, hegemonies and spheres of influence, but woman, continuing to produce explosive populations, will convert these pledges into the proverbial scraps of paper; or she may, 

by controlling birth, lift motherhood to the plane of a voluntary, intelligent function, and remake the world. When the world is thus remade, it will exceed the dream of statesman, reformer and revolutionist.<br />

<br />

Only in recent years has woman's position as the gentler and weaker half of the human family been emphatically and generally questioned. Men assumed that this was woman's place; woman herself accepted it. It seldom occurred to anyone to ask whether she would go on occupying it forever.<br />

<br />

Upon the mere surface of woman's organized protests there were no indications that she was desirous of achieving a fundamental change in her position. She claimed the right of suffrage and legislative regulation of her working hours, and asked that her property rights be equal to those of the man. None of these demands, however, affected directly the most vital factors of her existence. Whether she won her point or failed to win it, she remained a dominated weakling in a society controlled by men.<br />

<br />

Woman's acceptance of her inferior status was the more real because it was unconscious. She had chained herself to her place in society and the family through the maternal functions of her nature, and only chains thus strong could have bound her to her lot as a brood animal for the masculine civilizations of the world. In accepting her role as the "weaker and gentler half," she accepted that function. In turn, the acceptance of that function fixed the more firmly her rank as an inferior.</p>

<p> Caught in this "vicious circle," woman has, through her reproductive ability, founded and perpetuated the tyrannies of the Earth. Whether it was the tyranny of a monarchy, an oligarchy or a republic, the one indispensable factor of its existence was, as it is now, hordes of human beings -- human beings so plentiful as to be cheap, and so cheap that ignorance was their natural lot. Upon the rock of an unenlightened, submissive maternity have these been founded; upon the product of such a maternity have they flourished.<br />

<br />

No despot ever flung forth his legions to die in foreign conquest, no privilege-ruled nation ever erupted across its borders, to lock in death embrace with another, but behind them loomed the driving power of a population too large for its boundaries and its natural resources.<br />

<br />

No period of low wages or of idleness with their want among the workers, no peonage or sweatshop, no child-labor factory, ever came into being, save from the same source. Nor have famine and plague been as much "acts of God" as acts of too prolific mothers. They, also, as all students know, have their basic causes in over-population.<br />

<br />

The creators of over-population are the women, who, while wringing their hands over each fresh horror, submit anew to their task of producing the multitudes who will bring about the next tragedy of civilization.<br />

<br />

While unknowingly laying the foundations of tyrannies and providing the human tinder for racial conflagrations, woman was also unknowingly creating slums, filling asylums with insane, and institutions with other defectives. She was replenishing the ranks of 

the prostitutes, furnishing grist for the criminal courts and inmates for prisons. Had she planned deliberately to achieve this tragic total of human waste and misery, she could hardly have done it more effectively.<br />

<br />

Woman's passivity under the burden of her disastrous task was almost altogether that of ignorant resignation. She knew virtually nothing about her reproductive nature and less about the consequences of her excessive child-bearing. It is true that, obeying the inner urge of their nature, some women revolted. They went even to the extreme of infanticide and abortion. Usually their revolts were not general enough. They fought as individuals, not as a mass. In the mass they sank back into blind and hopeless subjection. They went on breeding with staggering rapidity those numberless, undesired children who become the clogs and the 

destroyers of civilization.<br />

<br />

Today, however, woman is rising in fundamental revolt. Even her efforts at mere reform are, as we shall see later, steps in that direction. Underneath each of them is the feminine urge to complete freedom. Millions of women are asserting their right to voluntary motherhood. They are determined to decide for themselves whether they shall become mothers, under what 

conditions and when. This is the fundamental revolt referred to. It is for woman the key to the temple of liberty.<br />

<br />

Even as birth control is the means by which woman attains basic freedom, so it is the means by which she must and will uproot the evil she has wrought through her submission. As she has unconsciously and ignorantly brought about social disaster, so must and will she consciously and intelligently undo that disaster and create a new and a better order.<br />

<br />

The task is hers. It cannot be avoided by excuses, nor can it be delegated. It is not enough for woman to point to the self-evident domination of man. Nor does it avail to plead the guilt of rulers and the exploiters of labor. It makes no difference that she does not formulate industrial systems nor that she is an instinctive believer in social justice. In her submission lies her 

error and her guilt. By her failure to withhold the multitudes of children who have made inevitable the most flagrant of our social evils, she incurred a debt to society. Regardless of her own wrongs, regardless of her lack of opportunity and regardless of all other considerations, she must pay that debt.<br />

<br />

She must not think to pay this debt in any superficial way. She cannot pay it with palliatives -- with child-labor laws, prohibition, regulation of prostitution and agitation against war. Political nostrums and social panaceas are but incidentally and superficially useful. They do not touch the source of the social disease.<br />

<br />

War, famine, poverty and oppression of the workers will continue while woman makes life cheap. They will cease only when she limits her reproductivity and human life is no longer a thing to be wasted.<br />

<br />

Two chief obstacles hinder the discharge of this tremendous obligation. The first and the lesser is the legal barrier. Dark age laws would still deny to her the knowledge of her reproductive nature. Such knowledge is indispensable to intelligent motherhood and she must achieve it, despite absurd statutes and equally absurd moral canons.</p>

<p> The second and more serious barrier is her own ignorance of the extent and effect of her submission. Until she knows the evil her subjection has wrought to herself, to her progeny and to the world at large, she cannot wipe out that evil.</p>

<p> To get rid of these obstacles is to invite attack from the forces of reaction which are so strongly entrenched in our present-day society. It means warfare in every phase of her life. Nevertheless, at whatever cost, she must emerge from her ignorance and assume her responsibility.<br />

<br />

She can do this only when she has awakened to a knowledge of herself and of the consequences of her ignorance. The first step is Birth Control. Through Birth Control she will attain to voluntary motherhood. Having attained this, the basic freedom of her sex, she will cease to enslave herself and the mass of humanity. Then, through the understanding of the intuitive forward urge within her, she will not stop at patching up the world; she will remake it.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Documents Online</h1>
		<div id="subnav">
			<a href="../documents/index.php">About</a><br>
			<b><a href="../documents/selected.php">Selected Writings</a></b><br>
			<a href="../documents/electroniced.php">Electronic Edition - Beta</a><br>
			<a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a><br>
			<a href="../documents/othersites.php">Documents on Other Sites</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
	