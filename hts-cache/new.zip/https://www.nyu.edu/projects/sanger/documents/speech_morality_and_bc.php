
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Documents Online / Selected Writings</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online" class="selected">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Selected Writings</h1>

<div class="maintext">
<h2>"MORALITY AND BIRTH CONTROL"
<br />By Margaret H. Sanger</h2>

<p align="left">[<span class="italicText">February 1918</span>]<br />

</p>

<p> Throughout the ages, every attempt woman has made to strike off the shackles of slavery has been met with the argument that such an act would result in the downfall of her morality. Suffrage was going to &ldquo;break up the home.&rdquo; Higher education would unfit her for motherhood, and co-education would surely result in making her immoral. Even today, in some of the more backward countries reading and writing is stoutly discouraged by the clerical powers because &ldquo;women may read about things they should not know.&rdquo;<br />

<br />

We now know that there never can be a free humanity until woman is freed from ignorance, and we know, too, that woman can never call herself free until she is mistress of her own body. Just so long as man dictates and controls the standards of sex morality, just so long will man control the world.<br />

<br />

Birth control is the first important step woman must take toward the goal of her freedom. It is the first step she must take to be man&rsquo;s equal. It is the first step they must both take toward human emancipation.<br />

<br />

The Twentieth Century can make progress only by fighting the superstitions and prejudices created in the Nineteenth Century -- fighting them in the open with the public searchlight upon them.<br />

<br />

The first questions we must ask ourselves are: Are we satisfied with present day morality? Are we satisfied with the results of present day standards of morality? Are these so satisfying that they need no improvement?<br />

<br />

For fourteen years I worked as a nurse in the factory and tenement districts of New York City. Eight years ago I was called into a home where the father, a machinist by trade, was earning eighteen dollars a week. He was at the time the father of six living children, to all appearances a sober, serious and hard working man. His wife, a woman in the thirties toiled early and late helping him to keep the home together and the little ones out of the sweatshops, for they were both anxious to give their children a little schooling.<br />

<br />

Two years ago I came across this same family, and found that five more children had been added in the meantime to their household. The three youngest were considered by medical authorities to be hopelessly feeble-minded, two of the older girls were prostitutes; three of the boys were serving long term sentences in penitentiaries, while another of the children had been injured by a fall and so badly crippled that she will not be able to help herself for years to come.</p>

<p> Out of this family of eleven children only two are now of any use to society, a little girl of seven, who stays at home and cares for her crippled sister during the day while the mother scrubs office floors, and a boy of nine who sells chewing gum after school hours at a subway exit. The father has become a hopeless drunkard, of whom the mother and children live in terror.</p>

<p> This is but one illustration of the results of our present day morality. Here was an opportunity for society to develop and preserve six children for human service; but prudery and ignorance added five more to this group, with the result that two out of eleven are left to fit the struggle against pauperism and charity. Will they succumb?<br />

<br />

Another case I should like to cite shows how shallow is the concern of society in regard to the over-crowded tenements, where thousands of little children occupy sleeping quarters with parents and boarders whose every act is visible to all. Morality indeed! Society is much like the ostrich with its head in the sand. It will not look at facts and face the responsibility of its own stupidity.<br />

<br />

I recall the death-bed scene, when the patient, a woman of twenty-six, passed away during the birth of her seventh child. Five out of the seven were girls, the eldest being about ten years old. Upon the death this woman, this girl began to assume the duties of her mother and continued to keep the four men roomers who had lodged in their home for years. A few years later, I found this girl suffering from the ravages of syphilis, although she had only just entered the period of puberty. She told me she could not remember when she had not dressed before the roomers, and on winter nights she often slept in their beds. She was already old -- old in ignorance, in vulgarity, in degeneracy.<br />

<br />

Another womanhood blighted in the bud, battered by ignorance, another soul sunk in despair.<br />

<br />

These five girl-women did not ask society to fill their minds, as it was willing to do, with a useless knowledge of Greek, Latin or the Sciences. But they did need and unconsciously demand the knowledge of life, of hygiene and sex psychology which is so prudishly and shamefully denied them. No doubt these five sisters will soon represent the ruins of an ancient prejudice, and five<br />

more derelicts will be added to that particular relic heap of humanity.</p>

<p> Again, is there anything more sickening to truth than the attitude of society toward that catch phrase &ldquo;Sacred Motherhood&rdquo;? Take another illustration and lay bare the living facts and view them for awhile.<br />

<br />

Two sisters lived in an upstate town, members of a large family, where the older daughters worked in factories, in order that the younger girls might have educational advantages. The youngest fell in love with a good-for-nothing fellow, with the result that she had an illegal child. Disgrace, ostracism and remorse drove her out into the world, and together with her baby she drifted from house to house in the capacity of a servant, until finally the baby died, leaving the mother free to enter upon another vocation.</p>

<p> During this time, however, due to the condescending treatment accorded to her by the women who employed her, she had become so accustomed to look upon herself as an outcast that soon, with other companions of her frame of mind, she began trafficking...on the streets of New York.<br />

<br />

Now the second sister, a few older, also fell in love with one of the &ldquo;town heroes,&rdquo; and came to grief; but owing to the &ldquo;disgrace&rdquo; of the youngest sister and sympathy for the elder members of the family, who were completely anguish stricken over this second mishap, the old family physician took her in charge and sent to her a place where an illegal operation was performed<br />

upon her. She returned, a sadder but wiser girl, to her home, finished the high school course, and several years later she became the principal of a school.<br />

<br />

Today she is one of the most respected women in that county. She devotes her life outside school hours to a sympathetic understanding of the needs of young boys and girls, and her sordid early experience, put to good use, has helped many boys and girls to lead clean lives.<br />

<br />

These cases represent actual modern conditions. Our laws force women into celibacy on the one hand, or abortion on the other.</p>

<p> Both conditions are declared by eminent medical authorities to be injurious to health. The ever ascending standard and cost of living, combined with the low wage of the young men of today, tend toward the postponement of marriage.<br />

<br />

Has knowledge of birth control, so carefully guarded and so secretly practiced by the women of the wealthy class -- and so tenaciously withheld from the working women -- brought them misery? Rather, has it not promoted greater happiness, greater freedom, greater prosperity and more harmony among them? The women who have this knowledge are the women who have<br />

been free to develop, free to enjoy in its best sense, and free to advance the interests of the community. And their men are the ones who motor, who sail yachts, who legislate, who lead and control. The men, women and children of this class do not form any part whatever in the social problems of our times.<br />

<br />

Had this class continued to reproduce in the prolific manner of the working people in the past twenty-five years, can human imagination picture what conditions would be today? All of our problems are the result of overbreeding among the working class, and if morality is to mean anything at all to us, we must regard all the changes which tend toward the uplift and survival of<br />

the human race as moral.<br />

<br />

Knowledge of birth control is essentially moral. Its general, though prudent, practice must lead to a higher individuality and ultimately to a cleaner race.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Documents Online</h1>
		<div id="subnav">
			<a href="../documents/index.php">About</a><br>
			<b><a href="../documents/selected.php">Selected Writings</a></b><br>
			<a href="../documents/electroniced.php">Electronic Edition - Beta</a><br>
			<a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a><br>
			<a href="../documents/othersites.php">Documents on Other Sites</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
	