
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Documents Online / Selected Writings</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online" class="selected">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Selected Writings</h1>
<div class="maintext">
<h2>"THE MAMMALS AND THEIR CHILDREN, PART 1"
<br />By Margaret H. Sanger</h2>

<p align="left">[<span class="italicText"><em>December 10, 1911</em></span>]</p>

<p align="left">

The first question one of the boys asked was, "What is a mammal?" and it was explained to the children that a mammal is an animal with a hairy covering, who breathes with lungs, and has warm or quick circulating blood. They have little ones, which when born are not in the form of eggs, like the frogs or birds, and have the same shape as their parents, though smaller and weaker. The mother mammal nurses these little ones with milk secreted from glands, called mammary glands. And that is why they are called "mammals."<br />

<br />

Their instincts are highly developed, and they are considered the highest animals. Many instances were shown them of the meaning of instinct, as that of the mother bird turning over her eggs every day. In fact, from the first word was explained in every stage to enable them to know the difference between instinct and reason later on.<br />

<br />

There was no one creature taken up this time, but all together, and some pictures were shown them of lower tribes of man, and it was decided that man must be classed with the mammals, for he is partly covered with hair, gives birth to young in his own shape, and feeds the young from mammary glands. So with this highest development in mind they were told that: There is a mammal, the spiny ant eater, covered with hair, which, however, lays eggs like the birds in nests. They were told about the kangaroo and opossum, who give birth to their little ones very early, and carry them in a pouch until they are able to help themselves. As soon as the little opossum is born, Mother Opossum picks him up in her mouth and places him in her pouch, where he sucks away at the milk which is secreted there, until he is strong and able to get food for himself -- which is about the same length of time that other mammals carry their young before giving birth to them. They were told of the bats and the flying squirrels, and well taught to think for themselves and learn of the process of transition or evolution. They were told that Bobby's cat must be given a new clean box, or bed; that she must not be handled roughly or chased, because she was going to have little kittens. To the utter astonishment of Bobby's mother there was a chorus of, "How do you know?" and she realized that she might have omitted a most important piece of information.<br />

<br />

They were again reminded of the birds and the undeveloped eggs coming from the ovary of mother bird, which at a certain time become ripe for fertilization; of how the father bird at a certain time feels he has developed (since the fertilizing principle within him has developed) so that in coming in contact with the undeveloped egg within the mother's body, these are quickened into life. The same process goes on with the mammals, but as the instinct becomes more developed as they go higher in the scale of life breeding becomes more complex.<br />

<br />

They were told that where in birds the whole egg, shell and all passes out of the mother's body into the nest, with the mammal the shell becomes a thin skin, which envelops the little one, but remains within the mother's body until it is grown enough and strong enough to live on the milk from the mother. While it is within the mother's body it is fed from the blood of the mother, and all the food she eats helps to make the little ones within her strong.<br />

<br />

It is of great assistance for a mother to have some knowledge of the processes of assimilation so that the children will learn how the food products in the blood, instead of supplying the mother, go to the child to build up bone, muscle, nerves and tissues.<br />

<br />

They were told that as the mammal grows and develops within the body of the mother her shape becomes changed -- becomes larger in the region where the new life lies, and that is how one could tell that Mrs. Pussy Cat was going to have a family.<br />

<br />

It was dwelt upon at great length that it was necessary to know this, because every mother needs protection from worry, excitement, cruelty, overwork, starvation at such a period; that she needed kindness, rest, good food, sunshine, in order that she give the little ones strength and health.<br />

<br />

They were told that in smaller animals many more eggs develop at a time and are fertilized but in the larger animals such as cows, horses, elephants, etc., only one egg develops and one animal is born. In man, too, this is true. One egg develops at a time, and if it is fertilized it remains in its little nest (or uterus), and grows until it is ready to stand the changed conditions into which it must come after is born. It is not fertilized it passes on out of the body and is lost[,] but when it is fertilized by the father, it remains in the uterus and grows until it is grown enough to withstand a different life and different surroundings.<br />

<br />

At first the new being is only the size of a pea (that is, in a week after it is fertilized). In a few weeks (eight) it is the size of a lemon, and its shape is complete. In four months it begins to move about, to kick, to move its little hands, and in nine months Mother Nature can develop it no more. It is time to change, if it is to live, so she sends it along the passage, enlarging the passage and stretching it as it goes -- which causes much pain and suffering to the mother, until it reaches the outside world, where it is taken and cared for and loved, and all the mother's pain is forgotten in the joy of having her little one alive and strong and well.<br />

<br />

One of the mothers was expecting the arrival of a little one, and great care and tenderness was shown her after the children knew of this event. She was assisted up the hills, brought flowers and all the tenderness of which children are capable was bestowed upon her.<br />

<br />

They anxiously watched and waited for its arrival, looked over the small clothing which was being prepared for it, and seemed as interested as any grown-up could ever be.<br />

<br />

They were taken to a farm some miles away to see a calf a few days old. Stories were read to them at this time about the habits of these animals and the care of their young. They were taken to the Museum of Natural History in New York and to Bronx Park, and such excursions were red letter days in their book of childhood. They were told of the freedom of the animals in choosing their mates -- that beauty and strength seemed the greatest qualifications. The story of the bees was briefly told. How the queen bee leaves her home amidst the hundreds of male bees who are all anxious to be the father of the future hive. How she rambles about for a little while, then up she flies -- up, up, straight into the clouds with hundreds of male bees following. Gradually the weakest bees drop off and return, but the stronger ones still follow until there are often only two male bees left in the race. The weaker of the two returns and the strongest bee of the whole hive wins the queen bee, and fertilizes the eggs within her body. After this act of reproduction he dies, and Mrs. Bee returns to her hive and lays thousands of bee eggs. The strongest gave his life that the future bees should be given his great strength.<br />

<br />

The children were sad about this. They wanted the strongest to live, and it was now the place to teach them of their own bodies, what cleanliness and strength means to the future race of man. But this we will learn of in our next lesson.</font></p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Documents Online</h1>
		<div id="subnav">
			<a href="../documents/index.php">About</a><br>
			<b><a href="../documents/selected.php">Selected Writings</a></b><br>
			<a href="../documents/electroniced.php">Electronic Edition - Beta</a><br>
			<a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a><br>
			<a href="../documents/othersites.php">Documents on Other Sites</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
	