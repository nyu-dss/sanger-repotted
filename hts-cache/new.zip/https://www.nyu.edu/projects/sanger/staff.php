			

<div class="maintext">

<h2>Editorial</h2>
<p><em><a href="esther_katz.php">Dr. Esther Katz</a></em>, Editor and Director</p>
<p><em><a href="Cathy_Hajo.php">Dr. Cathy Moran Hajo</a></em>, Associate Editor</p>
<p><em><a href="Peter_Engelman.php">Peter C. Engelman</a></em>, Associate Editor</p>


<h3>The Project's Advisory Board is:</h3>
<p><em>Ellen Chesler</em>, <span class="titles">Director of Women and Public Policy Initiative at Hunter College</span>. Author, <span class="italicText">Woman of Valor: Margaret Sanger and the Birth Control Movement in America </span>(1992, new edition forthcoming 2007).</p>
<p><em>Elizabeth Fee</em>, Associate Professor, Dept. of Health Policy and Management, Johns Hopkins University.</p>
<p><em>Gloria Feldt, </em>Author and  past president of Planned Parenthood Federation of America. See her <a href="http://www.gloriafeldt.com/">blog</a> </p>
<p><em>Linda Gordon</em>, Professor of History, New York University. Author, <span class="italicText">The Moral Property of Women: A History of Birth Control Politics in America</span> (2002).</p>
<p><em>Margaret Sanger Lampe</em>, Granddaughter of Margaret Sanger. Arlington, VA.</p>
<p><em>Andrew Lee</em>, Librarian for History, Political Science and Food Studies, Elmer Holmes Bobst Library, New York University. </p>
<p><em>Sherrill Redmon </em>Former Head, Sophia Smith Collection, Smith College Libraries.</p>
<p><em>James Reed</em>, Professor of History, Rutgers University, Author, <span class="italicText">From Private Vice to Public Virtue: The Birth Control Movement and American Society</span> (1978).</p>
<p><em>Cecile Richards, </em>Past President, Planned Parenthood Federation of America. </p>
<p><em>Alexander Sanger</em>, Grandson of Margaret Sanger, International Planned Parenthood Federation, Western Hemisphere Region, and author of <span class="italicText">Beyond Choice</span>(2004). </p>
<p><em>Jill Sheffield</em>, Member, Board of Directors. Family Care International.</p>
<p><em>Faye Wattleton</em>, former president of Planned Parenthood Federation of America.</p>

<h3><strong>Former Administrative Staff </strong></h3>
<p>Cathy Moran Hajo, Assistant Director</p>
<p>Peter Wosh (Co-Director) </p>
<p>Carl E. Prince, Co-Director </p>

<h3><strong>Former Editorial Staff </strong></h3>
<p>Amy Flanders, Assistant Editor (NHPRC Fellow) </p>
<p>Anke Voss Hubbard, Assitant Editor</p>
<p>Nancy Robertson, Assistant Editor </p>
<p>Jessie Roderioque, Assistant Editor</p>
<p>Stacy Kinclock Sewell, Assistant Editor (NHPRC Fellow)</p>
<h4>Graduate Assistants:</h4>
<p>Meng Wei, Zawadi Barskile, Marion Casey, Angela Cotten-Harris, Kate Culkin, Andrew Darien, Mia Feng, Kirsten Fermaglich, Lisette Fuhs, Eileen Gatti, Maxine Gordon, Melanie Gustafson, 
Samara Heifitz, John Herman, Wendy Holliday, Sean Holmes, Rashauna Johnson, Youn Jong Lee, Cathleen McDonnell, Jasmine Mir, Nancy Mykoff, Tracy Neumann, Claire Payton, Jane Rothstein, 
Rachel Scharfman, Daniel Sokolow, Christopher K. Stevens, Tracy Tullis, and Susan Valentine.</p>

<h4>Student Assistants:</h4>
<p>Samuel Magida, Girlie Gaviola, Laura Fillion, Andy Carloff, Angela Wu, Melissa Aragon, Lia Araujo,  Jennifer Beckman, Katie Beers, Stephanie Bennett, Shareeza Bhola, Scott Boggins, Madeline Bohm, 
Pilara Brunson, Molly Cartwright, Josh Chung, Sasha Dawson, Gina DeCaprio, Diane DeWindt, Meghan Duffy, Heather Dumorne, Jennifer Duncan, Stan German, Susan Haacke, Christine Haran, Mark Hellen, 
Meghan Horvath,  Alfredo Ignacio (VLDE), Sepideh Jafari, Liz Joseph,Tricia Khan, Kristin Kapsis, Sara Kluberdanz, Maria LaCalle, Barbara E. Lewis, Hannah Lisak, Shelley Matthews, 
Caroline McHugh, Sam Magida, Stephanie Margolin, Katy Mohrman, Rita J. Mularoni, Hannah Munroe, Rebecca Murry, David Nahass,  Agam Neiman, Christina M. Nelson, Jordan Pascoe, Isidoros Passalaris, 
Lisa Patel, Allison Poindexter, Eva Pollard, Katie Redfield, Cassandra Rodenberg, David Rodini, Tammy Roth, Natalia Sanoja,  Melissa Schwartz, David H. Serlin, Deborah Steinbach, 
Candace Taylor, Rachel Teicher, Stavritsa Terzis, Elizabeth Vayda, Meghan Walsh, Kristina Wertz, Jackie Woodruff, Angela Wu, Tawana Youngblood, and Stephanie Zorn.</p>
<p>For a list of the interns who have aided the worked at the project, <a href="../../../../Admin/Dropbox/MSPP-NYU/project/former_interns.php">click here</a>. </p>

</div>

<div id="sidebar">
		<h1>Search</h1>

	<script>
  	(function() {
    var cx = '016619794450116726182:r0pm5z5tz6e';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  	})();
	</script>
	<gcse:searchbox-only></gcse:searchbox-only>

	<br><br>
	
		<h1>Project</h1>
		<div id="subnav">
		
		<!---LINKS (bold current section)--->
			<a href="../../../../Admin/Dropbox/MSPP-NYU/project/index.php">About</a><br>
			<b><a href="../../../../Admin/Dropbox/MSPP-NYU/project/staff.php">Staff</a></b><br>
			<a href="../../../../Admin/Dropbox/MSPP-NYU/project/former_interns.php">Former Interns</a><br>
			<a href="../../../../Admin/Dropbox/MSPP-NYU/project/funders.php">Funders</a><br>
			<a href="../../../../Admin/Dropbox/MSPP-NYU/project/reviews.php">Reviews</a><br>
			<a href="../../../../Admin/Dropbox/MSPP-NYU/project/editing.php">Editing at the MSPP</a><br>
 		
          <!---END LINKS--->
		 
	</div>
		</div>
			<div id="mainend"></div>
		
		</div>
	
		<div id="footer">		
		<center>
		All contents copyright � The Margaret Sanger Papers. All rights reserved.
		</center>
			</div>
					

