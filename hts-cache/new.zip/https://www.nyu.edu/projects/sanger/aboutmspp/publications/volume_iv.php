﻿
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / <font style="font-size:97%">The Selected Papers of Margaret Sanger: Volume IV</font></title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="../images/logo.png"></a> 
    
    <ul id="nav">
        
    
        </ul>
    
        </div>
        </div>
        <div id="main">
        <body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
 
	</div>
	</div>
		</div>
	
	
    <ul id="nav">
			
	
	<div id="wrap">
		<div id="header">
		<div align="left">

	<ul id="nav">
		<li>
			<a href="../aboutms/about.php">About Sanger</a>
			<ul>
				<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		</li>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The MSPP Project" class="selected">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About</a></li>
				<li><a href="../project/staff.php">Staff</a></li>
				<li><a href="../project/former_interns.php">Former Interns</a></li>
				<li><a href="../project/funders.php">Funders</a></li>
				<li><a href="../project/reviews.php">Reviews</a></li>
				<li><a href="../project/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../publications/about.php" title="Publications">Publications</a>
			<ul>
				<li><a href="../publications/about.php">About</a></li>
				<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../publications/image.php">Publications/On-Line Image Edition</a></li>
				<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				<li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/index.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		<li>
			<a href="../documents/about.php" title="Documents Online">Documents Online</a>
			<ul>
				<li><a href="../documents/index.php">About</a></li>
				<li><a href="../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		</li>
		<li>
			<a href="../research/index.php" title="Research Resources">Resources</a>
			<ul>
				<li><a href="../research/index.php">Research</a></li>
				<li><a href="../research/editorsnotes.php">Editor's Notes</a></li>
				<li><a href="../research/nhday.php">National History Day</a></li>
				<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
				<li><a href="../research/images.php">Sanger Images</a></li>
				<li><a href="../research/links.php">Links</a></li>
			</ul>
		</li>
		<li>
			<a href="../contactus.html" title="Contact Us">Contact Us</a>
		</li>
		
		</ul>
			
		</div>
		</div>
		<div id="main">
		
		
	
    
    <br><br>
    
    <h1><font style="font-size:97%">The Selected Papers of Margaret Sanger: Volume IV</font></h1>			

<div class="maintext">

<h1>'Round the World for Birth Control, 1920-1966</h1>

<center>
<p><a href="volume_i.php">Volume I</a> / <a href="volume_ii.php">Volume II</a> / <a href="volume_iii.php">Volume III</a> / <a href="volume_iv.php">Volume IV</a> / <a href="editorial_methods.php">Editorial Methods</a><br /><br /></p>
</center>

<p><img src="../images/vol4-cover.jpg" width="206" height="312" align="right" style="margin-left: 15px" /></p>

<p>Edited by Esther Katz</p>

<p>Peter C. Engelman and<br> Cathy Moran Hajo, <br>
Associate Editors</p>

<p>Volume IV is devoted to the most understudied and
least understood aspect of Sanger's career -- her international work.
Beginning with her visit to post-World War I Germany, it carries Sanger through her groundbreaking tour of Japan and China in 1922, her
1930s trips to the Soviet Union and India, and her several postwar trips to
Japan and India, the volume documents Sanger's active promotion of birth
control clinics throughout the world. Volume IV covers her interwar
travels to Europe and Asia, the historic 1927 World Population Conference in
Geneva, which Sanger organized, along with subsequent international birth
control conferences from 1930 to 1961, as well as the Birth Control
International Information Centre, a clearing-house for the exchange of ideas and
practical information. The volume also addresses Sanger's post World War II
revival of international support for birth control, documenting the backlash of
post-Holocaust rejection of the eugenics movement and the pro-natalist voices of
those whose populations were decimated by the war. It traces the
founding of the International Planned Parenthood Federation (IPPF) and
illustrates the relationships between population controllers and many feminist
and health-oriented birth controllers. The volume closes with Sanger's
efforts to maintain control over the direction of the IPPF even after her
resignation as president, not only by trying to choose her successor but by
attempting to ensure that the new leadership not ignore the primary importance
of a feminist-based commitment to birth control.</p>

<p>Volume IV is being published in Dec.2016 by the <a href="http://www.press.uillinois.edu/books/catalog/92xgk7mc9780252403822.html">University of Illinois Press</a>.</p>

<p><a target="_new" href="http://www.nyu.edu/projects/sanger/publications/V4toc.pdf">Draft Table of Contents</a></p>
<hr>



</div>

