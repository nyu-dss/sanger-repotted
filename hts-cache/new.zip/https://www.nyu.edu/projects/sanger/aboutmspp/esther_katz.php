
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / The Project / Staff</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project" class="selected">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Staff</h1>			

<div class="maintext">
<h1>Esther Katz, Editor and Director</h1>

<p><img src="../images/esther-katz.jpg" width="200" height="200" align="right" style="margin-left: 15px; margin-bottom: 15px;">Associate Professor (ret.), US History</p>
<p>Director/Editor, The Margaret Sanger Papers Project</p>
<p>East Hampton, NY</p>

<p><a href="mailto:esther.katz@nyu.edu">Send E-mail</a></p>

<p>Project Director Esther Katz, a Research Scholar and Adj. Associate Professor (ret.)at New York University, founded the Sanger Papers Project in 1987. She had previously worked on<i>The Papers of William Livingston,</i> the <i>Letters of William Loyd Garrison</i> and the <i>National Women's Trade Union League Records.</i> Dr. Katz was previously Associate Director for the Institute for Research in History. She has served as interim director of NYU's Program in Archives and Historical Editing, and has consulted on for a variety of institutions including in the Ford Foundation, MSNBC, and several documentary film and television productions.</p>

<p>She completed the last volume of the four-volume <em><a href="../../../AppData/Esther%20Katz/Dropbox/SangerWeb-PHP/publications/book.php">The Selected Writings of Margaret Sanger</a>, Round the World for Birth Control, 1920-1966</em> in 2016 . Drawn from over 120,000 of Sanger's letters and papers, these volumes will highlight the public and private life of the nation's most notable birth control leader and her impact on the movement she founded and led, and will trace the intersection of Sanger's life and work with other reformers, activists and world leaders. In addition, Dr. Katz is currently completing the Project's digital edition, The <em><a href="../../../AppData/Esther%20Katz/Dropbox/SangerWeb-PHP/documents/electroniced.php">Speeches and Articles</a></em> of Margaret Sanger</p>

<p>Dr. Katz is a past-president of the <a href="http://www.documentaryediting.org/wordpress/">Association for Documentary Editing</a>, and a special faculty member of <a href="http://www.archives.gov/nhprc/about/">National Historical Publications and Records Commission</a>'s <a href="http://www.archives.gov/nhprc/partners/editing-institute.html#top">Institute for Editing Historical Documents</a> in 2016, and has served on the ADE Council, as well as its Education Committee, Research, and Web Committee. She was the 2015 recipient of the <a href="http://www.documentaryediting.org/wordpress/?page_id=14">Lyman H. Butterfield</a> award for her contributions to the area of documentary editing. She has also been a member of the Organization of American History's Committee on Research and Preservation. In addition to the book edition, she is currently  working on <em>The Speeches and Articles of Margaret Sanger</em>, an electronic edition of Sanger's unpublished speeches and less accessible articles being mounted on our web site.</p>

<p>In addition to her work on the Sanger Project, Dr. Katz is writing a biography of Margaret Sanger for the <em>Lives of American Women</em> series to be published by Westview Press.</p>

<p>Dr. Katz has taught graduate seminars on Digital Editing Projects for NYU's Archives and Public History Program, along with courses in NYU's History Department on Women in American Society; Great Depression and New Deal, Modern America, and The Progressive Era.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>The Project</h1>
		<div id="subnav">
			<a href="../project/index.php">About</a><br>
			<b><a href="../project/staff.php">Staff</a></b><br>
			<a href="../project/internships.php">Internships</a><br>
			<a href="../project/support.php">Support</a><br>
			<a href="../project/funders.php">Funders</a><br>
			<a href="../project/reviews.php">Reviews</a><br>
			<a href="../project/editing.php">Editing at the MSPP</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
