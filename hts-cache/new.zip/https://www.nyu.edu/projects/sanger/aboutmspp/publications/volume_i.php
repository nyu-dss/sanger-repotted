
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / <font style="font-size:97%">The Selected Papers of Margaret Sanger: Volume I</font></title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="../images/logo.png"></a> 
    
    <ul id="nav">
        
    
        </ul>
    
        </div>
        </div>
        <div id="main">
        <body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
 
	</div>
	</div>
		</div>
	
	
    <ul id="nav">
			
	
	<div id="wrap">
		<div id="header">
		<div align="left">

	<ul id="nav">
		<li>
			<a href="../aboutms/about.php">About Sanger</a>
			<ul>
				<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		</li>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The MSPP Project" class="selected">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About</a></li>
				<li><a href="../project/staff.php">Staff</a></li>
				<li><a href="../project/former_interns.php">Former Interns</a></li>
				<li><a href="../project/funders.php">Funders</a></li>
				<li><a href="../project/reviews.php">Reviews</a></li>
				<li><a href="../project/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../publications/about.php" title="Publications">Publications</a>
			<ul>
				<li><a href="../publications/about.php">About</a></li>
				<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../publications/image.php">Publications/On-Line Image Edition</a></li>
				<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				<li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/index.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		<li>
			<a href="../documents/about.php" title="Documents Online">Documents Online</a>
			<ul>
				<li><a href="../documents/index.php">About</a></li>
				<li><a href="../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		</li>
		<li>
			<a href="../research/index.php" title="Research Resources">Resources</a>
			<ul>
				<li><a href="../research/index.php">Research</a></li>
				<li><a href="../research/editorsnotes.php">Editor's Notes</a></li>
				<li><a href="../research/nhday.php">National History Day</a></li>
				<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
				<li><a href="../research/images.php">Sanger Images</a></li>
				<li><a href="../research/links.php">Links</a></li>
			</ul>
		</li>
		<li>
			<a href="../contactus.html" title="Contact Us">Contact Us</a>
		</li>
		
		</ul>
			
		</div>
		</div>
		<div id="main">
		
		
	
    
    <br><br>
    
    <h1><font style="font-size:97%">The Selected Papers of Margaret Sanger: Volume I</font></h1>			

<div class="maintext">

<center>
<h1>The woman Rebel 1900-1928)</h1>


<a href="./volume_i.php">Volume I</a> / <a href="./volume_ii.php">Volume II</a> / <a href="./volume_iii.php">Volume III</a> / <a href="/.volume_iv.php">Volume IV</a> / <a href="./editorial_methods.php">Editorial Methods</a><br /><br /></p>
</center>

<p><img src="./vol1cover.jpg" width="180" height="254" align="right" style="margin-left: 15px;"></p>

<p>Edited by Esther Katz</p>

<p>Cathy Moran Hajo and Peter C. Engelman,<br />
Assistant Editors</p>

<a href="/Sanger Website/aboutmspp/reviews.html">/Sanger Website/aboutmspp/reviews.html</a>a href="./project/reviews.php">Click here for Reviews and Comments.</a></p>
<p>The birth control crusader, feminist, and reformer Margaret Sanger was one of the most controversial and compelling figures in the twentieth century. This first volume 
of <em>The Selected Papers of Margaret Sanger</em> documents the critical phases and influences of an American feminist icon and offers rare glimpses into her working-class 
childhood, burgeoning feminism, spiritual and scientific interests, sexual explorations, and diverse roles as wife, mother, nurse, journalist, radical socialist, and activist. 
These letters and other writings, including diaries, journals, articles, and speeches, most of which have never before been published, have been selected and assembled with 
an eye to telling the story of a remarkable life, punctuated by arrests and imprisonments, exile, love affairs, and a momentous personal loss--a life consumed with the quest for women's 
sexual liberation. Because its narrative line is so absorbing, Volume 1 may be read as a powerful biography. Volume 1 covers a twenty-eight-year period from her nurse's training and early
socialist involvement in pre-World War I bohemian Greenwich Village to her adoption of birth control (a term she helped coin in 1914) as a fundamental tenet of women's rights. It 
traces the intersection of her life and work with other reformers, activists and leaders of modernity on both sides of the Atlantic, including Havelock Ellis, H. G. Wells, 
George Bernard Shaw, Emma Goldman, Max Eastman, and Eugene Debs, as well as many leading radical artists and writers of the day. It highlights her legislative and 
organizational efforts, her support of the eugenics movement, and the alliances she secured with medical professionals in her crusade to make birth control legal, respectable, 
and accessible. This volume also includes letters from women desperately in need of fertility control who saw Sanger as their last hope. Supplemented by an introduction, 
brief essays providing narrative and chronological links, and substantial notes, the volume is an invaluable tool for understanding Sanger's actions and accomplishments.

<p>Volume II documents a difficult period for Sanger as she faced sustained political opposition to getting birth control legislation passed. Documents will track the unsuccessful efforts of her Congressional lobbying group, the National Committee for Federal Legislation on Birth Control, as their repeated efforts to amend the Comstock Act, as well as failed efforts to incorporate birth control into New Deal public health programs. It also will trace efforts to expand the reach of birth control clinics to rural and African-American women as well as Sanger's decision to shift from legislative to judicial reform. The success of the 1936<span class="italicText"> U.S. v. One Package</span> decision overturned a major portion of the Comstock Law, resulting in Sanger's reluctant decision to reunite her Birth Control Clinical Research Bureau with the ABCL in 1939 to form the Birth Control Federation of America, an organization managed by public relations professionals, which in 1942 became the Planned Parenthood Federation of America. The volume will close with the growing threat of war in Europe and Sanger's efforts to assist the flight of German sex reformers and physicians.</p>

<p>Volume II was published in 2007 by the <a href="http://www.press.uillinois.edu/f06/sanger.html">University of Illinois Press.</a></p>

<h2>Table of Contents</h2>
<p>Consult the table of contents in <a href="http://www.nyu.edu/projects/sanger/images/V2toc.pdf">PDF format</a>. </p>

<h2>Buy the Book!</h2>

<p><a href="http://www.amazon.com/Selected-Papers-Margaret-Sanger-Volume/dp/0252031377/"><img src="amazonbuy.gif"></a></p>

</div>

