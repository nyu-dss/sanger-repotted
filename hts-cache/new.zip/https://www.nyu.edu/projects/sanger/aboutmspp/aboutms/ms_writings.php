
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / Sanger's Writings</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="../images/logo.png"></a> 
    
    <ul id="nav">
        
    
        </ul>
    
        </div>
        </div>
        <div id="main">
        <body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
 
	</div>
	</div>
		</div>
	
	
    <ul id="nav">
			
	
	<div id="wrap">
		<div id="header">
		<div align="left">

	<ul id="nav">
		<li>
			<a href="../aboutms/about.php">About Sanger</a>
			<ul>
				<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		</li>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The MSPP Project" class="selected">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About</a></li>
				<li><a href="../project/staff.php">Staff</a></li>
				<li><a href="../project/former_interns.php">Former Interns</a></li>
				<li><a href="../project/funders.php">Funders</a></li>
				<li><a href="../project/reviews.php">Reviews</a></li>
				<li><a href="../project/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../publications/about.php" title="Publications">Publications</a>
			<ul>
				<li><a href="../publications/about.php">About</a></li>
				<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../publications/image.php">Publications/On-Line Image Edition</a></li>
				<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				<li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/index.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		<li>
			<a href="../documents/about.php" title="Documents Online">Documents Online</a>
			<ul>
				<li><a href="../documents/index.php">About</a></li>
				<li><a href="../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		</li>
		<li>
			<a href="../research/index.php" title="Research Resources">Resources</a>
			<ul>
				<li><a href="../research/index.php">Research</a></li>
				<li><a href="../research/editorsnotes.php">Editor's Notes</a></li>
				<li><a href="../research/nhday.php">National History Day</a></li>
				<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
				<li><a href="../research/images.php">Sanger Images</a></li>
				<li><a href="../research/links.php">Links</a></li>
			</ul>
		</li>
		<li>
			<a href="../contactus.html" title="Contact Us">Contact Us</a>
		</li>
		
		</ul>
			
		</div>
		</div>
		<div id="main">
		
		
	
    
    <br><br>
    
    <h1>Sanger's Writings</h1>
<div class="maintext">

<ul>
<li><a href="#bcr">BC Review</a></li>
<li><a href="#pamphlets">Pamphlets</a></li>
<li><a href="#rebel">Woman Rebel</a></li>
<li><a href="#biblio">Bibliographies</a></li>
</ul>

<A NAME="corr"></A>
<h2>Letters</h2>

<p><i>The Margaret Sanger Papers Microfilm Edition</i> has gathered together primary source material on Sanger from over three hundred archival collections and serves as the best source for Sanger's unpublished writings and correspondence.  It includes letters written to and from Sanger, diaries, speeches, articles, legal records, documents produced by Sanger's organizations, and other miscellaneous material.  Consult the index portion of the Reel Guides for specific citations.</p>

<A NAME="autobio"></A>
<h2>Autobiographies</h2>

<p>Sanger wrote two autobiographies:</p> 

<p><i>My Fight for Birth Control.</i> New York:  Farrar & Rinehardt, 1931. (<a href="https://books.google.com/books?id=HXIiAAAAYAAJ&q=%22my+fight+for+birth+control%22&dq=%22my+fight+for+birth+control%22&hl=en&ei=eHCHTduJMdCbtwfc-fDeBA&sa=X&oi=book_result&ct=result&resnum=1&ved=0CEMQ6AEwAA">Google Books &quot;snippet&quot; view</a>)</p>

<p><i>Autobiography.</i> New York: W.W. Norton & Co., 1938. (<a href="https://books.google.com/books?id=vJGwNqzhCPQC&printsec=frontcover&dq=margaret+sanger+autobiography&hl=en&ei=p3CHTdqvOo63tweN_ty4BA&sa=X&oi=book_result&ct=result&resnum=1&ved=0CDMQ6AEwAA#v=onepage&q&f=false">Google Books</a>)</p>

<p>Draft versions of these manuscripts appear on the <i><a href="/aboutmspp/publications/microfilm.php">Margaret Sanger Papers Microfilm Edition.</a></i>  Consult the index for specific citations.</p>

<p>Other autobiographical material appears in some of her speeches and articles. </p>

<A NAME="bcbooks"></a>
<h2>On Birth Control</h2>

<p>A listing of the major books and pamphlets follows.  Sanger wrote over 600 speeches and articles, which are indexed by title in the <i><a href="aboutmspp/publications/microfilm.php">Margaret Sanger Papers Microfilm Edition</a></i>, and will be included in the forthcoming <i><a href="../documents/electroniced.php">Speeches and Articles of Margaret Sanger, 1911-1959</a>.</i></p>

<p><i>Appeals from American Mothers.</i> New York: New York Women's Publishing Co., 1921.</p>

<p><i>The Case for Birth Control: A Supplementary Brief and Statement of the Facts.</i> New York:
Modern Art Printing Company, 1917. (<a href="http://books.google.com/books?id=EkUSAAAAYAAJ&printsec=frontcover&source=gbs_ge_summary_r&cad=0#v=onepage&q&f=false">Google Books</a>.) </p>

<p><i>Debate Between Margaret Sanger and Winter Russell.</i> New York: The Fine Arts Guild, 1921.  (see a digital image of this work at <a href="https://digital.lib.msu.edu/">Michigan State University's Special Collections</a> web site)</p>

<p><i>Happiness in Marriage.</i> New York: Brentano's, 1926.</p>

<p><i>Motherhood in Bondage.</i> New York:  Brentano's, 1928. (<a href="https://books.google.com/books?id=KXrD8rTUHDkC&printsec=frontcover&dq=margaret+sanger+motherhood+in+bondage&hl=en&ei=XnGHTZPjCs2jtgeY-JC2BA&sa=X&oi=book_result&ct=result&resnum=1&ved=0CC0Q6AEwAA#v=onepage&q&f=false">Google Books</a>)</p>

<p><i>The New Motherhood.</i> London: Jonathan Cape, 1922. (British edition of <i>Woman and the New Race</i>)</p>

<p><i>Pivot of Civilization.</i> New York: Brentanos, 1922. (<A HREF="http://ibiblio.org/gutenberg/etext99/pvcvl10.txt?num=1689">Transcriptions available through Project Guttenberg.</A> or <a href="http://books.google.com/books?id=jhpLAAAAYAAJ&pg=PA214&dq=margaret+sanger+happiness+in+marriage&hl=en&ei=2HCHTeX8F4e4tgfRrrncBA&sa=X&oi=book_result&ct=result&resnum=6&ved=0CEoQ6AEwBQ#v=onepage&q&f=false">Google Books</a>)</p>

<p><i>Sayings of Others on Birth Control.</i> New York: New York Women's Publishing Co., 1921.</p>

<p><i>What Every Girl Should Know.</i> New York: M.N. Maisel, 1920.  (See a digital images of a 1920 and 1922 edition at <a href="http://digital.lib.msu.edu/">Michigan State University's Special Collections</a> web site) For a digital image of an edition in Yiddish, see the <a href="http://www.archive.org/details/nybc211933">Internet Archive</a> web site. </p>

<p><i>What Every Mother Should Know: Or How Six Little Children Were Taught the Truth.</i> New York: The Rabelais Press, 1914. (See a digital image of a 1922 edition at <a href="http://digital.lib.msu.edu/">Michigan State University's Special Collections</a> web site).</p>

<p><i>Woman and the New Race.</i> New York: Brentano's, 1920. (Bartelby.com or <a href="http://books.google.com/books?id=AywKAAAAIAAJ&dq=margaret%20sanger%20woman%20and%20new%20race&pg=PP1#v=onepage&q&f=false">Google Books</a>) </p>

<A NAME="conf-ms"></A>
<h2>Conferences</h2>

<p>Margaret Sanger edited the conference proceedings from several birth control and population conferences.</p>

<p><i>The Sixth International Neo-Malthusian and Birth Control Conference</i>, New York: American Birth Control League.  In four volumes:

<ul class="thin-indent">
<li>Vol. 1: <i>International Aspects of Birth Control</i>, 1925.</li>
<li>Vol. 2: <i>Problems of Overpopulation</i>, 1926.</li>
<li>Vol. 3: <i>Medical and Eugenic Aspects of Birth Control</i>, 1926.</li>
<li>Vol 4: <i>Religious and Ethical Aspects of Birth Control,</i> 1926.</li>
</ul>    

<p><i>Proceedings of the World Population Conference</i>.  London:  Edward Arnold & Co., 1927.</p>

<p><i>The Practice of Contraception; An Introductory Symposium and Survey</i> (proceedings of the Seventh International Birth Control Conference).  Baltimore:  Williams and Wilkins Co. 1931. With Hannah Mayer Stone.</p>

<p><i>American Conference on Birth Control and National Recovery.  Biological and Medical Aspects of Contraception</i>.  Washington, DC: Committee on Federal Legislation for Birth Control, 1934.</p>

<A NAME="rebel"></A>
<h2><span class="title boldText">The Woman Rebel</i></h2>  

<p>All seven issues of Sanger's 1914 journal are included in the <a href="../publications/collected_documents.php">Margaret Sanger Papers Microfilm Edition, Collected Documents Series</a>, see index for specific citations. </p>

<p><i>The Woman Rebel</i> is also available as part of University Publications of America's <i>Periodicals on Women and Women's Rights.</i>  It has also been reprinted by Alex Baskin, ed. <i>The Woman Rebel. </i>New York: Archives of Social History, 1976.</p>

<A NAME="bcr"></A>
<h2>The Birth Control Review</h2>

<p>Sanger articles are included in the<span class="italicText">  <a href="../publications/microfilm.php">Margaret Sanger Papers Microfilm Edition</a></i>. See the index under article titles for specific citations.  The texts will be included in the forthcoming
<a href="../publications/electronic_ed/speeches_and_articles.php">Speeches and Articles of Margaret Sanger,1911-1959</a>.</i>   </p>
<p>The entire run of the <i>Birth Control Review</i> is also available on microfilm as part of the <i>History of Women</i> (Research Publications, reels 15-16) and was reprinted by DeCapo Press in 1970.</p>
<p>Issues published before 1923 are available in full-text format on <a href="http://books.google.com/books?id=k0IsAAAAYAAJ&dq=birth%20control%20review&pg=PP1#v=onepage&q&f=false">Google Books</a>.</p>

<A NAME="pamphlets"></A>
<H2>Pamphlets</H2>

<p><i>Family Limitation</i> (1914-1931) <br />Many versions of this pamphlet were created. and have been  microfilmed as part of the <a href="../publications/microfilm.php">Margaret Sanger Papers Microfilm Edition</a>, see index for specific citation.  </p>
<p><i>Dutch Methods of Birth Control</i> (1915)<br/>
Filmed as part of the <a href="../publications/microfilm.php">Margaret Sanger Papers Microfilm Edition</a>. This pamphlet is also available on our online edition, <span class="italicText"i><a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=101920.xml">Dutch Methods</a></i> </p>

<p><i>English Methods of Birth Control</i> (1915)<br />Filmed as part of the <a href="../publications/microfilm.php">Margaret Sanger Papers Microfilm Edition</a>. Also avaialble in our online edition, <span class="italicText"i><a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=128063.xml">English Methods</a></i> </p>

<p><i>Magnetation Methods of Birth Control</i> (1915)<br />  Filmed as part of the <a href="../publications/microfilm.php">Margaret Sanger Papers Microfilm Edition</a> Also available in our online edition, <span class="italicText"i><a href="http://www.nyu.edu/projects/sanger/webedition/app/documents/show.php?sangerDoc=129014.xml">Magnetation Methods</a></i> </p>
</p>

<a name="video"></a>
<h2>Audio and Video</h2>

<p><a href="http://www.nyu.edu/projects/sanger/documents/this_i_believe.php">"This I Believe"</a> 1953 radio speech</p>
<p><a href="http://www.hrc.utexas.edu/collections/film/holdings/wallace/">Television interview on the "Mike Wallace Interview," 1957</a></p>

<A NAME="biblio"></A>
<H2>Bibliographies</H2>

<p>For a complete list of Sanger's writings, see the <a href="../publications/microfilm.php">Margaret Sanger Papers Microfilm Edition</A>, Subseries 4.</p> 

<p>See also Ronald and Gloria Moore, <i>Margaret Sanger: A Bibliography, 1911-1984.</i> Metutchen: Scarecrow Press, 1986, though not all articles have been included.</p> 

</div>

	
	