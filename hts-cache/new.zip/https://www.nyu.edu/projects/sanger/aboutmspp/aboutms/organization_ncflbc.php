
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="../images/logo.png"></a> 
    
    <ul id="nav">
        
    
        </ul>
    
        </div>
        </div>
        <div id="main">
        <body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
 
	</div>
	</div>
		</div>
	
	
    <ul id="nav">
			
	
	<div id="wrap">
		<div id="header">
		<div align="left">

	<ul id="nav">
		<li>
			<a href="../aboutms/about.php">About Sanger</a>
			<ul>
				<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		</li>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The MSPP Project" class="selected">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About</a></li>
				<li><a href="../project/staff.php">Staff</a></li>
				<li><a href="../project/former_interns.php">Former Interns</a></li>
				<li><a href="../project/funders.php">Funders</a></li>
				<li><a href="../project/reviews.php">Reviews</a></li>
				<li><a href="../project/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../publications/about.php" title="Publications">Publications</a>
			<ul>
				<li><a href="../publications/about.php">About</a></li>
				<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../publications/image.php">Publications/On-Line Image Edition</a></li>
				<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				<li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/index.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		<li>
			<a href="../documents/about.php" title="Documents Online">Documents Online</a>
			<ul>
				<li><a href="../documents/index.php">About</a></li>
				<li><a href="../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		</li>
		<li>
			<a href="../research/index.php" title="Research Resources">Resources</a>
			<ul>
				<li><a href="../research/index.php">Research</a></li>
				<li><a href="../research/editorsnotes.php">Editor's Notes</a></li>
				<li><a href="../research/nhday.php">National History Day</a></li>
				<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
				<li><a href="../research/images.php">Sanger Images</a></li>
				<li><a href="../research/links.php">Links</a></li>
			</ul>
		</li>
		<li>
			<a href="../contactus.html" title="Contact Us">Contact Us</a>
		</li>
		
		</ul>
			
		</div>
		</div>
		<div id="main">
		
		
	
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>National Committee on Federal Legislation on Birth Control</h1>
<h2>History</h2>

<p>In November of 1928, the Illinois Birth Control League elected Margaret Sanger as temporary chairman of a new legislative committee organized to lobby for an amendment to the federal anti-obscenity laws that would legalize the distribution of contraceptives and contraceptive information through the mails. In the months that followed, Sanger and several supporters formulated plans to expand the Illinois League's proposed program into a national campaign, with headquarters in the Midwest. On April 30, 1929, following theannual meeting of the Illinois Birth Control League, Sanger formally ratified plans for the formation of a National Committee on Federal Legislation for Birth Control (NCFLBC), structured into four regions: East, South, Middle West, and West, and further divided by congressional districts. Committee organizers in Chicago elected Sanger national chairman, and set an agenda for the election of additional officers and congressional district chairman.</p>

<p>Margaret Sanger served as the National Chairman of the NCFLBC until it was incorporated in 1932, at which time she was named president. From 1929 until 1935, she concentrated her efforts on Committee work, shuttling between New York, where she continued to run the Birth Control Clinical Research Bureau (BCCRB), and Washington, D.C. where permanent NCFLBC headquarters were established in 1933. She also made frequent speaking tours throughout the country on behalf of the NCFLBC and organized several national conferences.</p>

<p>The NCFLBC set out to conduct a nationwide lobbying campaign using the pressure of public opinion to convince congressional representatives to sponsor or vote for an amendment to Section 211 and other sections of the Federal Penal Code, which classified contraceptive information and supplies as obscene material and made it unlawful to import contraceptives or send contraceptive information through the mails. The Committee's other primary goals were to educate the public about birth control and the need to amend the federal laws, and to secure the endorsements of medical associations, religious institutions, social-welfare groups, and other prominent organizations in the country.</p>

<p>The Committee's Washington office opened in the fall of 1929 with a small but committed staff that included several seasoned Washington lobbyists, who often worked in conjunction with the BCCRB staff in New York, where Sanger initially set up NCFLBC headquarters. The leadership of the Committee, consisting of Sanger and several veterans of the American Birth Control League, coordinated lobbying activities and outreach programs, including a sophisticated press campaign. By the end of 1929, the NCFLBC had nine officers, 91 chairman, and over 3,000 members.</p>

<p>NCFLBC staff, through tireless lobbying, convinced a handful of congressmen between 1929 and 1936 to sponsor legislation that would amend the anti-birth control measures of the Federal Penal Code. Several versions of these amendments, both a "Doctor's Bill" and a "States Rights Bill," went before various House and Senate committees during the seven years of the Committee's existence. Sanger and other Committee members, along with medical and legal experts, and religious leaders, testified in favor of the proposed amendments and testified against several anti-birth control bills that were also introduced but made little progress in Congress. Birth control legislation was seen as a liability by many congressman no matter which way they voted. A majority of Congress wanted to ignore the issue and shut their doors to Sanger and National Committee lobbyists. Furthermore, the Catholic Church assembled a vocal anti-birth control campaign and marshaled significant opposition to the NCFLBC through its own congressional lobbying. While a total of 10 bills were sponsored and six congressional hearings were held, only one Senate bill (S.1842) made it out of committee to a floor vote, where it passed but was immediately recalled.</p>

<p>The NCFLBC met greater success with its educational campaigns. Relying on its vast network of regional committees, the Committee organized over 1500 lectures around the country, held regional and local conferences, conducted extensive mail campaigns (an estimated 500,000 outgoing letters), released hundreds of circulars and flyers, and flooded the press with frequent releases, radio broadcasts and educational materials. The Committee succeeded in winning endorsements from close to 1000 regional, state and local organizations, including the American Civil Liberties Union, the American Association of University Women, the American Gynecological Society, the General Federation of Women's Clubs, and the General Council of Congregational and Christian Churches.</p>

<p>Unable to make headway in Congress, Sanger turned to the courts. In 1936, the U.S. Circuit Court of Appeals for the Second District rendered an historic decision in U.S. v. One Package, a test case instigated by Sanger in 1933 that challenged the legality of the confiscation by customs officials of a package of pessaries sent from Japan to Dr. Hannah Stone at the BCCRB. In his decision, Justice Augustus Hand asserted the rights of the physician in the legitimate use of contraceptives and eradicated the restrictions prohibiting the importation, sale or carriage by mail of contraceptive materials and information for medical purposes. Sanger publicized the decision widely, sending announcements to doctors throughout the country. Claiming victory for the NCFLBC, she disbanded the organization in April of 1937 in a victorious and celebratory spirit, obscuring the general inability of the NCFLBC to effect legislative change.</p>


<h2>Organizational Structure, Major departments and Committees</h2>

<b>Advisory Committees:</b>
<p>Medical and Legal Advisory Committees helped to formulate the proposed amendments to the Federal Penal Code, assisted with testimony given before congressional committees, advised on strategy in the U.S. v. One Package case, and were consulted on many other matters, including the dissolution of the Committee in 1937.</p>

<b>Board of Directors:</b>
<p>The national chairman/president served along with up to nine directors who were elected by the Active Members and managed the general affairs of the organization, including personnel and salaries. The Board of Directors also adopted and amended the by-laws.</p>

<b>Congressional Committee:</b>
<p>Consisted of Board of Directors and Active Members who helped draft the birth control bills and supervised the congressional lobbying campaigns.</p>

<b>Educational Department:</b>
<p>Established in February of 1935 to supervise press relations and publicity campaigns, and furnish written material for magazine and newspaper articles. The Department also ran an information service and library and book service.</p>

<b>Executive Committee:</b>
<p>A dual NCFLBC/BCCRB committee established in 1935 to help manage the affairs of both organizations while Sanger was abroad. The Executive Committee worked in concert with the Board of Directors.</p>

<b>Field Work:</b>
<p>Consisted of lobbying activities and educational work (lectures, meetings, interviews). Field workers were sent out by Washington headquarters staff or worked within a region to educate the membership, attract new members, and lobby congressional representatives. The number of field workers varied from a few to more than a dozen.</p>

<b>Headquarters:</b>
<p>From 1929 until 1933, the BCCRB in New York served as the national headquarters. An office was opened in Washington in 1929 and the national headquarters was officially moved there in 1933. A small staff conducted the national education campaigns, public relations and lobbying activities, and supervised regional education and lobbying work, also referred to as field work. The number of staff changed frequently, from 4 or 5 to a high of 14 or 15, and generally consisted of a legislative secretary, publication director, field workers (lobbyists), and various administrative</p>
staff.

<b>Membership:</b>
<p>There were three categories of membership: Active Members had voting rights and were elected by the Board of Directors; Contributing Members made a contribution of a dollar or more; Endorsing Members signed a petition or endorsed the work of the Committee in writing. An annual meeting was held for all Active Members.</p>

<b>New York Office (BCCRB):</b>
<p>The BCCRB served as the organizational headquarters until 1933. The BCCRB assisted with field work and educational activities primarily in the New York area, and helped to coordinate Sanger's work. Several BCCRB administrative staff also worked for the NCFLBC, including Sanger's secretaries. The Board of Managers of the BCCRB served as an auxiliary committee to the NCFLBC in 1932 to advise and help with fund-raising. The BCCRB's Motherhood Advice Bureau responded to the inquiries that came into the NCFLBC regarding birth control and sexuality.</p>

<b>Officers:</b>
<p>National chairman/president, several vice chairman/vice presidents, a secretary, and a treasurer.</p>

<p>Regions: Each region (East, West, Middle West, and South) was placed under the direction of a regional chairman who appointed state and congressional district chairman. District chairmen were responsible for organizing public sentiment and lobbying congressional representatives. Regions often held their own conferences, meetings and educational and lobbying campaigns.</p>

<p>The NCFLBC also included several other committees organized for fund-raising campaigns and conferences.</p>

<h2>Staff Members, Officers, Board Members, Chairman and Committee Members</h2>

<p><ul class="thin">
<li>Ackermann, Frances B. - Assistant Treasurer
<li>Alexander, Nell Wells - Field Worker/Lobbyist
<li>Andrews, George Reid - Field Worker/Lobbyist
<li>Ballard, Frederick A. - Legal Advisory Committee
<li>Barker, Marian B. - Board of Directors; Executive Committee
<li>Barney, J. Dellinger - Medical Advisory Committee
<li>Benjamin, Hazel C. - Librarian; Administrative Staff
<li>Berger, Rebecca - Administrative Staff
<li>Brashear, Roma - Administrative Staff; Research Assistant
<li>Brush, Dorothy Hamilton - Secretary; Board of Directors; Executive Committee
<li>Calhoun, Douglas A. - Field Worker/Lobbyist; Medical Advisory Committee
<li>Cameron, Helen Harper - Administrative Staff
<li>Carpenter, Helen Graham Fairbank - Vice Chairman
<li>Caulk, John R. -Medical Advisory Committee
<li>Chapman, Ross McC. - Medical Advisory Committee
<li>Cloud, Mrs. F. A. - Chairman, Southern Region
<li>Clyde, Ethel - Board of Directors; Chairman, Eastern Region
<li>Cook, Adelaide Pearson - Administrative Staff; Field Worker/Lobbyist
<li>Davidson, Doris - Field Worker/Lobbyist 
<li>Dick, Alexander C. - Legal Advisory Committee 
<li>Dickinson, Robert Latou - Medical Advisory Committee
<li>Dryden, Leila - Board of Directors
<li>Erdmann, John F. - Medical Advisory Committee 
<li>Ernst, Morris Leopold - Legal Advisory Committee
<li>Fairchild, Henry Pratt --Vice-President; Board of Directors
<li>Favill, John - Medical Advisory Committee
<li>Fosdick, Raymond B. - Legal Advisory Committee
<li>Fuhr, Lee Moerkerk - Field Worker/Lobbyist
<li>Fuld, Carrie B. F. - Vice-President; Board of Directors
<li>Goldstein, Rabbi Sidney E. - Board of Directors
<li>Gracey, Helen Countryman - Field Worker/Lobbyist
<li>Hagner, Francis R. - Medical Advisory Committee
<li>Hamilton, Ruth - Administrative Staff; Field Worker/Lobbyist
<li>Hanau, Stella Bloch - Publicity and Educational Director
<li>Hartwell, John Augustus - Medical Advisory Committee
<li>Haynes, John Randolph - Vice Chairman/Vice President
<li>Heck, Constance S. - Field Worker/Lobbyist
<li>Hepburn, Katharine Houghton - Legislative Chairman; Board of Directors
<li>Hill, Louise B. - Chairman, Southern Region
<li>Hinman, Frank - Medical Advisory Committee
<li>Holmes, Rev. John Haynes - Vice Chairman, Eastern Region
<li>Horsley, J. Shelton - Medical Advisory Committee
<li>Hosford, Maryan L. - Administrative Staff
<li>Hughston, Mary - Field Worker/Lobbyist
<li>Hunt, Dorothy - Vice Chairman/Vice President
<li>Ingraham, Clarence B. - Medical Advisory Committee
<li>Jelliffe, Smith Ely - Medical Advisory Committee; Vice Chairman, Eastern Region
<li>King, Mary Van Beuren - Chairman, Eastern Region
<li>Kingsbury, John Adams - Board of Directors
<li>Kleinman, Lucille - Administrative Staff
<li>Leong, Ellen F. - Territorial Chairman
<li>Levine, Sara - Administrative Staff
<li>Mann, Rabbi Louis L. - Board of Directors
<li>McChesney, Margaret M. - Secretary
<li>McCord, James R. - Medical Advisory Committee
<li>McGraw, Clara Louise - Administrative Staff; Field Worker/Lobbyist
<li>McGuire, Stuart - Medical Advisory Committee
<li>McKinnon, Edna Rankin - Field Worker/Lobbyist
<li>Meyer, Adolf - Medical Advisory Committee
<li>Moore, Hazel Z. - Legislative Secretary; Field Worker/Lobbyist
<li>Murray, Willa L. - Administrative Staff; Field Worker/Lobbyist
<li>Owen, Marguerite - Legislative Consultant
<li>Palache, Alice H. - Executive Secretary; Field Worker/Lobbyist
<li>Prather, Bess McDole - Field Worker/Lobbyist
<li>Pusey, William Allen - Medical Advisory Committee
<li>Randall, Alexander - Medical Advisory Committee
<li>Reed, Mary - Chairman, Western Region
<li>Rose, Florence - Administrative Staff; Field Worker/Lobbyist
<li>Rublee, Juliet Barrett - Board of Directors
<li>Rumsey, Mrs. Dexter P. - Vice Chairman/Vice President
<li>Sanger, Margaret - National Chairman/President; Board of Directors; Board of Managers
<li>Scribner, Blanche - Board of Directors
<li>Scribner, Charles Edwin - Legal Advisory Committee
<li>Shallenberger, W. F. - Medical Advisory Committee
<li>Simonds, Marion - Administrative Staff
<li>Slee, J. Noah - Treasurer; Board of Directors
<li>Smith, Gladys DeLancey - Field Worker/Lobbyist
<li>Stokes, John H. - Medical Advisory Committee
<li>Taussig, Frederick J.- Medical Advisory Committee
<li>Timme, Ida Haar - Vice Chairman/Vice President; Assistant Treasurer; Board of Directors; Executive Committee; Chairman, Eastern Region
<li>Toy, James Joseph - Field Worker/Lobbyist
<li>Tweed, Harrison - Legal Advisory Committee
<li>Upham, John H. J. - Chairman, Middle Western Region
<li>Van Dusen, Albert P. - Field Worker/Lobbyist
<li>Vaux, Norris W. - Medical Advisory Committee
<li>Welch, William Henry - Medical Advisory Committee
<li>Wickham, Bernice - Administrative Staff
<li>Wile, Ira Solomon - Board of Directors; Medical Advisory Committee
<li>Willson, Prentiss - Medical Advisory Committee
<li>Winternitz, Milton C. -- Medical Advisory Committee
<li>Wright, Cecil Damon - Assistant Treasurer; Administrative Staff
<li>Zborowski, Hazel M. - Administrative Staff
</ul>
</p>

<h2>Related Sources</h2>

<p>The Library of Congress microfilm contains the largest collection of NCFLBC organizational records (reels 40-111), including minutes, assorted reports, personnel files, and a voluminous states file, and is the best source for locating material on the regions and congressional districts, as well as endorsing organizations. The Collected Documents Series has a small assortment of Committee publications, including form letters, reports and other material, as well as some correspondence with Committee members. The Smith College Collections Series contains incomplete minutes, numerous reports (annual, summary, congressional), form letters, newsletters and publications, as well as correspondence related to the NCFLBC, including Sanger's letters to and from staff, officers, chairmen, congressional representatives and officials of endorsing organizations. See also correspondence between Sanger and George Aubrey Hastings of Tamblyn and Tamblyn (a consulting firm that assisted with NCFLBC fund-raising), and Guy Irving Burch of the Population Reference Bureau who assisted with the congressional
campaign.</p>

<p><b>For other organizations involved with the NCFLBC, see:</b>
<ul class="thin-indent">
<li>BCCRB for records related to NCFLBC's initial headquarters and its New York office; cooperative activities; the Auxiliary Committee of the NCFLBC (formed by the defunct board of managers of the BCCRB); shared Executive Committee (1935-1937) and staff members who worked for both organizations.
<li>BCIIC for records of Sanger's international activities during her tenure as national chairman/president of the NCFLBC, which was also affiliated with the BCIIC.
</ul>
</p>

<p><b>For conferences sponsored by or associated with the NCFLBC, see:</b>
<ul class="thin-indent">
<li>1929 Middle Western States Conference on Birth Control
<li>1929 Eastern Regional States Conference
<li>1930 Western States Conference on Birth Control and Population Problems
<li>1934 American Conference on Birth Control and National Recovery
<li>1935 Birth Control Comes of Age Anniversary Dinner
<li>1936 Conference on Contraceptive Research and Clinical Practice
<li>1937 Regional Conference of Western States (Proposed)
</ul>
</p>

<p><b>For luncheons and dinners sponsored by or associated with the NCFLBC, see:</b>
<ul class="thin-indent">
<li>1930 Julian Huxley Luncheon
<li>1931 H. G. Wells Dinner
<li>1932 Testimonial Dinner to Margaret Sanger
</ul>
</p>

<p><b>For legal records associated with the NCFLBC, see:</b>
<ul class="thin-indent">
<li>U. S. v. One Package
</ul>
</p>

<p><b>For legislative bills sponsored by the NCFLBC, see:</b>
<ul class="thin-indent">
<li>1930 71st Congress S.4582 (Gillett)
<li>1932 72nd Congress H.R.11082 (Hancock)
<li>1932 72nd Congress S.4436 (Hatfield)
<li>1933 73rd Congress S.1842 (Hastings)
<li>1933 73rd Congress H.R.5978 (Pierce)
<li>1935 74th Congress H.R.5370 (Higgins)
<li>1935 74th Congress S.600 (Hastings)
<li>1935 74th Congress H.R.2000 (Pierce)
<li>1935 74th Congress H.R.5600 (Pierce)
<li>1936 74th Congress H.R.11330 (Gassaway)
<li>1936 74th Congress S.4000 (Copeland)
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>

