
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="../images/logo.png"></a> 
    
    <ul id="nav">
        
    
        </ul>
    
        </div>
        </div>
        <div id="main">
        <body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
 
	</div>
	</div>
		</div>
	
	
    <ul id="nav">
			
	
	<div id="wrap">
		<div id="header">
		<div align="left">

	<ul id="nav">
		<li>
			<a href="../aboutms/about.php">About Sanger</a>
			<ul>
				<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		</li>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The MSPP Project" class="selected">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About</a></li>
				<li><a href="../project/staff.php">Staff</a></li>
				<li><a href="../project/former_interns.php">Former Interns</a></li>
				<li><a href="../project/funders.php">Funders</a></li>
				<li><a href="../project/reviews.php">Reviews</a></li>
				<li><a href="../project/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../publications/about.php" title="Publications">Publications</a>
			<ul>
				<li><a href="../publications/about.php">About</a></li>
				<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../publications/image.php">Publications/On-Line Image Edition</a></li>
				<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				<li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/index.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		<li>
			<a href="../documents/about.php" title="Documents Online">Documents Online</a>
			<ul>
				<li><a href="../documents/index.php">About</a></li>
				<li><a href="../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		</li>
		<li>
			<a href="../research/index.php" title="Research Resources">Resources</a>
			<ul>
				<li><a href="../research/index.php">Research</a></li>
				<li><a href="../research/editorsnotes.php">Editor's Notes</a></li>
				<li><a href="../research/nhday.php">National History Day</a></li>
				<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
				<li><a href="../research/images.php">Sanger Images</a></li>
				<li><a href="../research/links.php">Links</a></li>
			</ul>
		</li>
		<li>
			<a href="../contactus.html" title="Contact Us">Contact Us</a>
		</li>
		
		</ul>
			
		</div>
		</div>
		<div id="main">
		
		
	
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>Birth Control International Information Centre</h1>
<h2>History</h2>

<p> A birth control information center was established
in London in 1928 under the direction of Edith How-Martyn. In 1930, following the Seventh
International Conference on Birth Control in Zurich, the center was re-organized as the Birth Control International Information Centre (BCIIC), with Margaret Sanger as president and Edith How-Martyn as director. The BCIIC merged with the National Birth Control Association of England (name later changed to the Family Planning Association of England) in 1938, which continued much of the international agenda of the Centre until the formation of the International Committee on Planned Parenthood in 1948.</p>

<p>The stated purpose of the BCIIC was to "spread the knowledge of birth control all over the world." In effect, the Centre acted as a clearinghouse for birth control information, responding to inquiries regarding the location of clinics, availability and effectiveness of particular contraceptives, methods, and legal restrictions. The Centre published numerous pamphlets, transcriptions of speeches, newsletters, bulletins and other information about contraception, new research and clinic updates. The BCIIC coordinated international birth control activities (the organization of clinics and conferences) with the help of correspondents in over 30 countries. Centre staff also arranged for visitors to tour clinics in London and New York, and hosted weekly meetings in London with guest speakers from various countries.</p>

<p>The BCIIC sponsored several tours for birth control, including Sanger's tour of Scandinavia and the Soviet Union in 1934, Edith How-Martyn's tour of India in 1934, and Sanger and How-Martyn's World Tour for Birth Control in 1935-1936, during which they spoke to numerous groups and organized birth control organizations in India, Burma, Malay, China, the Philippines, Japan, Hawaii, Canada, and the West Coast of the U.S. A record of their tour was published in 1937 under the title Round the World for Birth Control.</p>

<p>Sanger used the BCIIC to help shape an international identity as the leader of the birth control movement and create a network of doctors, social workers and clinics that would follow her basic program for medically-supervised contraceptive dissemination and careful follow-up work. However, she acted largely as a consultant to the Centre, leaving daily operations of the BCIIC in the hands of Edith How-Martyn. In 1937 Sanger decided she would not be able to effectively run the organization from the U. S. and resigned as president. She was replaced by Lord Thomas Horder. How-Martyn also left the BCIIC before its absorption into the National Birth Control Association and retired to Australia.</p>

<h2>Organizational Structure</h2>

<p>The BCIIC consisted of a president, director, treasurer, secretary, and advisory council. The Centre also retained correspondents in over 30 countries. A Special Efforts group was established in the early 1930s to undertake fund-raising campaigns.</p>

<h2>BCIIC Council, Staff and Officers</h2>

<p>Names of Board members who served as State Representatives are followed by their state.</p>

<p><ul class="thin">
<li>	Glass, David S.- Council
<li>    Guy, Gerda S. - Treasurer; Honorary Treasurer
<li>    Guy, John Henry - Council
<li>    Horder, Lord Thomas Mervyn - President
<li>    Hawarden, Eleanor A. - Organizing Secretary
<li>    How-Martyn, Edith - Director; Honorary Director
<li>    Johnson, Olive M. - Office Secretary
<li>    Laski, Frida - Council
<li>    Lewin, Julius - Council
<li>    Newfield, Maurice - Honorary Director
<li>    Rama Rau, Lady Dhanvanthi - Council
<li>    Rathbone, Eleanor - Council
<li>    Sanger, Margaret - President; Honorary President
</ul>
</p>

<h2>Related Sources</h2>

<p>There is no extensive collection of BCIIC records. Newsletters, a good deal of correspondence (most of it between Sanger and How-Martyn), and other information on the Centre can be found in the Collected Documents Series. A copy of the Sanger/How-Martyn pamphlet, Round the World for Birth Control, as well as press releases, a statement of policy, some pertinent correspondence, and additional newsletters are contained in the Smith College Collections Series. The Library of Congress microfilm contains information on international work from 1930-1938 in the foreign files on reels 11-20. For additional information on the relationship between the National Birth Control Association of England (Family Planning Association of England) and the BCIIC, see the Records of the British Family Planning Association at the Wellcome Institute on the History of Medicine. In addition, the Margaret Sanger Papers in the Sophia Smith Collection at Smith College includes foreign files related to the BCIIC's work, and publications distributed by the BCIIC that were not filmed in this edition. The <i>Birth Control Review</i> also frequently published updates on international activities sponsored by the BCIIC and summaries of Sanger's world travels.</p>

<p><b>For other organizations involved with the BCIIC, see</b>:<br>
<ul class="thin-indent">
<li>BCCRB and NCFLBC for records related to Sanger's travels and international work while president and honorary president of the BCIIC
</ul>
</p>

<p><b>For conferences sponsored by the BCIIC, see</b>:<br>
<ul class="thin-indent">
<li>1933 Conference on Birth Control in Asia
</ul>
</p>

<p><b>For Sanger's travel journals related to BCIIC-sponsored trips, see</b>:<br>
<ul class="thin-indent">
<li>Diaries and Journals (China Journal, Wardha India Journal, India Journal, Russia Journal)
</ul>
</p>

<p><b>For miscellaneous materials related to international travels, see</b>:<br>
<ul class="thin-indent">
<li>Itineraries, Tours &amp; Posters, 1930-1938
<li>Calendars, Datebooks, &amp; Appointment Books, 1930-1938
<li>Transcripts of Conversations and Interviews, 1930-1938
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>

