
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="../images/logo.png"></a> 
    
    <ul id="nav">
        
    
        </ul>
    
        </div>
        </div>
        <div id="main">
        <body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
 
	</div>
	</div>
		</div>
	
	
    <ul id="nav">
			
	
	<div id="wrap">
		<div id="header">
		<div align="left">

	<ul id="nav">
		<li>
			<a href="../aboutms/about.php">About Sanger</a>
			<ul>
				<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		</li>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The MSPP Project" class="selected">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About</a></li>
				<li><a href="../project/staff.php">Staff</a></li>
				<li><a href="../project/former_interns.php">Former Interns</a></li>
				<li><a href="../project/funders.php">Funders</a></li>
				<li><a href="../project/reviews.php">Reviews</a></li>
				<li><a href="../project/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../publications/about.php" title="Publications">Publications</a>
			<ul>
				<li><a href="../publications/about.php">About</a></li>
				<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../publications/image.php">Publications/On-Line Image Edition</a></li>
				<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				<li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/index.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		<li>
			<a href="../documents/about.php" title="Documents Online">Documents Online</a>
			<ul>
				<li><a href="../documents/index.php">About</a></li>
				<li><a href="../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		</li>
		<li>
			<a href="../research/index.php" title="Research Resources">Resources</a>
			<ul>
				<li><a href="../research/index.php">Research</a></li>
				<li><a href="../research/editorsnotes.php">Editor's Notes</a></li>
				<li><a href="../research/nhday.php">National History Day</a></li>
				<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
				<li><a href="../research/images.php">Sanger Images</a></li>
				<li><a href="../research/links.php">Links</a></li>
			</ul>
		</li>
		<li>
			<a href="../contactus.html" title="Contact Us">Contact Us</a>
		</li>
		
		</ul>
			
		</div>
		</div>
		<div id="main">
		
		
	
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>Birth Control Council of America</h1>
<h2>History</h2>

<p>The Birth Control Council of America (BCCA) was formed in 1937 to coordinate the activities of the American Birth Control League (ABCL) and the Birth Control Clinical Research Bureau (BCCRB), eliminate duplication of efforts, establish joint standards of affiliation of birth control clinics, and discuss new directions for the movement. The Council was established in the wake of the disbanding of the National Committee on Federal Legislation for Birth Control and the 1936 decision of the Federal Circuit Court of Appeals for the Second Circuit in the
<i>U.S. vs. One Package</i> case, effectively removing legal obstacles limiting the ability of doctors to import, disseminate and prescribe contraceptives.</p>

<p>With Margaret Sanger as chairman, the BCCA held a series of meetings in 1937 focusing much of the discussion on clinic affiliation and the amalgamation of the two birth control publications: The Birth Control Review and The Birth Control News. However, Council members could not agree on specific proposals or resolve disagreements regarding a joint publication. Sanger resigned as chairman in June of 1937 over the BCCA's ineffectiveness and lack of power. The Council disbanded, but several of its members reconvened in 1938 as the Joint Committee/ABCL and BCCRB to continue discussions between the two organizations and arrange and coordinate a merger.</p>

<h2>Organization and Members</h2>

<p>The Council consisted of nine members who met periodically in 1937.</p>
<p><ul class="thin">
<li>Fairchild, Henry Pratt - Vice-Chairman
<li>Goldstein, Rabbi Sidney E.
<li>Holden, Frederick C.
<li>Matsner, Eric M.
<li>Moore, Allison Pierce
<li>Sanger, Margaret - Chairman
<li>Stone, Abraham
<li>Stone, Hannah Mayer
<li>Wile, Ira Solomon
</ul></p>

<h2>Related Sources</h2>

<p>Sources on the BCCA are limited. Some scattered correspondence between Council members can be found in the Collected Documents Series. The Smith College Collections Series contains an incomplete file of BCCA minutes and some relevant correspondence. The Library of Congress microfilm contains a few documents related to the merger in 1939, but nothing specifically related to the BCCA.</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>

