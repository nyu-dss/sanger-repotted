
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / The Project</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>The Project</h1>			

<div class="maintext">
		
			
			
<p>The Margaret Sanger Papers Project is a historical editing project initially sponsored by the <a href="https://history.as.nyu.edu/object/estherkatz">Department of History</a> and then by 
the <a href="http://www.nyu.edu/academics/libraries.html">Division of Libraries</a> at <a href="https://www.nyu.edu/">New York University</a>. The Project was formed 
by <a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/esther_katz.php">Dr. Esther Katz</a> in 1985 to locate, arrange, edit, research, and publish the papers of the noted birth control pioneer.</p>

<p>The Margaret Sanger Papers Project has published a two-series microfilm edition, the <i>Margaret Sanger Papers<a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/publications/microfilm.php">Microfilm Edition:</a> 
<a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/publications/smith_series.php">Smith College Collections</a></i> and the <i><a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/publications/collected_documents.php">Collected Documents Series</a>Collected Documents Series.</i> Work on the Smith College Collections entailed the rearrangement and organization of over 50,000 
Sanger documents in the Margaret Sanger collection and seventeen other collections at the Sophia Smith Collection and Smith College Archives. 
Work on the Collected Documents Series included a ten-year international search of over 1,500 archives and private collections, photocopying material 
and organizing over 9,000 documents for publication. Both series have been published with a printed reel guide that includes an item-level index by
University Publications of America, now a division of <a href="http://cisupa.proquest.com/ws_display.asp?filter=upa_intermediate&item_id={8A05BFDC-6146-42E4-BC54-1D887B081E00}">Proquest</a>. </p>

<p>The Project completed a four-volume book edition, <i>The Selected Papers of Margaret Sanger</i> published by the <a href="http://www.press.uillinois.edu/books/catalog/74xsd6pe9780252074608.html">University of Illinois Press</a>University of Illinois Press. The 
volumes are subtitled <a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/publications/volume_i.php"><i>The Woman Rebel, 1900-1928</i></a>, <a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/publications/volume_ii.php"><i>Birth Control Comes of Age, 1928-1939</i>,</a>  <a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/project/..publications/volume_iii.php"><i>The Politics of Planned Parenthood, 
1939-1966</i>,</a> and <a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/publications/volume_iv.php">'Round the World for Birth Control, 1920-1959</a>.</p>

<p>The Project also published an electronic edition of a small sample of documents related to Sanger's <a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/aboutms/aboutmspp/publications/mswomanrebel.php"><i>Woman Rebel</i></a> and is 
currently working on a digital edition, <a href="http://sangerpapers.org/documents/aboutedition.php"><i>The Speeches and Articles of Margaret Sanger, 1911-1959</i></a>.</p>

<p>For more see <a href="../../../../Esther/AppData/Local/Temp/scp46597/www/sites/nyu.edu/htdocs/pages/projects/sanger/publications/publications.php">Publications</a></p>
 
  </div>
  </div>
</div>
 
	<div id="sidebar">
       
     <h2>Search</h2><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
	<h1>About the Project</h1>
		<div id="subnav">
		
		<!---LINKS (bold current section)--->
		<p><b><a href="../aboutmspp/project/index.php">About</a></b><br>
		    <a href="staff.php">Staff</a><br>
			<a href="former_interns.php">Former Interns</a><br>
		    <a href="funders.php">Funders</a><br>
		    <a href="../aboutmspp/..project/reviews.php">Reviews</a><br>
		    <a href="editing.php">Editing at the MSPP</a></p>
		<p><br>
          <!---END LINKS--->
		    
		  <!--END RIGHT HAND NAVIGATION--->

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
                        
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
