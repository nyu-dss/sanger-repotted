
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / Birth Control Organizations</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="../images/logo.png"></a> 
    
    <ul id="nav">
        
    
        </ul>
    
        </div>
        </div>
        <div id="main">
        <body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
 
	</div>
	</div>
		</div>
	
	
    <ul id="nav">
			
	
	<div id="wrap">
		<div id="header">
		<div align="left">

	<ul id="nav">
		<li>
			<a href="../aboutms/about.php">About Sanger</a>
			<ul>
				<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		</li>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The MSPP Project" class="selected">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About</a></li>
				<li><a href="../project/staff.php">Staff</a></li>
				<li><a href="../project/former_interns.php">Former Interns</a></li>
				<li><a href="../project/funders.php">Funders</a></li>
				<li><a href="../project/reviews.php">Reviews</a></li>
				<li><a href="../project/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../publications/about.php" title="Publications">Publications</a>
			<ul>
				<li><a href="../publications/about.php">About</a></li>
				<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../publications/image.php">Publications/On-Line Image Edition</a></li>
				<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				<li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/index.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		<li>
			<a href="../documents/about.php" title="Documents Online">Documents Online</a>
			<ul>
				<li><a href="../documents/index.php">About</a></li>
				<li><a href="../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		</li>
		<li>
			<a href="../research/index.php" title="Research Resources">Resources</a>
			<ul>
				<li><a href="../research/index.php">Research</a></li>
				<li><a href="../research/editorsnotes.php">Editor's Notes</a></li>
				<li><a href="../research/nhday.php">National History Day</a></li>
				<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
				<li><a href="../research/images.php">Sanger Images</a></li>
				<li><a href="../research/links.php">Links</a></li>
			</ul>
		</li>
		<li>
			<a href="../contactus.html" title="Contact Us">Contact Us</a>
		</li>
		
		</ul>
			
		</div>
		</div>
		<div id="main">
		
		
	
    
    <br><br>
    
    <h1>Birth Control Organizations</h1>
<div class="maintext">
<h1>Birth Control Review</h1>
<h2>History</h2>

<p>Margaret Sanger published the first issue of <em>The Birth Control Review</em> (BCR), "Dedicated to the Principle of Intelligent and Voluntary Motherhood," in New York City in February 1917. Sanger published the <em>Review</em> through its first year on revenues from newsstand sales, subscriptions, and donations from wealthy benefactors. In February of 1918, Sanger organized and incorporated the New York Women's Publishing Company (NYWPC) for the express purpose of financing the <em>Review</em>, as well as to promote the cause of birth control. Apart from financing and overseeing the publication of the Review, the NYWPC published a pamphlet, <em>Sayings of Others on Birth Control</em>, and reprints of articles in the <em>BCR</em>. The NYWPC was primarily the brain-child of Juliet Rublee, Sanger's close friend and benefactor, who provided the initial seed money and brought in several friends to purchase shares of the company. A thousand shares of stock were issued at ten dollars per share, and a board of directors was formed. The NYWPC assumed publication of the <em>BCR</em> with the May 1918 issue. The <em>BCR</em> continued to be published independently by the NYWPC until May of 1923 when the stockholders dissolved the company so that the <a href="organization_abcl.php">American Birth Control League</a> (ABCL) could absorb the <em>Review</em> as its major propaganda tool and "official organ."</p>

<p>The <em>BCR</em> chronicled the activities of the birth control movement and served as the chief source of information for supporters of birth control. Vigorous street sales and circulation campaigns made the Review available in nearly every state and boosted circulation to about 10,000 copies per issue by 1922. The success of the street sales was largely due to the efforts of street hawkers, most notably Kitty Marion, a British suffragist, who sold the <em>Review</em> in downtown New York City for 13 years. She became a well-known street figure, faced perpetual jeers and defiance, and was arrested several times for violating the obscenity laws, including a 1918 arrest for which she served 30 days in prison.</p>

<p>Sanger had first launched the <em>Review</em> with the significant assistance of Frederick Blossom, a young Socialist worker from Cleveland, who served as the managing editor of the first several issues. Their brief association ended in the summer of 1917 when Sanger accused Blossom of siphoning off <em>Review</em> revenues for which he could not account. Sanger pressed charges, and the affair touched off a debate within the Socialist Party, with many members accusing Sanger of betraying a fellow member. She eventually dropped the charges, though she remained bitterly convinced of Blossom's guilt.</p>

<p>As editor, Sanger used the <em>Review</em> as her own podium, publishing many of her own speeches throughout the late 1910s and 1920s, as well as articles on a wide array of topics from the need for birth control clinics to profiles of other birth control pioneers. All the while she updated her growing audience on the events of the movement and her own activities and travels organizing for birth control. She also induced an assortment of noteworthy figures, many of them friends, including Havelock Ellis, Crystal Eastman, Eugene Debs, Charles Drysdale, and Marie Stopes, among others, to contribute articles. Most issues contained artwork, political cartoons, poetry, book reviews, and a lively letters section that often included opposing views and sometimes "mothers letters," excerpts from the letters of women seeking birth control advice.</p>

<p>Margaret Sanger served as editor of the <em>BCR</em> until January 31, 1929 (seven months after her resignation as president of the ABCL), when she resigned as editor of the <em>Review</em> and simultaneously as a director of the ABCL. The ABCL continued to published the <em>BCR</em> in its original format until July of 1933, after which it produced a shorter monthly bulletin under the same name. The second incarnation of the <em>Review</em> ceased publication in January of 1940.</p>


<h2>Organizational Structure</h2>

<p><b>Circulation Staff:</b><br>
Consisted of a circulation manager and several street sellers. After 1923, the circulation of the Review was administered by the Subscription Department, part of the Publication Department of the ABCL. Other ABCL departments, including the Motherhood Advice Bureau and the Education Department, assisted with matters related to the Review.</p>

<p><b>Editorial Staff:</b><br>
Editor, managing editor, literary and art editors, and later associate editors. A secretary/treasurer served from 1917-1918.</p>

<p><b>New York Women's Publishing Company (NYWPC):</b><br>
President, treasurer, secretary, and board of directors who oversaw the publication of the BCR from 1918-1923.</p>


<h2>bcr and nwpc officers and staff</h2>

<p>Other members of the ABCL also worked on the Birth Control Review. See organizational history of ABCL for a list of names.</p>

<p><ul class="thin">
<li>    Ackermann, Frances B. - Treasurer, NYWPC  
<li>    Albert, Ruth - Circulation Manager  
<li>    Ashley, Anita - Corresponding Secretary  
<li>    Ashley, Jessie - Literary Editor; Board of Directors, NYWPC  
<li>    Barnes, Cornelia - Editor; Art Editor; Associate Editor  
<li>    Bjoerkman, Frances M. - Editor  
<li>    Blossom, Frederick A. - Managing Editor; Editor  
<li>    Boyd, Mary Sumner - Managing Editor  
<li>    Boyle, Gertrude - Art Editor  
<li>    Chamberlain, Mary - Board of Directors, NYWPC  
<li>    Chambers, Elizabeth M. F. - Board of Directors, NYWPC  
<li>    Colt, Elizabeth W. - Board of Directors, NYWPC  
<li>    Cothren, Marion B. - President, NYWPC; Board of Directors, NYWPC  
<li>    Dennett, Mary Ware - Board of Directors, NYWPC  
<li>    Edgren, Maude - Editor; Literary Editor  
<li>    Frier, ? - Sales  
<li>    Grandcourt, Genevieve - Sales  
<li>    Halton, Mary - Board of Directors, NYWPC  
<li>    Hanau, Stella Bloch - ABCL Administrative Staff; Publications Department  
<li>    Heidelberg, Virginia - Board of Directors, NYWPC  
<li>    Hersey, Harold Brainerd - Associate Editor  
<li>    Hyde, Virginia - Board of Directors, NYWPC  
<li>    Jack, Cerise Carman - Board of Directors, NYWPC  
<li>    Kennedy, Anne - Associate Editor  
<li>    Knoblauch, Mary B. - Editor; Literary Editor; Secretary, NYWPC; Board of Directors, NYWPC  
<li>    Levine, Sara - ABCL Administrative Staff  
<li>    Marion, Kitty - Sales  
<li>    McClement, ? - Sales  
<li>    Nieman, Sara E. - Recording Secretary  
<li>    O'Day, Caroline Goodwin - Board of Directors, NYWPC  
<li>    Porritt, Annie Webb - Managing Editor; Editor; Assistant Editor  
<li>    Ridge, Lola - Literary Editor  
<li>    Roberts, Walter Adolph - Editor; Literary Editor  
<li>    Rogers, Lou - Art Editor; Associate Editor  
<li>    Rublee, Juliet Barrett - Board of Directors, NYWPC; President, NYWPC  
<li>    Sanger, Margaret - Editor; Literary Editor; Board of Directors, NYWPC  
<li>    Schrack, Blanche - Editor; Associate Editor  
<li>    Spinney, Mrs. William - Board of Directors, NYWPC  
<li>    Stuyvesant, Elizabeth - Treasurer/Secretary; Editor  
<li>Tavis, D. E. - ABCL Administrative Assistant  
<li>    Todd, Helen - Board of Directors, NYWPC  
<li>    Tomkins, Sally Bates - Board of Directors, NYWPC  
<li>    Tuttle, Florence Guertin - Associate Editor; Board of Directors, NYWPC  
<li>    Williams, Gertrude - Literary Editor; Board of Directors, NYWPC  
<li>    Winner, Lily - Editor; Literary Editor  
<li>    Young, Virginia - Board of Directors, NYWPC
</ul>
</p>

<h2>Related Sources</h2>

<p>Correspondence and legal material on the <em>Review</em> and the Blossom dispute can be found in the  <a href="../../publications/collected_documents.php">Collected Documents Series</a>, along with "client" letters from women asking for birth control information which were reprinted in the <em>Review</em>. The <a href="../../publications/smith_series.php">Smith College Collections Series</a> contains reports and form letters of the <em> BCR</em> along with minutes and reports of the NYWPC. The <a href="../../publications/library_of_congress.php">Library of Congress microfilm</a> contains substantial material on the Blossom dispute and other material on the publication of the <em>Review</em>. The <em>BCR</em> was re-issued by De Capo Press in 1970 and is also available on microfilm as part of Research Publication's <i>History of Women Collection</i>, Reels 14-15.</p>

<p><b>For legal records associated with the <em>BCR</em>, see</b>:<br>
<ul class="thin-indent">
<li>Frederick Blossom/Margaret Sanger Dispute<br />
<li>State of New York v. Kitty Marion (<em>BIRTH CONTROL REVIEW</em>)     
</ul>
</p>

<p><b>For other organizations involved with the <em>BCR</em> and NYWPC, see</b>:<br>
<ul class="thin-indent">
<li>ABCL for records related to the <em>BCR</em>, 1923-1929<br />
</ul>
</p>

<p><b>For Sanger's writings while editor of the <em>Review</em>, see</b>:<br>
<ul class="thin-indent">
<li>Articles and Speeches, 1917-1929 (she also wrote articles for the <em>Review</em> in the 1930s)
</ul>
</p>

<br><br>

<a href="bc_organizations.php">&lt; Return to <b>Birth Control Organizations</b></a>

</div>

