
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / Microfilm Edition</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="../images/logo.png"></a> 
    
    <ul id="nav">
        
    
        </ul>
    
        </div>
        </div>
        <div id="main">
        <body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
 
	</div>
	</div>
		</div>
	
	
    <ul id="nav">
			
	
	<div id="wrap">
		<div id="header">
		<div align="left">

	<ul id="nav">
		<li>
			<a href="../aboutms/about.php">About Sanger</a>
			<ul>
				<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		</li>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The MSPP Project" class="selected">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About</a></li>
				<li><a href="../project/staff.php">Staff</a></li>
				<li><a href="../project/former_interns.php">Former Interns</a></li>
				<li><a href="../project/funders.php">Funders</a></li>
				<li><a href="../project/reviews.php">Reviews</a></li>
				<li><a href="../project/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../publications/about.php" title="Publications">Publications</a>
			<ul>
				<li><a href="../publications/about.php">About</a></li>
				<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../publications/image.php">Publications/On-Line Image Edition</a></li>
				<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				<li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/index.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		<li>
			<a href="../documents/about.php" title="Documents Online">Documents Online</a>
			<ul>
				<li><a href="../documents/index.php">About</a></li>
				<li><a href="../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		</li>
		<li>
			<a href="../research/index.php" title="Research Resources">Resources</a>
			<ul>
				<li><a href="../research/index.php">Research</a></li>
				<li><a href="../research/editorsnotes.php">Editor's Notes</a></li>
				<li><a href="../research/nhday.php">National History Day</a></li>
				<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
				<li><a href="../research/images.php">Sanger Images</a></li>
				<li><a href="../research/links.php">Links</a></li>
			</ul>
		</li>
		<li>
			<a href="../contactus.html" title="Contact Us">Contact Us</a>
		</li>
		
		</ul>
			
		</div>
		</div>
		<div id="main">
		
		
	
    
    <br><br>
    
    <h1>Microfilm Edition</h1>			

<div class="maintext">

<center><p>
<a href="https://www.nyu.edu/projects/sanger/publications/smith_series.php">Smith College Collections</a> / <a href="./collected_documents.php">Collected Documents</a> / <a href="./library_of_congress.php">Library of Congress</a><br />
</p></center>

<img border="1" src="ms_at_desk.jpg" align="right" width="199" height="240" style="margin-left: 15px;">
<p>The first goal of the Margaret Sanger Papers Project was to gather together her voluminous personal papers and make them readily available to the public. Preserving them on microfilm guaranteed their survival and enabled researchers who were not located at the repositories that held the collections to search
through the entire corpus of Sanger's Papers.</p>

<p>From 1986-1996, the Margaret Sanger Papers Project organized and microfilmed the Margaret Sanger papers in the Sophia Smith Collection at Smith College and from other respositories. We organized, assembled the documents, and produced astate of the art microfilm edition of
over 60,000 papers and records divided into two series: the <em><a href="./smith_series.php">Smith College Collections</a></em> and <em><a href="./collected_documents.php">Collected Documents</a></em>. <em>The Margaret Sanger Papers Microfilm Edition</em> (101 reels) was published in 1996 by University Publications of America (now <a href="http://cisupa.proquest.com/ws_display.asp?filter=upa_intermediate&item_id={8A05BFDC-6146-42E4-BC54-1D887B081E00}">Proquest</a>, with a printed reel guide and name and
title index to each series. Now available in over twenty-five libraries from Ankara to Detroit, the microfilm edition, enables chiefly scholars and students to make use of Sanger’s papers in their entirety.</p>

<p>In the 1940s, Margaret Sanger donating what she called her &quot;professional papers&quot; to the Library of Congress. In reality, this collection, much
as the &quot;personal&quot; one she donated to Smith College, documents both her professional and personal life, and neither one is complete on its own.
The <a href="./library_of_congress.php">Library of Congress </a> collection, was microfilmed in 1977, and the Sanger Project has completed a draft index to the Sanger documents on that microfilm (the reels also include records created by .
Sanger's birth control organizations). We are currently seeking funds to fully proofread, correct and integrated the Library of Congress index with the indexes produced for our two microfilm series. This integrated index, which we intend to make available on the World Wide Web, would provide access to the entire corpus of Sanger Papers, will be published by University
Publications of America. We  broadening access to the material. Eventually we hope to use it as the basis for a web-based version of the entire microfilm.</p>

<p> We continue to gather Sanger documents and anticipate issuing an addendum microfilm that will include these additional documents unearthed since 1996.</p>

</div>

