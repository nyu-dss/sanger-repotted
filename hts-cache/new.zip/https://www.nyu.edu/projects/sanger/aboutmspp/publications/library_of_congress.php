﻿
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP /  / Microfilm Edition: Library of Congress</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="../images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="../images/logo.png"></a> 
    
    <ul id="nav">
        
    
        </ul>
    
        </div>
        </div>
        <div id="main">
        <body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
 
	</div>
	</div>
		</div>
	
	
    <ul id="nav">
			
	
	<div id="wrap">
		<div id="header">
		<div align="left">

	<ul id="nav">
		<li>
			<a href="../aboutms/about.php">About Sanger</a>
			<ul>
				<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
				<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
				<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a>
				<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
			</ul>
		</li>
		<li>
			<a href="../aboutmspp/aboutmspp.php" title="The MSPP Project" class="selected">The Project</a>
			<ul>
				<li><a href="../aboutmspp/aboutmspp.php">About</a></li>
				<li><a href="../project/staff.php">Staff</a></li>
				<li><a href="../project/former_interns.php">Former Interns</a></li>
				<li><a href="../project/funders.php">Funders</a></li>
				<li><a href="../project/reviews.php">Reviews</a></li>
				<li><a href="../project/editing.php">Editing at the MSPP</a></li>
			</ul>
		</li>
		<li>
			<a href="../publications/about.php" title="Publications">Publications</a>
			<ul>
				<li><a href="../publications/about.php">About</a></li>
				<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
				<li><a href="../publications/image.php">Publications/On-Line Image Edition</a></li>
				<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				<li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
			</ul>
		</li>
		<li>
			<a href="../newsletter/about.php" title="Newsletter">Newsletter</a>
			<ul>
				<li><a href="../newsletter/index.php">About</a></li>
				<li><a href="../newsletter/articlelist.php">Article List</a></li>
			</ul>
		</li>
		<li>
			<a href="../documents/about.php" title="Documents Online">Documents Online</a>
			<ul>
				<li><a href="../documents/index.php">About</a></li>
				<li><a href="../documents/selected.php">Selected Writings</a></li>
				<li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
			</ul>
		</li>
		<li>
			<a href="../research/index.php" title="Research Resources">Resources</a>
			<ul>
				<li><a href="../research/index.php">Research</a></li>
				<li><a href="../research/editorsnotes.php">Editor's Notes</a></li>
				<li><a href="../research/nhday.php">National History Day</a></li>
				<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
				<li><a href="../research/images.php">Sanger Images</a></li>
				<li><a href="../research/links.php">Links</a></li>
			</ul>
		</li>
		<li>
			<a href="../contactus.html" title="Contact Us">Contact Us</a>
		</li>
		
		</ul>
			
		</div>
		</div>
		<div id="main">
		
		
	
    
    <br><br>
    
    <h1>Microfilm Edition: Library of Congress</h1>			

<div class="maintext">

<center><p>
<a href="smith_series.php">Smith College Collections</a> / <a href="collected_documents.php">Collected Documents</a> / <a href="library_of_congress.php">Library of Congress</a><br /><br />
</p></center>

<p>Margaret Sanger gave a massive collection of her papers to the Library of
Congress, which were microfilmed on 145 reels in 1977 by the Library.
These papers cover the years 1900-1966, but the major part of the collection is
concentrated between 1928-1940. The collection includes personal and
family correspondence, correspondence with international birth control leaders,
and the voluminous records of the National Committee for Federal Legislation on
Birth Control. Records of the American Birth Control League, the Birth
Control Clinical Research Bureau and other organizations, as well as many Sanger
speeches and articles are also included. The Library of Congress did not
microfilm the entire collection--there are some scrapbooks, clippings files and
other materials which can only be used in the Library of Congress's Manuscript
Reading Room.</p>

<p>The Sanger Papers Project has undertaken the task of indexing the Sanger
documents in this collection, and is currently seeking funding to proofread its
draft index and integrate it with the indexes to our two microfilm collections.</p>

<p>The Library of Congress produced a register to the papers and the microfilm,
which is available on its <a href="http://lcweb2.loc.gov/service/mss/eadxmlmss/eadpdfmss/1998/ms998010.pdf" target="_new">website</a>.</p>

</div>

