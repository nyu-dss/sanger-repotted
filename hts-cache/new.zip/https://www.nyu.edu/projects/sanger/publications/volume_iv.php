﻿
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Publications / <font style="font-size:97%">The Selected Papers of Margaret Sanger: Volume IV</font></title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications" class="selected">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1><font style="font-size:97%">The Selected Papers of Margaret Sanger: Volume IV</font></h1>			

<div class="maintext">

<h1>'Round the World for Birth Control, 1920-1966</h1>

<center>
<p><a href="volume_i.php">Volume I</a>  / <a href="volume_ii.php">Volume II</a>  / <a href="volume_iii.php">Volume III</a>  / <a href="volume_iv.php">Volume IV</a> / <a href="editorial_methods.php">Editorial Methods</a><br /><br /></p>
</center>

<p><img src="vol4cover.jpg" width="206" height="312" align="right" style="margin-left: 15px" /></p>

<p>Edited by Esther Katz</p>

<p>Peter C. Engelman and<br> Cathy Moran Hajo, <br>
Associate Editors</p>

<p>Volume IV is devoted to the most understudied and
least understood aspect of Sanger's career -- her international work.
Beginning with her visit to post-World War I Germany, it carries Sanger through her groundbreaking tour of Japan and China in 1922, her
1930s trips to the Soviet Union and India, and her several postwar trips to
Japan and India, the volume documents Sanger's active promotion of birth
control clinics throughout the world. Volume IV covers her interwar
travels to Europe and Asia, the historic 1927 World Population Conference in
Geneva, which Sanger organized, along with subsequent international birth
control conferences from 1930 to 1961, as well as the Birth Control
International Information Centre, a clearing-house for the exchange of ideas and
practical information. The volume also addresses Sanger's post World War II
revival of international support for birth control, documenting the backlash of
post-Holocaust rejection of the eugenics movement and the pro-natalist voices of
those whose populations were decimated by the war. It traces the
founding of the International Planned Parenthood Federation (IPPF) and
illustrates the relationships between population controllers and many feminist
and health-oriented birth controllers. The volume closes with Sanger's
efforts to maintain control over the direction of the IPPF even after her
resignation as president, not only by trying to choose her successor but by
attempting to ensure that the new leadership not ignore the primary importance
of a feminist-based commitment to birth control.</p>

<p>Volume IV was published by the University of Illinois Press in April 2016. It is also available in <a href="https://www.amazon.com/Selected-Papers-Margaret-Sanger-1920-1966-ebook/dp/B06XBTXHNP/ref=sr_1_4?s=books&ie=UTF8&qid=1535041381&sr=1-4&keywords=Selected+Papers+of+Margaret+Sanger">E-Book.</a></p>

<p><a target="_new" href="https://www.nyu.edu/projects/sanger/publications/V4toc.pdf">Table of Contents</a></p>
<p>&lt;h2&gt;Buy the Book!&lt;/h2&gt;</p>
<p><a href="https://www.amazon.com/Selected-Papers-Margaret-Sanger-Parenthood/dp/0252033728/ref=bseries_lb_0252033728">Volume IV: 'Round the World for Birth Control'</a></p>
<p>&nbsp;</p>
<hr>

</div>
</div>
	
<div id="sidebar">
		<h2>Search</h2>
	<script>
  (function() {
    var cx = '016619794450116726182:r0pm5z5tz6e';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  	})();
	</script>
	<gcse:searchbox-only></gcse:searchbox-only>

	<br><br>
	
		<div id="sidebar">
		<h2>Publications</h2>
	
		<div id="subnav">
		
		<!---LINKS (bold current section)--->
		<p><b><a href="index.php">About</a></b><br>
			<a href="book.php">Book</a><br>
			<a href="microfilm.php">Microfilm Edition</a><br>
		    <a href="microfilm-online.php">Online Microfilm</a><br>
			<a href="editorial_methods.php">Editorial Methods</a><br>
 	</p>
		<br>
          <!---END LINKS--->
		    
		  <!--END RIGHT HAND NAVIGATION--->
		
		</div>

		

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Publications</h1>
		<div id="subnav">
			<a href="../publications/index.php">About</a><br>
			<b><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></b><br>
			<a href="../publications/microfilm.php">The Microfilm Edition</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
