
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Documents Online / Documents on Other Sites</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online" class="selected">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Documents on Other Sites</h1>
<div class="maintext">

<p>
<img border="1" src="familylim.jpg" align="right" width="139" height="200" style="margin-left: 15px;"> 
Below are links to scholarly sites that have mounted documents (either 
transcriptions or digital images) written by Margaret Sanger. The Project 
has not proofread these documents, and is not responsible for the quality 
of the work. Any questions about them should be directed to the host sites.</p>
<p>Note that the documents on some of these sites are not necessarily the 
first or only version of articles or pamphlets. For full information on 
the various editions of Sanger's writings, see our microfilm. <a href="http://books.google.com/">Google Books</a> also may have full or limited access to Sanger authored books. </p>
<p>If you know of any sites not listed below, please <a href="mailto:sanger.papers@nyu.edu">contact the Project</a>.
</p>

<h3>Books, Articles and Pamphlets</h3>
<p><a target="_new" href="http://historymatters.gmu.edu/d/5084/">&quot;No Gods, No Masters</a>,&quot;
<span class="title">The Woman Rebel</span>, Mar. 1914 (transcription mounted by 
<a target="_new" href="http://historymatters.gmu.edu">History Matters</a>.)
</p>
<p><a href="http://pds.lib.harvard.edu/pds/view/2577621?n=1">Family Limitation</a>, New York: New Review, 1914 (image mounted by Harvard Open Collections). Though this is cited as 1914, we believe it to be a later version, likely the mid-1920s. </p>
<p><a href="http://pds.lib.harvard.edu/pds/view/2573366">The Case for Birth Control: A Supplementary Brief and Statement of Facts</a> (New York: Modern Art Print Co., 1917) (image mounted by Harvard Open Collections).</p>
<p><a target="_new" href="http://www.bartleby.com/1013/">Woman and the New Race</a>. New York: Brentanos, 1920 (transcription mounted by
<a target="_new" href="http://www.bartleby.com">Bartelby.com</a>)</p>
<p><a href="http://archive.lib.msu.edu/DMC/AmRad/whateverygirl1920.pdf">What Every Girl Should Know</a> (Springfield, Ill.: United Sales Co., 1920) </p>
<p><a href="http://pds.lib.harvard.edu/pds/view/3003757">What We Stand For: Principles and Aims of the American Birth Control League, Inc.</a> (New York, 1921). (Mounted by Harvard's Open Collections) </p>
<p><a target="_new" href="http://digital.library.upenn.edu/webbin/gutbook/lookup?num=1689">The
Pivot
of Civilization.</a> New York: Brentanos, 1922. (transcription mounted by Project Guttenberg)</p>
<p>Extract from <a target="_new" href="http://historymatters.gmu.edu/d/5083/">Motherhood in Bondage</a> New York: Brentanos, 1928.
(transcription 
mounted by <a target="_new" href="http://historymatters.gmu.edu">History Matters</a>)</p>
<p>&quot;<a target="_new" href="http://historymatters.gmu.edu/d/5082/">The Civilizing 
Force of Birth Control</a>&quot; in V. F. Calverton and S.D. Schmalhausen, eds. <span class="title">Sex in
Civilization</span>. New York: Garden City, 1929 (transcription 
mounted by <a target="_new" href="http://historymatters.gmu.edu">History Matters</a>). </p>
<p><a href="http://pds.lib.harvard.edu/pds/view/3928801">Laws Concerning Birth Control in the United States </a>(New York: National Committee on Federal Legislation for Birth Control, 1929). (Mounted by Harvard's Open Collections) </p>
<h3>Collections of documents:</h3>
<p>&quot;Birth Control&quot; in <a target="_new" href="http://digital.lib.msu.edu/">Michigan State University's Digital Sources Center</a>'s American Radicalism section, includes:</p>
<p><blockquote>
Family Limitation, 1917 (digital image)<br />
What Every Mother Should Know New York: Truth Publishing Co. 1921. (digital image) <br />
What Every Girl Should Know  New York: United Sales Co, 1920 (digital image) <br />
Debate Between Margaret Sanger and Winter Russell</a>.Girard, KS: Haldeman-Julius
Co. 1921. (digital image) <br />
What Every Girl Should Know. Girard, KS: Haldeman-Julius Co. 1922-3? 
(digital image).
</blockquote> 
</p><a target="_new" href="http://womhist.alexanderstreet.com/birth/doclist.htm">&quot;How Did the Debate Between Margaret Sanger and Mary Ware Dennett Shape the Movement to Legalize Birth Control?&quot;</a>
1999 editorial project by Melissa Doak and Rachel Brugger, posted on Alexander Street Press<a target="_new" href="http://womhist.alexanderstreet.com/projectmap.htm"></a>Women
and Social Movements in the United States, 1775-2000</a> website. The Alexander Street Press <a target="_new" href="https://search-alexanderstreet-com.proxy.library.nyu.edu/wass">Woman and Social Movements in the United States, 1600-2000</a> site  contains the following Sanger articles, as well as some
transcribed correspondence:</p>
<p><blockquote>

<li class="pad">"Hard Facts," <span class="title">Birth Control Review</span> (March 1919), pp 3-4. 

<li class="pad">"How Shall We Change the Law,"
<span class="title">Birth Control Review</span>, 3
(July 1919): 8-9. 

<li class="pad"> "A Birth Strike To Avert World Famine,"
<span class="title">Birth Control Review</span>, 4 (January 1920): 1. 

<li class="pad">"Editorial," <span class="title">Birth Control Review</span> (March 1921), pp. 1-2. 

<li class="pad">"Editorial," <span class="title">Birth Control
Review</span>, 5 (March 1921): 3-4. 

<li class="pad">"Unity!" <span class="title">Birth Control
Review</span>, 5 (November 1921): 3-4.</p>
</blockquote>

<p>See also <a href="https://womhist.alexanderstreet.com/katze/doclist.htm">"How Did Margaret Sanger's 1922 Tour of Japan Help Spread the Idea of Birth Control
and Inspire the Formation of a Japanese Birth Control Movement?" in <a href="https://womhist.alexanderstreet.com/projectmap.htm">Woman and Social Movements in the United States, 1600-2000.</a>
</p>

<p>There are also a number of <a href="https://search.alexanderstreet.com/wasi/browse/subject-person-page?ff%5B0%5D=subject_person_cato_facet%3Asanger%20margaret%2ASanger%2C%20Margaret%2C%201879-1966%7C810612">Sanger documents</a> included in the Alexander Street Press projects
<a href="https://proquest.libguides.com/WASI">Women and Social Movements International</a>, including an essay by Esther Katz entitled <a href="https://search.alexanderstreet.com/preview/work/bibliographic_entity%7Cbibliographic_details%7C2476937">Margaret Sanger and the International Birth Control Movement</a>
</blockquote>
</p>


</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Documents Online</h1>
		<div id="subnav">
			<a href="../documents/index.php">About</a><br>
			<a href="../documents/selected.php">Selected Writings</a><br>
			<a href="../documents/electroniced.php">Electronic Edition - Beta</a><br>
			<a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a><br>
			<b><a href="../documents/othersites.php">Documents on Other Sites</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
	