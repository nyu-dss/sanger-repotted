﻿
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Publications / <font style="font-size:97%">The Selected Papers of Margaret Sanger: Volume III</font></title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications" class="selected">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1><font style="font-size:97%">The Selected Papers of Margaret Sanger: Volume III</font></h1>			

<div class="maintext">

<h1>The Politics of Planned Parenthood (1939-1966)</h1>

<center>
<p><a href="volume_i.php">Volume I</a> / <a href="volume_ii.php">Volume II</a> / <a href="volume_iii.php">Volume III</a> / <a href="volume_iv.php">Volume IV</a> / <a href="editorial_methods.php">Editorial Methods</a><br /><br /></p>
</center>

<p><img src="vol3cover.jpg" width="200" height="308" align="right" style="margin-left: 15px;"/>

<p>Edited by Esther Katz</p>

<p>Cathy Moran Hajo and Peter C. Engelman,<br />
Assistant Editors</p>

<a href="../project/reviews.php">Click here for Reviews and Comments.</a></p>

<p>Volume III begins with the outbreak of war in Europe,
Sanger's initial opposition to American entry and her worry over her two
sons serving in the armed forces. The war years were quiet ones for her, as
she officially retired from the Birth Control Federation of America (renamed
Planned Parenthood Federation of America in 1942) and moved to Tucson to tend
her ailing husband. But Sanger's continuing efforts to direct the birth
control movement from afar according to her beliefs ran into opposition from
BCFA leaders in New York. The divisive issues include the Negro Project, which
Sanger hoped would bring birth control service to African-American women in
the rural South through education undertaken by black community leaders,
doctors and nurses; to clashes over Sanger's opposition to the
transformation of birth control clinics into women's health and infertility
centers. In the post-war years Sanger concentrated on the pursuit of her
decades-long dream of finding an effective non-barrier method of birth
control. This volume will trace Sanger's masterful direction of scientists,
philanthropists and birth control bureaucrats to combine forces toward the
development of the first birth control pill, released in 1960. The volume will
conclude with Sanger's final years in which she surveyed and evaluated her
life and work. In particular, her letters regarding the disposition of her
papers and her correspondence with biographer Lawrence Lader provide an apt
summary of her career.</p>

<p>This volume was published in June 2010 by  the
<a href="http://www.press.uillinois.edu/books/catalog/54myn9qx9780252033728.html">University of Illinois Press</a>.</p>

<h2>Table of Contents</h2>
<p>Consult the table of contents in <a href="http://www.nyu.edu/projects/sanger/images/V2toc.pdf">PDF format</a>.</p>

<h2>Buy the Book!</h2>
<p><a href="http://www.amazon.com/Selected-Papers-Margaret-Sanger-Volume/dp/0252033728/"><img src="../images/amazonbuy.gif"></a></p>

</div>
</div>
	
<div id="sidebar">
		<h2>Search</h2>
	<script>
  (function() {
    var cx = '016619794450116726182:r0pm5z5tz6e';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  	})();
	</script>
	<gcse:searchbox-only></gcse:searchbox-only>

	<br><br>
	
		<div id="sidebar">
		<h2>Publications</h2>
	
		<div id="subnav">
		
		<!---LINKS (bold current section)--->
		<p><b><a href="index.php">About</a></b><br>
			<a href="book.php">Book</a><br>
			<a href="microfilm.php">Microfilm Edition</a><br>
		    <a href="microfilm-online.php">Online Microfilm</a><br>
			<a href="editorial_methods.php">Editorial Methods</a><br>
 	</p>
		<br>
          <!---END LINKS--->
		    
		  <!--END RIGHT HAND NAVIGATION--->
		
		</div>

		


</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Publications</h1>
		<div id="subnav">
			<a href="../publications/index.php">About</a><br>
			<b><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></b><br>
			<a href="../publications/microfilm.php">The Microfilm Edition</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
