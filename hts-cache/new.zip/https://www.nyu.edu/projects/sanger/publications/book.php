
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / Publications / The Selected Papers of Margaret Sanger</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications" class="selected">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>The Selected Papers of Margaret Sanger</h1>			

<div class="maintext">

<center>
<h1>The Selected Papers of Margaret Sanger - 4 Volumes</h1>
</center>

<center>
<a href="volume_i.php">Volume I</a> / <a href="volume_ii.php">Volume II</a> / <a href="volume_iii.php">Volume III</a> / <a href="volume_iv.php">Volume IV</a> / <a href="editorial_methods.php">Editorial Methods</a><br /><br />
</center>



<p>Edited by Esther Katz</p>

<p>Cathy Moran Hajo and Peter C. Engelman,<br />
Associate Editors</p>


The four volumes of <i>The Selected Papers of Margaret Sanger</i> were published by the <a href="https://www.press.uillinois.edu/books/catalog/74xsd6pe9780252074608.html">University of Illinois Press</a>:

    Volume I: The Woman Rebel, 1900-1928

    Volume II: Birth Control Comes of Age, 1928-1939

    Volume III: The Politics of Planned Parenthood, 1939-1966

    Volume IV: Round the World for Birth Control, 1920-1966

    Editorial Methods used in the Sanger volumes.


<h2>Table of Contents</h2>
<p>Consult the table of contents in <a href="http://www.nyu.edu/projects/sanger/images/V2toc.pdf">PDF format</a>. </p>

<h2>Buy the Book!</h2>

<p><a href="https://www.amazon.com/gp/bookseries/B01B27G3WI/ref=dp_st_0252031377"></a><img src="../images/amazonbuy.gif"></a></p>
<p>&nbsp;</p>
</div>
	<!---END CONTENT--->
			
		  </div>
			</div>

		<div id="sidebar">
		<h1>Search</h1>
	<script>
 	(function() {
    var cx = '016619794450116726182:r0pm5z5tz6e';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
    '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  	})();
	</script>
	<gcse:searchbox-only></gcse:searchbox-only>

	<br><br>
	
		
		<h1>Publications</h1>
		<div id="subnav">
		
		<!---LINKS (bold current section)--->
		    <a href="index.php">About</a></b><br>
			<b><a href="book.php">Selected Papers of Margaret Sanger</a></b><br>
			<a href="microfilm.php">Microfilm Edition</a><br>
			<a href="microfilm-online.php">Online Microfilm</a><br>
			<a href="editorial_methods.php">Editorial Methods</a><br></p>
 			<br>
     		    
	</div>
		</div>
			<div id="mainend"></div>
		
		</div>
	
		<div id="footer">		
		
		<center>
		All contents copyright © The Margaret Sanger Papers. All rights reserved.
		</center>
			</div>
					
        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>Publications</h1>
		<div id="subnav">
			<a href="../publications/index.php">About</a><br>
			<b><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></b><br>
			<a href="../publications/microfilm.php">The Microfilm Edition</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
