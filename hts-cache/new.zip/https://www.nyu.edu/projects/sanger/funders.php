			

<div class="maintext">

<h3>We would like to acknowledge and thank our major funders:</h3>

<ul class="spaced">
<li><a href="http://acls.org/">American Council of Learned Societies</a>
<li><a href="http://www.marydukebiddlefoundation.org/">Mary Duke Biddle Foundation</a></li>
<li><a href="http://fdncenter.org/grantmaker/bingham/">William Bingham Foundation</a></li>
<li><a href="http://foundationcenter.org/grantmaker/brush/">The Brush Foundation</a></li>
<li>The Clayton Foundation</li>
<li><a href="http://www.colcomfdn.org/">Colcom Foundation</a></li>
<li><a href="http://www.cmwf.org/">Commonwealth Fund</a></li>
<li>Dickler Family Foundation</li>
<li>Lucius and Eva Eastman Foundation</li>
<li><a href="http://www.fordfound.org/">Ford Foundation</a></li>
<li><a href="http://www.furthermore.org/">Furthermore: a program of the J. M. Kaplan Foundation</a></li>
<li><a href="http://www.gundfdn.org/">George Gund Foundation</a></li>
<li><a href="http://www.hewlett.org/">William and Flora Hewlett Foundation</a></li>
<li>Joyce and Seward Johnson Foundation</li>
<li><a href="http://www.laskerfoundation.org">Albert and Mary Lasker Foundation</a></li>
<li>Joe &amp; Emily Lowe Foundation</li>
<li><a href="http://www.hluce.org/">Henry Luce Foundation</a></li>
<li><a href="http://www.mellon.org/">Andrew Mellon Foundation</a></li>
<li><a href="http://mep.cla.sc.edu/">Model Editions Partnership</a></li>
<li><a href="http://www.neh.gov/">National Endowment for the Humanities</a></li>
<li><a href="http://www.archives.gov/nhprc">National Historical Publications and Records Commission</a></li>
<li><a href="http://www.humanitiesinitiative.org/index.php/dhannouncements/114-digcomms-cfp">NYU Digital Commons</a></li>
<li><a href="http://www.nyu.edu/osp/funding/urcf.php">NYU Research Challenge Fund</a></li>
<li><a href="http://www.rockfound.org/">Rockefeller Foundation</a></li>
<li>Blanchette Hooker Rockefeller Fund</li>
<li><a  href="http://www.samuelrubinfoundation.org/">Samuel Rubin Foundation</a></li>
<li><a  href="http://www.skaggs.org/">L.J. and Mary C. Skaggs Foundation </a></li>
<li>The Sulzberger Foundation</li>
<li><a  href="http://www.hwwilson.com/">H.W. Wilson Foundation</a></li>
<li><a href="http://www.nathancummings.org/">Nathan Cummings Foundation</a></li>
<li>Anonymous</li>
</ul>

	</div>
		<!---RIGHT HAND NAVIGATION--->

		<div id="sidebar">
		<h2>Search</h2>
	<script>
  	(function() {
    var cx = '016619794450116726182:r0pm5z5tz6e';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  	})();
	</script>
	<gcse:searchbox-only></gcse:searchbox-only>

	<br><br>
	
		
	<h2>The Project</h2>
		<div id="subnav">
		
		<!---LINKS (bold current section)--->
		<p><b></b><a href="index.php">About</a></b><br>
		    <a href="staff.php">Staff</a><br>
			<a href="former_interns.php">Former Interns</a><br>
		    <a href="funders.php">Funders</a><br>
		    <a href="reviews.php">Reviews</a><br>
		    <a href="editing.php">Editing at the MSPP</a></p>
		     
		 <br>   
		 <!---END LINKKS--->

		  <!--END RIGHT HAND NAVIGATION--->
		
		</div>

