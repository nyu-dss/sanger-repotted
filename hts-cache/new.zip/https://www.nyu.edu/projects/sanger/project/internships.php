
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / The Project / Former Interns</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project" class="selected">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Former Interns</h1>			

<div class="maintext">

<p>We would like to thank all those who have assisted the Project over the years. At least two of our interns have gone on to take jobs as historical editors.  Unless noted, all interns worked at NYU in the summer months.</p>

<p><strong>2016</strong></p>
<li>Taylor Sullivan (Ramapo college of New Jersey)

<p><strong>2015</strong></p>
<ul>
<li>Misha Choudhry (Ramapo College of New Jersey)</li>
<li>Jacklyn Collens (Sarah Lawrence College)</li>
<li>Heather DeBel (Ramapo College of New Jersey)</li>
<li>Leeza Hirt (Columbia College)</li>
<li>Circe Johnson-Flenga (Lycee Francais de New York)</li>
<li>Himaja Rachakonda (New York University)</li>
<li>Angela Tan (New York University)</li>
</ul>

<p><strong>2014</strong></p>
<ul>
<li>Grace Afsari-Mamagani (New York University)</li>
<li>Sarah Corrado (Ramapo College of New Jersey)</li>
<li>Yvonne Garrett (Palmer School)</li>
<li>Kaitlin Hackbarth (Smith College)</li>
<li>Madeline Moran (State University of New York at Purchase)</li>
<li>Robin Pokorski (George Washington University)</li>
<li>Victoria Sciancalepore (Ramapo College of New Jersey)</li>
<li>Allie Strickler (University of Delware)</li>
</ul>

<p><strong>2013</strong></p>
<ul>
<li>Tyler Buckley (Ramapo College of New Jersey)</li>
<li>Emelie Coleman (Harvard University)</li>
<li>Jennifer Confortini (Ramapo College of New Jersey)</li>
<li>Lauren Halky (Palmer School) (Spring)</li>
<li>Jessica Kluge (Ramapo College of New Jersey)</li>
<li>Robin Pokorski (George Washington University)</li>
<li>Sabarish Raghupathy (University of Michigan)</li>
</ul>

<p><strong>2012</strong></p>
<ul>
<li>Molly Goldfarb (New York University) - Summer </li>
<li>Caroline Ruth Kahlenberg ( ) -Summer </li>
<li>Sydney B. Lakin (New York University) - Fall </li>
</ul>  

<p><strong>2011</strong></p>
<ul>
<li>Sarah Pinnington (University of Ottawa)</li>
<li>Leah Aronowsky (Research Associate, Columbia University) - Spring/Summer</li>
<li>Nicolette Calhoun (University of South Carolinia) - Summer</li>
<li>Nafisa Chowdhury (Bingahamton University) - Summer</li>
<li>Susana C. Delgadillo (NYU-Computer Science) - Fall</li>
<li>Chloe Edwards (University of Texas at Austin) - Summer </li>
<li>Theresia Kowara (Baruch College/CUNY) -Spring</li>
<li>Timothy Lindner (Ramapo College of NJ) - Fall </li>
<li>Devin McGinley (Ramapo College of NJ) - Spring </li>
<li>Rachel Pitkin (Queens College, CUNY) - Summer </li>
<li>Sarah Schoengold (New York University) - Spring</li>
<li>Ami E. Stearns (University of Oklahoma) - Summer </li>
<li>Madeleine Strohl (Yale University) - Summer </li>
<li>Rachel Tennant (University of North Carolina) - Summer</li>
</ul>

<p><strong>2010</strong></p>
<ul>
<li>Ashley Carvagno (Ramapo College of NJ) -Spring</li>
<li>Katelyn Davis (Smith College) </li>
<li>Jill Grimaldi (Ramapo College of NJ))-Fall</li>
<li>Nora Jager (University of Bremen) </li>
<li>Latoya Lee (SUNY Binghamton) </li>
<li>Andrew Lissenden (Rutgers University)</li>
<li>Samantha Pearlman (Whitman College) </li>
<li>Elizabeth Rieur (Simmons College) </li>
<li>Lesley Sideck (Ramapo College of NJ)-Spring</li>
<li>Erin Shaw (University of Chicago)</li>
<li>Elizabeth Stack (Fordham University)-Spring</li>
</ul>  

<p><strong>2009</strong></p>
<ul>
<li>Alison Channon (Brandeis University)</li>
<li>Mei-Ying Chiang (Rutgers University)</li>
<li>Alison C. Goldstein (Ramapo College of NJ)-Fall </li>
<li>Mackenzie Sheridan Kane (Concordia College) </li>
<li>Laura Larsell (University of Texas, Austin)</li>
<li>Patricia Nelson (University of Texas, Austin)</li>
<li>Darcy Rendon (Smith College)</li>
<li>Jennifer Sands (Arizona State University)</li>
<li>Tracey Spinato (Ramapo College of NJ)-Fall </li>
<li>Dagmar Wernitzning (Oxford University) -Fall </li>
</ul>

<p><strong>2008</strong></p>
<ul>
<li>Ellen Adams (College of William and Mary)</li>
<li>Rhonda Chadwick (Simmons College)</li>
<li>Mei-Ying Chiang (Rutgers University)</li>
<li>Victoria Christine Crowell (Centre College)</li>
<li>Carolyn Eberts (Bowling Green State University)</li>
<li>Melinda Lewis (Bowling Green State University)</li>
<li>Nana Robinette (University of Western Ontario) </li>
<li>Erick Zimmerman (Ramapo College of New Jersey) </li>
</ul>

<p><strong>2007</strong></p>
<ul>
<li>Christine Buckley (University of Colorado-Boulder)</li>
<li>Astrid Flikweert (Universiteit Utrecht) </li>
<li>Jackie Lynch (University of Texas at Austin)</li>
<li>William Mayfield (New York University)-Spring</li>
<li>Ashley Pattison (College of William and Mary) </li>
<li>Joshua Tapper (New York University - Spring)</li>
<li>Kevin Grant (Ramapo College of New Jersey - Spring)</li>
</ul>
<p><strong>2006</strong></p>
<ul>
<li>Nicole Venutolo (Ramapo College of New Jersey)--Spring</li>
<li>Carol Burbank (McGill University) </li>
<li>Laurel Halladay (University of Calgary)</li>
<li>Sylwia Kuzma (Polish Academy of Science)</li>
<li>Erin Miller (Willamette University)</li>
<li>Devin Segal</li>
<li>Exa Von Alt (Wheelock College) </li>
<li>Michael Clark (Ramapo College of New Jersey)-Fall</li>
</ul>  

<p><strong>2005</strong></p>
<ul>
<li>Michael Ferrante (Ramapo College of NJ) -Winter </li>
<li>Lauren Gargani (Ramapo College of NJ) -Winter</li>
<li>Dan Cun (Indiana University)</li>
<li>Edward Chung (Ramapo College of NJ)</li>
<li>Carla DeGironimo (Ramapo College of NJ)</li>
<li>Laura Miller (SUNY, Geneseo)</li>
<li>Jenna Silvers (Fordham University)</li>
<li>Susanna Joy Smith (Columbia University)</li>
</ul>

<p><strong>2004</strong></p>
<ul>
<li>Emily L. Conroy (Columbia University)</li>
<li>Sarah Lynn Crossley (Sarah Lawrence College) </li>
<li>Yvette F. Lane (Monmouth University) </li>
<li>Lauren Robertson</li>
<li>Caitlin Segal</li>
</ul>

<p><strong>2003</strong></p>
<ul>
<li>Jenna Anderson (Western Kentucky University)</li>
<li>Shane Butterfield (University of Rochester)</li>
<li>Rashidah Khalifa (College of New Jersey)</li>
<li>Valerie Olsen (DePaul University)</li>
<li>Susan M. Rensing (University of Minnesota)</li>
<li>Katherine Schugren-Meyer (University of California, Santa Barbara)</li>
</ul>

<p><strong>2002</strong></p>
<ul>
<li>Kate Aaby (University of Maryland)</li>
<li>Kelly Detrick (College of New Jersey)</li>
<li>Lori Duarte (St. Mary's University)</li>
<li>Katrin Hochst�tter (University of Cologne, Germany)</li>
<li>Christine Kosturski (College of New Jersey)</li>
</ul>

<p><strong>2001</strong></p>
<ul>
<li>Sarah Karp (Sarah Lawrence College)</li>
<li>Renee Klorman (Sarah Lawrence College)</li>
<li>Roberta A. McCutcheon (City University of New York, Graduate Center)</li>
<li>Eugenia Potter</li>
<li>Ramona Treuer (University of Minnesota, Duluth)</li>
</ul>

<p><strong>2000</strong></p>
<ul>
<li>Franck Dubois (Universite de Bourgogne, France)</li>
<li>Leigh Fought (University of Houston)</li>
<li>Rosanna Gabriele (University of Rochester)</li>
<li>Ivy Klenetsky (Rutgers University)</li>
<li>Jon S. Middaugh (Washington State University)</li>
<li>Emily Osborne (University of Virginia)</li>
<li>Zivah Perel (University of Delaware)</li>
<li>Viola Voss (Rutgers University)</li>
<li>Natalie Whittaker (University of Glasgow, Scotland)</li>
</ul>

<p><strong>1999</strong></p>
<ul>
<li>Heather Davis (Georgia College and State University)</li>
<li>Sarah Habich (Denison University)</li>
<li>Amy Hay (Michigan State University)</li>
<li>Carli Crozier Schiffner (University of Washington)</li>
</ul>

<p><strong>1998</strong></p>
<ul>
<li>Bernadette Boucher (Rutgers University)</li>
<li> Anastasia Curwood (Princeton University)</li>
<li> Lisa Hasday (Yale University)</li>
<li> Chris Nardi (Sarah Lawrence College)</li>
<li>Holly Piscopo (University of California at Santa Cruz)</li>
</ul>

<p><strong>1997</strong></p>
<ul>
<li>Gwendolyn Peroti (University of Amsterdam, Netherlands)</li>
<li>Marieke van Groot (University of Amsterdam, Netherlands)</li>
</ul>

<p><strong>1995</strong></p>
<ul>
<li>Leslie Fields (Smith College, MA) -- at Smith College</li>
<li>Saskia Rozier (The University of Utrecht, Netherlands)</li>
<li> Tracy Van Dorpe (Dartmouth College, NH)</li>
<li>Veronique von Weissenbruch (The University of Utrecht, Netherlands)</li>
</ul>

</div>


        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>The Project</h1>
		<div id="subnav">
			<a href="../project/index.php">About</a><br>
			<a href="../project/staff.php">Staff</a><br>
			<a href="../project/internships.php">Internships</a><br>
			<a href="../project/support.php">Support</a><br>
			<a href="../project/funders.php">Funders</a><br>
			<a href="../project/reviews.php">Reviews</a><br>
			<a href="../project/editing.php">Editing at the MSPP</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
