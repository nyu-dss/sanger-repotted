<html lang="en">
<head>
 
  <meta charset="utf-8">
  <title>MSPP / The Project / About</title>
 
 <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href="//fonts.googleapis.com/css?family=PT+Sans|Lato" rel="stylesheet" type="text/css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
	</head>

<body>
	
	<div id="top">
    <div style="width: 1000px;">
  	<a href="//www.nyu.edu"><img src="../images/nyulogo.png" width="170" height="50" title="New York University" style="float: left;"></a>
	
				
  <div style="float: right;">
    <a href="https://www.facebook.com/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="../images/facebook.png" width="25" height="50"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="../images/twitter.png" width="25" height="50"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="center">
          <a href="../index.php"><img src="../images/logo.png" width="682" height="100"></a>
         
	 <ul id="nav"> 		 
  	    	<li>
			  <div align="left"><a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		          <ul>
		            <li><a href="../aboutms/msbio.php">Biographical Sketch</a></li>
		            <li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		            <li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		            <li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
	            </ul>
		      </div>
  	    	</li>

		<li>
			    <div align="left"><a href="index.php" title="The Project" class="selected">The Project</a>
			        <ul>
				      <li><a href="staff.php">Staff</a></li>
				      <li><a href="../former_interns.php">Former Interns</a></li>
		              <li><a href="../funders.php">Funders</a></li>
			          <li><a href="../reviews.php">Reviews</a></li>
			          <li><a href="../editing.php">Editing at the MSPP</a></li>
			        </ul>
	      </div>
		</li>
		<li>
			<div align="left"><a href="../publications/index.php" title="Publications">Publications</a>
			    <ul>
					<li><a href="../publications/book.php">Books -- Selected Papers of Margaret Sanger</a></li>
					<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
				    <li><a href="../publications/microfilm-online.php">On-Line Microfilm</a></li>
				    <li><a href="../publications/electroniced.php">The Speeches and Articles Digital Edition</a></li>
					<li><a href="../publications/editorial_methods.php">Editorial Methods</a></li>
		      </ul>
		  </div>
		</li>
		<li>
			<div align="left"><a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
			    <ul>
				    <li><a href="../newsletter/index.php">About</a></li>
				    <li><a href="../newsletter/articlelist.php">Article List</a></li>
		      </ul>
		  </div>
		</li>
		<li>
			<div align="left"><a href="../documents/index.php" title="Documents Online">Documents Online</a>
			    <ul>
				    <li><a href="../documents/index.php">About</a></li>
				    <li><a href="../documents/selected.php">Selected Writings</a></li>
				    <li><a href="../documents/electroniced.php">Electronic Edition</a></li>
				    <li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
				    <li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		      </ul>
		  </div>
		</li>
		<li>
			<div align="left"><a href="../research/index.php">Resources</a>
			    <ul>
				    <li><a href="../research/research.php">Research</a></li>
				    <li><a href="../research/nhday.html">National History Day</a></li>
				    <li><a href="../research/bibliography.html">Sanger Bibliography</a></li>
				    <li><a href="../research/images.php">Sanger Images</a></li>
				    <li><a href="../research/links.html">Links</a></li>
		      </ul>
		  </div>
		</li>
		<li>
			<div align="left"><a href="../contactus/index.php">Contact Us</a>
	      </div>
		</li>
		
		</ul>
		</div>
		</div>
	  <div id="main">
		
		<center>
		<img src="mainimage.png">
		</center>
				
			<h1>About the Project</h1>
							
		
				<!---BEGIN CONTENT--->
													
		<p>The Margaret Sanger Papers Project is a historical editing project initially sponsored by the <a href="https://as.nyu.edu/history.html">Department of History</a> and 
		then by the <a href="https://www.nyu.edu/academics/libraries.html">Division of Libraries</a> at <a href="https://www.nyu/edu">New York University</a>. The Project was formed 
		by <a href="https://www.nyu.edu/projects/sanger/esther_katz.php">Dr. Esther Katz</a> in 1985 to locate, arrange, edit, research, and publish the papers of the
		 noted birth control pioneer.</p>
		 
				<p>The Margaret Sanger Papers Project has published a two-series microfilm edition, the <i><a href="../publications/microfilm.php">Margaret Sanger Papers Microfilm,</a></i>
				  <a href="https://www.nyu.edu/projects/sanger/publications/smith_series.php">Smith College Collections</a> and the 
				<a href="https://www.nyu.edu/projects/sanger/publications/collected_documents.php">Collected Documents Series</a>. Work on the Smith College Collections entailed the 
				rearrangement and organization of over 50,000 Sanger documents in the Margaret Sanger collection and seventeen other collections at the Sophia Smith Collection and 
				Smith College Archives. Work on the Collected Documents Series included a ten-year international search of over 1,500 archives and private collections, photocopying 
				material and organizing over 9,000 documents for publication. Both series have been published with a printed reel guide that includes an item-level index by University Publications 
				of America, now a division of <a href="https://www.proquest.com/">Proquest</a>. On online edition of the Project's micorfilm is available through Proquest's 
				<a href="http://proquest.libguides.com/historyvault/sanger">History Vault</a></p>
				
				<p>The Project has completed a four-volume book edition of Sanger's Papers, published by the <a href="http://www.press.uillinois.edu/" target="_new">University of 
				Illinois Press</a>.  The volumes are subtitled <i><a href="../publications/volume_i.php">The Woman Rebel, 1900-1928</a></i>, <i><a href="../publications/volume_ii.php">Birth Control Comes of Age, 1928-1939</a></i>,
				<a href="../publications/volume_iii.php">The Politics of Parenthood, 1939-1966</a></i>, and <i><a href="../publications/volume_iv.php">'Round the World for Birth Control,' 1920-1959</a>,</i> have been published.</p>

				<p>The Project also published an electronic edition of a small sample of documents related to Sanger's <a href="../publications/mswomanrebel.php">The Woman Rebel</a>.</p>
	
				<!---END CONTENT--->
			
			
			    <p>&nbsp;</p>
			    <p><img src="../images/neh_logo_horizontal_rgb.jpg" width="252" height="72" hspace="75">  <img src="../images/nhprc-download-1-m.jpg" width="318" height="90" hspace="90" align="middle"> </p>
	  </div>
	  </div>
			</div>
			<div id="sidebar">
			
		<h1>Search</h1><script>
	  (function() {
      var cx = '016619794450116726182:r0pm5z5tz6e';
      var gcse = document.createElement('script');
      gcse.type = 'text/javascript';
      gcse.async = true;
      gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
      '//www.google.com/cse/cse.js?cx=' + cx;
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(gcse, s);
     })();
     </script>
     <gcse:searchbox-only></gcse:searchbox-only>

	<br>
	
	 
		</div>
			</div>
		
		<div id="mainend"></div>
		
		</div>
	
		<div id="footer">
		
		<center>
		All contents copyright © The Margaret Sanger Papers. All rights reserved.
		</center>
			</div>
					
	</body>
</html>