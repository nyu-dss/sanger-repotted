﻿
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / The Project / Staff</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project" class="selected">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Staff</h1>			

<div class="maintext">
<h1>Cathy Moran Hajo, Associate Editor/Assistant Director</h1>

<p><img src="cathy_hajo.jpg" width="200" height="200" border="0" align="right" style="margin-left: 15px; margin-bottom: 15px;"></a>Dr. Cathy Hajo, of the <a href="http://janeaddams.ramapo.edu/">Jane Addams Papers</a> at Ramapo College, was with the Sanger Papers Project since 1989. She has a B.A. from Ramapo College of New Jersey, an M.A. and Ph.D. in History, and a certificate in Archival Management from New York University. She received training in historical editing at the NHPRC's Editing Institute. Among her interests are the digital publication of primary source material and the history of women and gender. </p>

<p>Her work at the Sanger Project included assisting in all phases of editing including selection, proofreading, research, indexing and preparing the manuscript for publication. She worked on  general administration of the Project, supervising students and interns, researching and writing grant applications and overseeing the Project's computer systems. </p>

<p>Cathy's first book, <em><a href="http://www.press.uillinois.edu/books/catalog/55qew6cg9780252035364.html">Birth Control on Main Street: Organizing Clinics in the United States, 1916-1939</a></em> was published by the University of Illinois Press in 2010.</p>

<p> Recent publications and addresses include: &quot;<a href="http://aphdigital.org/?page_id=1549&preview=true">The Sustainability of Scholarly Editions in a Digital World</a>,&quot; &quot;<a href="http://aphdigital.org/people/cathy-moran-hajo/scholarly-editing-in-a-web-2-0-world/">Scholarly Editing in a Web 2.0 World,</a>&quot; and &quot;<a href="http://www.nyu.edu/projects/sanger/images/Hajo.pdf">Last Words: Documenting the End of Lives</a>.&quot;  Cathy participated in the 2007 Nebraska Digital Workshop, presenting the Project's <em>Speeches and Articles of Margaret Sanger</em> digital collection. She served  on the Advisory Council for the third edition of  Mary Jo Kline's <em>A Guide to Documentary Editing</em>. Cathy  has served on the Faculty of the NHPRC's Institute for the Editing of Historical Documents from 2008-2011. She is a Past-President of the Association for Documentary Editing, and serves on its Website Committee, and on the ADE's advisory committee for the Institute for Editing Historical Documents. She is currently working on the topic of contextual annotation in a digital environment. </p>

<p>Cathy's first book, <em><a href="http://www.press.uillinois.edu/books/catalog/55qew6cg9780252035364.html">Birth Control on Main Street: Organizing Clinics in the United States, 1916-1939</a></em> was published by the University of Illinois Press in 2010.</p>

<p> Recent publications and addresses include: &quot;<a href="http://aphdigital.org/?page_id=1549&preview=true">The Sustainability of Scholarly Editions in a Digital World</a>,&quot; &quot;<a href="http://aphdigital.org/people/cathy-moran-hajo/scholarly-editing-in-a-web-2-0-world/">Scholarly Editing in a Web 2.0 World,</a>&quot; and &quot;<a href="http://www.nyu.edu/projects/sanger/images/Hajo.pdf">Last Words: Documenting the End of Lives</a>.&quot;  Cathy participated in the 2007 Nebraska Digital Workshop, presenting the Project's <em>Speeches and Articles of Margaret Sanger</em> digital collection. She served  on the Advisory Council for the third edition of  Mary Jo Kline's <em>A Guide to Documentary Editing</em>. Cathy  has served on the Faculty of the NHPRC's Institute for the Editing of Historical Documents from 2008-2011. She is a Past-President of the Association for Documentary Editing, and serves on its Website Committee, and on the ADE's advisory committee for the Institute for Editing Historical Documents. She is currently working on the topic of contextual annotation in a digital environment. </p>

<p> She has taught graduate courses on&quot;<a href="http://historynewmedia.wikidot.com/">History in the New Media</a>&quot; and &quot;<a href="http://creatingdigitalhistory.wikidot.com/">Creating Digital History</a>&quot; for NYU's Archives and Public History Program. She now teaches at Ramapo College.</p> 

<p>Contact Cathy Hajo by e-mail at <a href="mailto:chajo@ramapo.edu">chajo@ramapo.edu</a></p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>The Project</h1>
		<div id="subnav">
			<a href="../project/index.php">About</a><br>
			<b><a href="../project/staff.php">Staff</a></b><br>
			<a href="../project/internships.php">Internships</a><br>
			<a href="../project/support.php">Support</a><br>
			<a href="../project/funders.php">Funders</a><br>
			<a href="../project/reviews.php">Reviews</a><br>
			<a href="../project/editing.php">Editing at the MSPP</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
