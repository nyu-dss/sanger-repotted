
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / The Project / Support</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project" class="selected">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Support</h1>			

<div class="maintext">

<p>The Margaret Sanger Papers Project is supported by grants from <a href="funders.php"> public and private foundations</a> as well as individual donations.</p>

<p>The Margaret Sanger Papers Project receives little direct assistance from New York University, chiefly space, services and the salary of a research assistant. All other salaries, equipment, and research costs must be raised through grants and individual donations. Donations to the Margaret Sanger Papers to help support these activities are tax deductible.</p>

<p>While the Project has received the support of many foundations and federal agencies, our ability to complete our work and our survival depends on the generosity of our supporters as well as readers of the <a href="../newsletter/index.php"><em>Project's Newsletter</em>.</a> We will send complimentary copies of the <em>Newsletter</em> to all who donate at least $25.</p>

<h2>You may donate <a href="../donate/index.php">online</a> or send checks, made out to New York University, to:</h2>
<blockquote>
<p>The Margaret Sanger Papers Project<br />
New York University <br />
Division of Libraries<br />
838 Broadway, Suite 504<br />
New York, NY 10003-4812
</p>
</blockquote>

<p>If you are planning to purchase our books through on-line booksellers, use these links to donate a percentage of the purchase price to the Margaret Sanger Papers.  Use the link below to purchase anything else at Amazon.com and the project will receive a small donation. Just click on the cover you want to purchase:  </p>

<center>
<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=US&source=ac&ref=tf_til&ad_type=product_link&tracking_id=margsangpapep-20&marketplace=amazon&region=US&placement=0252074602&asins=0252074602&linkId=YJSN3KTOXIQTIMSK&show_border=true&link_opens_in_new_window=true">
</iframe>
<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=US&source=ac&ref=tf_til&ad_type=product_link&tracking_id=margsangpapep-20&marketplace=amazon&region=US&placement=0252031377&asins=0252031377&linkId=DV25Z7Z7R6H4ODIR&show_border=true&link_opens_in_new_window=true">
</iframe>
<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=US&source=ac&ref=tf_til&ad_type=product_link&tracking_id=margsangpapep-20&marketplace=amazon&region=US&placement=0252033728&asins=0252033728&linkId=SPGISKAZZ7QGYEH7&show_border=true&link_opens_in_new_window=true">
</iframe>

 <script type="text/javascript" language="javascript">   amzn_assoc_ad_type = "contextual";   amzn_assoc_tracking_id = "margsangpapep-20";   amzn_assoc_marketplace = "amazon";   amzn_assoc_region = "US";   amzn_assoc_placement = "FMZFJBTT3I6BE5AN";   amzn_assoc_linkid = "FMZFJBTT3I6BE5AN";
  amzn_assoc_emphasize_categories = "";
  amzn_assoc_fallback_products = "";
  amzn_assoc_width = "300";
  amzn_assoc_height = "250";
</script>
<script type="text/javascript" language="javascript" src="//z-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&Operation=GetScript&ID=OneJS&WS=1&MarketPlace=US&source=ac"></script>

</center>

<p>We thank you very much for your support. </p>

<hr>

<h1>How You Can Help</h1>
<p>Support for documentary editions can take many forms. If you find the work of the Margaret Sanger Papers Project useful, please take the time to let us know.</p>

<h2>Donations</h2>

<p>The Margaret Sanger Papers Project receives no direct assistance from New York University, only space and services. Salaries, equipment, and research costs must be raised through grants and individual donations. Donations to the Margaret Sanger Papers are tax deductible and checks should be made out to <strong>New York University.</strong></p>

<p>While the Project has received the support of many foundations and federal agencies, our ability to complete our work and our survival depends on the generosity of our supporters as well as readers of the Project's <em>Newsletter</em>. We will send complimentary copies of the <em>Newsletter</em> to all who donate at least $25.</p>

<p>Please send any contributions to:</p>       

<p> <blockquote>The Margaret Sanger Papers Project<br />
New York University<br />
Division of Libraries<br />
838 Broadway, Suite 504<br />
New York, NY 10003-4812  
</blockquote></p>

<h2>Lobby Your Library</h2>
<p>Lobby your local research library to purchase the project's publications, in order to make these documents more widely accessible.</p>
<p>A list of the libraries that already own the <em>Margaret Sanger Papers Microfilm Edition</em> is available on this web site (Smith /Collected Docs). For more information consult <a href="http://academic.lexisnexis.com/pdf/factsheets/2681_2679_margaretsangerpapers%5B2%5D.pdf" target="_new">Lexis-Nexis' fact sheet</a>.</p>

<p>Orders for the <em>Selected Papers of Margaret Sanger</em> can be made through the <a href="http://www.press.uillinois.edu/" target="_new">University of Illinois' web site</a> or through on-line booksellers such as Amazon.com.  If you purchase the books through the link below, the Project will receive a small percentage of the purchase price as a donation. </p>

<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=US&source=ac&ref=tf_til&ad_type=product_link&tracking_id=margsangpapep-20&marketplace=amazon&region=US&placement=0252074602&asins=0252074602&linkId=YJSN3KTOXIQTIMSK&show_border=true&link_opens_in_new_window=true">
</iframe>
<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=US&source=ac&ref=tf_til&ad_type=product_link&tracking_id=margsangpapep-20&marketplace=amazon&region=US&placement=0252031377&asins=0252031377&linkId=DV25Z7Z7R6H4ODIR&show_border=true&link_opens_in_new_window=true">
</iframe>
<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=US&source=ac&ref=tf_til&ad_type=product_link&tracking_id=margsangpapep-20&marketplace=amazon&region=US&placement=0252033728&asins=0252033728&linkId=SPGISKAZZ7QGYEH7&show_border=true&link_opens_in_new_window=true">
</iframe>

<h2>Support Documentary Editing</h2>
<p>Documentary editions, such as the Sanger Papers, are in trouble.  Funding for these multi-year projects has become harder to come by, as federal agencies such as the National Historical Publications and Records Commission (NHPRC) and National Endowment for the Humanities have faced budget cuts. Please support funding for these two agencies. For more information, or to get involved see the <a href="http://www.nhalliance.org/">National Humanities Alliance Website</a>.</p>

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>The Project</h1>
		<div id="subnav">
			<a href="../project/index.php">About</a><br>
			<a href="../project/staff.php">Staff</a><br>
			<a href="../project/internships.php">Internships</a><br>
			<b><a href="../project/support.php">Support</a></b><br>
			<a href="../project/funders.php">Funders</a><br>
			<a href="../project/reviews.php">Reviews</a><br>
			<a href="../project/editing.php">Editing at the MSPP</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
