
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / The Project / Reviews</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project" class="selected">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Reviews</h1>			

<div class="maintext">

<h2 style="margin-top: -10px"><a href="#vol1">Volume 1</a> | <a href="#Vol2">Volume 2</a> | <a href="#Vol3">Volume 3</a> | <a href="#Speeches">Speeches and Articles</a> </h2>

<p>If you know of any other reviews, please bring them to the <a href="mailto:<a href="mailto:sanger.papers@nyu.edu">">Project's attention.</a></p> 


<h3>The Selected Papers of Margaret Sanger, <a href="../publications/volume_iii.php">Volume 3</a>, The Politics of Planned Parenthood, 1939-1966. (2010) </h3>
<p>"This volume provides accurate, dramatic context to the often conflicting struggle to make birth control acceptable in American culture and to make it a global movement. Katz, Hajo, and Engelman have produced an edition that is useful to biographers, scholars, students, and the inquisitive policy maker. I give it my highest recommendation.&rdquo;--<strong>Allida M. Black, editor and director of The Eleanor Roosevelt Papers Project</strong></p>

<hr>

<p>Excerpts from anonymous reviews on the manuscript:

<p align="left"><h2>Review 1</h2>

<a href="http://www.press.uillinois.edu/"><img src="../images/Illinoislogo.jpg"></a><br>

With two volumes already in print, most certainly UIP&rsquo;s publication of the letters of this major contributor to 20th century American life must be continued. By telling the story of Sanger&rsquo;s struggles to make birth control a central and acceptable practice, the volumes document the controversies regarding this significant issue, one that extends well beyond U.S. borders and into the 21st century. The editors have produced a commendably balanced account, explaining the outcomes, both positive and negative, of MS&rsquo;s efforts. MS is not lionized. . . .Her quarrels with colleagues such as Juliet Rublee, Dorothy Brush, and institutions, chiefly the Roman Catholic Church, are fully documented. From MS&rsquo;s vivid, informal prose, we get a sense of how she conducted business. The general introduction and introductions to each chapter are concise and well-written, free from annoying jargon.&rdquo;</p>

<p>&ldquo;The editors have meticulously transcribed and annotated Sanger&rsquo;s correspondence. Their selection is appropriate, with careful references to the microfilm edition for readers who seek more background, or a fuller text of a letter that is only mentioned. Inclusion of the client letters gives us a sense of MS&rsquo;s reputation in her lifetime. Scholarship is impressive and thorough, with excellent use of primary sources, including local Tucson newspapers. A random check of secondary sources indicates that the editors provide accurate information.&rdquo;
</p>
<h2>Review 2</h2>
&ldquo;In many ways, it is the most compelling volume in the series. I make this strong endorsement for four reasons: 1) It provides accurate, dramatic context for the often conflicting struggle to make birth control acceptable to American society/culture while simultaneously struggling to make it a global movement. 2) It shows a side of Sanger most often ignored by biographers and birth control scholars -- especially how she struggled (and failed) to find balance as she aged and other leaders emerged to help her lead the movement. 3) It reveals (as the Mike Wallace interview documents) the &lsquo;public intelligensia&rsquo;s&rsquo; inability to differentiate between what they want to see/depict and the record. 4) It offers compelling evidence of the Cold War&rsquo;s impact on women, American ethnicity, and religious interpretation.&rdquo;</p>
<p>The volume is well-organized. Organizing the documents chronologically is not only logical, it is the only framework that traces Sanger&rsquo;s decisions, frustrations, and challenges. The brief chapter introductions set the contextual and personal stage for the documents that follow without being terse or assuming that all readers will be familiar with the organizations and issues referenced in the documents. I particularly applaud Katz&rsquo;s decision to use this space to share her insight into Sanger&rsquo;s temperament. . . While I would prefer a headnote for each document, I realize that this approach is unfeasible--unless you wanted to (and could afford to) increase the size of the manuscript accordingly. Thus, the headers that do appear take on added importance. Katz and her team appreciate this and use the space accordingly. . . . The annotation is concise without being superficial. The editors have combed the canon and the obscure to compile a thoroughly innovative bibliography of secondary literature. . . . they wisely opted to annotate for readers who may not have total historical recall or care about issues outside their specific area of concentration.</p>
<p>The selection is engaging, and while correspondence dominates, the narrative avoids the tedium most letters editions convey. It constructs a story that needs to be told in ways that encourage the reader to stay with the volume. Many editions fail at this. (And while I wish that more incoming correspondence could be included, the editorial team does a good job in excerpting key segments for use in introductory headnotes.)</p>
<p>The clarity and organization of this volume will entice a strong, varied readership. Students, from those engaging in National History Day projects to undergraduate and graduate research, will be able to navigate this volume without the intimidation that accompanies most scholarly editions. Scholars of women&rsquo;s history, cultural history, religious history, public policy and health will find this volume of enormous use. I hope that reviewers will draw attention to its importance to the general political and social histories of World War II and early Cold War as well.</p>
<hr />
<h2>The Selected Papers of Margaret Sanger, Volume II<a name="Vol2" id="Vol2"></a>, Birth Control Comes of Age, 1928-1939 </h2>
<p><img src="hnetreview.jpg" width="280" height="115" align="right" style="margin: 15px 0px 15px 15px;" />&quot;for teachers, volumes 1 and 2 (and eventually all four volumes) may provide valuable primary material to utilize in the classroom. Students have a chance to read Sanger's words firsthand without having to travel to examine her papers, which can be easily be integrated into a high school history lesson plan or college classroon activity.... As a scholar, I found that as I read through the letters, I was drawn in as much to Sanger as a wife, mother, and friend as I was to Sanger, the birth control advocate. In my opinion, we, as scholars, periodically forget that our subjects of analysis have a human side.&nbsp;We become so involved in what they said or did regarding a particular social and political issue that we overlook their everyday worries, such as their health or children; we forget that they argued with their spouses or reveled in a visit from a friend.&nbsp;. . . &nbsp;What does it say about Sanger who fought with her husband over issues of money and had several affairs?&nbsp;Does it detract from her accomplishments or does it provide a more complex side of a woman who instills both hatred and respect?&nbsp;Although not all the letters focused on Sanger&rsquo;s personal life, it is refreshing to note that Katz and her staff were not only interested in projecting a portrait of Sanger the advocate working tirelessly to carve out some authority within a movement she began, but also committed to giving the reader an image of Sanger as a woman, whose friends and family were just as important to her.&nbsp;She struggled to balance both roles and did not always do so successfully. It is this &ldquo;other&rdquo; side that gives the bulk of the letters substance and allows readers an opportunity to see that Sanger had human flaws and to also question if there is evidence indicating that those imperfections pushed her to achieve her accomplishments.&quot;&nbsp;Cheryl K. Lemus, &quot;<a href="http://www.h-net.org/reviews/showrev.php?id=24628">Sorting Truth from Myth: The Letters of Margaret Sanger, 1928-1939</a>,&quot; <em>H-Review, Sept. 2009. </em></p>
<p><img src="DocEditing30.jpg" width="101" height="147" align="right" style="margin: 15px 0px 15px 15px;"/>&quot;Birth Control Comes of Age continues the important story begun by Volume I of this series. It brings to print for the first time documents that are valuable for the tales they tell about activism and advocacy, as well as about the life and work of MS. In this day of quick, do-it-yourself publishing, it's reassuring that scholars such as Katz and her editorial team continue to pay close attention to detail and historical context in order to present a factual and objective collection of primary sources. And luckily for us, as the book's acknowledgements state, 'it's not over yet!'&quot; Jimmy Wilkinson Meyer, &quot;A Place in the Sun,&quot; <em>Documentary Editing</em> 30 (1 &amp; 2) 2008, 88-93. </p>
<p>&nbsp;</p>
<p>&quot;No biographical method delves more accurately into the thinking of an individual than the use of personal letters. In this excellent volume, there are no second-hand accounts, but simply Margaret Sanger writing to her friends, family, associates and political leaders. The correspondence tells the story of he vital role in bringing about the birth control <img src="padr.jpg" align="right" width="293" height="47" style="margin: 15px 0px 15px 15px;"/>movement from 1928-1939....For a greater understanding of how far we have come in a relatively short span of years, this volume is essential reading for anyone involved with women's reproductive health or reproductive rights as a human right. It also contributes substantially to the literature documenting the social change of the twentieth century advancing the right of the individual in decisions concerning human fertility.&quot; S.J.S. <em>Population and Development Review</em> Sept. 2007 33:3, 638-39.  </p>
<p align="left"><img src="nationlogo.gif" align="right" width="289" height="60" style="margin: 15px 0px 15px 15px;"/>&quot;Against this polarized backdrop, <em>The Selected 
Papers of Margaret Sanger</em> is a   refreshing antidote. (The first volume, <em>The Woman Rebel, 1900-1928</em>, was released in 2003; the second, <em>Birth Control Comes of Age, 1928-1939</em> has just 
been published. Two more volumes are planned, to cover the last third of 
Sanger's life and her international work.) The editors have burrowed through 
an archive of more than 120,000 documents to select speeches, diary entries 
and, mostly, letters. The papers they've chosen reflect the commendable as 
well as the unsavory in Sanger's political views and personal life. This 
fidelity extends to scrupulously transcribed misspellings and heroically 
comprehensive footnotes. Altogether, the two completed volumes offer a 
singular record of her life and times.&quot; Rebecca Tuhus-Dubrow, &quot;Sanger vs. Sanger,&quot; <em>The Nation </em>(July 30, 2007). </p>
<p>&quot;In uncovering these historical gems, <em>Volume 2</em>, makes an unmatched contribution to the study of reproductive rights, genetic inheritance, and women's rights, and reminds us of the importance of vigilance in protecting what Sanger won.&quot; <strong>Ann D. Gordon, editor of <em>The Selected Papers of Elizabeth Cady Stanton and Susan B. Anthony</em>.</strong></p>
<p>&quot;Sanger comes across to readers as a human being with many dimensions, rather than merely a larger-than-life figurehead for a cause. Her foibles and eccentricities appear in the documents, along with her commanding presence as the key public leader in the effort to bring the possibility of birth control to a wide range of women who have begun to demand it. Sanger's world, with its flurry of Congressional appearances, overseas conferences, consultations with staff and medical advisors of the various organizations with which she was affiliated, comes to life through the documents chosen for inclusion in this volume.&quot; <strong>Carolyn DeSwarte Gifford, editor of <em>Writing Out My Heart: Selections from the Journal of Frances E. Willard, 1855-96 </em></strong></p>
<h3>&nbsp;</h3><hr />

<h2>The Selected Papers of Margaret Sanger, Volume I<a name="vol1" id="vol1"></a>, The Woman Rebel, 1900-1928 </h2>
<p><img src="docedit.jpg" width="119" height="174" align="right" style="margin: 15px 0px 15px 15px;"/>&quot;Anyone who's not yet familiar with this evocative woman and her activism can get better acquainted by perusing <em>The Selected Papers of Margaret Sanger, Volume I: The Woman Rebel, 1900-1928</em>. Likewise, anyone who thinks that they already know MS will discover more about her complicated life and advocacy in this award-winning work. And the journey will be delightful...For over half a century, Margaret Sanger tried to pull sexuality and birth control 'out of the gutter of obscenity and into the light of human understanding.' The history of her work, presented in this well-crafted volume and presumably in the others in the series . . . should enlighten modern woman. We need to hear the tale of Sanger's hard fought battle to fully comprehend the dangerous health care precipice on which women stand today. Hopefully Sanger's work will inspire us to confront and change policy, so that her efforts will not have been in vain.&quot; --<strong>Jimmy Meyer</strong>, &quot;&quot;From the Gutter of Obscenity,&quot; <em>Documentary Editing</em> 28:4 (Winter 2006), 184-94.</p>
<p><img src="nationlogo.gif" width="289" height="60" align="right" style="margin: 15px 0px 15px 15px;"/>&quot;Against this polarized backdrop, The Selected Papers of Margaret Sanger is a refreshing antidote. (The first volume, <em>The Woman Rebel, 1900-1928</em>, was released in 2003; the second, <em>Birth Control Comes of Age, 1928-1939</em> has just been published. Two more volumes are planned, to cover the last third of Sanger's life and her international work.) The editors have burrowed through an archive of more than 120,000 documents to select speeches, diary entries and, mostly, letters. The papers they've chosen reflect the commendable as well as the unsavory in Sanger's political views and personal life. This fidelity extends to scrupulously transcribed misspellings and heroically comprehensive footnotes. Altogether, the two completed volumes offer a singular record of her life and times.&quot; <strong>Rebecca Tuhus-Dubrow, </strong>&quot;Sanger vs. Sanger,&quot; The Nation (July 30, 2007).</p>
<hr noshade="noshade" size="1" /></p>

<p><img src="armlogo.gif" width="150" height="150" align="right" style="margin: 15px 0px 15px 15px;">&quot;The book allows insights into Sanger's motivations and actions, and traces the course of her relationships with family members, and with colleagues who were friends, such as Emma Goldman, or lovers, such as Havelock Ellis.  . . .Faced with an archive of over 120,000 documents--letters, speeches, journals, and legal and organizational records--Esther Katz and her editorial team have chosen selections that document the critical events and central issues of Sanger's life. . . . Ultimately the work of Katz and her team is critical for a fuller understanding of first-wave feminism, family planning and one of the century's most interesting women, and I look forward to the next three volumes.&quot; -- <strong>Roxanne Harde</strong>, <em>Journal of the Association for Research on Mothering, 6:1 (Spring/Summer 2004), pp. 205-206. </em></p>
<p><hr noshade="noshade" size="1" /></p>

<p><img src="iasrbar.gif" align="right" width="400" height="60" style="margin: 15px 0px 15px 15px;">
"This volume. . . marks the first publication of what is a major project which should be in libraries everywhere. It is scholarship at its highest level and when complete will be a standard work of reference for anyone interested in the development of birth control or the history of sex education not only in the United States but also in the rest of the world.  It will also record the life of one of the most influential women of the twentieth century.&quot; -- <strong>Vern L. Bullough, <u>Archives of Sexual Behavior</u>, Vol. 33, No. 6, December 2004, pp. 611-612. </strong></p>

<p><hr noshade="noshade" size="1" /></p>

<p><img border="0" src="bhmcoversmall.gif" align="right" width="117" height="177" style="margin: 15px 0px 15px 15px;"></p>
<p>&quot;The publication of the first volume of Sanger's selected papers is most welcome, in part because it provides a kind of reality check on the vast and proliferating nonsense about her that has been generated by zealots in our contemporary culture wars . . . .The meticulously edited first volume of her <span class="italicText">Selected Papers</span> provides ready access to a complicated and compelling career. If you want to know the real woman who led the successful fight to remove the stigma of obscenity from contraception, this is an excellent place to
begin.&quot; -- <span class="italicText"><span class="boldText">James W. Reed</span>, </span><u>Bulletin of the History of Medicine</u>, Spring 2004,
238-39.</p>

<p><hr noshade="noshade" size="1" /></p>

<p><img src="socialservicereview.gif" width="158" height="239" align="right" style="margin: 15px 0px 15px 15px;"/>Volume I, <span class="italicText">The Woman Rebel, 1900-1928</span>, draws
primarily on Sanger's correspondence, supplemented by excerpts from her
speeches, published articles, and journal entries, to trace the first 3 decades
of her career. These documents are organized chronologically into chapters
that reflect various phases of her life. Each section begins with an
introduction that provides historical context and biographical detail.
Every document is scrupulously annotated to identify unfamiliar people, places,
events and terminology. In addition, researchers can use these endnotes to
identify relevant archival materials that are not included in the volume.
Given the extraordinary editorial work of Katz and her assistants, it is not too
much to claim, as the publisher does, that the <span class="italicText">Woman Rebel</span> can be read as
a biography.&quot; --<span class="italicText"><span class="boldText">Kimberly Reilly</span></span>, <u>Social Service Review</u>,
Sep 2003, 487-88.</p>

<p><hr noshade="noshade" size="1" /></p>

<p><strong>In January 2004, Volume I was selected as one of <span class="italicText">Choice's</span> &quot;Outstanding Academic Titles&quot; </strong></p>
<p><img border="1" src="choice.gif" align="right" width="227" height="76" style="margin: 15px 0px 15px 15px;"></p>
<p>&quot;The first in a four-book series, this compilation of letters Sanger wrote and received, speeches she gave, and other materials is more than a history of Sanger's efforts to promote birth control. The 250
documents detail Sanger's relationships in and outside marriage, her
affiliations with many early 20th-century notables--Max Eastman, Emma Goldman,
Havelock Ellis, H. G. Wells, and Carrie Chapman Catt, among others--and issues
ranging from labor strikes to eugenics. The documents are remarkable for
their content and sheer volume....Although two autobiographies and several
biographies of her life exist, this collection is a welcome addition to Sanger
scholarship. It allows readers to explore all aspects of her complex life
and ideas. Readers might find her admirable and inspiring, then turn the
page and find her maddening, arrogant, or irresponsible. Introductions to
each section add context; readers can provide their own interpretation.
The collection offers a wonderful window into Sanger and the early 20th-century
US. Summing up: Highly Recommended. All levels and libraries.&quot; -- <span class="italicText"><span class="boldText">C. A. Kanes</span></span>, <u>Choice: Current Reviews for Academic Libraries</u>, Sept. 2003.</p>

<p><hr noshade="noshade" size="1" /></p>

<p><span class="italicText"><img border="0" src="jama.gif" align="right" width="215" height="78" style="margin: 15px 0px 15px 15px;">Volume 1: The Woman Rebel, 1900-1928</span> documents the
formative years of one of America's most controversial and influential
feminists. It details Margaret Higgins Sanger's difficult journey from
working-class radical in pre-World War I bohemian Greenwich Village to
upper-class celebrity who achieved mainstream respectability as she forged
alliances with the medical profession in an ongoing crusade to ensure the right of every woman to determine whether and when to have children....The editorial team, headed by Esther Katz, the editor of the Margaret Sanger Papers
Microfilm Edition, has assembled letters, diary excerpts, and essays, most of
which have never been published, that offer significant insights into Sanger's
struggles and accomplishments. Informative chapter introductions, along with
meticulous annotations, allow readers to gain new insights into Sanger's crusade for birth control...&quot; <span class="italicText"><span class="boldText">Judy Barrett-Litoff</span>, <u>JAMA</u>,
July 16, 2003, 408-9.</span></p>

<p><hr noshade="noshade" size="1" /></p>

<p><img border="0" src="weekstan.jpeg" align="right" width="254" height="80" style="margin: 15px 0px 15px 15px;">&quot;Somewhere, amidst the sucker punches and cries of foul, the truth must reside. And "somewhere," it turns out, is the enormous and altogether dazzling selection of public and private records just put out by the manuscript curators at New York University's "Margaret Sanger Papers Project." They too, like the earlier biographers, unambiguously admire the woman. But they have done their editing with scrupulous care, they have annotated the documents they reproduce with monk-like dispassion, and on the face of it they have held nothing back. "The Woman Rebel, 1900-1928" is the first in a projected four-volume series. For relevance to still unsettled political arguments, though, this volume, covering all the crucial years of Sanger's career, is clearly the one that matters.&quot; -- <span class="italicText"><span class="boldText">David Tell, </span>&quot;</span>
<span class="italicText"><a href="http://www.weeklystandard.com/content/public/articles/000/000/002/139rdqpe.asp">Planned Un-Parenthood:
Roe v. Wade at thirty</a>.&quot; <u>The Weekly Standard</u>, January 27,
2003, Volume 008, Issue 19.</span></p>

<p><hr noshade="noshade" size="1" /></p>

<p>"Mesmerizing letters from the days
when birth control was legally obscene and jail sentences were regularly given
out for talking about it in public. Nearly a century ago, Margaret Sanger
was defending woman's 'ownership of her own body' and linking access to
contraception to civil liberties and personal freedom. Rights we take for
granted have a long and sometimes surprising history that comes clear on
these pages. Required reading for our own time, whichever side of Roe v. Wade you are on."

-- <span class="italicText"><span class="boldText">Linda K. Kerber</span>, author of <u> No Constitutional Right to Be Ladies: Women and the Obligations of Citizenship</u></span></p>

<p><hr noshade="noshade" size="1" /></p>

<p>"These wonderful letters, diary excerpts, and essays dramatize women's long struggle for respect, self-awareness, independence, influence, and control over our bodies and our lives. To contemplate Margaret Sanger's harsh reality and the enduring vision of this courageous pioneer-- while the war against women escalates on every front-- is a heartening and galvanizing act of rebellion. Esther Katz and her splendid team have given us all a very great gift."
<span class="italicText">-- <span class="boldText"> Blanche Wiesen Cook</span>, University                                                          Distinguished Professor, John Jay                                                          College and the Graduate Center,
CUNY, and the author of <u> Eleanor Roosevelt,</u> volumes 1 and 2</span></p>

<p><hr noshade="noshade" size="1" /></p>

<p>"This engrossing volume, meticulously edited and selected, captures Margaret Sanger in all her complexity during a formative period in her long career. Open to practically any page, and something will grab your historical
attention." 
<span class="italicText">-- <span class="boldText">Susan Ware</span>, editor of <u> Notable American
Women</u>, volume 5</span></p>

<p><hr noshade="noshade" size="1" />
</p>
<iframe marginwidth="0" marginheight="0" width="120" height="240" scrolling="no" frameborder="0" src="http://rcm-na.amazon-adsystem.com/e/cm?o=1&amp;l=as1&amp;f=ifr&amp;t=margaresangerpap&amp;dev-t=D68HUNXKLHS4J&amp;p=8&amp;asins=025202737X&amp;IS2=1&amp;lt1=_blank"><MAP NAME="boxmap-p8">
<AREA SHAPE="RECT" COORDS="14, 200, 103, 207" HREF="http://rcm.amazon.com/e/cm/privacy-policy.html?o=1" >
<AREA COORDS="0,0,10000,10000" HREF="http://www.amazon.com/exec/obidos/redirect-home/margaresangerpap" >
</map>
</iframe>    
<A HREF="http://www.amazon.com/exec/obidos/redirect-home/margaresangerpap">
</a>
<A HREF="http://www.amazon.com/exec/obidos/redirect-home/margaresangerpap">  </A>

<iframe src="http://rcm-na.amazon-adsystem.com/e/cm?t=margaresangerpap&o=1&p=8&l=as1&asins=0252031377&fc1=000000&IS2=1&lt1=_blank&lc1=0000FF&bc1=000000&bg1=FFFFFF&f=ifr" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>
<iframe src="http://rcm-na.amazon-adsystem.com/e/cm?t=margaresangerpap&o=1&p=8&l=as1&asins=0252074602&fc1=000000&IS2=1&lt1=_blank&lc1=0000FF&bc1=000000&bg1=FFFFFF&f=ifr" style="width:120px;height:240px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe><!-- END CONTENT -->

<br />

<h2>Speeches and Articles of Margaret Sanger, 1911-1959</h2> 

<p><img border="0" src="DocCompass-logo.png" align="right" width="154">Documents Compass <a href="http://documentscompass.org/digital_editions/margaret-sanger-papers/"><a name="Speeches" id="Speeches">Review</a>, 2011 (of beta version)</p> 

</div>

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>The Project</h1>
		<div id="subnav">
			<a href="../project/index.php">About</a><br>
			<a href="../project/staff.php">Staff</a><br>
			<a href="../project/internships.php">Internships</a><br>
			<a href="../project/support.php">Support</a><br>
			<a href="../project/funders.php">Funders</a><br>
			<b><a href="../project/reviews.php">Reviews</a></b><br>
			<a href="../project/editing.php">Editing at the MSPP</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
