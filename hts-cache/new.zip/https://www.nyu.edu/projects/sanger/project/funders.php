
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / The Project / Funders</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project" class="selected">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Funders</h1>			

<div class="maintext">

<h3>We would like to acknowledge and thank our major funders:</h3>

<ul class="spaced">
<li><a href="http://acls.org/">American Council of Learned Societies</a>
<li><a href="http://www.marydukebiddlefoundation.org/">Mary Duke Biddle Foundation</a></li>
<li><a href="http://fdncenter.org/grantmaker/bingham/">William Bingham Foundation</a></li>
<li><a href="http://foundationcenter.org/grantmaker/brush/">The Brush Foundation</a></li>
<li>The Clayton Foundation</li>
<li><a href="http://www.colcomfdn.org/">Colcom Foundation</a></li>
<li><a href="http://www.cmwf.org/">Commonwealth Fund</a></li>
<li>Dickler Family Foundation</li>
<li>Lucius and Eva Eastman Foundation</li>
<li><a href="http://www.fordfound.org/">Ford Foundation</a></li>
<li><a href="http://www.furthermore.org/">Furthermore: a program of the J. M. Kaplan Foundation</a></li>
<li><a href="http://www.gundfdn.org/">George Gund Foundation</a></li>
<li><a href="http://www.hewlett.org/">William and Flora Hewlett Foundation</a></li>
<li>Joyce and Seward Johnson Foundation</li>
<li><a href="http://www.laskerfoundation.org">Albert and Mary Lasker Foundation</a></li>
<li>Joe &amp; Emily Lowe Foundation</li>
<li><a href="http://www.hluce.org/">Henry Luce Foundation</a></li>
<li><a href="http://www.mellon.org/">Andrew Mellon Foundation</a></li>
<li><a href="http://mep.cla.sc.edu/">Model Editions Partnership</a></li>
<li><a href="http://www.neh.gov/">National Endowment for the Humanities</a></li>
<li><a href="http://www.archives.gov/nhprc">National Historical Publications and Records Commission</a></li>
<li><a href="http://www.humanitiesinitiative.org/index.php/dhannouncements/114-digcomms-cfp">NYU Digital Commons</a></li>
<li><a href="http://www.nyu.edu/osp/funding/urcf.php">NYU Research Challenge Fund</a></li>
<li><a href="http://www.rockfound.org/">Rockefeller Foundation</a></li>
<li>Blanchette Hooker Rockefeller Fund</li>
<li><a  href="http://www.samuelrubinfoundation.org/">Samuel Rubin Foundation</a></li>
<li><a  href="http://www.skaggs.org/">L.J. and Mary C. Skaggs Foundation </a></li>
<li>The Sulzberger Foundation</li>
<li><a  href="http://www.hwwilson.com/">H.W. Wilson Foundation</a></li>
<li><a href="http://www.nathancummings.org/">Nathan Cummings Foundation</a></li>
<li>Anonymous</li>
</ul>

</div>
		<!---RIGHT HAND NAVIGATION--->

	<div id="sidebar">
		<h1>Search</h1>

	<script>
  	(function() {
    var cx = '016619794450116726182:r0pm5z5tz6e';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  	})();
	</script>
	<gcse:searchbox-only></gcse:searchbox-only>

	<br><br>
	
		
		<h1>The Project</h1>
		<div id="subnav">
		
		<!---LINKS (bold current section)--->
			<a href="index.php">About</a><br>
		  <b><a href="staff.php">Staff</a></b><br>
			<a href="former_interns.php">Former Interns</a><br>
		    <a href="funders.php">Funders</a><br>
		    <a href="reviews.php">Reviews</a><br>
		    <a href="editing.php">Editing at the MSPP</a></p>
		     
		 <br>   
		 <!---END LINKKS--->
</div>

<div id="footer">		
		<center>
		All contents copyright � The Margaret Sanger Papers. All rights reserved.
		</center>
</div>
					

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>The Project</h1>
		<div id="subnav">
			<a href="../project/index.php">About</a><br>
			<a href="../project/staff.php">Staff</a><br>
			<a href="../project/internships.php">Internships</a><br>
			<a href="../project/support.php">Support</a><br>
			<b><a href="../project/funders.php">Funders</a></b><br>
			<a href="../project/reviews.php">Reviews</a><br>
			<a href="../project/editing.php">Editing at the MSPP</a><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
