
<html lang="en">

<head>

  <meta charset="utf-8">
  
  <title>MSPP / The Project / Editing</title>
  
  <meta name="viewport" content="width=device-width,initial-scale=1">
  
  <link href='//fonts.googleapis.com/css?family=PT+Sans|Lato' rel='stylesheet' type='text/css'>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//www.nyu.edu/projects/sanger/style.css">
  
</head>

<body>

  <center>
  <div id="top">
  <center>
  <div style="width: 1000px;">
  <a href="//www.nyu.edu"><img src="//www.nyu.edu/projects/sanger/images/nyulogo.png" title="New York University" style="float: left;"></a> 
  
  <div style="float: right;">
    <a href="https://www.facebook.com/pages/Friends-of-the-Margaret-Sanger-Papers/53274104181" title="Facebook"><img src="//www.nyu.edu/projects/sanger/images/facebook.png"></a>
    <a href="https://twitter.com/sangerpapers" title="Twitter"><img src="//www.nyu.edu/projects/sanger/images/twitter.png"></a>
    </div>
    </div>
    </div>
    
    <div id="wrap">
        <div id="header">
        <div align="left">
            <a href="//www.nyu.edu/projects/sanger/index.php"><img src="//www.nyu.edu/projects/sanger/images/logo.png"></a> 
    
    <ul id="nav">
    
    	<li>
	<a href="../aboutms/index.php" title="About Sanger">About Sanger</a>
		<ul>
		<li><a href="../aboutms/index.php">Biographical Sketch</a></li>
		<li><a href="../aboutms/bc_organizations.php">Birth Control Organizations</a></li>
		<li><a href="../aboutms/sanger_archive.php">The Sanger Archive</a></li>
		<li><a href="../aboutms/ms_writings.php">Sanger's Writing</a></li>
		</ul>
	</li>

	<li>
	<a href="../project/index.php" title="The Project" class="selected">The Project</a>
		<ul>
		<li><a href="../project/index.php">About</a></li>
		<li><a href="../project/staff.php">Staff</a></li>
		<li><a href="../project/internships.php">Internships</a></li>
		<li><a href="../project/support.php">Support</a></li>
		<li><a href="../project/funders.php">Funders</a></li>
		<li><a href="../project/reviews.php">Reviews</a></li>
		<li><a href="../project/editing.php">Editing at the MSPP</a></li>
		</ul>
	</li>

	<li>
	<a href="../publications/index.php" title="Publications">Publications</a>
		<ul>
		<li><a href="../publications/index.php">About</a></li>
		<li><a href="../publications/book.php">The Selected Papers of Margaret Sanger</a></li>
		<li><a href="../publications/microfilm.php">The Microfilm Edition</a></li>
		</ul>
	</li>

	<li>
	<a href="../newsletter/index.php" title="Newsletter">Newsletter</a>
		<ul>
		<li><a href="../newsletter/index.php">About</a></li>
		<li><a href="../newsletter/articlelist.php">Article List</a></li>
		</ul>
	</li>

	<li>
	<a href="../documents/index.php" title="Documents Online">Documents Online</a>
		<ul>
		<li><a href="../documents/index.php">About</a></li>
		<li><a href="../documents/selected.php">Selected Writings</a></li>
		<li><a href="../documents/electroniced.php">Electronic Edition - Beta</a></li>
		<li><a href="../documents/mswomanrebel.php">Margaret Sanger and the Woman Rebel</a></li>
		<li><a href="../documents/othersites.php">Documents on Other Sites</a></li>
		</ul>
	</li>

	<li>
	<a href="../research/index.php" title="Resources">Resources</a>
		<ul>
		<li><a href="../research/index.php">Research Requests</a></li>
		<li><a href="../research/nhday.php">National History Day</a></li>
		<li><a href="../research/bibliography.php">Sanger Bibliography</a></li>
		<li><a href="../research/images.php">Sanger Images</a></li>
		<li><a href="../research/links.php">Links</a></li>
		</ul>
	</li>

	<li>
	<a href="../contactus/index.php" title="Contact Us">Contact Us</a>
	</li>

    
    </ul>
    
        </div>
        </div>
        <div id="main">
        
    <img src="./mainimage.png">
    
    <br><br>
    
    <h1>Editing</h1>			

<div class="maintext">

<p>Creating scholarly editions of  historical documents requires training and rigorous attention to details. The editors at the Sanger Papers project have trained and taught at New York University's History Department <a href="http://history.fas.nyu.edu/object/history.gradprog.archivespublichistory" target="_new" >Program in Archives and Public History</a>, attended the National Historical Publications and Records Commission's <a href="http://www.archives.gov/nhprc/partners/editing-institute.html" target="_new" >Institute for Editing Historical Documents</a>, and are active participants in the <a href="http://www.documentaryediting.org/"  target="_new">Association for Documentary Editing</a>.</p>

<p>See our editorial policy for <a href="../publications/editorial_methods.php">print volumes</a>.</p>

<p>Read Associate Editor Cathy Moran Hajo's article, &quot;<a href="http://www.nyu.edu/projects/sanger/images/Hajo.pdf">Last Words: Documenting the End of Lives</a>,&quot; (PDF) in the Fall 2006 issue of <em>Documentary Editing</em> on questions of selection that editors need to address at the end of their volumes. </p>

<p>Interested in how we first created our digital editions <em>Speeches and Articles</em>? Read Matthew Zimmerman's 2003 article, &quot;<a href="http://www.nyu.edu/content/dam/nyu/its/documents/connectMagazine/archives/2003/2003fall.pdf">Publishing XML Files on the Web</a>.&quot; from <em>Connect </em> magazine. </p>

<p>Read Esther Katz and Cathy Moran Hajo's 1998 article &quot;<a href="../project/Katz-MSPPElectronic.pdf">The Margaret Sanger Papers Project: Documentary Edition in the Digital Age</a>,&quot; in <em>Connect</em> magazine. </p>

<p>Listen to Editor Esther Katz interviewed on NPR's Here and Now, August 17, 2015, on "<a target="_new" href="http://hereandnow.wbur.org/2015/08/17/margaret-sanger-ben-carson/">Was Margaret Sanger Out to 'Control' the Black Population?</a>"
<p>Listen to Editor Esther Katz speak at <a href="http://www.loc.gov/locvideo/womenact/"  target="_new">Women's Activism and Social Change: Documenting the Lives of Margaret Sanger and Jane Addams</a> BOOKS &amp; BEYOND, March 24, 2003 at the Library of Congress' Center for the Book (with Jane Addams Papers Editor, Mary Lynn McCree Bryan). </p>

<p>We will be adding more material to this site on how the project edits its documents. </p>

</div>
  

        </div>
        <div id="sidebar">

        
            <h1>Search</h1><script>
            (function() {
            var cx = '016619794450116726182:r0pm5z5tz6e';
            var gcse = document.createElement('script');
            gcse.type = 'text/javascript';
            gcse.async = true;
            gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
            '//www.google.com/cse/cse.js?cx=' + cx;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(gcse, s);
            })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>

            <br><br>
		
            
            	<h1>The Project</h1>
		<div id="subnav">
			<a href="../project/index.php">About</a><br>
			<a href="../project/staff.php">Staff</a><br>
			<a href="../project/internships.php">Internships</a><br>
			<a href="../project/support.php">Support</a><br>
			<a href="../project/funders.php">Funders</a><br>
			<a href="../project/reviews.php">Reviews</a><br>
			<b><a href="../project/editing.php">Editing at the MSPP</a></b><br>
		</div>
            
        </div>

        <div id="mainend"></div>
        
        </div>
    
    
    <div id="footer">
        <center>
        All contents copyright &copy; The Margaret Sanger Papers. All rights reserved.
        </center>
    </div>
        
        
    </body>
</html>
  